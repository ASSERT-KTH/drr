import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundCeiling((long) (short) 0);
        boolean boolean13 = delegatedDateTimeField9.isLeap(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField9, (int) (byte) 100);
        try {
            long long18 = skipUndoDateTimeField15.set(0L, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [2,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(31, (-88885920), (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-88885889) + "'", int3 == (-88885889));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean8 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property9 = localDate7.weekOfWeekyear();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime21.withPeriodAdded(readablePeriod25, (-1));
        try {
            java.lang.String str29 = dateTime27.toString("CopticChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        java.util.Locale locale16 = null;
        int int17 = property12.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.clockhourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField19, (int) (short) 10, 8, 52);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        boolean boolean4 = instant3.isEqualNow();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateMidnight dateMidnight18 = localDate16.toDateMidnight(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        int[] intArray22 = localDate21.getValues();
        boolean boolean23 = dateMidnight18.equals((java.lang.Object) localDate21);
        int int24 = localDate21.getWeekOfWeekyear();
        int int25 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        java.lang.String str27 = offsetDateTimeField12.getAsShortText((long) (short) 1);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField12.getAsText(6280, locale29);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 41 + "'", int25 == 41);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "41" + "'", str27.equals("41"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "6280" + "'", str30.equals("6280"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone5);
        java.lang.String str7 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        long long25 = dateTimeZone18.convertLocalToUTC((long) 8, false, (long) 0);
        org.joda.time.Chronology chronology26 = buddhistChronology0.withZone(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str7.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-3839992L) + "'", long25 == (-3839992L));
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "19691231T000000.002+0104");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        long long14 = delegatedDateTimeField7.remainder((long) 10);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray17 = null;
        java.util.Locale locale19 = null;
        try {
            int[] intArray20 = delegatedDateTimeField7.set(readablePartial15, (int) (short) 10, intArray17, "", locale19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 57600010L + "'", long14 == 57600010L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime21.withPeriodAdded(readablePeriod25, (-1));
        org.joda.time.DateTime dateTime29 = dateTime27.withMillis(2440592L);
        boolean boolean31 = dateTime27.equals((java.lang.Object) "16:00:00.041");
        org.joda.time.DateTime.Property property32 = dateTime27.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology39);
        int int41 = localDate40.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology44);
        int int46 = localDate45.getYearOfEra();
        int int47 = localDate40.compareTo((org.joda.time.ReadablePartial) localDate45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone49);
        org.joda.time.LocalDate localDate52 = localDate50.minusYears((int) 'a');
        boolean boolean53 = localDate40.isAfter((org.joda.time.ReadablePartial) localDate50);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate40.minus(readablePeriod54);
        org.joda.time.LocalTime localTime56 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology59);
        int int61 = localDate60.getYearOfEra();
        int int62 = localDate60.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int64 = julianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology63.getZone();
        org.joda.time.Interval interval66 = localDate60.toInterval(dateTimeZone65);
        org.joda.time.DateTime dateTime67 = localDate40.toDateTime(localTime56, dateTimeZone65);
        org.joda.time.LocalTime localTime68 = null;
        org.joda.time.DateTime dateTime69 = localDate40.toDateTime(localTime68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localTime68, (int) ' ', locale71);
        int int74 = skipUndoDateTimeField12.get((long) 69);
        long long77 = skipUndoDateTimeField12.set((-3839992L), (int) (byte) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1970 + "'", int62 == 1970);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(interval66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "32" + "'", str72.equals("32"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 69 + "'", int74 == 69);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-3839900L) + "'", long77 == (-3839900L));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.String str2 = dateTimeFormatter0.print(28800000L);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone5);
        org.joda.time.LocalDate localDate8 = localDate6.minusYears((int) 'a');
        int int9 = localDate6.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology12);
        int int14 = localDate13.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology17);
        int int19 = localDate18.getYearOfEra();
        int int20 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone22);
        org.joda.time.LocalDate localDate25 = localDate23.minusYears((int) 'a');
        boolean boolean26 = localDate13.isAfter((org.joda.time.ReadablePartial) localDate23);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate13.minus(readablePeriod27);
        org.joda.time.LocalTime localTime29 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology32);
        int int34 = localDate33.getYearOfEra();
        int int35 = localDate33.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int37 = julianChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology36.getZone();
        org.joda.time.Interval interval39 = localDate33.toInterval(dateTimeZone38);
        org.joda.time.DateTime dateTime40 = localDate13.toDateTime(localTime29, dateTimeZone38);
        boolean boolean41 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.LocalDate localDate44 = localDate13.withPeriodAdded(readablePeriod42, 1);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = localDate44.toDateTimeAtMidnight(dateTimeZone45);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00.000-08:00" + "'", str2.equals("00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(interval39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(dateTime46);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
        org.joda.time.LocalDate localDate12 = property10.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", "ISOChronology[America/Los_Angeles]");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException(0L, "16:00:00.041");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.LocalDate localDate26 = dateTime22.toLocalDate();
        int int27 = dateTime22.getMillisOfSecond();
        int int28 = dateTime22.getDayOfWeek();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundCeiling((long) (short) 0);
        boolean boolean13 = delegatedDateTimeField9.isLeap(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField9, (int) (byte) 100);
        int int17 = skipUndoDateTimeField15.get((long) 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 32 + "'", int17 == 32);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfYear]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfYear]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        java.lang.Class<?> wildcardClass13 = dateTime12.getClass();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTimeField3, (org.joda.time.Chronology) gregorianChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(52, 9700, 366, (int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        try {
            long long10 = gJChronology2.getDateTimeMillis(1852, (int) (byte) 0, 999, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendFractionOfDay(14, 999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) property5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property12.setCopy("0");
        org.joda.time.DurationField durationField17 = property12.getDurationField();
        long long20 = durationField17.subtract((-57600000L), (-1));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3155702400000L + "'", long20 == 3155702400000L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate5.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) property7, chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone10);
        java.lang.String str13 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str13.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 2, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.weekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology10.getZone();
        org.joda.time.DateMidnight dateMidnight18 = localDate2.toDateMidnight(dateTimeZone17);
        org.joda.time.LocalDate localDate20 = localDate2.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        int int25 = localDate24.getYearOfEra();
        int int26 = localDate24.getWeekyear();
        org.joda.time.LocalDate localDate28 = localDate24.minusWeeks(0);
        org.joda.time.LocalDate localDate30 = localDate28.minusMonths(1969);
        org.joda.time.Partial partial31 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate28);
        boolean boolean32 = localDate20.isBefore((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate localDate34 = localDate20.withCenturyOfEra(100);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        int int36 = localDate20.indexOf(dateTimeFieldType35);
        java.lang.Object obj37 = null;
        boolean boolean38 = localDate20.equals(obj37);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000081d + "'", double1 == 2440587.500000081d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) (short) 0);
        boolean boolean11 = delegatedDateTimeField7.isLeap(0L);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField7.getDurationField();
        long long15 = durationField12.subtract(856L, (int) 'a');
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-8384399144L) + "'", long15 == (-8384399144L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gJChronology2.add(readablePeriod4, (long) 999, (int) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 999L + "'", long7 == 999L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 0, "+00:00:00.010");
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190615T152732.506-0700");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        long long7 = dateTimeZone4.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = partial10.getFieldTypes();
        int int12 = partial10.size();
        boolean boolean13 = jodaTimePermission1.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology8);
        java.lang.String str10 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) localDate9);
        java.lang.String str11 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property12 = localDate9.monthOfYear();
        org.joda.time.LocalDate localDate13 = property12.roundCeilingCopy();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate13, (-1267200000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19691231T������.000" + "'", str10.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "19691231T������.000" + "'", str11.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.weekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology10.getZone();
        org.joda.time.DateMidnight dateMidnight18 = localDate2.toDateMidnight(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate2.plus(readablePeriod19);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) 100, (java.lang.Number) 2592000002L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime21.withPeriodAdded(readablePeriod25, (-1));
        org.joda.time.DateTime dateTime29 = dateTime27.withMillis(2440592L);
        org.joda.time.DateTime dateTime31 = dateTime27.plusDays((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone33);
        org.joda.time.LocalDate localDate36 = localDate34.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property37 = localDate36.centuryOfEra();
        org.joda.time.LocalDate localDate38 = property37.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone40);
        org.joda.time.LocalDate localDate43 = localDate41.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int45 = julianChronology44.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone46 = julianChronology44.getZone();
        long long50 = dateTimeZone46.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime51 = localDate43.toDateTimeAtStartOfDay(dateTimeZone46);
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int53 = julianChronology52.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone54 = julianChronology52.getZone();
        long long58 = dateTimeZone54.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime59 = dateTime51.withZone(dateTimeZone54);
        org.joda.time.DateTime dateTime61 = dateTime59.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone62 = dateTime61.getZone();
        org.joda.time.DateMidnight dateMidnight63 = localDate38.toDateMidnight(dateTimeZone62);
        java.lang.String str64 = dateTimeZone62.getID();
        org.joda.time.DateTime dateTime65 = dateTime31.toDateTime(dateTimeZone62);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateMidnight63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UTC" + "'", str64.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime65);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology11);
        int int13 = localDate12.getYearOfEra();
        int int14 = localDate12.getWeekyear();
        org.joda.time.LocalDate localDate16 = localDate12.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime22 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        long long26 = dateTimeZone19.convertLocalToUTC((long) 8, false, (long) 0);
        org.joda.time.Chronology chronology27 = limitChronology5.withZone(dateTimeZone19);
        long long31 = dateTimeZone19.convertLocalToUTC((long) 18, true, (long) '4');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-3839992L) + "'", long26 == (-3839992L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3839982L) + "'", long31 == (-3839982L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        int int16 = property12.getMaximumValue();
        org.joda.time.LocalDate localDate17 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2922789 + "'", int16 == 2922789);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        java.lang.String str12 = partial8.toString();
        try {
            java.lang.String str14 = partial8.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfMinute();
        java.lang.String str2 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime21.withPeriodAdded(readablePeriod25, (-1));
        org.joda.time.DateTime dateTime29 = dateTime27.withMillis(2440592L);
        org.joda.time.DateTime dateTime31 = dateTime27.plusDays((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime33 = dateTime31.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = gJChronology2.get(readablePeriod4, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190615T152732.506-0700");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundCeiling((long) (short) 0);
        boolean boolean13 = delegatedDateTimeField9.isLeap(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField9, (int) (byte) 100);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) 100, 7, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [7,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        int int10 = dateMidnight4.getMinuteOfHour();
        int int11 = dateMidnight4.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
        int int32 = dateTime31.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime34 = dateTime31.minusWeeks(1852);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHourOfDay(1872);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.centuries();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getUpperLimit();
        org.joda.time.DateTime dateTime8 = limitChronology6.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField9 = limitChronology6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology12);
        int int14 = localDate13.getYearOfEra();
        int int15 = localDate13.getWeekyear();
        org.joda.time.LocalDate localDate17 = localDate13.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean22 = dateTimeZone20.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime23 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        long long27 = dateTimeZone20.convertLocalToUTC((long) 8, false, (long) 0);
        org.joda.time.Chronology chronology28 = limitChronology6.withZone(dateTimeZone20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean30 = limitChronology6.equals((java.lang.Object) dateTimeFormatter29);
        try {
            org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.parse("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", dateTimeFormatter29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-3839992L) + "'", long27 == (-3839992L));
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.Instant instant30 = instant25.minus((long) 1872);
        long long31 = instant30.getMillis();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3692217541872L) + "'", long31 == (-3692217541872L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        long long6 = gJChronology2.add(1L, 0L, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        org.joda.time.Chronology chronology15 = gregorianChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology19 = gJChronology2.withZone(dateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) 0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("18721230T235959.900Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType13 = partial11.getFieldType(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) '4', (int) (byte) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DurationField durationField14 = property13.getDurationField();
        org.joda.time.DateTime dateTime16 = property13.addToCopy((int) (short) -1);
        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) (byte) 0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendOptional(dateTimeParser9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime13 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        long long17 = dateTimeZone10.convertLocalToUTC((long) 8, false, (long) 0);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3839992L) + "'", long17 == (-3839992L));
        org.junit.Assert.assertNotNull(iSOChronology18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial12 = partial10.plus(readablePeriod11);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = partial10.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology16);
        int int18 = localDate17.getYearOfEra();
        int int19 = localDate17.getWeekyear();
        org.joda.time.LocalDate localDate21 = localDate17.minusWeeks(0);
        org.joda.time.LocalDate localDate23 = localDate21.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = localDate21.isSupported(dateTimeFieldType24);
        org.joda.time.DateTime dateTime26 = localDate21.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime28 = dateTime26.minusMonths(2);
        org.joda.time.DateTime.Property property29 = dateTime26.minuteOfDay();
        boolean boolean30 = partial10.isMatch((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        try {
            java.lang.String str7 = localDate4.toString("1969-12-30T14:56:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime24 = property23.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        int int5 = localDate4.getYearOfEra();
        int int6 = localDate4.getWeekyear();
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean13 = dateTimeZone11.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
        long long18 = dateTimeZone11.convertLocalToUTC((long) 8, false, (long) 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = dateTimeZone11.getName((long) (byte) 1, locale20);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) 41, dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3839992L) + "'", long18 == (-3839992L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+01:04" + "'", str21.equals("+01:04"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime();
        org.joda.time.DateTime dateTime33 = dateTime28.withDayOfYear((int) (byte) 1);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int36 = julianChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology35.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int40 = julianChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology39.getZone();
        org.joda.time.Chronology chronology42 = gregorianChronology38.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DurationField durationField44 = gregorianChronology38.days();
        org.joda.time.Chronology chronology45 = gregorianChronology38.withUTC();
        org.joda.time.DateTime dateTime46 = dateTime33.toDateTime((org.joda.time.Chronology) gregorianChronology38);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTime46);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int32 = julianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology31.getZone();
        long long36 = dateTimeZone33.adjustOffset((long) 0, true);
        org.joda.time.Chronology chronology37 = gJChronology30.withZone(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
        java.lang.String str18 = gJChronology17.toString();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        long long25 = delegatedDateTimeField22.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField22, (int) (byte) 10);
        int int29 = offsetDateTimeField27.get((long) (short) 100);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField27.getMaximumShortTextLength(locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, readableInstant33);
        java.lang.String str35 = gJChronology34.toString();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology34.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
        long long42 = delegatedDateTimeField39.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField39, (int) (byte) 10);
        boolean boolean45 = offsetDateTimeField44.isLenient();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone47);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone52);
        int[] intArray54 = localDate53.getValues();
        boolean boolean55 = dateMidnight50.equals((java.lang.Object) localDate53);
        int int56 = localDate53.getWeekOfWeekyear();
        int int57 = offsetDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localDate53);
        org.joda.time.LocalDate localDate59 = localDate53.minusMonths(0);
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDate53, locale60);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone63);
        org.joda.time.LocalDate localDate66 = localDate64.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int68 = julianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone69 = julianChronology67.getZone();
        long long73 = dateTimeZone69.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime74 = localDate66.toDateTimeAtStartOfDay(dateTimeZone69);
        org.joda.time.DateTime.Property property75 = dateTime74.centuryOfEra();
        org.joda.time.DateTime dateTime77 = dateTime74.withYearOfCentury((int) (short) 1);
        int int78 = dateTime77.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone79 = dateTime77.getZone();
        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone79);
        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology80);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray82 = localDate81.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.LocalDate localDate85 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone84);
        int[] intArray86 = localDate85.getValues();
        org.joda.time.Partial partial87 = new org.joda.time.Partial(dateTimeFieldTypeArray82, intArray86);
        int int88 = delegatedDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDate53, intArray86);
        try {
            org.joda.time.LocalDate localDate90 = localDate53.withWeekOfWeekyear(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str18.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 345600001L + "'", long25 == 345600001L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 41 + "'", int29 == 41);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str35.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 345600001L + "'", long42 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 41 + "'", int57 == 41);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31" + "'", str61.equals("31"));
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1L + "'", long73 == 1L);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(julianChronology80);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray82);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField6 = iSOChronology1.eras();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime25 = dateTime23.plusYears(999);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime23.toMutableDateTime();
        try {
            org.joda.time.DateTime dateTime30 = dateTime23.withDate(10, (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfMonth(856);
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekOfWeekyear(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime dateTime28 = dateTime25.plusMinutes(2000);
        try {
            org.joda.time.DateTime dateTime30 = dateTime28.withEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute(4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = buddhistChronology26.withUTC();
        org.joda.time.Chronology chronology28 = buddhistChronology26.withUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = buddhistChronology26.getZone();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime25.toMutableDateTime((org.joda.time.Chronology) buddhistChronology26);
        int int31 = mutableDateTime30.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 6280);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField7.getAsShortText((int) (short) -1, locale18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = delegatedDateTimeField7.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime dateTime16 = dateTime12.withDayOfWeek(7);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime19 = dateTime12.withDurationAdded(readableDuration17, (int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekyear(0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) (short) 0);
        boolean boolean11 = delegatedDateTimeField7.isLeap(0L);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField7.getDurationField();
        long long15 = delegatedDateTimeField7.add((long) 6280, (-88885920));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-7679743488415720L) + "'", long15 == (-7679743488415720L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.hourOfDay();
        java.lang.String str7 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readablePeriod32);
        int int34 = dateTime30.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 69 + "'", int34 == 69);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = copticChronology21.getZone();
        long long24 = dateTimeZone15.getMillisKeepLocal(dateTimeZone22, (long) '#');
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800035L + "'", long24 == 28800035L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = delegatedDateTimeField7.getMinimumValue(readablePartial11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField7.getAsShortText(10, locale15);
        java.lang.String str17 = delegatedDateTimeField7.getName();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfMonth" + "'", str17.equals("dayOfMonth"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property29 = dateTime25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime25.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
        java.lang.String str17 = gJChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        long long24 = delegatedDateTimeField21.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21, (int) (byte) 10);
        boolean boolean27 = offsetDateTimeField26.isLenient();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone29);
        org.joda.time.LocalDate localDate32 = localDate30.minusYears((int) 'a');
        java.util.Locale locale34 = null;
        java.lang.String str35 = localDate30.toString("18", locale34);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone37);
        int[] intArray39 = localDate38.getValues();
        int[] intArray40 = localDate38.getValues();
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate30, intArray40);
        long long43 = offsetDateTimeField26.roundHalfFloor((-1295999990L));
        boolean boolean45 = offsetDateTimeField26.isLeap((long) 3840000);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone47);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight(dateTimeZone49);
        int int51 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, readableInstant54);
        java.lang.String str56 = gJChronology55.toString();
        org.joda.time.DateTimeField dateTimeField57 = gJChronology55.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField58 = gJChronology55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField60 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58, dateTimeFieldType59);
        long long62 = delegatedDateTimeField60.roundCeiling((long) (short) 0);
        boolean boolean64 = delegatedDateTimeField60.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone66);
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone70);
        int[] intArray72 = localDate71.getValues();
        int[] intArray73 = localDate71.getValues();
        int[] intArray74 = localDate71.getValues();
        int[] intArray76 = delegatedDateTimeField60.addWrapPartial((org.joda.time.ReadablePartial) localDate67, (int) (short) 0, intArray74, 11);
        try {
            int[] intArray78 = skipUndoDateTimeField12.addWrapPartial((org.joda.time.ReadablePartial) localDate48, 12, intArray76, 1852);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str17.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 345600001L + "'", long24 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "18" + "'", str35.equals("18"));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1267200000L) + "'", long43 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str56.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 28800000L + "'", long62 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(7, 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField32 = localDate3.getField(0);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate35 = localDate3.withPeriodAdded(readablePeriod33, 12);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone37);
        org.joda.time.LocalDate localDate40 = localDate38.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int42 = julianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone43 = julianChronology41.getZone();
        long long47 = dateTimeZone43.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime48 = localDate40.toDateTimeAtStartOfDay(dateTimeZone43);
        org.joda.time.DateTime.Property property49 = dateTime48.centuryOfEra();
        org.joda.time.DateTime dateTime51 = dateTime48.withYearOfCentury((int) (short) 1);
        int int52 = dateTime51.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime54 = dateTime51.plus(readablePeriod53);
        org.joda.time.DateTime dateTime56 = dateTime51.withYearOfCentury(8);
        org.joda.time.DateTime dateTime57 = localDate35.toDateTime((org.joda.time.ReadableInstant) dateTime51);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendYearOfEra(2, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology39);
        int int41 = localDate40.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology44);
        int int46 = localDate45.getYearOfEra();
        int int47 = localDate40.compareTo((org.joda.time.ReadablePartial) localDate45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone49);
        org.joda.time.LocalDate localDate52 = localDate50.minusYears((int) 'a');
        boolean boolean53 = localDate40.isAfter((org.joda.time.ReadablePartial) localDate50);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate40.minus(readablePeriod54);
        org.joda.time.LocalTime localTime56 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology59);
        int int61 = localDate60.getYearOfEra();
        int int62 = localDate60.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int64 = julianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology63.getZone();
        org.joda.time.Interval interval66 = localDate60.toInterval(dateTimeZone65);
        org.joda.time.DateTime dateTime67 = localDate40.toDateTime(localTime56, dateTimeZone65);
        org.joda.time.LocalTime localTime68 = null;
        org.joda.time.DateTime dateTime69 = localDate40.toDateTime(localTime68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localTime68, (int) ' ', locale71);
        int int74 = skipUndoDateTimeField12.get((long) 69);
        org.joda.time.DurationField durationField75 = skipUndoDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1970 + "'", int62 == 1970);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(interval66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "32" + "'", str72.equals("32"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 69 + "'", int74 == 69);
        org.junit.Assert.assertNull(durationField75);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.LocalDate localDate26 = dateTime22.toLocalDate();
        org.joda.time.DateTime.Property property27 = dateTime22.dayOfWeek();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateMidnight dateMidnight18 = localDate16.toDateMidnight(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        int[] intArray22 = localDate21.getValues();
        boolean boolean23 = dateMidnight18.equals((java.lang.Object) localDate21);
        int int24 = localDate21.getWeekOfWeekyear();
        int int25 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        java.lang.String str27 = offsetDateTimeField12.getAsShortText((long) (short) 1);
        boolean boolean28 = offsetDateTimeField12.isLenient();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 41 + "'", int25 == 41);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "41" + "'", str27.equals("41"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.LocalDate localDate6 = localDate3.plusWeeks((-1));
        int[] intArray7 = localDate3.getValues();
        try {
            org.joda.time.LocalDate localDate9 = localDate3.withDayOfMonth((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
        int[] intArray10 = localDate9.getValues();
        boolean boolean11 = dateMidnight6.equals((java.lang.Object) localDate9);
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate9);
        int[] intArray14 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate9, (-86400000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = dateTime9.isSupported(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.era();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology2.weekyear();
        org.joda.time.DurationField durationField7 = buddhistChronology2.hours();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        java.lang.String str12 = localDate7.toString();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneShortName(strMap13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendFractionOfSecond(2922789, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.appendTimeZoneOffset("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "", false, 11, 18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate2.isSupported(dateTimeFieldType5);
        org.joda.time.LocalDate.Property property7 = localDate2.era();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        illegalFieldValueException2.prependMessage("00:01:00.000Z");
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(31, 1, 30);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(9700, (-88885889), 60, (int) '#', 0, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology26);
        int int28 = localDate27.getYearOfEra();
        int int29 = localDate27.getWeekyear();
        org.joda.time.LocalDate localDate31 = localDate27.minusWeeks(0);
        org.joda.time.LocalDate localDate33 = localDate31.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        boolean boolean35 = localDate31.isSupported(dateTimeFieldType34);
        org.joda.time.DateTime dateTime36 = localDate31.toDateTimeAtCurrentTime();
        org.joda.time.DateTime.Property property37 = dateTime36.minuteOfHour();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime40 = dateTime36.plusWeeks(19);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1970 + "'", int29 == 1970);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        int int12 = delegatedDateTimeField7.getLeapAmount((long) 2000);
        java.lang.String str13 = delegatedDateTimeField7.getName();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
        java.lang.String str17 = gJChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        boolean boolean22 = delegatedDateTimeField21.isLenient();
        boolean boolean23 = delegatedDateTimeField21.isLenient();
        long long25 = delegatedDateTimeField21.roundFloor((-1L));
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField21.getAsText((long) '#', locale27);
        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DurationField durationField30 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField21.getAsShortText((int) (short) -1, locale32);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone35);
        org.joda.time.LocalDate localDate38 = localDate36.minusYears((int) 'a');
        java.util.Locale locale40 = null;
        java.lang.String str41 = localDate36.toString("18", locale40);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, readableInstant44);
        java.lang.String str46 = gJChronology45.toString();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology45.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology45.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
        long long53 = delegatedDateTimeField50.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField50, (int) (byte) 10);
        boolean boolean56 = offsetDateTimeField55.isLenient();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone58);
        org.joda.time.LocalDate localDate61 = localDate59.minusYears((int) 'a');
        java.util.Locale locale63 = null;
        java.lang.String str64 = localDate59.toString("18", locale63);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone66);
        int[] intArray68 = localDate67.getValues();
        int[] intArray69 = localDate67.getValues();
        int int70 = offsetDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) localDate59, intArray69);
        int[] intArray72 = delegatedDateTimeField21.addWrapField((org.joda.time.ReadablePartial) localDate36, 0, intArray69, 4);
        java.util.Locale locale74 = null;
        java.lang.String str75 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate36, 0, locale74);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfMonth" + "'", str13.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str17.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-57600000L) + "'", long25 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31" + "'", str28.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-1" + "'", str33.equals("-1"));
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "18" + "'", str41.equals("18"));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str46.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 345600001L + "'", long53 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "18" + "'", str64.equals("18"));
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 11 + "'", int70 == 11);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.minus(readablePeriod7);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateMidnight21);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        int[] intArray4 = localDate2.getValues();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.DateTimeField dateTimeField7 = localDate2.getField(0);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.LocalDate localDate17 = localDate15.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = localDate15.isSupported(dateTimeFieldType18);
        org.joda.time.DateTime dateTime20 = localDate15.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate22 = localDate15.withEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateMidnight dateMidnight27 = localDate25.toDateMidnight(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone29);
        int[] intArray31 = localDate30.getValues();
        boolean boolean32 = dateMidnight27.equals((java.lang.Object) localDate30);
        int int33 = localDate30.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate34 = localDate15.withFields((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.LocalDate localDate35 = localDate2.withFields((org.joda.time.ReadablePartial) localDate34);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate35);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology9);
        int int11 = localDate10.getYearOfEra();
        int int12 = localDate5.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        boolean boolean18 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate20 = localDate5.minusYears(10);
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) (byte) 10);
        org.joda.time.Chronology chronology23 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        org.joda.time.DateTime dateTime28 = dateTime25.withMinuteOfHour(18);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.Interval interval17 = property12.toInterval();
        org.joda.time.LocalDate localDate19 = property12.setCopy("19");
        org.joda.time.LocalDate.Property property20 = localDate19.year();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        java.lang.String str6 = gJChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.dayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str6.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType13);
        boolean boolean15 = delegatedDateTimeField7.isLenient();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        boolean boolean3 = delegatedDateTimeField2.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        long long14 = delegatedDateTimeField12.roundFloor((long) 2922789);
        int int16 = delegatedDateTimeField12.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57600000L) + "'", long14 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 6280);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) -1, dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField9 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType7, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-1");
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.plus(57600010L);
        boolean boolean25 = dateTime21.isAfterNow();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            org.joda.time.Partial partial1 = new org.joda.time.Partial(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate5.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        int int5 = localDate4.getYearOfEra();
        int int6 = localDate4.getWeekyear();
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(0);
        org.joda.time.LocalDate localDate10 = localDate8.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = localDate8.isSupported(dateTimeFieldType11);
        org.joda.time.LocalDate.Property property13 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate15 = property13.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        long long19 = durationField16.subtract((long) (byte) 1, (-1L));
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3155760000001L + "'", long19 == 3155760000001L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(57600097L, (-3061065600100L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 57600097 * -3061065600100");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-908840220278822001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone9);
        org.joda.time.LocalDate localDate12 = localDate10.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = localDate12.toDateTimeAtStartOfDay(dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int22 = julianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology21.getZone();
        long long27 = dateTimeZone23.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime28 = dateTime20.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime30 = dateTime28.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.DateTime.Property property32 = dateTime30.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology35);
        int int37 = localDate36.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology40);
        int int42 = localDate41.getYearOfEra();
        int int43 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone45);
        org.joda.time.LocalDate localDate48 = localDate46.minusYears((int) 'a');
        boolean boolean49 = localDate36.isAfter((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.LocalDate localDate51 = localDate36.minus(readablePeriod50);
        org.joda.time.LocalTime localTime52 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology55);
        int int57 = localDate56.getYearOfEra();
        int int58 = localDate56.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int60 = julianChronology59.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone61 = julianChronology59.getZone();
        org.joda.time.Interval interval62 = localDate56.toInterval(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = localDate36.toDateTime(localTime52, dateTimeZone61);
        org.joda.time.DateTime dateTime64 = dateTime30.withZone(dateTimeZone61);
        try {
            org.joda.time.LocalDate localDate65 = new org.joda.time.LocalDate((java.lang.Object) str7, dateTimeZone61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1969 + "'", int42 == 1969);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1969 + "'", int57 == 1969);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1970 + "'", int58 == 1970);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(interval62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        boolean boolean31 = offsetDateTimeField12.isLeap((long) 3840000);
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField12.getAsText(1, locale33);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", 0, (int) ' ');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withYearOfCentury(8);
        boolean boolean21 = dateTime15.isBeforeNow();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(28800000L, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
        org.joda.time.DateTime dateTime16 = dateTime13.withYearOfCentury((int) (short) 1);
        int int17 = dateTime16.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime16.getZone();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = localDate20.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        org.joda.time.Partial partial26 = new org.joda.time.Partial(dateTimeFieldTypeArray21, intArray25);
        org.joda.time.Chronology chronology27 = partial26.getChronology();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2922789, chronology27);
        org.joda.time.DateTime.Property property29 = dateTime28.yearOfEra();
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        long long18 = delegatedDateTimeField7.addWrapField((long) 1852, 1969);
        long long21 = delegatedDateTimeField7.addWrapField((long) 2, 100);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1295998148L) + "'", long18 == (-1295998148L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2073599998L) + "'", long21 == (-2073599998L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology8);
        int int10 = localDate9.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology13);
        int int15 = localDate14.getYearOfEra();
        int int16 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.minusYears((int) 'a');
        boolean boolean22 = localDate9.isAfter((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate9.minus(readablePeriod23);
        org.joda.time.LocalTime localTime25 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology28);
        int int30 = localDate29.getYearOfEra();
        int int31 = localDate29.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int33 = julianChronology32.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone34 = julianChronology32.getZone();
        org.joda.time.Interval interval35 = localDate29.toInterval(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = localDate9.toDateTime(localTime25, dateTimeZone34);
        boolean boolean37 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate40 = localDate9.withPeriodAdded(readablePeriod38, 1);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology43);
        int int45 = localDate44.getYearOfEra();
        int int46 = localDate44.getWeekyear();
        org.joda.time.LocalDate localDate48 = localDate44.minusWeeks(0);
        org.joda.time.LocalDate localDate50 = localDate48.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        boolean boolean52 = localDate48.isSupported(dateTimeFieldType51);
        org.joda.time.LocalDate.Property property53 = localDate48.centuryOfEra();
        org.joda.time.LocalDate localDate55 = property53.addToCopy((int) (short) 1);
        org.joda.time.LocalDate localDate57 = localDate55.plusYears(0);
        org.joda.time.LocalDate localDate59 = localDate55.plusWeeks(0);
        int int60 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate55);
        int int61 = localDate9.getYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(interval35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        java.lang.String str12 = dateTimeZone10.getID();
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology16);
        int int18 = localDate17.getYearOfEra();
        int int19 = localDate17.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        org.joda.time.Interval interval23 = localDate17.toInterval(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int30 = julianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology29.getZone();
        long long35 = dateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime36 = localDate28.toDateTimeAtStartOfDay(dateTimeZone31);
        org.joda.time.DateTime.Property property37 = dateTime36.centuryOfEra();
        org.joda.time.DateTime dateTime39 = dateTime36.minus(100L);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded(readableDuration40, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) dateTime42, 1);
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime42.toMutableDateTime();
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int47 = julianChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology46.getZone();
        long long51 = dateTimeZone48.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology56);
        int int58 = localDate57.getYearOfEra();
        int int59 = localDate57.getWeekyear();
        org.joda.time.LocalDate localDate61 = localDate57.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean66 = dateTimeZone64.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime67 = localDate61.toDateTimeAtStartOfDay(dateTimeZone64);
        int int68 = dateTimeZone48.getOffset((org.joda.time.ReadableInstant) dateTime67);
        int int69 = dateTime67.getMillisOfSecond();
        org.joda.time.DateTime dateTime71 = dateTime67.plusMillis(2);
        org.joda.time.DateTime dateTime73 = dateTime67.plusDays((int) '#');
        org.joda.time.chrono.LimitChronology limitChronology74 = org.joda.time.chrono.LimitChronology.getInstance(chronology13, (org.joda.time.ReadableDateTime) dateTime42, (org.joda.time.ReadableDateTime) dateTime73);
        org.joda.time.DateTime dateTime75 = limitChronology74.getUpperLimit();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(interval23);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1969 + "'", int58 == 1969);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1970 + "'", int59 == 1970);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(limitChronology74);
        org.junit.Assert.assertNotNull(dateTime75);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfHour(0, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(3840000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        int int21 = dateTime18.compareTo((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant23 = instant20.withMillis(0L);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Instant instant25 = instant20.minus(readableDuration24);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(instant25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.weekyear();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology4.dayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime dateTime16 = dateTime12.withDayOfWeek(7);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfDay();
        try {
            org.joda.time.DateTime dateTime3 = property1.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]", (java.lang.Number) 856, number2, (java.lang.Number) 2922789);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.centuryOfEra();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        int int7 = copticChronology6.getMinimumDaysInFirstWeek();
        java.lang.String str8 = copticChronology6.toString();
        org.joda.time.Chronology chronology9 = copticChronology6.withUTC();
        boolean boolean10 = julianChronology1.equals((java.lang.Object) chronology9);
        try {
            org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatter0, chronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str8.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateMidnight dateMidnight18 = localDate16.toDateMidnight(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        int[] intArray22 = localDate21.getValues();
        boolean boolean23 = dateMidnight18.equals((java.lang.Object) localDate21);
        int int24 = localDate21.getWeekOfWeekyear();
        int int25 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        long long27 = offsetDateTimeField12.roundHalfFloor((-908840220278822001L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 41 + "'", int25 == 41);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-908840220250022000L) + "'", long27 == (-908840220250022000L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
        try {
            org.joda.time.LocalDate localDate22 = localDate19.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292272992]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        int int5 = localDate4.getYearOfEra();
        int int6 = localDate4.getWeekyear();
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(0);
        org.joda.time.LocalDate localDate10 = localDate8.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = localDate8.isSupported(dateTimeFieldType11);
        org.joda.time.LocalDate.Property property13 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property13.roundFloorCopy();
        org.joda.time.LocalDate localDate15 = property13.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate17 = property13.setCopy("0");
        org.joda.time.DurationField durationField18 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField18, dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder3.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = dateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.withYearOfCentury((int) (short) 1);
        int int19 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        long long25 = dateTimeZone22.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int29 = julianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology28.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField30, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology35);
        int int37 = localDate36.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology40);
        int int42 = localDate41.getYearOfEra();
        int int43 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone45);
        org.joda.time.LocalDate localDate48 = localDate46.minusYears((int) 'a');
        boolean boolean49 = localDate36.isAfter((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.LocalDate localDate51 = localDate36.minus(readablePeriod50);
        org.joda.time.LocalDate localDate53 = localDate36.minusDays((int) (short) 10);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDate36, 0, locale55);
        org.joda.time.DateTimeField[] dateTimeFieldArray57 = localDate36.getFields();
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int59 = julianChronology58.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        long long63 = dateTimeZone60.adjustOffset((long) 0, true);
        long long66 = dateTimeZone60.adjustOffset((-100L), false);
        org.joda.time.Interval interval67 = localDate36.toInterval(dateTimeZone60);
        long long69 = dateTimeZone2.getMillisKeepLocal(dateTimeZone60, (-1L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1969 + "'", int42 == 1969);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray57);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-100L) + "'", long66 == (-100L));
        org.junit.Assert.assertNotNull(interval67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-1L) + "'", long69 == (-1L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray16 = null;
        int int17 = delegatedDateTimeField7.getMinimumValue(readablePartial15, intArray16);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.LocalDate localDate21 = dateTime12.toLocalDate();
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = localDate21.toString("", locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.LocalTime localTime31 = null;
        org.joda.time.DateTime dateTime32 = localDate3.toDateTime(localTime31);
        int int33 = localDate3.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 69 + "'", int33 == 69);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1970, 2592000002L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2591998032L) + "'", long2 == (-2591998032L));
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
//        int int4 = localDate3.getYearOfEra();
//        int int5 = localDate3.getWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
//        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
//        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
//        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
//        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
//        java.lang.String str32 = dateTimeZone8.getName((long) 32);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone9);
        org.joda.time.LocalDate localDate12 = localDate10.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = localDate12.toDateTimeAtStartOfDay(dateTimeZone15);
        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.minus(readableDuration24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        boolean boolean28 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime27);
        try {
            java.lang.String str30 = dateTime20.toString("19691231T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withWeekyear((-1));
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime2, (java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.plus(readableDuration15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTime12.toString("365", locale18);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "365" + "'", str19.equals("365"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.lang.Integer int4 = dateTimeFormatter3.getPivotYear();
        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) int4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DurationField durationField9 = limitChronology5.eras();
        try {
            long long17 = limitChronology5.getDateTimeMillis(2, 0, 60, 41, (int) ' ', (int) (byte) -1, 6280);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 41 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfEra(60);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime dateTime16 = dateTime12.withDayOfWeek(7);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds(69);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusYears(0);
        org.joda.time.LocalDate localDate18 = localDate14.plusWeeks(0);
        try {
            org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField12.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        long long25 = dateTimeZone21.convertLocalToUTC((long) 7, false, (-57600000L));
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime12.toMutableDateTime(dateTimeZone21);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28800007L + "'", long25 == 28800007L);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField12.getMaximumTextLength(locale13);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int13 = offsetDateTimeField12.getOffset();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField12.getAsShortText((long) (short) -1, locale15);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "41" + "'", str16.equals("41"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("19");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.Instant instant30 = instant28.minus(readableDuration29);
        org.joda.time.DateTime dateTime31 = instant30.toDateTimeISO();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 1, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        int[] intArray6 = localDate5.getValues();
        int[] intArray7 = localDate5.getValues();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate5.minus(readablePeriod8);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateMidnight dateMidnight14 = localDate12.toDateMidnight(dateTimeZone13);
        boolean boolean15 = dateMidnight4.isEqual((org.joda.time.ReadableInstant) dateMidnight14);
        int int16 = dateMidnight14.getSecondOfMinute();
        boolean boolean18 = dateMidnight14.isEqual((long) 1970);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology21);
        int int23 = localDate22.getYearOfEra();
        int int24 = localDate22.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int26 = julianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology25.getZone();
        org.joda.time.Interval interval28 = localDate22.toInterval(dateTimeZone27);
        java.lang.String str29 = dateTimeZone27.getID();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone27);
        boolean boolean31 = dateMidnight14.isBefore((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.plusDays(0);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone35);
        org.joda.time.LocalDate localDate38 = localDate36.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int40 = julianChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology39.getZone();
        long long45 = dateTimeZone41.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime46 = localDate38.toDateTimeAtStartOfDay(dateTimeZone41);
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int48 = julianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone49 = julianChronology47.getZone();
        long long53 = dateTimeZone49.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime54 = dateTime46.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime56 = dateTime54.minus((-100L));
        org.joda.time.DateTime dateTime57 = dateTime54.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime59 = dateTime57.plusYears(999);
        boolean boolean60 = dateTime33.isAfter((org.joda.time.ReadableInstant) dateTime57);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1970 + "'", int24 == 1970);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(interval28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UTC" + "'", str29.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology9);
        int int11 = localDate10.getYearOfEra();
        int int12 = localDate5.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        boolean boolean18 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate20 = localDate5.minusYears(10);
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) (byte) 10);
        org.joda.time.LocalDate localDate24 = localDate20.plusDays(18);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(localDate24);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        java.lang.String str4 = gJChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        long long10 = delegatedDateTimeField8.roundCeiling((long) (short) 0);
        boolean boolean12 = delegatedDateTimeField8.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone18);
        int[] intArray20 = localDate19.getValues();
        int[] intArray21 = localDate19.getValues();
        int[] intArray22 = localDate19.getValues();
        int[] intArray24 = delegatedDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate15, (int) (short) 0, intArray22, 11);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        int int26 = copticChronology25.getMinimumDaysInFirstWeek();
        java.lang.String str27 = copticChronology25.toString();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology25.dayOfYear();
        try {
            org.joda.time.Partial partial29 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray24, (org.joda.time.Chronology) copticChronology25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str27.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.DateTime dateTime19 = localDate3.toDateTimeAtMidnight();
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(70);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-70) + "'", int1 == (-70));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        try {
            org.joda.time.LocalDateTime localDateTime7 = dateTimeFormatter0.parseLocalDateTime("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-8384399144L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean8 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate localDate10 = localDate2.minusDays((int) (short) 1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28800000L, number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology9);
        int int11 = localDate10.getYearOfEra();
        int int12 = localDate5.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        boolean boolean18 = localDate5.isAfter((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate20 = localDate5.minusYears(10);
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) (byte) 10);
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        long long6 = dateTimeZone3.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((-1L), (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType11, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.Class<?> wildcardClass3 = iSOChronology2.getClass();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 30, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.year();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.LocalDate localDate6 = localDate3.plusWeeks((-1));
        org.joda.time.LocalDate localDate8 = localDate6.plusYears((int) (byte) 100);
        org.joda.time.LocalTime localTime9 = null;
        org.joda.time.DateTime dateTime10 = localDate6.toDateTime(localTime9);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.String str2 = dateTimeFormatter0.print(28800000L);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("41");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"41\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00.000-08:00" + "'", str2.equals("00:00:00.000-08:00"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int11 = julianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology10.getZone();
        long long16 = dateTimeZone12.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime17 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        org.joda.time.DateTime dateTime20 = dateTime17.withYearOfCentury((int) (short) 1);
        int int21 = dateTime20.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
        try {
            org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime20, 856);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 856");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField10 = gregorianChronology4.days();
        org.joda.time.Chronology chronology11 = gregorianChronology4.withUTC();
        java.lang.String str12 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) 10);
        long long20 = dateTimeZone15.convertLocalToUTC((long) (byte) 100, false);
        org.joda.time.Chronology chronology21 = gregorianChronology4.withZone(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology4.dayOfYear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[UTC]" + "'", str12.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3839900L) + "'", long20 == (-3839900L));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendSecondOfDay(18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.weekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology10.getZone();
        org.joda.time.DateMidnight dateMidnight18 = localDate2.toDateMidnight(dateTimeZone17);
        org.joda.time.LocalDate localDate20 = localDate2.minusDays(4);
        org.joda.time.LocalDate.Property property21 = localDate20.dayOfMonth();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField7.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 6280);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.withMaximumValue();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType15, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 2000, "dayOfMonth");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int14 = offsetDateTimeField12.get((long) (short) 100);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField12.getMaximumShortTextLength(locale15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        java.lang.String str22 = gJChronology21.toString();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
        long long28 = delegatedDateTimeField26.roundCeiling((long) (short) 0);
        boolean boolean30 = delegatedDateTimeField26.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone36);
        int[] intArray38 = localDate37.getValues();
        int[] intArray39 = localDate37.getValues();
        int[] intArray40 = localDate37.getValues();
        int[] intArray42 = delegatedDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) localDate33, (int) (short) 0, intArray40, 11);
        try {
            int[] intArray44 = offsetDateTimeField12.addWrapPartial(readablePartial17, (-70), intArray42, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -70");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 41 + "'", int14 == 41);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str22.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.era();
        org.joda.time.DurationField durationField6 = buddhistChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.getID();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        long long22 = dateTimeZone18.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime23 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.joda.time.DateTime dateTime26 = dateTime23.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime23.minus(readableDuration27);
        int int29 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
        int int31 = dateTimeZone8.getOffsetFromLocal((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
//        int int5 = localDate4.getYearOfEra();
//        int int6 = localDate4.getWeekyear();
//        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(0);
//        org.joda.time.LocalDate localDate10 = localDate8.minusMonths(1969);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = localDate8.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime13 = localDate8.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(1872);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime13.getZone();
//        java.lang.String str17 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime19 = dateTime13.minusMillis((int) '4');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "16:00:00.003" + "'", str17.equals("16:00:00.003"));
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int14 = offsetDateTimeField12.get((long) (short) 100);
        int int15 = offsetDateTimeField12.getOffset();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 41 + "'", int14 == 41);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.Class<?> wildcardClass16 = iSOChronology15.getClass();
        org.joda.time.DateTime dateTime17 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology15);
        try {
            org.joda.time.DateTime dateTime19 = dateTime12.withMillisOfSecond(6280);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6280 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury((int) '4');
        boolean boolean38 = dateTime12.isBefore((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int40 = julianChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology39.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.halfdayOfDay();
        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology42);
        try {
            long long50 = gregorianChronology42.getDateTimeMillis(0L, 3, (-1), (-88885889), (-88885889));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190615T152732.506-0700");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        boolean boolean10 = delegatedDateTimeField9.isLenient();
        boolean boolean11 = delegatedDateTimeField9.isLenient();
        long long13 = delegatedDateTimeField9.roundFloor((-1L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField9.getAsText((long) '#', locale15);
        org.joda.time.DateTimeField dateTimeField17 = delegatedDateTimeField9.getWrappedField();
        org.joda.time.DurationField durationField18 = delegatedDateTimeField9.getDurationField();
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField9.getAsShortText((int) (short) -1, locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        org.joda.time.LocalDate localDate26 = localDate24.minusYears((int) 'a');
        java.util.Locale locale28 = null;
        java.lang.String str29 = localDate24.toString("18", locale28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        java.lang.String str34 = gJChronology33.toString();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        long long41 = delegatedDateTimeField38.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField38, (int) (byte) 10);
        boolean boolean44 = offsetDateTimeField43.isLenient();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.minusYears((int) 'a');
        java.util.Locale locale51 = null;
        java.lang.String str52 = localDate47.toString("18", locale51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone54);
        int[] intArray56 = localDate55.getValues();
        int[] intArray57 = localDate55.getValues();
        int int58 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate47, intArray57);
        int[] intArray60 = delegatedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDate24, 0, intArray57, 4);
        jodaTimePermission1.checkGuard((java.lang.Object) localDate24);
        java.lang.String str62 = jodaTimePermission1.toString();
        java.lang.String str63 = jodaTimePermission1.getActions();
        java.lang.String str64 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "18" + "'", str29.equals("18"));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str34.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 345600001L + "'", long41 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "18" + "'", str52.equals("18"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"20190615T152732.506-0700\")" + "'", str62.equals("(\"org.joda.time.JodaTimePermission\" \"20190615T152732.506-0700\")"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.DateTime dateTime26 = dateTime24.plusSeconds(1852);
        try {
            org.joda.time.DateTime dateTime28 = dateTime24.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate16.getFields();
        org.joda.time.LocalDate localDate39 = localDate16.plusMonths(69);
        int int40 = localDate16.getWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1970 + "'", int40 == 1970);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.MutableDateTime mutableDateTime29 = instant25.toMutableDateTime();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = julianChronology0.halfdays();
        org.joda.time.DurationField durationField4 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = delegatedDateTimeField7.getMinimumValue(readablePartial11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField7.getAsShortText(10, locale15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, 18);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology18);
        try {
            long long28 = julianChronology18.getDateTimeMillis((int) ' ', (int) (byte) 1, 52, (int) (short) 1, 856, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 856 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 3840000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3840097 + "'", int2 == 3840097);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate16.getFields();
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int39 = julianChronology38.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone40 = julianChronology38.getZone();
        long long43 = dateTimeZone40.adjustOffset((long) 0, true);
        long long46 = dateTimeZone40.adjustOffset((-100L), false);
        org.joda.time.Interval interval47 = localDate16.toInterval(dateTimeZone40);
        long long49 = dateTimeZone40.convertUTCToLocal((-100L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology50.year();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology54);
        int int56 = localDate55.getYearOfEra();
        int int57 = localDate55.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int59 = julianChronology58.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        org.joda.time.Interval interval61 = localDate55.toInterval(dateTimeZone60);
        org.joda.time.Chronology chronology62 = buddhistChronology50.withZone(dateTimeZone60);
        long long64 = dateTimeZone40.getMillisKeepLocal(dateTimeZone60, (long) 'a');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-100L) + "'", long46 == (-100L));
        org.junit.Assert.assertNotNull(interval47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-100L) + "'", long49 == (-100L));
        org.junit.Assert.assertNotNull(buddhistChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1969 + "'", int56 == 1969);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(interval61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone22);
        int[] intArray24 = localDate23.getValues();
        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldTypeArray20, intArray24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
        java.lang.String str29 = gJChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        long long35 = delegatedDateTimeField33.roundCeiling((long) (short) 0);
        boolean boolean37 = delegatedDateTimeField33.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone43);
        int[] intArray45 = localDate44.getValues();
        int[] intArray46 = localDate44.getValues();
        int[] intArray47 = localDate44.getValues();
        int[] intArray49 = delegatedDateTimeField33.addWrapPartial((org.joda.time.ReadablePartial) localDate40, (int) (short) 0, intArray47, 11);
        org.joda.time.Partial partial50 = new org.joda.time.Partial(dateTimeFieldTypeArray20, intArray49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.Partial partial53 = partial50.withPeriodAdded(readablePeriod51, (-88885889));
        int[] intArray54 = partial50.getValues();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str29.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800000L + "'", long35 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(partial53);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        java.util.Locale locale11 = null;
        java.lang.String str12 = partial8.toString("19", locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.Partial partial15 = partial8.with(dateTimeFieldType13, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        java.lang.String str15 = delegatedDateTimeField7.getName();
        long long17 = delegatedDateTimeField7.roundHalfFloor(2440592L);
        boolean boolean18 = delegatedDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 1970, chronology1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneShortName(strMap13);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendHourOfHalfday((-88885889));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField15 = property13.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = gregorianChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant6);
        java.lang.String str8 = gJChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        long long15 = delegatedDateTimeField12.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, (int) (byte) 10);
        boolean boolean18 = offsetDateTimeField17.isLenient();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        org.joda.time.LocalDate localDate23 = localDate21.minusYears((int) 'a');
        java.util.Locale locale25 = null;
        java.lang.String str26 = localDate21.toString("18", locale25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone28);
        int[] intArray30 = localDate29.getValues();
        int[] intArray31 = localDate29.getValues();
        int int32 = offsetDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray31);
        org.joda.time.DurationField durationField33 = offsetDateTimeField17.getLeapDurationField();
        int int35 = offsetDateTimeField17.getMaximumValue((long) (short) 0);
        java.lang.String str37 = offsetDateTimeField17.getAsShortText((long) 14);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) offsetDateTimeField17, 3840000);
        try {
            long long47 = gregorianChronology3.getDateTimeMillis((-88885920), (int) ' ', 999, 0, 32, 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str8.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345600001L + "'", long15 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "18" + "'", str26.equals("18"));
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 41 + "'", int35 == 41);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "41" + "'", str37.equals("41"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate15 = property12.withMaximumValue();
        org.joda.time.LocalDate localDate17 = localDate15.minusDays(3);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime19 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime.Property property20 = dateTime19.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        java.lang.Class<?> wildcardClass23 = iSOChronology22.getClass();
        org.joda.time.DateTime dateTime24 = dateTime19.toDateTime((org.joda.time.Chronology) iSOChronology22);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (byte) 10, 30, 18, (int) (byte) -1, (int) (short) 0, 52, 24, (org.joda.time.Chronology) iSOChronology22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology6);
        try {
            org.joda.time.Instant instant10 = new org.joda.time.Instant((java.lang.Object) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(21, '#', 21, (int) '#', (int) (byte) -1, true, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withWeekyear((-1));
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime0);
//        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTime.Property property24 = dateTime22.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology27);
        int int29 = localDate28.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology32);
        int int34 = localDate33.getYearOfEra();
        int int35 = localDate28.compareTo((org.joda.time.ReadablePartial) localDate33);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone37);
        org.joda.time.LocalDate localDate40 = localDate38.minusYears((int) 'a');
        boolean boolean41 = localDate28.isAfter((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.LocalDate localDate43 = localDate28.minus(readablePeriod42);
        org.joda.time.LocalTime localTime44 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology47);
        int int49 = localDate48.getYearOfEra();
        int int50 = localDate48.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int52 = julianChronology51.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology51.getZone();
        org.joda.time.Interval interval54 = localDate48.toInterval(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = localDate28.toDateTime(localTime44, dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime22.withZone(dateTimeZone53);
        boolean boolean58 = dateTime56.isAfter((long) (short) 10);
        org.joda.time.DateTime dateTime60 = dateTime56.withEra(0);
        org.joda.time.DateTime.Property property61 = dateTime56.year();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1970 + "'", int50 == 1970);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(interval54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        java.lang.String str34 = gJChronology33.toString();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone38);
        org.joda.time.LocalDate localDate41 = localDate39.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int43 = julianChronology42.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone44 = julianChronology42.getZone();
        long long48 = dateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime49 = localDate41.toDateTimeAtStartOfDay(dateTimeZone44);
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int51 = julianChronology50.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone52 = julianChronology50.getZone();
        long long56 = dateTimeZone52.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime57 = dateTime49.withZone(dateTimeZone52);
        org.joda.time.DateTime dateTime59 = dateTime57.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone60 = dateTime59.getZone();
        org.joda.time.DateTime.Property property61 = dateTime59.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone63);
        org.joda.time.LocalDate localDate65 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology64);
        int int66 = localDate65.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology69);
        int int71 = localDate70.getYearOfEra();
        int int72 = localDate65.compareTo((org.joda.time.ReadablePartial) localDate70);
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.LocalDate localDate75 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone74);
        org.joda.time.LocalDate localDate77 = localDate75.minusYears((int) 'a');
        boolean boolean78 = localDate65.isAfter((org.joda.time.ReadablePartial) localDate75);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        org.joda.time.LocalDate localDate80 = localDate65.minus(readablePeriod79);
        org.joda.time.LocalTime localTime81 = null;
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.chrono.ISOChronology iSOChronology84 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone83);
        org.joda.time.LocalDate localDate85 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology84);
        int int86 = localDate85.getYearOfEra();
        int int87 = localDate85.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology88 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int89 = julianChronology88.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone90 = julianChronology88.getZone();
        org.joda.time.Interval interval91 = localDate85.toInterval(dateTimeZone90);
        org.joda.time.DateTime dateTime92 = localDate65.toDateTime(localTime81, dateTimeZone90);
        org.joda.time.DateTime dateTime93 = dateTime59.withZone(dateTimeZone90);
        org.joda.time.Chronology chronology94 = gJChronology33.withZone(dateTimeZone90);
        long long96 = dateTimeZone28.getMillisKeepLocal(dateTimeZone90, (long) (short) 100);
        int int98 = dateTimeZone28.getOffsetFromLocal((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str34.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1969 + "'", int66 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1969 + "'", int71 == 1969);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(iSOChronology84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1969 + "'", int86 == 1969);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1970 + "'", int87 == 1970);
        org.junit.Assert.assertNotNull(julianChronology88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 4 + "'", int89 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone90);
        org.junit.Assert.assertNotNull(interval91);
        org.junit.Assert.assertNotNull(dateTime92);
        org.junit.Assert.assertNotNull(dateTime93);
        org.junit.Assert.assertNotNull(chronology94);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 100L + "'", long96 == 100L);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime12.toYearMonthDay();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(4, 0);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int5 = julianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfHour();
        org.joda.time.LocalDateTime localDateTime14 = dateTime12.toLocalDateTime();
        boolean boolean15 = dateTimeZone2.isLocalDateTimeGap(localDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        java.util.Date date10 = localDate7.toDate();
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.fromDateFields(date10);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(localDate11);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3L + "'", long0 == 3L);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfMonth();
        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfSecond(12);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury((int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute(4);
        int int26 = dateTime25.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendSecondOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField7.getAsShortText((int) (short) -1, locale18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.minusYears((int) 'a');
        java.util.Locale locale26 = null;
        java.lang.String str27 = localDate22.toString("18", locale26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
        java.lang.String str32 = gJChronology31.toString();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology31.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
        long long39 = delegatedDateTimeField36.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField36, (int) (byte) 10);
        boolean boolean42 = offsetDateTimeField41.isLenient();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone44);
        org.joda.time.LocalDate localDate47 = localDate45.minusYears((int) 'a');
        java.util.Locale locale49 = null;
        java.lang.String str50 = localDate45.toString("18", locale49);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone52);
        int[] intArray54 = localDate53.getValues();
        int[] intArray55 = localDate53.getValues();
        int int56 = offsetDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) localDate45, intArray55);
        int[] intArray58 = delegatedDateTimeField7.addWrapField((org.joda.time.ReadablePartial) localDate22, 0, intArray55, 4);
        java.lang.String str59 = localDate22.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "18" + "'", str27.equals("18"));
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str32.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 345600001L + "'", long39 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "18" + "'", str50.equals("18"));
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969-12-31" + "'", str59.equals("1969-12-31"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays(1872);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime12.getZone();
        org.joda.time.DateTime dateTime18 = dateTime12.withDurationAdded((long) (byte) 10, 14);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime12.minus(readableDuration19);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
//        int int4 = localDate3.getYearOfEra();
//        int int5 = localDate3.getWeekyear();
//        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
//        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.Partial partial12 = partial10.plus(readablePeriod11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology16);
//        int int18 = localDate17.getYearOfEra();
//        int int19 = localDate17.getWeekyear();
//        org.joda.time.LocalDate localDate21 = localDate17.minusWeeks(0);
//        org.joda.time.LocalDate localDate23 = localDate21.minusMonths(1969);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
//        boolean boolean25 = localDate21.isSupported(dateTimeFieldType24);
//        org.joda.time.DateTime dateTime26 = localDate21.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime28 = dateTime26.minusDays(1872);
//        org.joda.time.DateTimeZone dateTimeZone29 = dateTime26.getZone();
//        java.lang.String str30 = dateTimeFormatter13.print((org.joda.time.ReadableInstant) dateTime26);
//        boolean boolean31 = partial10.isMatch((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime26.plus(readablePeriod32);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(partial12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "16:00:00.003" + "'", str30.equals("16:00:00.003"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withWeekyear((-1));
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime0);
//        org.joda.time.DateTime dateTime4 = dateTime0.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay((-70), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.dayOfMonth();
        java.lang.String str3 = copticChronology1.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException6.getSuppressed();
        java.lang.String str8 = illegalFieldValueException6.getIllegalValueAsString();
        boolean boolean9 = copticChronology1.equals((java.lang.Object) str8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        long long29 = dateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime22.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.withDurationAdded(readableDuration33, (int) (byte) 0);
        boolean boolean36 = copticChronology1.equals((java.lang.Object) (byte) 0);
        int int37 = copticChronology1.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((java.lang.Object) strSet0, (org.joda.time.Chronology) copticChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.util.TreeSet");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strSet0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str3.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(3155702400000L, "");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        int int8 = localDate7.getYearOfEra();
        int int9 = localDate7.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int11 = julianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology10.getZone();
        org.joda.time.Interval interval13 = localDate7.toInterval(dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.getID();
        org.joda.time.Chronology chronology15 = julianChronology2.withZone(dateTimeZone12);
        try {
            org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType0, (-70), (org.joda.time.Chronology) julianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        long long13 = delegatedDateTimeField10.addWrapField((-1L), 0);
        long long15 = delegatedDateTimeField10.roundHalfFloor((long) 52);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        boolean boolean15 = property13.isLeap();
        org.joda.time.DateTime dateTime16 = property13.roundCeilingCopy();
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 0, 0, 0, 12, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial12 = partial10.plus(readablePeriod11);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = partial10.getFieldTypes();
        int int14 = partial10.size();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", "ISOChronology[America/Los_Angeles]");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField12.getMaximumTextLength(locale13);
        long long17 = delegatedDateTimeField12.getDifferenceAsLong((long) (-1), (long) (byte) -1);
        int int19 = delegatedDateTimeField12.get((-3839992L));
        org.joda.time.DurationField durationField20 = delegatedDateTimeField12.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("18", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(9700, '#', 60, 52, 32, false, 1970);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("18721230T235959.900Z", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial12 = partial10.plus(readablePeriod11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.Partial.Property property14 = partial12.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(partial12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DurationField durationField14 = property13.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone16);
        org.joda.time.LocalDate localDate19 = localDate17.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        long long26 = dateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime27 = localDate19.toDateTimeAtStartOfDay(dateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int29 = julianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology28.getZone();
        long long34 = dateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime35 = dateTime27.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury(0);
        int int38 = property13.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property39 = dateTime37.weekyear();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int41 = julianChronology40.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone42 = julianChronology40.getZone();
        long long45 = dateTimeZone42.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology50);
        int int52 = localDate51.getYearOfEra();
        int int53 = localDate51.getWeekyear();
        org.joda.time.LocalDate localDate55 = localDate51.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean60 = dateTimeZone58.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime61 = localDate55.toDateTimeAtStartOfDay(dateTimeZone58);
        int int62 = dateTimeZone42.getOffset((org.joda.time.ReadableInstant) dateTime61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone42);
        boolean boolean64 = dateTime37.isBefore((org.joda.time.ReadableInstant) dateTime63);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1969 + "'", int52 == 1969);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1970 + "'", int53 == 1970);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        java.lang.String str13 = delegatedDateTimeField7.toString();
        long long15 = delegatedDateTimeField7.roundHalfEven((long) 30);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(0L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate17, locale18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.minusYears((int) 'a');
        int int25 = localDate22.getYearOfCentury();
        int[] intArray27 = new int[] { (-88885889) };
        try {
            int int28 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) localDate22, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str13.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 69 + "'", int25 == 69);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendCenturyOfEra((int) (short) 1, 69);
        dateTimeFormatterBuilder14.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField10 = gregorianChronology4.days();
        org.joda.time.Chronology chronology11 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, readableInstant13);
        java.lang.String str15 = gJChronology14.toString();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
        long long22 = delegatedDateTimeField19.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField19, (int) (byte) 100);
        int int28 = skipDateTimeField26.get((-8384399144L));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology31);
        int int33 = localDate32.getYearOfEra();
        int int34 = localDate32.getWeekyear();
        org.joda.time.LocalDate localDate36 = localDate32.minusWeeks(0);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
        boolean boolean40 = localDate36.isSupported(dateTimeFieldType39);
        org.joda.time.LocalDate.Property property41 = localDate36.centuryOfEra();
        org.joda.time.LocalDate localDate42 = property41.roundFloorCopy();
        int int43 = property41.get();
        java.util.Locale locale44 = null;
        java.lang.String str45 = property41.getAsText(locale44);
        org.joda.time.Interval interval46 = property41.toInterval();
        org.joda.time.LocalDate localDate48 = property41.setCopy("1");
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone50 = copticChronology49.getZone();
        int int51 = copticChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology54);
        int int56 = localDate55.getYearOfEra();
        int int57 = localDate55.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int59 = julianChronology58.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        org.joda.time.Interval interval61 = localDate55.toInterval(dateTimeZone60);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone60);
        boolean boolean63 = copticChronology49.equals((java.lang.Object) dateTimeZone60);
        org.joda.time.DateTime dateTime64 = localDate48.toDateTimeAtStartOfDay(dateTimeZone60);
        java.util.Locale locale66 = null;
        java.lang.String str67 = skipDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate48, (int) (short) -1, locale66);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str15.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 345600001L + "'", long22 == 345600001L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1970 + "'", int34 == 1970);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 19 + "'", int43 == 19);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "19" + "'", str45.equals("19"));
        org.junit.Assert.assertNotNull(interval46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1969 + "'", int56 == 1969);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(interval61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "-1" + "'", str67.equals("-1"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.Partial partial11 = partial8.minus(readablePeriod10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = partial11.toString("CopticChronology[UTC]", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime22.plus(readablePeriod25);
        java.util.GregorianCalendar gregorianCalendar27 = dateTime22.toGregorianCalendar();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar27);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertNotNull(localDate28);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("365");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "19691231T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundCeiling((long) (short) 0);
        boolean boolean13 = delegatedDateTimeField9.isLeap(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField9, (int) (byte) 100);
        long long17 = delegatedDateTimeField9.roundCeiling((long) 41);
        int int19 = delegatedDateTimeField9.get((long) ' ');
        long long21 = delegatedDateTimeField9.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.Instant instant29 = instant28.toInstant();
        org.joda.time.Chronology chronology30 = instant29.getChronology();
        org.joda.time.MutableDateTime mutableDateTime31 = instant29.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate8 = localDate3.withEra(0);
        try {
            java.lang.String str10 = localDate8.toString("(\"org.joda.time.JodaTimePermission\" \"20190615T152732.506-0700\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        int int10 = partial8.size();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial12 = partial8.minus(readablePeriod11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial8.getFormatter();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertNull(dateTimeFormatter13);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = buddhistChronology2.getZone();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.minus(readableDuration23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        long long6 = dateTimeZone3.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(0L, dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException5.getSuppressed();
        java.lang.String str7 = illegalFieldValueException5.getIllegalValueAsString();
        boolean boolean8 = copticChronology0.equals((java.lang.Object) str7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone10);
        org.joda.time.LocalDate localDate13 = localDate11.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int23 = julianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology22.getZone();
        long long28 = dateTimeZone24.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime21.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded(readableDuration32, (int) (byte) 0);
        boolean boolean35 = copticChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField36 = copticChronology0.eras();
        int int37 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            long long42 = copticChronology0.getDateTimeMillis(0, (int) (byte) 0, 1970, 366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitYear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.LocalDate localDate12 = localDate3.plusMonths(1852);
        org.joda.time.LocalDate localDate14 = localDate3.plusWeeks(366);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = localDate3.isSupported(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 1852);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        org.joda.time.LocalDate localDate16 = property12.getLocalDate();
        int int17 = property12.getLeapAmount();
        org.joda.time.LocalDate localDate19 = property12.setCopy("32");
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(localDate19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.DateTime dateTime17 = dateTime12.plusMinutes(0);
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 3840097);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
//        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
//        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
//        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) 'a');
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
//        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 100);
//        org.joda.time.DateTime dateTime19 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
//        long long26 = dateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 100);
//        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime29 = dateTime27.minus((-100L));
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime29.getZone();
//        org.joda.time.DateMidnight dateMidnight31 = localDate6.toDateMidnight(dateTimeZone30);
//        java.lang.String str32 = dateTimeZone30.getID();
//        java.lang.String str34 = dateTimeZone30.getShortName((long) (byte) -1);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UTC" + "'", str32.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UTC" + "'", str34.equals("UTC"));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        java.lang.String str21 = property20.getAsShortText();
        org.joda.time.DateTime dateTime22 = property20.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime24 = property20.setCopy("[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "365" + "'", str21.equals("365"));
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute(4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = buddhistChronology26.withUTC();
        org.joda.time.Chronology chronology28 = buddhistChronology26.withUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = buddhistChronology26.getZone();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime25.toMutableDateTime((org.joda.time.Chronology) buddhistChronology26);
        java.lang.Class<?> wildcardClass31 = mutableDateTime30.getClass();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate8 = localDate3.withEra(0);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate14 = localDate7.withEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateMidnight dateMidnight19 = localDate17.toDateMidnight(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        int[] intArray23 = localDate22.getValues();
        boolean boolean24 = dateMidnight19.equals((java.lang.Object) localDate22);
        int int25 = localDate22.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate26 = localDate7.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int int28 = localDate26.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.plusMinutes(1970);
        org.joda.time.Chronology chronology21 = dateTime15.getChronology();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(1852);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField12.getLeapDurationField();
        boolean boolean29 = offsetDateTimeField12.isLenient();
        long long31 = offsetDateTimeField12.roundHalfCeiling(100L);
        int int34 = offsetDateTimeField12.getDifference((long) 14, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology37);
        int int39 = localDate38.getYearOfEra();
        int int40 = localDate38.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int42 = julianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone43 = julianChronology41.getZone();
        org.joda.time.Interval interval44 = localDate38.toInterval(dateTimeZone43);
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate38, 8, locale46);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800000L + "'", long31 == 28800000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1970 + "'", int40 == 1970);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(interval44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "8" + "'", str47.equals("8"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime21.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = dateTimeZone24.isLocalDateTimeGap(localDateTime25);
        org.joda.time.Chronology chronology27 = gregorianChronology0.withZone(dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        long long34 = offsetDateTimeField12.roundHalfCeiling(0L);
        long long36 = offsetDateTimeField12.roundHalfEven((long) (short) -1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendFractionOfHour(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        java.lang.String str25 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.year();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 2000);
        org.joda.time.DateTime dateTime33 = dateTimeFormatter29.parseDateTime("19691231T000000.002+0104");
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.append(dateTimePrinter19, dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19691231T������.000" + "'", str25.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.field.FieldUtils.verifyValueBounds("18721230T235959.900Z", 856, (int) ' ', 1852);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.DateTime dateTime17 = dateTime12.plusMinutes(0);
        org.joda.time.DateTime dateTime19 = dateTime17.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfYear();
        org.joda.time.DateTime dateTime22 = dateTime19.withYearOfCentury(10);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone9);
        org.joda.time.LocalDate localDate12 = localDate10.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = localDate12.toDateTimeAtStartOfDay(dateTimeZone15);
        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.minus(readableDuration24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("41", 41, (int) '4', 0, '4', 3840000, 366, (int) (byte) 100, false, 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(52);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateMidnight dateMidnight15 = localDate13.toDateMidnight(dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate13.minusYears((int) '4');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate21.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int25 = julianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology24.getZone();
        org.joda.time.Interval interval27 = localDate21.toInterval(dateTimeZone26);
        long long29 = dateTimeZone26.convertUTCToLocal((-1L));
        org.joda.time.DateTime dateTime30 = localDate13.toDateTimeAtMidnight(dateTimeZone26);
        int int31 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(interval27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneShortName(strMap13);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long20 = dateTimeZone17.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone24);
        org.joda.time.LocalDate localDate27 = localDate25.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int29 = julianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology28.getZone();
        long long34 = dateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime35 = localDate27.toDateTimeAtStartOfDay(dateTimeZone30);
        org.joda.time.DateTime.Property property36 = dateTime35.centuryOfEra();
        org.joda.time.DateTime dateTime38 = dateTime35.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime40 = dateTime35.minus(readableDuration39);
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime42 = dateTime35.withLaterOffsetAtOverlap();
        int int43 = dateTime35.getDayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology47);
        java.lang.String str49 = dateTimeFormatter44.print((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology50.year();
        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology50.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) buddhistChronology50);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter53.withPivotYear((java.lang.Integer) 2000);
        org.joda.time.DateTime dateTime57 = dateTimeFormatter53.parseDateTime("19691231T000000.002+0104");
        java.lang.String str58 = dateTime35.toString(dateTimeFormatter53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder14.append(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "19691231T������.000" + "'", str49.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "24151230T160702.000-0752" + "'", str58.equals("24151230T160702.000-0752"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException5.getSuppressed();
        java.lang.String str7 = illegalFieldValueException5.getIllegalValueAsString();
        boolean boolean8 = copticChronology0.equals((java.lang.Object) str7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone10);
        org.joda.time.LocalDate localDate13 = localDate11.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int23 = julianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology22.getZone();
        long long28 = dateTimeZone24.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime21.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded(readableDuration32, (int) (byte) 0);
        boolean boolean35 = copticChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((long) (byte) 100);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField12.getMaximumShortTextLength(locale35);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology39);
        int int41 = localDate40.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology44);
        int int46 = localDate45.getYearOfEra();
        int int47 = localDate40.compareTo((org.joda.time.ReadablePartial) localDate45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone49);
        org.joda.time.LocalDate localDate52 = localDate50.minusYears((int) 'a');
        boolean boolean53 = localDate40.isAfter((org.joda.time.ReadablePartial) localDate50);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate40.minus(readablePeriod54);
        org.joda.time.LocalDate.Property property56 = localDate40.weekyear();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone59);
        org.joda.time.LocalDate localDate62 = localDate60.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int64 = julianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology63.getZone();
        long long69 = dateTimeZone65.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime70 = localDate62.toDateTimeAtStartOfDay(dateTimeZone65);
        org.joda.time.DateTime.Property property71 = dateTime70.centuryOfEra();
        org.joda.time.DateTime dateTime73 = dateTime70.withYearOfCentury((int) (short) 1);
        int int74 = dateTime73.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone75 = dateTime73.getZone();
        org.joda.time.chrono.JulianChronology julianChronology76 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone75);
        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology76);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray78 = localDate77.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone80);
        int[] intArray82 = localDate81.getValues();
        org.joda.time.Partial partial83 = new org.joda.time.Partial(dateTimeFieldTypeArray78, intArray82);
        try {
            int[] intArray85 = offsetDateTimeField12.addWrapField((org.joda.time.ReadablePartial) localDate40, 69, intArray82, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 69");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "41" + "'", str34.equals("41"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1L + "'", long69 == 1L);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(julianChronology76);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray78);
        org.junit.Assert.assertNotNull(intArray82);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("41", 41, (int) '4', 0, '4', 3840000, 366, (int) (byte) 100, false, 19);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1970-01-19", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendCenturyOfEra((int) (short) 1, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime22.plus(readablePeriod25);
        int int27 = dateTime26.getDayOfYear();
        org.joda.time.DateTime dateTime29 = dateTime26.plusHours(69);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 366 + "'", int27 == 366);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial12 = partial10.plus(readablePeriod11);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = partial10.getFieldTypes();
        java.lang.String str14 = partial10.toStringList();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str14.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        long long6 = dateTimeZone3.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((-1L), (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        boolean boolean10 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate localDate12 = localDate7.withEra((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        int[] intArray16 = localDate15.getValues();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology19);
        boolean boolean21 = localDate15.isEqual((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = localDate7.equals((java.lang.Object) boolean21);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.Instant instant29 = instant28.toInstant();
        org.joda.time.Chronology chronology30 = instant29.getChronology();
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.Instant instant32 = instant29.plus(readableDuration31);
        org.joda.time.DateTime dateTime33 = instant32.toDateTimeISO();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        long long20 = dateTimeZone15.convertLocalToUTC((long) (byte) 0, true, 2592000002L);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone15);
        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", 0, (int) ' ');
        boolean boolean28 = zonedChronology21.equals((java.lang.Object) "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]");
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 3840000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException5.getSuppressed();
        java.lang.String str7 = illegalFieldValueException5.getIllegalValueAsString();
        boolean boolean8 = copticChronology0.equals((java.lang.Object) str7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone10);
        org.joda.time.LocalDate localDate13 = localDate11.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int23 = julianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology22.getZone();
        long long28 = dateTimeZone24.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime21.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded(readableDuration32, (int) (byte) 0);
        boolean boolean35 = copticChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField36 = copticChronology0.eras();
        int int37 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.Object obj38 = null;
        boolean boolean39 = copticChronology0.equals(obj38);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        int int21 = dateTime18.compareTo((org.joda.time.ReadableInstant) instant20);
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime18.plusMillis(7);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        int int17 = localDate14.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField12.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType29, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        org.joda.time.LocalDate localDate16 = property12.getLocalDate();
        int int17 = property12.getLeapAmount();
        int int18 = property12.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922789 + "'", int18 == 2922789);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTime dateTime17 = dateTime12.minusDays(1);
        org.joda.time.DateTime dateTime18 = dateTime12.toDateTimeISO();
        boolean boolean20 = dateTime18.isAfter((long) 9700);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfHour(0, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfDay(30, (int) '#');
        boolean boolean21 = dateTimeFormatterBuilder20.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendHourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap24 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendTimeZoneShortName(strMap24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatterBuilder9.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(strMap24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        java.lang.Class<?> wildcardClass4 = dateTimeZone3.getClass();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 100, dateTimeZone3);
        org.joda.time.LocalDate localDate7 = localDate5.withDayOfYear(19);
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfWeek();
        org.joda.time.LocalDate localDate9 = property8.withMaximumValue();
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.DateTime dateTime11 = localDate9.toDateTime(localTime10);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.joda.time.DateTime dateTime16 = dateTime14.minusMillis((int) (short) 1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTime();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Partial partial13 = partial8.plus(readablePeriod12);
        org.joda.time.Chronology chronology14 = partial8.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.Partial partial16 = partial8.without(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
        org.junit.Assert.assertNotNull(partial13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(partial16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.joda.time.DurationField durationField15 = property13.getLeapDurationField();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property13.getAsText(locale16);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "18" + "'", str17.equals("18"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        org.joda.time.Partial partial2 = partial0.without(dateTimeFieldType1);
        org.junit.Assert.assertNotNull(partial2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology2.getZone();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone7);
        org.joda.time.LocalDate localDate10 = localDate8.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        long long17 = dateTimeZone13.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime18 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int20 = julianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology19.getZone();
        long long25 = dateTimeZone21.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime26 = dateTime18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime28 = dateTime26.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone29 = dateTime28.getZone();
        org.joda.time.DateTime.Property property30 = dateTime28.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology33);
        int int35 = localDate34.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology38);
        int int40 = localDate39.getYearOfEra();
        int int41 = localDate34.compareTo((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone43);
        org.joda.time.LocalDate localDate46 = localDate44.minusYears((int) 'a');
        boolean boolean47 = localDate34.isAfter((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate49 = localDate34.minus(readablePeriod48);
        org.joda.time.LocalTime localTime50 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology53);
        int int55 = localDate54.getYearOfEra();
        int int56 = localDate54.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int58 = julianChronology57.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone59 = julianChronology57.getZone();
        org.joda.time.Interval interval60 = localDate54.toInterval(dateTimeZone59);
        org.joda.time.DateTime dateTime61 = localDate34.toDateTime(localTime50, dateTimeZone59);
        org.joda.time.DateTime dateTime62 = dateTime28.withZone(dateTimeZone59);
        org.joda.time.Chronology chronology63 = gJChronology2.withZone(dateTimeZone59);
        try {
            long long71 = gJChronology2.getDateTimeMillis(19, 100, 70, 69, 14, 69, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1969 + "'", int40 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1969 + "'", int55 == 1969);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1970 + "'", int56 == 1970);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(interval60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(chronology63);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        int int21 = dateTime20.getMillisOfDay();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(57600097L, (-1L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-57600097) + "'", int2 == (-57600097));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.withMinimumValue();
        org.joda.time.LocalDate.Property property14 = localDate13.era();
        org.joda.time.ReadableInstant readableInstant15 = null;
        try {
            int int16 = property14.getDifference(readableInstant15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText(0, locale14);
        boolean boolean17 = delegatedDateTimeField12.isLeap((long) (-57600097));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField7.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType17);
        long long21 = delegatedDateTimeField18.add((long) 18, (-1));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-86399982L) + "'", long21 == (-86399982L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((long) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int36 = julianChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology35.getZone();
        long long40 = dateTimeZone37.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology45);
        int int47 = localDate46.getYearOfEra();
        int int48 = localDate46.getWeekyear();
        org.joda.time.LocalDate localDate50 = localDate46.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean55 = dateTimeZone53.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime56 = localDate50.toDateTimeAtStartOfDay(dateTimeZone53);
        int int57 = dateTimeZone37.getOffset((org.joda.time.ReadableInstant) dateTime56);
        int int58 = dateTime56.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology61);
        int int63 = localDate62.getYearOfEra();
        int int64 = localDate62.getWeekyear();
        org.joda.time.LocalDate localDate66 = localDate62.minusWeeks(0);
        org.joda.time.LocalDate localDate68 = localDate66.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
        boolean boolean70 = localDate66.isSupported(dateTimeFieldType69);
        org.joda.time.LocalDate.Property property71 = localDate66.centuryOfEra();
        org.joda.time.LocalDate localDate73 = property71.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField74 = property71.getDurationField();
        org.joda.time.LocalDate localDate75 = property71.getLocalDate();
        org.joda.time.DateTime dateTime76 = dateTime56.withFields((org.joda.time.ReadablePartial) localDate75);
        int int77 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate75);
        org.joda.time.DurationField durationField78 = offsetDateTimeField12.getLeapDurationField();
        boolean boolean79 = offsetDateTimeField12.isLenient();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "41" + "'", str34.equals("41"));
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1969 + "'", int47 == 1969);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1970 + "'", int48 == 1970);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1969 + "'", int63 == 1969);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1970 + "'", int64 == 1970);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 11 + "'", int77 == 11);
        org.junit.Assert.assertNull(durationField78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate14 = localDate7.withEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateMidnight dateMidnight19 = localDate17.toDateMidnight(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        int[] intArray23 = localDate22.getValues();
        boolean boolean24 = dateMidnight19.equals((java.lang.Object) localDate22);
        int int25 = localDate22.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate26 = localDate7.withFields((org.joda.time.ReadablePartial) localDate22);
        int int27 = localDate26.getWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
//        int int4 = localDate3.getYearOfEra();
//        int int5 = localDate3.getWeekyear();
//        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
//        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
//        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
//        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
//        org.joda.time.DateTime dateTime16 = property15.getDateTime();
//        int int17 = dateTime16.getHourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.LocalDate localDate17 = property12.withMaximumValue();
        org.joda.time.LocalDate localDate18 = property12.withMinimumValue();
        org.joda.time.DateMidnight dateMidnight19 = localDate18.toDateMidnight();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateMidnight19);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        long long20 = dateTimeZone15.convertLocalToUTC((long) (byte) 0, true, 2592000002L);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone15);
        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
        try {
            long long28 = zonedChronology21.getDateTimeMillis((-97L), (-57600097), 0, 30, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600097 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((long) (byte) 100);
        int int35 = offsetDateTimeField12.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology38);
        int int40 = localDate39.getYearOfEra();
        int int41 = localDate39.getWeekyear();
        org.joda.time.LocalDate localDate43 = localDate39.minusWeeks(0);
        org.joda.time.LocalDate localDate45 = localDate43.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = localDate43.isSupported(dateTimeFieldType46);
        org.joda.time.LocalDate.Property property48 = localDate43.centuryOfEra();
        org.joda.time.LocalDate localDate49 = property48.roundFloorCopy();
        int int50 = property48.get();
        java.util.Locale locale51 = null;
        java.lang.String str52 = property48.getAsText(locale51);
        long long53 = property48.remainder();
        org.joda.time.LocalDate localDate54 = property48.withMinimumValue();
        int[] intArray55 = null;
        int int56 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate54, intArray55);
        int int57 = offsetDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "41" + "'", str34.equals("41"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 41 + "'", int35 == 41);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1969 + "'", int40 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1970 + "'", int41 == 1970);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 19 + "'", int50 == 19);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "19" + "'", str52.equals("19"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-86400000L) + "'", long53 == (-86400000L));
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 41 + "'", int56 == 41);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 11 + "'", int57 == 11);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
//        int int4 = localDate3.getYearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
//        int int9 = localDate8.getYearOfEra();
//        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
//        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
//        org.joda.time.LocalTime localTime19 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
//        int int24 = localDate23.getYearOfEra();
//        int int25 = localDate23.getWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
//        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
//        int int32 = dateTimeZone28.getOffsetFromLocal(2440592L);
//        java.lang.String str34 = dateTimeZone28.getShortName((long) 3840000);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone28.getShortName((long) (byte) 0, locale36);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(interval29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UTC" + "'", str34.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UTC" + "'", str37.equals("UTC"));
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfEra();
        org.joda.time.DurationField durationField4 = iSOChronology1.minutes();
        org.joda.time.DurationField durationField5 = iSOChronology1.years();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime19 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int26 = julianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology25.getZone();
        long long31 = dateTimeZone27.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime32 = localDate24.toDateTimeAtStartOfDay(dateTimeZone27);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int34 = julianChronology33.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology33.getZone();
        long long39 = dateTimeZone35.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime40 = dateTime32.withZone(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime32.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(readableDuration43, (int) (byte) 0);
        org.joda.time.DateTime dateTime46 = dateTime45.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime45);
        try {
            org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((java.lang.Object) iSOChronology1, (org.joda.time.Chronology) gJChronology47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(gJChronology47);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DurationField durationField14 = property13.getDurationField();
        java.util.Locale locale15 = null;
        int int16 = property13.getMaximumShortTextLength(locale15);
        java.util.Locale locale17 = null;
        java.lang.String str18 = property13.getAsShortText(locale17);
        org.joda.time.DurationField durationField19 = property13.getDurationField();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "18" + "'", str18.equals("18"));
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        long long17 = delegatedDateTimeField7.add((long) (byte) 0, 2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 172800000L + "'", long17 == 172800000L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate3 = localDate1.withWeekOfWeekyear(7);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.LocalDate localDate6 = localDate1.withFieldAdded(durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType13);
        boolean boolean16 = delegatedDateTimeField14.isLeap((long) 1969);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField14.getAsShortText(366, locale18);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "366" + "'", str19.equals("366"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        try {
            long long15 = limitChronology5.getDateTimeMillis(366, 1, 10, 1970, 0, (-1), (-70));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime23.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.era();
        org.joda.time.DurationField durationField6 = buddhistChronology2.hours();
        org.joda.time.DurationField durationField7 = buddhistChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("366", "19691231T000000.002+0104", 32, 52);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        int int25 = localDate24.getYearOfEra();
        int int26 = localDate24.getWeekyear();
        org.joda.time.LocalDate localDate28 = localDate24.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean33 = dateTimeZone31.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime34 = localDate28.toDateTimeAtStartOfDay(dateTimeZone31);
        org.joda.time.DateTime dateTime35 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property36 = dateTime35.hourOfDay();
        boolean boolean37 = julianChronology18.equals((java.lang.Object) property36);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded((long) (short) -1, 4);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.plusMinutes(1970);
        org.joda.time.DateTime.Property property21 = dateTime15.minuteOfDay();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190615T152732.506-0700");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        boolean boolean10 = delegatedDateTimeField9.isLenient();
        boolean boolean11 = delegatedDateTimeField9.isLenient();
        long long13 = delegatedDateTimeField9.roundFloor((-1L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField9.getAsText((long) '#', locale15);
        org.joda.time.DateTimeField dateTimeField17 = delegatedDateTimeField9.getWrappedField();
        org.joda.time.DurationField durationField18 = delegatedDateTimeField9.getDurationField();
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField9.getAsShortText((int) (short) -1, locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        org.joda.time.LocalDate localDate26 = localDate24.minusYears((int) 'a');
        java.util.Locale locale28 = null;
        java.lang.String str29 = localDate24.toString("18", locale28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        java.lang.String str34 = gJChronology33.toString();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        long long41 = delegatedDateTimeField38.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField38, (int) (byte) 10);
        boolean boolean44 = offsetDateTimeField43.isLenient();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.minusYears((int) 'a');
        java.util.Locale locale51 = null;
        java.lang.String str52 = localDate47.toString("18", locale51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone54);
        int[] intArray56 = localDate55.getValues();
        int[] intArray57 = localDate55.getValues();
        int int58 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate47, intArray57);
        int[] intArray60 = delegatedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDate24, 0, intArray57, 4);
        jodaTimePermission1.checkGuard((java.lang.Object) localDate24);
        java.lang.String str62 = jodaTimePermission1.toString();
        java.lang.String str63 = jodaTimePermission1.getActions();
        java.lang.Object obj64 = null;
        boolean boolean65 = jodaTimePermission1.equals(obj64);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "18" + "'", str29.equals("18"));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str34.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 345600001L + "'", long41 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "18" + "'", str52.equals("18"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"20190615T152732.506-0700\")" + "'", str62.equals("(\"org.joda.time.JodaTimePermission\" \"20190615T152732.506-0700\")"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter4.withLocale(locale6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", 0, (int) ' ');
        long long6 = fixedDateTimeZone4.nextTransition((long) 856);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) -1);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", 0, (int) ' ');
        long long17 = fixedDateTimeZone15.nextTransition((long) 856);
        int int19 = fixedDateTimeZone15.getOffsetFromLocal((long) (byte) -1);
        java.lang.String str21 = fixedDateTimeZone15.getNameKey(0L);
        int int23 = fixedDateTimeZone15.getOffsetFromLocal((long) 0);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean25 = fixedDateTimeZone4.equals((java.lang.Object) localDate24);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 856L + "'", long6 == 856L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]" + "'", str10.equals("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 856L + "'", long17 == 856L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]" + "'", str21.equals("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GJChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate5.dayOfMonth();
        org.joda.time.LocalDate localDate9 = localDate5.minusWeeks(3840000);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        java.lang.Class<?> wildcardClass4 = dateTimeZone3.getClass();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 100, dateTimeZone3);
        org.joda.time.LocalDate localDate7 = localDate5.withDayOfYear(19);
        org.joda.time.LocalDate.Property property8 = localDate7.dayOfWeek();
        int int9 = localDate7.getDayOfYear();
        java.lang.String str10 = localDate7.toString();
        int int11 = localDate7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-19" + "'", str10.equals("1970-01-19"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.weekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology10.getZone();
        org.joda.time.DateMidnight dateMidnight18 = localDate2.toDateMidnight(dateTimeZone17);
        org.joda.time.LocalDate localDate20 = localDate2.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        int int25 = localDate24.getYearOfEra();
        int int26 = localDate24.getWeekyear();
        org.joda.time.LocalDate localDate28 = localDate24.minusWeeks(0);
        org.joda.time.LocalDate localDate30 = localDate28.minusMonths(1969);
        org.joda.time.Partial partial31 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate28);
        boolean boolean32 = localDate20.isBefore((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate localDate34 = localDate20.withCenturyOfEra(100);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        int int36 = localDate20.indexOf(dateTimeFieldType35);
        org.joda.time.LocalDate.Property property37 = localDate20.monthOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(property37);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190615T152732.506-0700");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        boolean boolean10 = delegatedDateTimeField9.isLenient();
        boolean boolean11 = delegatedDateTimeField9.isLenient();
        long long13 = delegatedDateTimeField9.roundFloor((-1L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField9.getAsText((long) '#', locale15);
        org.joda.time.DateTimeField dateTimeField17 = delegatedDateTimeField9.getWrappedField();
        org.joda.time.DurationField durationField18 = delegatedDateTimeField9.getDurationField();
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField9.getAsShortText((int) (short) -1, locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        org.joda.time.LocalDate localDate26 = localDate24.minusYears((int) 'a');
        java.util.Locale locale28 = null;
        java.lang.String str29 = localDate24.toString("18", locale28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, readableInstant32);
        java.lang.String str34 = gJChronology33.toString();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        long long41 = delegatedDateTimeField38.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField38, (int) (byte) 10);
        boolean boolean44 = offsetDateTimeField43.isLenient();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.minusYears((int) 'a');
        java.util.Locale locale51 = null;
        java.lang.String str52 = localDate47.toString("18", locale51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone54);
        int[] intArray56 = localDate55.getValues();
        int[] intArray57 = localDate55.getValues();
        int int58 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate47, intArray57);
        int[] intArray60 = delegatedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDate24, 0, intArray57, 4);
        jodaTimePermission1.checkGuard((java.lang.Object) localDate24);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone63);
        int[] intArray65 = localDate64.getValues();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone67);
        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology68);
        boolean boolean70 = localDate64.isEqual((org.joda.time.ReadablePartial) localDate69);
        boolean boolean71 = jodaTimePermission1.equals((java.lang.Object) localDate64);
        java.security.PermissionCollection permissionCollection72 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "18" + "'", str29.equals("18"));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str34.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 345600001L + "'", long41 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "18" + "'", str52.equals("18"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(iSOChronology68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(permissionCollection72);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfMinute(14, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime21.plusMillis(2);
        org.joda.time.DateTime dateTime27 = dateTime25.minus((long) 9700);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.LocalDate localDate21 = dateTime12.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate21.plus(readablePeriod22);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateMidnight dateMidnight18 = localDate16.toDateMidnight(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        int[] intArray22 = localDate21.getValues();
        boolean boolean23 = dateMidnight18.equals((java.lang.Object) localDate21);
        int int24 = localDate21.getWeekOfWeekyear();
        int int25 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        java.lang.String str27 = offsetDateTimeField12.getAsShortText((long) (short) 1);
        long long30 = offsetDateTimeField12.getDifferenceAsLong((long) 3840000, 999L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 41 + "'", int25 == 41);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "41" + "'", str27.equals("41"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        java.lang.String str12 = dateTimeZone10.getID();
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology16);
        int int18 = localDate17.getYearOfEra();
        int int19 = localDate17.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        org.joda.time.Interval interval23 = localDate17.toInterval(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int30 = julianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology29.getZone();
        long long35 = dateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime36 = localDate28.toDateTimeAtStartOfDay(dateTimeZone31);
        org.joda.time.DateTime.Property property37 = dateTime36.centuryOfEra();
        org.joda.time.DateTime dateTime39 = dateTime36.minus(100L);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded(readableDuration40, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) dateTime42, 1);
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime42.toMutableDateTime();
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int47 = julianChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology46.getZone();
        long long51 = dateTimeZone48.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology56);
        int int58 = localDate57.getYearOfEra();
        int int59 = localDate57.getWeekyear();
        org.joda.time.LocalDate localDate61 = localDate57.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean66 = dateTimeZone64.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime67 = localDate61.toDateTimeAtStartOfDay(dateTimeZone64);
        int int68 = dateTimeZone48.getOffset((org.joda.time.ReadableInstant) dateTime67);
        int int69 = dateTime67.getMillisOfSecond();
        org.joda.time.DateTime dateTime71 = dateTime67.plusMillis(2);
        org.joda.time.DateTime dateTime73 = dateTime67.plusDays((int) '#');
        org.joda.time.chrono.LimitChronology limitChronology74 = org.joda.time.chrono.LimitChronology.getInstance(chronology13, (org.joda.time.ReadableDateTime) dateTime42, (org.joda.time.ReadableDateTime) dateTime73);
        org.joda.time.DateTime dateTime75 = dateTime73.toDateTime();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(interval23);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1969 + "'", int58 == 1969);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1970 + "'", int59 == 1970);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(limitChronology74);
        org.junit.Assert.assertNotNull(dateTime75);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTimeField dateTimeField6 = limitChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology5.monthOfYear();
        org.joda.time.Chronology chronology8 = limitChronology5.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime19 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        long long26 = dateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime29 = dateTime27.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone30 = dateTime29.getZone();
        org.joda.time.DateMidnight dateMidnight31 = localDate6.toDateMidnight(dateTimeZone30);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateMidnight31);
        org.junit.Assert.assertNotNull(iSOChronology32);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.Chronology chronology4 = gJChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12" + "'", str2.equals("1969-12"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.DateTime.Property property14 = dateTime13.centuryOfEra();
        org.joda.time.DateTime dateTime16 = dateTime13.withYearOfCentury((int) (short) 1);
        int int17 = dateTime16.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime16.getZone();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = localDate20.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        org.joda.time.Partial partial26 = new org.joda.time.Partial(dateTimeFieldTypeArray21, intArray25);
        org.joda.time.Chronology chronology27 = partial26.getChronology();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2922789, chronology27);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology31);
        int int33 = localDate32.getYearOfEra();
        int int34 = localDate32.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int36 = julianChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology35.getZone();
        org.joda.time.Interval interval38 = localDate32.toInterval(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone40);
        org.joda.time.LocalDate localDate43 = localDate41.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int45 = julianChronology44.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone46 = julianChronology44.getZone();
        long long50 = dateTimeZone46.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime51 = localDate43.toDateTimeAtStartOfDay(dateTimeZone46);
        org.joda.time.DateTime.Property property52 = dateTime51.centuryOfEra();
        org.joda.time.DateTime dateTime54 = dateTime51.minus(100L);
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.DateTime dateTime57 = dateTime54.withDurationAdded(readableDuration55, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime57, 1);
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int61 = julianChronology60.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone62 = julianChronology60.getZone();
        long long65 = dateTimeZone62.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone69);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology70);
        int int72 = localDate71.getYearOfEra();
        int int73 = localDate71.getWeekyear();
        org.joda.time.LocalDate localDate75 = localDate71.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean80 = dateTimeZone78.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime81 = localDate75.toDateTimeAtStartOfDay(dateTimeZone78);
        int int82 = dateTimeZone62.getOffset((org.joda.time.ReadableInstant) dateTime81);
        int int83 = dateTime81.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.chrono.ISOChronology iSOChronology85 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone84);
        org.joda.time.DurationField durationField86 = iSOChronology85.seconds();
        org.joda.time.DateTime dateTime87 = dateTime81.withChronology((org.joda.time.Chronology) iSOChronology85);
        org.joda.time.DateTime.Property property88 = dateTime87.hourOfDay();
        int int89 = dateTime87.getHourOfDay();
        boolean boolean90 = gJChronology59.equals((java.lang.Object) dateTime87);
        boolean boolean91 = dateTime28.isBefore((org.joda.time.ReadableInstant) dateTime87);
        org.joda.time.DateTime.Property property92 = dateTime87.dayOfYear();
        org.joda.time.Instant instant93 = dateTime87.toInstant();
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1970 + "'", int34 == 1970);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(interval38);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1970 + "'", int73 == 1970);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(iSOChronology85);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(property88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 14 + "'", int89 == 14);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(property92);
        org.junit.Assert.assertNotNull(instant93);
    }
}

