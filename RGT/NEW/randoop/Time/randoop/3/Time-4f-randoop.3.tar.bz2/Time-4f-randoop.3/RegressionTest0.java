import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, (int) (short) 1, (int) '4', (int) (short) 1, (int) (short) -1, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, (java.lang.Number) 0.0d, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray3 = new int[] { 10 };
        try {
            org.joda.time.Partial partial4 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null: index 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField1 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long9 = julianChronology0.getDateTimeMillis((int) '#', 1, (int) '4', (-1), 1, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.centuries();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        try {
            org.joda.time.DateTimeField dateTimeField5 = localDate3.getField((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GJChronology[America/Los_Angeles]", (int) (short) 100, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for GJChronology[America/Los_Angeles] must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long7 = iSOChronology1.getDateTimeMillis(1L, (int) (byte) 100, 0, (int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        try {
            org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        long long5 = durationField2.subtract((long) 1, (long) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3155674021999L) + "'", long5 == (-3155674021999L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.centuries();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology4, readableDateTime6, readableDateTime7);
        try {
            org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray2, (org.joda.time.Chronology) limitChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(limitChronology8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        try {
            org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190615T152732.506-0700" + "'", str4.equals("20190615T152732.506-0700"));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 0, 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) buddhistChronology0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            int int6 = localDate4.get(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        long long22 = dateTimeZone18.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime23 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int[] intArray25 = null;
        try {
            int[] intArray27 = delegatedDateTimeField7.addWrapField((org.joda.time.ReadablePartial) localDate15, (int) (short) -1, intArray25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("20190615T152732.506-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20190615T152732.506-0700\" is malformed at \"2732.506-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePeriod3, (long) 'a', (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1970, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        try {
            long long10 = gJChronology2.getDateTimeMillis((int) (short) 100, 0, (int) (short) 1, 1969, 1970, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            int int24 = dateTime22.get(dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        try {
            org.joda.time.LocalDate localDate6 = localDate2.withEra(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "20190615T152732.506-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        try {
            long long13 = delegatedDateTimeField7.set((-1L), "19691231T������.000");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"19691231T������.000\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis((int) ' ', 1970, 0, (int) (short) 1, (int) (byte) 0, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        long long29 = dateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime22.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfCentury((int) '4');
        int int35 = dateMidnight4.compareTo((org.joda.time.ReadableInstant) dateTime34);
        int int36 = dateMidnight4.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            boolean boolean13 = localDate7.isAfter(readablePartial12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        try {
            org.joda.time.DateTimeField dateTimeField11 = localDate9.getField((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 100");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology8.centuries();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) -1, (int) '#', (int) (short) 1, 1969, (int) (byte) 0, (int) '4', 0, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = delegatedDateTimeField7.getAsShortText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        long long29 = dateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime22.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfCentury((int) '4');
        int int35 = dateMidnight4.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeZone dateTimeZone36 = dateMidnight4.getZone();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 'a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate8.getWeekyear();
        org.joda.time.LocalDate localDate12 = localDate8.minusWeeks(0);
        org.joda.time.LocalDate localDate14 = localDate12.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = localDate12.isSupported(dateTimeFieldType15);
        org.joda.time.DateTime dateTime17 = localDate12.toDateTimeAtCurrentTime();
        try {
            dateTimeFormatter3.printTo(appendable4, (org.joda.time.ReadablePartial) localDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.centuries();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.DurationField durationField7 = iSOChronology2.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField9 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField7, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.DateTime dateTime6 = localDate4.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.minuteOfHour();
        int int28 = dateTime25.get(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        java.util.Locale locale14 = null;
        try {
            org.joda.time.LocalDate localDate15 = property12.setCopy("19691231T������.000", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"19691231T������.000\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        try {
            long long14 = limitChronology5.getDateTimeMillis((-3155674021999L), (int) (byte) 10, (int) (short) 100, 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime14 = localDate6.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.joda.time.DateTime dateTime17 = dateTime14.withYearOfCentury((int) (short) 1);
        int int18 = dateTime17.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readablePeriod19);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (byte) 0);
        int int19 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.LocalDate localDate21 = localDate16.withEra(0);
        int[] intArray27 = new int[] { 4, 'a', (byte) 1, 30 };
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = delegatedDateTimeField12.set((org.joda.time.ReadablePartial) localDate21, 100, intArray27, "BuddhistChronology[America/Los_Angeles]", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[America/Los_Angeles]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withHourOfDay(0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone17);
        int[] intArray19 = localDate18.getValues();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        boolean boolean24 = localDate18.isEqual((org.joda.time.ReadablePartial) localDate23);
        try {
            int int25 = property15.compareTo((org.joda.time.ReadablePartial) localDate23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField[] dateTimeFieldArray4 = localDate3.getFields();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.DateTime dateTime21 = dateTime15.withFieldAdded(durationFieldType19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        try {
            long long12 = limitChronology5.getDateTimeMillis((long) 2, 0, (int) (byte) -1, 1969, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int10 = julianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology9.getZone();
        org.joda.time.Chronology chronology12 = gregorianChronology8.withZone(dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, 7, 1970, (int) (byte) 100, 100, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        int int12 = delegatedDateTimeField7.getLeapAmount((long) 2000);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (byte) 0);
        int int19 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.LocalDate.Property property20 = localDate18.dayOfMonth();
        int[] intArray22 = null;
        try {
            int[] intArray24 = delegatedDateTimeField7.addWrapField((org.joda.time.ReadablePartial) localDate18, (int) (byte) 10, intArray22, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"31\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = dateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.withYearOfCentury((int) (short) 1);
        int int19 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.DurationField durationField3 = iSOChronology1.months();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("19691231T������.000", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19691231T������.000\" is malformed at \"691231T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        try {
            org.joda.time.DateTime dateTime27 = dateTime22.withTime(0, 0, (int) (short) -1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology5);
        int int7 = localDate6.getYearOfEra();
        boolean boolean8 = buddhistChronology0.equals((java.lang.Object) int7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        int int10 = localDate7.getWeekOfWeekyear();
        try {
            java.lang.String str12 = localDate7.toString("20190615T152732.506-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField7.getAsShortText(10L, locale12);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31" + "'", str13.equals("31"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsShortText((long) 2000, locale13);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        org.joda.time.LocalDate localDate14 = localDate11.plusWeeks((-1));
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone17);
        int[] intArray19 = localDate18.getValues();
        try {
            int[] intArray21 = delegatedDateTimeField7.add((org.joda.time.ReadablePartial) localDate14, 1969, intArray19, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, (int) (byte) 1, 4, (int) (short) 1, (-1), (int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = dateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.withYearOfCentury((int) (short) 1);
        int int19 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        java.lang.Class<?> wildcardClass20 = dateTimeZone2.getClass();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0, 0, 9700);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        try {
            long long13 = gJChronology2.getDateTimeMillis(1969, (int) (short) 1, 10, (int) (byte) 1, (int) (short) -1, 30, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfMinute();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 30, (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for secondOfMinute must be in the range [32,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10L, number2, (java.lang.Number) (-1295999990L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate8.getWeekyear();
        org.joda.time.LocalDate localDate12 = localDate8.minusWeeks(0);
        org.joda.time.LocalDate localDate14 = localDate12.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = localDate12.isSupported(dateTimeFieldType15);
        org.joda.time.DateTime dateTime17 = localDate12.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(2);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime17.plus(readableDuration20);
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology6);
        try {
            org.joda.time.LocalDate localDate11 = dateTimeFormatter9.parseLocalDate("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\" is malformed at \":00:00.010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        try {
            long long38 = gJChronology30.getDateTimeMillis(1, (int) 'a', 2000, (int) '4', (int) (short) 0, (int) '4', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = buddhistChronology0.get(readablePeriod2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 1970, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) (short) 0);
        org.joda.time.DurationField durationField10 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, durationField10, dateTimeFieldType11, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        java.lang.String str9 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDate8);
        java.lang.String str10 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDate8);
        try {
            org.joda.time.Instant instant11 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19691231T������.000" + "'", str10.equals("19691231T������.000"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Partial partial11 = partial8.withFieldAdded(durationFieldType9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        boolean boolean26 = dateTime24.isAfterNow();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("GregorianChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeDivide((-57600000L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime.Property property15 = dateTime12.minuteOfDay();
        java.util.Locale locale17 = null;
        try {
            org.joda.time.DateTime dateTime18 = property15.setCopy("GregorianChronology[UTC]", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.Partial partial11 = partial8.withField(dateTimeFieldType9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 0, (int) (short) 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime24.minusMinutes(2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.LocalDate localDate6 = localDate2.withFieldAdded(durationFieldType4, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Partial partial11 = partial8.withFieldAdded(durationFieldType9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        java.lang.String str16 = gJChronology15.toString();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        int int21 = dateTime12.get(dateTimeField18);
        try {
            org.joda.time.DateTime dateTime23 = dateTime12.withEra((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str16.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        try {
            long long11 = gregorianChronology3.getDateTimeMillis(0, (int) (byte) -1, (int) (byte) 1, (int) '#', 30, 2, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        try {
            long long14 = limitChronology5.getDateTimeMillis(0, (int) (byte) 100, (int) ' ', 10, (int) (short) 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        try {
            long long13 = limitChronology5.getDateTimeMillis((-1), (-1), (int) (short) 0, 1852);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        int int12 = delegatedDateTimeField7.getLeapAmount((long) 2000);
        boolean boolean14 = delegatedDateTimeField7.isLeap((long) 100);
        int int15 = delegatedDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int int3 = localDate2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        int int23 = dateTime22.getYearOfEra();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1872 + "'", int23 == 1872);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.Partial partial14 = partial11.withFieldAdded(durationFieldType12, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(9700, (int) (short) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        int[] intArray20 = localDate19.getValues();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(chronology21);
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) '4');
        try {
            org.joda.time.DateTime dateTime28 = dateTime24.withDate(0, (int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = limitChronology5.withZone(dateTimeZone10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.LocalDate localDate12 = localDate9.withFieldAdded(durationFieldType10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        try {
            long long17 = delegatedDateTimeField7.set((-3155674021999L), "UTC");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        java.lang.String str4 = gJChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) julianChronology0, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) periodType6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = dateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.withYearOfCentury((int) (short) 1);
        int int19 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        boolean boolean20 = dateTime18.isBeforeNow();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeDivide((long) 1872, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 10);
        long long7 = dateTimeZone2.convertLocalToUTC((long) (byte) 100, false);
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (-3839900L), 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3839900L) + "'", long7 == (-3839900L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DurationField durationField14 = property13.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone16);
        org.joda.time.LocalDate localDate19 = localDate17.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int21 = julianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology20.getZone();
        long long26 = dateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime27 = localDate19.toDateTimeAtStartOfDay(dateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int29 = julianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology28.getZone();
        long long34 = dateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime35 = dateTime27.withZone(dateTimeZone30);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury(0);
        int int38 = property13.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        int int40 = property13.getDifference(readableInstant39);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = dateTime12.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime21.plusMillis(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology29);
        java.lang.String str31 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.year();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology32.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) buddhistChronology32);
        java.lang.String str36 = dateTime25.toString(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19691231T������.000" + "'", str31.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "19691231T000000.002+0104" + "'", str36.equals("19691231T000000.002+0104"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        long long19 = dateTime15.getMillis();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3061065600100L) + "'", long19 == (-3061065600100L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText(0, locale14);
        int int16 = delegatedDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone6);
        int[] intArray8 = localDate7.getValues();
        boolean boolean9 = dateMidnight4.equals((java.lang.Object) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        long long29 = dateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime22.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfCentury((int) '4');
        int int35 = dateMidnight4.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property36 = dateTime34.yearOfEra();
        org.joda.time.DateTime dateTime37 = property36.getDateTime();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        try {
            long long9 = buddhistChronology0.getDateTimeMillis((int) ' ', 30, 0, (int) 'a', (int) (short) -1, (int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("19691231T������.000", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19691231T������.000\" is malformed at \"1231T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = limitChronology5.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.Instant instant30 = instant25.plus((-3839992L));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant30);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter0.printTo(appendable6, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = copticChronology0.toString();
        try {
            long long10 = copticChronology0.getDateTimeMillis(1, 3, 100, (int) (byte) 1, 1, 2000, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        long long10 = limitChronology5.add((long) 1852, (long) 1, 4);
        try {
            long long18 = limitChronology5.getDateTimeMillis(3, 0, 31, 2000, (int) '#', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1856L + "'", long10 == 1856L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.LocalDate localDate18 = localDate3.minusYears(10);
        try {
            org.joda.time.LocalDate localDate20 = localDate3.withMonthOfYear((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField12.getMaximumTextLength(locale13);
        boolean boolean15 = delegatedDateTimeField12.isLenient();
        int int17 = delegatedDateTimeField12.get((long) 2);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long23 = dateTimeZone20.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, (int) (short) 1);
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology30);
        int int32 = localDate31.getYearOfEra();
        org.joda.time.LocalDate localDate34 = localDate31.plusWeeks((-1));
        int[] intArray35 = localDate31.getValues();
        try {
            int[] intArray37 = delegatedDateTimeField12.set((org.joda.time.ReadablePartial) partial26, (int) (byte) 1, intArray35, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException5.getSuppressed();
        java.lang.String str7 = illegalFieldValueException5.getIllegalValueAsString();
        boolean boolean8 = copticChronology0.equals((java.lang.Object) str7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone10);
        org.joda.time.LocalDate localDate13 = localDate11.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int23 = julianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology22.getZone();
        long long28 = dateTimeZone24.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime21.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded(readableDuration32, (int) (byte) 0);
        boolean boolean35 = copticChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology0.weekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfCentury((int) (short) 1);
        int int26 = dateTime25.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        boolean boolean29 = localDate9.equals((java.lang.Object) julianChronology28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        try {
            int[] intArray33 = julianChronology28.get(readablePeriod30, (long) (short) -1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        long long15 = property12.remainder();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-86400000L) + "'", long15 == (-86400000L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.clockhourOfDay();
        try {
            org.joda.time.Instant instant20 = new org.joda.time.Instant((java.lang.Object) dateTimeField19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.ZeroIsMaxDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 10);
        java.lang.String str6 = dateTimeZone2.getName((long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+01:04" + "'", str6.equals("+01:04"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-100L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.centuryOfEra();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        boolean boolean8 = julianChronology0.equals((java.lang.Object) chronology7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        int int12 = delegatedDateTimeField7.getLeapAmount((long) 2000);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        java.util.Locale locale19 = null;
        java.lang.String str20 = localDate15.toString("18", locale19);
        int int21 = delegatedDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDate15);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "18" + "'", str20.equals("18"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(345600001L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440592L + "'", long1 == 2440592L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.Chronology chronology10 = gregorianChronology6.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DurationField durationField12 = gregorianChronology6.days();
        org.joda.time.Chronology chronology13 = gregorianChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) chronology1, chronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.monthOfYear();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = localDate7.isSupported(durationFieldType11);
        int int13 = localDate7.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.LocalDate localDate21 = localDate19.withYearOfCentury(8);
        try {
            org.joda.time.LocalDate localDate23 = localDate21.withDayOfMonth(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime28.toYearMonthDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        long long7 = dateTimeZone4.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int11 = julianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField12, (int) '4');
        org.joda.time.DurationField durationField15 = skipUndoDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, durationField15, dateTimeFieldType16, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(readableDuration36, (int) (byte) 0);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime38);
        java.lang.String str41 = gJChronology40.toString();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]" + "'", str41.equals("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(57600097L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        long long14 = delegatedDateTimeField7.roundHalfCeiling((long) 856);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfEven(28800000L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28800000L + "'", long29 == 28800000L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withDefaultYear(856);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������.000" + "'", str5.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) (short) 0);
        boolean boolean11 = delegatedDateTimeField7.isLeap(0L);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField7.getMaximumShortTextLength(locale12);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone8);
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime19 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone21);
        org.joda.time.LocalDate localDate24 = localDate22.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int26 = julianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology25.getZone();
        long long31 = dateTimeZone27.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime32 = localDate24.toDateTimeAtStartOfDay(dateTimeZone27);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int34 = julianChronology33.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology33.getZone();
        long long39 = dateTimeZone35.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime40 = dateTime32.withZone(dateTimeZone35);
        org.joda.time.DateTime dateTime42 = dateTime32.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(readableDuration43, (int) (byte) 0);
        org.joda.time.DateTime dateTime46 = dateTime45.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime45);
        try {
            org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(31, (int) '#', 11, 100, (int) (short) 0, 9700, 1, (org.joda.time.Chronology) gJChronology47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(gJChronology47);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology30);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int14 = offsetDateTimeField12.get((long) (short) 100);
        long long16 = offsetDateTimeField12.roundCeiling(10L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 41 + "'", int14 == 41);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime14 = localDate6.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = dateTime14.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime24 = dateTime22.minus((-100L));
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.LocalDate localDate6 = localDate3.plusWeeks((-1));
        org.joda.time.LocalDate localDate8 = localDate6.plusYears((int) (byte) 100);
        try {
            org.joda.time.LocalDate localDate10 = localDate8.withDayOfYear(1852);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1852 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Object obj0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(obj0, chronology1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-86400000L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        int int37 = skipUndoDateTimeField12.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.DateTime dateTime27 = dateTime24.withFieldAdded(durationFieldType25, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType15, 856, 19, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.withMaximumValue();
        int int14 = localDate13.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = iSOChronology25.seconds();
        org.joda.time.DateTime dateTime27 = dateTime21.withChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTime.Property property28 = dateTime27.hourOfDay();
        java.util.Locale locale30 = null;
        try {
            org.joda.time.DateTime dateTime31 = property28.setCopy("32", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 2592000002L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalDate localDate20 = localDate3.minusDays((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = iSOChronology22.centuries();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.DateTime dateTime27 = limitChronology26.getUpperLimit();
        org.joda.time.DateTime dateTime28 = limitChronology26.getUpperLimit();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int30 = julianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology29.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.Chronology chronology33 = limitChronology26.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = localDate3.toDateTimeAtMidnight(dateTimeZone31);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        try {
            int int36 = localDate3.get(dateTimeFieldType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNull(dateTime27);
        org.junit.Assert.assertNull(dateTime28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusYears(0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone18);
        int[] intArray20 = localDate19.getValues();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean27 = localDate19.equals((java.lang.Object) dateTimeFormatter26);
        boolean boolean28 = localDate16.isBefore((org.joda.time.ReadablePartial) localDate19);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury((int) '4');
        boolean boolean38 = dateTime12.isBefore((org.joda.time.ReadableInstant) dateTime35);
        try {
            java.lang.String str40 = dateTime35.toString("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: O");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology39);
        int int41 = localDate40.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology44);
        int int46 = localDate45.getYearOfEra();
        int int47 = localDate40.compareTo((org.joda.time.ReadablePartial) localDate45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone49);
        org.joda.time.LocalDate localDate52 = localDate50.minusYears((int) 'a');
        boolean boolean53 = localDate40.isAfter((org.joda.time.ReadablePartial) localDate50);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate40.minus(readablePeriod54);
        org.joda.time.LocalTime localTime56 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology59);
        int int61 = localDate60.getYearOfEra();
        int int62 = localDate60.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int64 = julianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology63.getZone();
        org.joda.time.Interval interval66 = localDate60.toInterval(dateTimeZone65);
        org.joda.time.DateTime dateTime67 = localDate40.toDateTime(localTime56, dateTimeZone65);
        org.joda.time.LocalTime localTime68 = null;
        org.joda.time.DateTime dateTime69 = localDate40.toDateTime(localTime68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localTime68, (int) ' ', locale71);
        int int74 = skipUndoDateTimeField12.get((long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1970 + "'", int62 == 1970);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(interval66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "32" + "'", str72.equals("32"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DurationField durationField8 = limitChronology5.halfdays();
        try {
            long long16 = limitChronology5.getDateTimeMillis(0, 9700, 0, 4, (int) 'a', (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = buddhistChronology0.get(readablePeriod3, (long) (short) 0, (-3155674021999L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 9700, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
        int int15 = skipUndoDateTimeField12.get(1856L);
        long long17 = skipUndoDateTimeField12.roundCeiling(100L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 856 + "'", int15 == 856);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        try {
            long long8 = gJChronology2.getDateTimeMillis(100, 1872, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1872 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int13 = offsetDateTimeField12.getOffset();
        try {
            long long16 = offsetDateTimeField12.set(10L, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfMonth must be in the range [11,41]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate2.minusYears((int) '4');
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology9);
        int int11 = localDate10.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology14);
        int int16 = localDate15.getYearOfEra();
        int int17 = localDate10.compareTo((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone19);
        org.joda.time.LocalDate localDate22 = localDate20.minusYears((int) 'a');
        boolean boolean23 = localDate10.isAfter((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate25 = localDate10.minus(readablePeriod24);
        org.joda.time.LocalTime localTime26 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology29);
        int int31 = localDate30.getYearOfEra();
        int int32 = localDate30.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int34 = julianChronology33.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology33.getZone();
        org.joda.time.Interval interval36 = localDate30.toInterval(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate10.toDateTime(localTime26, dateTimeZone35);
        org.joda.time.DateTime dateTime38 = dateTime37.toDateTimeISO();
        int int39 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime37);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(interval36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3840000 + "'", int39 == 3840000);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute(4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = buddhistChronology26.withUTC();
        org.joda.time.Chronology chronology28 = buddhistChronology26.withUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = buddhistChronology26.getZone();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime25.toMutableDateTime((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.DateTime dateTime32 = dateTime25.plusWeeks(1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        long long14 = delegatedDateTimeField12.roundFloor((-1295999990L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1353600000L) + "'", long14 == (-1353600000L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        long long16 = delegatedDateTimeField7.roundCeiling((-100L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone32);
        org.joda.time.LocalDate localDate35 = localDate33.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int37 = julianChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology36.getZone();
        long long42 = dateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime43 = localDate35.toDateTimeAtStartOfDay(dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone45);
        org.joda.time.LocalDate localDate48 = localDate46.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int50 = julianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone51 = julianChronology49.getZone();
        long long55 = dateTimeZone51.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime56 = localDate48.toDateTimeAtStartOfDay(dateTimeZone51);
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int58 = julianChronology57.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone59 = julianChronology57.getZone();
        long long63 = dateTimeZone59.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime64 = dateTime56.withZone(dateTimeZone59);
        org.joda.time.DateTime dateTime66 = dateTime56.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration67 = null;
        org.joda.time.DateTime dateTime69 = dateTime66.withDurationAdded(readableDuration67, (int) (byte) 0);
        org.joda.time.DateTime dateTime70 = dateTime69.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) dateTime69);
        org.joda.time.DateTime dateTime72 = dateTime28.withChronology((org.joda.time.Chronology) gJChronology71);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTime72);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
        int int15 = skipUndoDateTimeField12.get(1856L);
        java.util.Locale locale16 = null;
        int int17 = skipUndoDateTimeField12.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 856 + "'", int15 == 856);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        int int19 = localDate3.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 69 + "'", int19 == 69);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.plus(readableDuration15);
        org.joda.time.DateTime dateTime20 = dateTime12.withDate(2, 4, (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        try {
            org.joda.time.LocalTime localTime30 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        java.lang.String str16 = gJChronology15.toString();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        int int21 = dateTime12.get(dateTimeField18);
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTime dateTime23 = dateTime12.withFields(readablePartial22);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str16.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("19691231T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19691231T������.000\" is malformed at \"691231T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 856, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate16.getFields();
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int39 = julianChronology38.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone40 = julianChronology38.getZone();
        long long43 = dateTimeZone40.adjustOffset((long) 0, true);
        long long46 = dateTimeZone40.adjustOffset((-100L), false);
        org.joda.time.Interval interval47 = localDate16.toInterval(dateTimeZone40);
        int int48 = localDate16.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-100L) + "'", long46 == (-100L));
        org.junit.Assert.assertNotNull(interval47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        long long29 = dateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime22.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfCentury((int) '4');
        org.joda.time.Instant instant35 = new org.joda.time.Instant((java.lang.Object) dateTime34);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.Instant instant38 = instant35.withDurationAdded(readableDuration36, 1852);
        try {
            org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) instant38, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(instant38);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays(100);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 4, "[]");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute(4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = buddhistChronology26.withUTC();
        org.joda.time.Chronology chronology28 = buddhistChronology26.withUTC();
        org.joda.time.DateTimeZone dateTimeZone29 = buddhistChronology26.getZone();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime25.toMutableDateTime((org.joda.time.Chronology) buddhistChronology26);
        int int31 = mutableDateTime30.getEra();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        java.lang.Appendable appendable29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, readableInstant31);
        java.lang.String str33 = gJChronology32.toString();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology32.dayOfMonth();
        org.joda.time.Instant instant36 = gJChronology32.getGregorianCutover();
        try {
            dateTimeFormatter0.printTo(appendable29, (org.joda.time.ReadableInstant) instant36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str33.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(instant36);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (-1295998148L), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 19, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.Instant instant4 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimeField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.PreciseDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField dateTimeField37 = skipUndoDateTimeField12.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType38, 0, (int) (byte) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.Partial partial14 = partial8.withFieldAddWrapped(durationFieldType12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = localDate3.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.monthOfYear();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = localDate7.isSupported(durationFieldType11);
        org.joda.time.LocalDate localDate14 = localDate7.minusYears(19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.Partial.Property property2 = partial0.property(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.LocalDate localDate8 = property5.setCopy("CopticChronology[America/Los_Angeles]", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[America/Los_Angeles]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField12.getMaximumTextLength(locale13);
        long long17 = delegatedDateTimeField12.getDifferenceAsLong((long) (-1), (long) (byte) -1);
        int int19 = delegatedDateTimeField12.get((-3839992L));
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField12.getAsShortText(0, locale21);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfEra();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int5 = julianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long9 = dateTimeZone6.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DurationField durationField12 = gregorianChronology11.hours();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, durationField12, dateTimeFieldType13, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (short) 0);
        org.joda.time.DateTimeField dateTimeField16 = property13.getField();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        java.lang.Class<?> wildcardClass4 = dateTimeZone3.getClass();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) 100, dateTimeZone3);
        org.joda.time.LocalDate localDate7 = localDate5.withDayOfYear(19);
        int int8 = localDate7.getYearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = localDate1.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        java.lang.String str2 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[UTC]" + "'", str2.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) 10);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        int int5 = localDate4.getYearOfEra();
        int int6 = localDate4.getWeekyear();
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(0);
        org.joda.time.LocalDate localDate10 = localDate8.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = localDate8.isSupported(dateTimeFieldType11);
        org.joda.time.LocalDate.Property property13 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate15 = property13.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        long long19 = durationField16.subtract((long) (byte) 1, (-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField16, dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3155760000001L + "'", long19 == 3155760000001L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("00:01:00.000Z");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateMidnight dateMidnight28 = localDate26.toDateMidnight(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone30);
        int[] intArray32 = localDate31.getValues();
        boolean boolean33 = dateMidnight28.equals((java.lang.Object) localDate31);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateMidnight dateMidnight38 = localDate36.toDateMidnight(dateTimeZone37);
        boolean boolean39 = dateMidnight28.isEqual((org.joda.time.ReadableInstant) dateMidnight38);
        org.joda.time.ReadableInstant readableInstant40 = null;
        boolean boolean41 = dateMidnight28.isAfter(readableInstant40);
        int int42 = property23.getDifference((org.joda.time.ReadableInstant) dateMidnight28);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateMidnight38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-88885920) + "'", int42 == (-88885920));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = limitChronology5.hourOfDay();
        org.joda.time.DateTime dateTime10 = limitChronology5.getUpperLimit();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(dateTime10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = julianChronology0.halfdays();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(3155760000001L, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 31557600000010");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = dateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime15 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.minus(100L);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded(readableDuration19, (int) (byte) -1);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfDay();
        org.joda.time.DateTime.Property property23 = dateTime21.dayOfMonth();
        java.lang.String str24 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "18721230T235959.900Z" + "'", str24.equals("18721230T235959.900Z"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        int int29 = offsetDateTimeField12.getMinimumValue((long) 7);
        boolean boolean31 = offsetDateTimeField12.isLeap((long) (short) 100);
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((int) (byte) 100, locale33);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "100" + "'", str34.equals("100"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime13 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean8 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean10 = localDate2.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            int int12 = localDate2.get(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "32");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.LocalTime localTime31 = null;
        org.joda.time.DateTime dateTime32 = localDate3.toDateTime(localTime31);
        try {
            org.joda.time.LocalDate localDate34 = localDate3.withYearOfCentury(856);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 856 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime26 = dateTime22.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) 1969, 3);
        org.joda.time.DateTime dateTime31 = dateTime26.withCenturyOfEra((int) ' ');
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        org.joda.time.LocalDate localDate16 = property12.getLocalDate();
        int int17 = property12.getLeapAmount();
        java.lang.String str18 = property12.getAsShortText();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19" + "'", str18.equals("19"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.Instant instant30 = instant25.minus((long) 1872);
        org.joda.time.Chronology chronology31 = instant25.getChronology();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone9);
        org.joda.time.LocalDate localDate12 = localDate10.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = localDate12.toDateTimeAtStartOfDay(dateTimeZone15);
        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.minus(readableDuration24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime20);
        boolean boolean28 = dateTimeZone2.isStandardOffset((long) (short) 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.Chronology chronology10 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNull(chronology10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        java.util.Locale locale6 = null;
        java.lang.String str7 = localDate2.toString("18", locale6);
        try {
            org.joda.time.LocalDate localDate9 = localDate2.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "18" + "'", str7.equals("18"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(readableDuration36, (int) (byte) 0);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology43);
        int int45 = localDate44.getYearOfEra();
        int int46 = localDate44.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int48 = julianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone49 = julianChronology47.getZone();
        org.joda.time.Interval interval50 = localDate44.toInterval(dateTimeZone49);
        java.lang.String str51 = dateTimeZone49.getID();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone49);
        boolean boolean53 = gJChronology40.equals((java.lang.Object) dateTime52);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(interval50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "UTC" + "'", str51.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        try {
            long long13 = limitChronology5.getDateTimeMillis((int) (byte) 10, 3, 1970, 69, 10, 31, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+01:04");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+01:04/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        long long14 = offsetDateTimeField12.roundHalfCeiling((long) 7);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        java.lang.String str4 = gJChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        boolean boolean9 = delegatedDateTimeField8.isLenient();
        boolean boolean10 = delegatedDateTimeField8.isLenient();
        long long12 = delegatedDateTimeField8.roundFloor((-1L));
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField8.getAsText((long) '#', locale14);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField8.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int18 = julianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.millisOfSecond();
        org.joda.time.DurationField durationField20 = julianChronology17.halfdays();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField21 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField16, durationField20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57600000L) + "'", long12 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField12.getLeapDurationField();
        int int30 = offsetDateTimeField12.getMinimumValue((-86400000L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        int[] intArray33 = null;
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = offsetDateTimeField12.set(readablePartial31, 1970, intArray33, "", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) -1, 10, (int) (byte) 100, 30, 1969, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        long long16 = delegatedDateTimeField7.remainder((long) 'a');
        java.util.Locale locale17 = null;
        int int18 = delegatedDateTimeField7.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 57600097L + "'", long16 == 57600097L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DurationField durationField6 = iSOChronology1.months();
        long long9 = durationField6.subtract((long) (-1), 345600001L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-908840220278822001L) + "'", long9 == (-908840220278822001L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField7.getMaximumTextLength(locale13);
        try {
            long long17 = delegatedDateTimeField7.set((-3155674021999L), "365");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.minus((-100L));
        org.joda.time.DateTime dateTime24 = dateTime20.minusMinutes(1970);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = limitChronology5.withZone(dateTimeZone10);
        try {
            long long20 = limitChronology5.getDateTimeMillis((int) 'a', (int) (byte) 100, 14, 52, 10, 70, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury((int) '4');
        boolean boolean38 = dateTime12.isBefore((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property39 = dateTime12.weekyear();
        org.joda.time.ReadableInstant readableInstant40 = null;
        long long41 = property39.getDifferenceAsLong(readableInstant40);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-97L) + "'", long41 == (-97L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        int int5 = localDate2.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology8);
        int int10 = localDate9.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology13);
        int int15 = localDate14.getYearOfEra();
        int int16 = localDate9.compareTo((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.minusYears((int) 'a');
        boolean boolean22 = localDate9.isAfter((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate9.minus(readablePeriod23);
        org.joda.time.LocalTime localTime25 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology28);
        int int30 = localDate29.getYearOfEra();
        int int31 = localDate29.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int33 = julianChronology32.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone34 = julianChronology32.getZone();
        org.joda.time.Interval interval35 = localDate29.toInterval(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = localDate9.toDateTime(localTime25, dateTimeZone34);
        boolean boolean37 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeField dateTimeField39 = localDate2.getField(0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField39, (int) (short) -1, 11, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for year must be in the range [11,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(interval35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField dateTimeField37 = skipUndoDateTimeField12.getWrappedField();
        long long39 = skipUndoDateTimeField12.roundHalfCeiling((long) 9700);
        int int41 = skipUndoDateTimeField12.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9700L + "'", long39 == 9700L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 999 + "'", int41 == 999);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone22);
        org.joda.time.LocalDate localDate25 = localDate23.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime36 = dateTime33.withYearOfCentury((int) (short) 1);
        int int37 = dateTime36.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology39.getZone();
        org.joda.time.DateTime dateTime42 = dateTime12.toDateTime(dateTimeZone41);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField7.getAsText((long) '#', locale13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField16 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField7.getAsShortText((int) (short) -1, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField7.getAsShortText((int) (short) 1, locale21);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        java.lang.String str7 = limitChronology5.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]" + "'", str7.equals("LimitChronology[ISOChronology[America/Los_Angeles], NoLimit, NoLimit]"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.getID();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        long long22 = dateTimeZone18.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime23 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.joda.time.DateTime dateTime26 = dateTime23.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime23.minus(readableDuration27);
        int int29 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
        try {
            org.joda.time.DateTime dateTime31 = dateTime23.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) ' ', 0, 100, 70, 52, (int) '4', 1872, chronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        long long6 = gJChronology2.add(1L, 0L, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology12.getZone();
        org.joda.time.Chronology chronology15 = gregorianChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology11.getZone();
        org.joda.time.Chronology chronology19 = gJChronology2.withZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, readableInstant21);
        java.lang.String str23 = gJChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
        long long30 = delegatedDateTimeField27.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField27, (int) (byte) 10);
        boolean boolean33 = offsetDateTimeField32.isLenient();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateMidnight dateMidnight38 = localDate36.toDateMidnight(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone40);
        int[] intArray42 = localDate41.getValues();
        boolean boolean43 = dateMidnight38.equals((java.lang.Object) localDate41);
        int int44 = localDate41.getWeekOfWeekyear();
        int int45 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        boolean boolean46 = gJChronology2.equals((java.lang.Object) offsetDateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str23.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 345600001L + "'", long30 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateMidnight38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 41 + "'", int45 == 41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("20190615T152732.506-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20190615T152732.506-0700\" is malformed at \"T152732.506-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 41);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalDate localDate20 = localDate3.minusDays((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = iSOChronology22.centuries();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.DateTime dateTime27 = limitChronology26.getUpperLimit();
        org.joda.time.DateTime dateTime28 = limitChronology26.getUpperLimit();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int30 = julianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology29.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.Chronology chronology33 = limitChronology26.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = localDate3.toDateTimeAtMidnight(dateTimeZone31);
        int int35 = dateTime34.getMillisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNull(dateTime27);
        org.junit.Assert.assertNull(dateTime28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        try {
            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(8, (int) (short) -1, 1969, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.monthOfYear();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = localDate7.isSupported(durationFieldType11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone19);
        int[] intArray21 = localDate20.getValues();
        boolean boolean22 = dateMidnight17.equals((java.lang.Object) localDate20);
        int int23 = localDate20.getWeekOfWeekyear();
        boolean boolean24 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate9.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (short) 0);
        org.joda.time.DateTime dateTime16 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = dateTime16.getDayOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.Partial.Property property10 = partial8.property(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate16.getFields();
        org.joda.time.LocalDate localDate39 = localDate16.plusMonths(69);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        try {
            org.joda.time.LocalDate localDate42 = localDate16.withField(dateTimeFieldType40, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertNotNull(localDate39);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        int int15 = localDate14.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = localDate14.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean8 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate7);
        int int9 = localDate2.getMonthOfYear();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        try {
            org.joda.time.DateTime dateTime26 = dateTime21.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        long long19 = gJChronology15.add(1L, 0L, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int22 = julianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology21.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int26 = julianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology25.getZone();
        org.joda.time.Chronology chronology28 = gregorianChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology24.weekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology24.getZone();
        org.joda.time.Chronology chronology32 = gJChronology15.withZone(dateTimeZone31);
        org.joda.time.Chronology chronology33 = buddhistChronology0.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(chronology33);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        long long8 = dateTimeZone5.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int12 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField13, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology18);
        int int20 = localDate19.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        int int25 = localDate24.getYearOfEra();
        int int26 = localDate19.compareTo((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone28);
        org.joda.time.LocalDate localDate31 = localDate29.minusYears((int) 'a');
        boolean boolean32 = localDate19.isAfter((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate34 = localDate19.minus(readablePeriod33);
        org.joda.time.LocalDate localDate36 = localDate19.minusDays((int) (short) 10);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate19, 0, locale38);
        org.joda.time.DateTimeField[] dateTimeFieldArray40 = localDate19.getFields();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int42 = julianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone43 = julianChronology41.getZone();
        long long46 = dateTimeZone43.adjustOffset((long) 0, true);
        long long49 = dateTimeZone43.adjustOffset((-100L), false);
        org.joda.time.Interval interval50 = localDate19.toInterval(dateTimeZone43);
        org.joda.time.Chronology chronology51 = buddhistChronology0.withZone(dateTimeZone43);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-100L) + "'", long49 == (-100L));
        org.junit.Assert.assertNotNull(interval50);
        org.junit.Assert.assertNotNull(chronology51);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(28800000L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("365");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"365/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalDate localDate20 = localDate3.minusDays((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology23);
        int int25 = localDate24.getYearOfEra();
        int int26 = localDate24.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int28 = julianChronology27.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology27.getZone();
        org.joda.time.Interval interval30 = localDate24.toInterval(dateTimeZone29);
        org.joda.time.DateMidnight dateMidnight31 = localDate3.toDateMidnight(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(interval30);
        org.junit.Assert.assertNotNull(dateMidnight31);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(28800000L, (long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 28771200000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("10");
        org.joda.time.LocalDate.Property property2 = localDate1.weekyear();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (-88885920));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -88885920");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 10, 2592000002L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25920000020L + "'", long2 == 25920000020L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = iSOChronology25.seconds();
        org.joda.time.DateTime dateTime27 = dateTime21.withChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTime.Property property28 = dateTime27.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = null;
        java.lang.String str30 = dateTime27.toString(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969-12-30T14:56:00.000-08:00" + "'", str30.equals("1969-12-30T14:56:00.000-08:00"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(11, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 31, "41");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((long) (byte) 100);
        int int35 = offsetDateTimeField12.getMaximumValue();
        long long37 = offsetDateTimeField12.roundHalfFloor((long) '4');
        java.util.Locale locale38 = null;
        int int39 = offsetDateTimeField12.getMaximumTextLength(locale38);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "41" + "'", str34.equals("41"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 41 + "'", int35 == 41);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 28800000L + "'", long37 == 28800000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology3);
        int int5 = localDate4.getYearOfEra();
        int int6 = localDate4.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.Interval interval10 = localDate4.toInterval(dateTimeZone9);
        java.lang.String str11 = dateTimeZone9.getID();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone13);
        org.joda.time.LocalDate localDate16 = localDate14.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int18 = julianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology17.getZone();
        long long23 = dateTimeZone19.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime24 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime.Property property25 = dateTime24.centuryOfEra();
        org.joda.time.DateTime dateTime27 = dateTime24.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime24.minus(readableDuration28);
        int int30 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) 1970, dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        java.lang.String str34 = offsetDateTimeField12.getAsShortText((long) (byte) 100);
        long long36 = offsetDateTimeField12.roundHalfEven((-1295999990L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "41" + "'", str34.equals("41"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1267200000L) + "'", long36 == (-1267200000L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime();
        org.joda.time.DateTime dateTime33 = dateTime28.withDayOfYear((int) (byte) 1);
        int int34 = dateTime33.getYearOfEra();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.minus(readablePeriod35);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1872 + "'", int34 == 1872);
        org.junit.Assert.assertNotNull(dateTime36);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
//        int int4 = localDate3.getYearOfEra();
//        int int5 = localDate3.getWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
//        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone8.getID();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
//        long long22 = dateTimeZone18.convertLocalToUTC((long) (short) 1, true, (long) 100);
//        org.joda.time.DateTime dateTime23 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
//        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
//        org.joda.time.DateTime dateTime26 = dateTime23.withYearOfCentury((int) (short) 1);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime23.minus(readableDuration27);
//        int int29 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone8.getName((long) 2000, locale31);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.withMaximumValue();
        org.joda.time.LocalDate localDate15 = property12.addWrapFieldToCopy(3840000);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone22);
        int[] intArray24 = localDate23.getValues();
        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldTypeArray20, intArray24);
        try {
            int int27 = partial25.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = dateTime22.withSecondOfMinute((int) ' ');
        try {
            org.joda.time.DateTime dateTime27 = dateTime22.withMillisOfSecond(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        int int29 = dateTime25.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) (short) 0);
        boolean boolean11 = delegatedDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone17);
        int[] intArray19 = localDate18.getValues();
        int[] intArray20 = localDate18.getValues();
        int[] intArray21 = localDate18.getValues();
        int[] intArray23 = delegatedDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) localDate14, (int) (short) 0, intArray21, 11);
        int int24 = localDate14.getYear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundFloor((-57600000L));
        org.joda.time.DurationField durationField30 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, durationField30, dateTimeFieldType31);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-57600000L) + "'", long29 == (-57600000L));
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        int int13 = delegatedDateTimeField7.getDifference((long) 1969, (long) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField16 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType14, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 0);
        int int6 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.LocalDate localDate9 = localDate5.withFieldAdded(durationFieldType7, (-88885920));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfMonth();
        int int21 = property20.get();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        int int29 = dateTime25.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 60 + "'", int29 == 60);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundCeiling((long) (short) 0);
        boolean boolean13 = delegatedDateTimeField9.isLeap(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField9, (int) (byte) 100);
        try {
            long long18 = skipUndoDateTimeField15.set((-3839992L), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [2,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.50000037d + "'", double1 == 2440587.50000037d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
        org.joda.time.LocalDate localDate22 = localDate19.withMonthOfYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.Partial partial11 = partial8.minus(readablePeriod10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.Partial partial14 = partial8.with(dateTimeFieldType12, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        int int26 = dateTime24.getWeekyear();
        int int27 = dateTime24.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1852 + "'", int26 == 1852);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 18 + "'", int27 == 18);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.010", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.010/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.DateTime dateTime17 = dateTime12.plusMinutes(0);
        org.joda.time.DateTime dateTime19 = dateTime17.withCenturyOfEra((int) (byte) 0);
        int int20 = dateTime19.getHourOfDay();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean8 = delegatedDateTimeField7.isLenient();
        boolean boolean9 = delegatedDateTimeField7.isLenient();
        long long11 = delegatedDateTimeField7.roundFloor((-1L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText(0, locale14);
        boolean boolean16 = delegatedDateTimeField12.isSupported();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.append(dateTimePrinter8, dateTimeParser9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.Interval interval9 = localDate3.toInterval(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone11);
        org.joda.time.LocalDate localDate14 = localDate12.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime.Property property23 = dateTime22.centuryOfEra();
        org.joda.time.DateTime dateTime25 = dateTime22.minus(100L);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded(readableDuration26, (int) (byte) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime28, 1);
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime();
        org.joda.time.DateTime dateTime33 = dateTime28.withDayOfYear((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime37 = dateTime28.withDate((int) (short) 100, 30, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTime.Property property24 = dateTime21.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusYears(0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology19);
        int int21 = localDate20.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology24);
        int int26 = localDate25.getYearOfEra();
        int int27 = localDate20.compareTo((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone29);
        org.joda.time.LocalDate localDate32 = localDate30.minusYears((int) 'a');
        boolean boolean33 = localDate20.isAfter((org.joda.time.ReadablePartial) localDate30);
        int int34 = localDate14.compareTo((org.joda.time.ReadablePartial) localDate30);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology5);
        int int7 = localDate6.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        boolean boolean19 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.LocalDate localDate21 = localDate6.minusYears(10);
        int[] intArray23 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate21, (long) (byte) 10);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 31, (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTime24.toString("31", locale26);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31" + "'", str27.equals("31"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (short) 0);
        org.joda.time.DateTime dateTime16 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = property17.getMaximumValue();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "", 14, 3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        int[] intArray12 = partial11.getValues();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        java.lang.String str12 = partial8.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.Partial.Property property14 = partial8.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField10 = gregorianChronology4.days();
        org.joda.time.Chronology chronology11 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", "GJChronology[UTC,cutover=1872-12-31T00:01:00.000Z]", 0, (int) ' ');
        long long6 = fixedDateTimeZone4.previousTransition((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "18");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', (int) ' ', 60, 856, 8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 856 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology18);
        org.joda.time.LocalDate localDate21 = localDate19.withYearOfCentury(8);
        org.joda.time.Partial partial22 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate19);
        try {
            org.joda.time.LocalDate localDate24 = localDate19.withWeekOfWeekyear(366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.Instant instant25 = new org.joda.time.Instant((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant28 = instant25.withDurationAdded(readableDuration26, 1852);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.Instant instant30 = instant28.minus(readableDuration29);
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.Instant instant32 = instant28.plus(readableDuration31);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant30);
        org.junit.Assert.assertNotNull(instant32);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology7);
        int int9 = localDate8.getYearOfEra();
        int int10 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusYears((int) 'a');
        boolean boolean16 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate3.minus(readablePeriod17);
        org.joda.time.LocalTime localTime19 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology22);
        int int24 = localDate23.getYearOfEra();
        int int25 = localDate23.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        org.joda.time.Interval interval29 = localDate23.toInterval(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate3.toDateTime(localTime19, dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTimeISO();
        org.joda.time.DateTime dateTime33 = dateTime31.minusMonths(30);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = iSOChronology18.centuries();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology18, readableDateTime20, readableDateTime21);
        org.joda.time.DateTime dateTime23 = limitChronology22.getUpperLimit();
        org.joda.time.DateTime dateTime24 = limitChronology22.getUpperLimit();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int26 = julianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology25.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.Chronology chronology29 = limitChronology22.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = localDate14.toDateTimeAtCurrentTime(dateTimeZone27);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNull(dateTime23);
        org.junit.Assert.assertNull(dateTime24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsShortText(locale7);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "18" + "'", str8.equals("18"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime14 = localDate6.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int16 = julianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime22 = dateTime14.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime24 = dateTime22.minus((-100L));
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone25.isLocalDateTimeGap(localDateTime26);
        boolean boolean28 = buddhistChronology0.equals((java.lang.Object) boolean27);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.LocalDate localDate26 = dateTime22.toLocalDate();
        org.joda.time.DateTime dateTime28 = dateTime22.plusMinutes(0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.Partial partial3 = partial0.withFieldAddWrapped(durationFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969-12-30T14:56:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfCeilingCopy();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.LocalDate localDate17 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 31);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        dateTimeFormatterBuilder9.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        long long34 = offsetDateTimeField12.roundHalfCeiling(0L);
        org.joda.time.DurationField durationField35 = offsetDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
        org.junit.Assert.assertNull(durationField35);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        boolean boolean8 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean10 = localDate2.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
        long long17 = gJChronology13.add(1L, 0L, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int20 = julianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology19.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int24 = julianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology23.getZone();
        org.joda.time.Chronology chronology26 = gregorianChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology22.weekyear();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology22.getZone();
        org.joda.time.Chronology chronology30 = gJChronology13.withZone(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter9.withChronology(chronology30);
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter31.getPrinter();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimePrinter32);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        int int14 = offsetDateTimeField12.get((long) (short) 100);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField12.getMaximumShortTextLength(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
        java.lang.String str20 = gJChronology19.toString();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        long long27 = delegatedDateTimeField24.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField24, (int) (byte) 10);
        boolean boolean30 = offsetDateTimeField29.isLenient();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateMidnight dateMidnight35 = localDate33.toDateMidnight(dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone37);
        int[] intArray39 = localDate38.getValues();
        boolean boolean40 = dateMidnight35.equals((java.lang.Object) localDate38);
        int int41 = localDate38.getWeekOfWeekyear();
        int int42 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.LocalDate localDate44 = localDate38.minusMonths(0);
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate38, locale45);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone48);
        org.joda.time.LocalDate localDate51 = localDate49.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int53 = julianChronology52.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone54 = julianChronology52.getZone();
        long long58 = dateTimeZone54.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime59 = localDate51.toDateTimeAtStartOfDay(dateTimeZone54);
        org.joda.time.DateTime.Property property60 = dateTime59.centuryOfEra();
        org.joda.time.DateTime dateTime62 = dateTime59.withYearOfCentury((int) (short) 1);
        int int63 = dateTime62.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone64 = dateTime62.getZone();
        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone64);
        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology65);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray67 = localDate66.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone69);
        int[] intArray71 = localDate70.getValues();
        org.joda.time.Partial partial72 = new org.joda.time.Partial(dateTimeFieldTypeArray67, intArray71);
        org.joda.time.Chronology chronology73 = partial72.getChronology();
        int[] intArray75 = new int[] {};
        try {
            int[] intArray77 = offsetDateTimeField12.addWrapPartial((org.joda.time.ReadablePartial) partial72, (int) (byte) 100, intArray75, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 41 + "'", int14 == 41);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str20.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 345600001L + "'", long27 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateMidnight35);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 41 + "'", int42 == 41);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "31" + "'", str46.equals("31"));
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(julianChronology65);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfEra();
        org.joda.time.DurationField durationField4 = iSOChronology1.minutes();
        org.joda.time.DurationField durationField5 = iSOChronology1.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, (int) (byte) 0);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTimeISO();
        boolean boolean27 = dateTime25.isBeforeNow();
        java.util.Locale locale28 = null;
        java.util.Calendar calendar29 = dateTime25.toCalendar(locale28);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(calendar29);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getUpperLimit();
        org.joda.time.DateTime dateTime7 = limitChronology5.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology11);
        int int13 = localDate12.getYearOfEra();
        int int14 = localDate12.getWeekyear();
        org.joda.time.LocalDate localDate16 = localDate12.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime22 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        long long26 = dateTimeZone19.convertLocalToUTC((long) 8, false, (long) 0);
        org.joda.time.Chronology chronology27 = limitChronology5.withZone(dateTimeZone19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean29 = limitChronology5.equals((java.lang.Object) dateTimeFormatter28);
        org.joda.time.DateTimeField dateTimeField30 = limitChronology5.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-3839992L) + "'", long26 == (-3839992L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime26 = dateTime22.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) 1969, 3);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime26.plus(readableDuration30);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury((int) '4');
        boolean boolean38 = dateTime12.isBefore((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property39 = dateTime12.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone41);
        org.joda.time.LocalDate localDate44 = localDate42.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int46 = julianChronology45.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone47 = julianChronology45.getZone();
        long long51 = dateTimeZone47.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime52 = localDate44.toDateTimeAtStartOfDay(dateTimeZone47);
        org.joda.time.DateTime.Property property53 = dateTime52.centuryOfEra();
        org.joda.time.DateTime dateTime55 = dateTime52.minus(100L);
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.DateTime dateTime58 = dateTime55.withDurationAdded(readableDuration56, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology61);
        int int63 = localDate62.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology66);
        int int68 = localDate67.getYearOfEra();
        int int69 = localDate62.compareTo((org.joda.time.ReadablePartial) localDate67);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone71);
        org.joda.time.LocalDate localDate74 = localDate72.minusYears((int) 'a');
        boolean boolean75 = localDate62.isAfter((org.joda.time.ReadablePartial) localDate72);
        org.joda.time.ReadablePeriod readablePeriod76 = null;
        org.joda.time.LocalDate localDate77 = localDate62.minus(readablePeriod76);
        org.joda.time.LocalTime localTime78 = null;
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone80);
        org.joda.time.LocalDate localDate82 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology81);
        int int83 = localDate82.getYearOfEra();
        int int84 = localDate82.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology85 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int86 = julianChronology85.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone87 = julianChronology85.getZone();
        org.joda.time.Interval interval88 = localDate82.toInterval(dateTimeZone87);
        org.joda.time.DateTime dateTime89 = localDate62.toDateTime(localTime78, dateTimeZone87);
        org.joda.time.DateTime dateTime90 = dateTime58.toDateTime(dateTimeZone87);
        int int91 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime58);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1969 + "'", int63 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1969 + "'", int68 == 1969);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1969 + "'", int83 == 1969);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1970 + "'", int84 == 1970);
        org.junit.Assert.assertNotNull(julianChronology85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 4 + "'", int86 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone87);
        org.junit.Assert.assertNotNull(interval88);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = dateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime22 = dateTime12.withMinuteOfHour(1);
        int int23 = dateTime22.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        java.lang.String str4 = gJChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.dayOfWeek();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.LocalDate.Property property9 = localDate8.year();
        int int10 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        java.lang.String str4 = gJChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.dayOfWeek();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(0L, (org.joda.time.Chronology) gJChronology3);
        int int9 = localDate8.getYearOfEra();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        try {
            long long15 = skipUndoDateTimeField12.set((long) 2000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfSecond must be in the range [1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        int int2 = localDate1.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-3061065600100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay(8);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime21.withPeriodAdded(readablePeriod25, (-1));
        org.joda.time.DateTime dateTime29 = dateTime27.withMillis(2440592L);
        int int30 = dateTime29.getSecondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6280 + "'", int30 == 6280);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.Chronology chronology3 = copticChronology0.withUTC();
        try {
            long long8 = copticChronology0.getDateTimeMillis(41, 0, (int) (byte) 100, 1852);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime13 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks((int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime.Property property15 = dateTime12.minuteOfDay();
        org.joda.time.DateTime.Property property16 = dateTime12.year();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int23 = julianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology22.getZone();
        long long28 = dateTimeZone24.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime29 = localDate21.toDateTimeAtStartOfDay(dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int31 = julianChronology30.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone32 = julianChronology30.getZone();
        long long36 = dateTimeZone32.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime37 = dateTime29.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime39 = dateTime29.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded(readableDuration40, (int) (byte) 0);
        org.joda.time.LocalDate localDate43 = dateTime39.toLocalDate();
        int int44 = dateTime39.getMillisOfSecond();
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime39);
        try {
            org.joda.time.DateTime dateTime50 = dateTime39.withTime(100, 0, 856, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        org.joda.time.DateTimeField dateTimeField15 = property12.getField();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int7 = julianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int15 = julianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        long long20 = dateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime13.withMinuteOfHour(1);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) dateTime25);
        int int27 = dateTime25.getWeekyear();
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime25);
        long long29 = dateTime25.getMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1852 + "'", int27 == 1852);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "00:01:00.000Z" + "'", str28.equals("00:01:00.000Z"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3692217540000L) + "'", long29 == (-3692217540000L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateMidnight dateMidnight18 = localDate16.toDateMidnight(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        int[] intArray22 = localDate21.getValues();
        boolean boolean23 = dateMidnight18.equals((java.lang.Object) localDate21);
        int int24 = localDate21.getWeekOfWeekyear();
        int int25 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
        java.lang.String str27 = offsetDateTimeField12.getAsShortText((long) (short) 1);
        try {
            long long30 = offsetDateTimeField12.set((long) (-1), "UTC");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 41 + "'", int25 == 41);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "41" + "'", str27.equals("41"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis((int) (byte) 1);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        long long21 = dateTimeZone18.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int30 = julianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology29.getZone();
        long long35 = dateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime36 = localDate28.toDateTimeAtStartOfDay(dateTimeZone31);
        org.joda.time.DateTime.Property property37 = dateTime36.centuryOfEra();
        org.joda.time.DateTime dateTime39 = dateTime36.withYearOfCentury((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime41 = dateTime36.minus(readableDuration40);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime dateTime43 = dateTime15.toDateTime((org.joda.time.Chronology) gJChronology42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        try {
            int int45 = dateTime43.get(dateTimeFieldType44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        int int21 = dateTime18.compareTo((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant23 = instant20.withMillis(0L);
        org.joda.time.MutableDateTime mutableDateTime24 = instant20.toMutableDateTime();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.Interval interval17 = property12.toInterval();
        org.joda.time.LocalDate localDate19 = property12.setCopy("1");
        java.lang.Class<?> wildcardClass20 = property12.getClass();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType11);
        java.lang.String str13 = delegatedDateTimeField7.toString();
        int int15 = delegatedDateTimeField7.getMinimumValue((long) 856);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str13.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        int int14 = skipUndoDateTimeField12.get((long) 18);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        java.lang.String str21 = property20.getAsShortText();
        org.joda.time.DateTime dateTime22 = property20.roundCeilingCopy();
        java.lang.String str23 = property20.toString();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "365" + "'", str21.equals("365"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[dayOfYear]" + "'", str23.equals("Property[dayOfYear]"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfEvenCopy();
        org.joda.time.DateTimeField[] dateTimeFieldArray15 = localDate14.getFields();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeFieldArray15);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        java.util.Locale locale11 = null;
        java.lang.String str12 = partial8.toString("19", locale11);
        try {
            int int14 = partial8.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology4);
        int int6 = localDate5.getYearOfEra();
        int int7 = localDate5.getWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.Interval interval11 = localDate5.toInterval(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology0.withZone(dateTimeZone10);
        long long16 = dateTimeZone10.convertLocalToUTC(2440588L, false, (long) 7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2440588L + "'", long16 == 2440588L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", number1, (java.lang.Number) 2000, (java.lang.Number) 1L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField10 = gregorianChronology4.days();
        org.joda.time.Chronology chronology11 = gregorianChronology4.withUTC();
        java.lang.String str12 = gregorianChronology4.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology4.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[UTC]" + "'", str12.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial11 = partial8.withPeriodAdded(readablePeriod9, (int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.Partial partial14 = partial11.withFieldAdded(durationFieldType12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(partial11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfCentury((int) (short) 1);
        int int16 = dateTime15.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime15.withYearOfCentury(8);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int22 = julianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology21.getZone();
        long long26 = dateTimeZone23.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology31);
        int int33 = localDate32.getYearOfEra();
        int int34 = localDate32.getWeekyear();
        org.joda.time.LocalDate localDate36 = localDate32.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtStartOfDay(dateTimeZone39);
        int int43 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime42);
        int int44 = dateTime42.getMillisOfSecond();
        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis(2);
        org.joda.time.DateTime dateTime48 = dateTime42.plusDays((int) '#');
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime42);
        long long50 = dateTime42.getMillis();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1970 + "'", int34 == 1970);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-90240000L) + "'", long50 == (-90240000L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology4.halfdays();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.addWrapField((long) (byte) 10, 1969);
        long long12 = delegatedDateTimeField7.roundHalfCeiling((-1L));
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField7.getAsText((-908840220278822001L), locale14);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1295999990L) + "'", long10 == (-1295999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3" + "'", str15.equals("3"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property12.setCopy("0");
        try {
            org.joda.time.LocalDate localDate18 = property12.setCopy("-1");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology10);
        int int12 = localDate11.getYearOfEra();
        int int13 = localDate11.getWeekyear();
        org.joda.time.LocalDate localDate15 = localDate11.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, 4);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) 10);
        org.joda.time.DateTime dateTime21 = localDate15.toDateTimeAtStartOfDay(dateTimeZone18);
        int int22 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getMillisOfSecond();
        org.joda.time.DateTime dateTime25 = dateTime21.plusMillis(2);
        org.joda.time.DateTime dateTime27 = dateTime21.plusDays((int) '#');
        org.joda.time.DateTime.Property property28 = dateTime21.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property12.roundFloorCopy();
        int int14 = property12.get();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        long long17 = property12.remainder();
        boolean boolean18 = property12.isLeap();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone20);
        org.joda.time.LocalDate localDate23 = localDate21.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int25 = julianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology24.getZone();
        long long30 = dateTimeZone26.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime31 = localDate23.toDateTimeAtStartOfDay(dateTimeZone26);
        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
        org.joda.time.DateTime dateTime34 = dateTime31.minus(100L);
        org.joda.time.DateTime dateTime36 = dateTime31.plusMinutes(0);
        int int37 = property12.getDifference((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-86400000L) + "'", long17 == (-86400000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        try {
            int int11 = localDate7.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 35");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (byte) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        java.lang.String str21 = property20.getAsShortText();
        org.joda.time.DateTime dateTime22 = property20.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime24 = dateTime22.withEra(12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "365" + "'", str21.equals("365"));
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        java.lang.String str9 = partial8.toStringList();
        java.lang.String str10 = partial8.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay(30, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        long long13 = delegatedDateTimeField7.add((long) 2, (long) 30);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2592000002L + "'", long13 == 2592000002L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField12.getAsText((int) (byte) 0, locale31);
        int int34 = offsetDateTimeField12.getMinimumValue((long) (short) 100);
        int int36 = offsetDateTimeField12.getMaximumValue((-1L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 41 + "'", int36 == 41);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 19);
        int int2 = localDate1.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "00:01:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.Chronology chronology3 = copticChronology0.withUTC();
        try {
            long long11 = copticChronology0.getDateTimeMillis(60, 30, (int) (byte) 100, (int) (byte) 100, 2, 366, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 31);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("41");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"41\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight(dateTimeZone3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate2.isSupported(dateTimeFieldType5);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate2);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.centuries();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology3, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = limitChronology7.getUpperLimit();
        long long12 = limitChronology7.add((long) 1852, (long) 1, 4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = limitChronology7.withZone(dateTimeZone13);
        try {
            org.joda.time.Partial partial15 = new org.joda.time.Partial(dateTimeFieldType0, 1872, chronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1856L + "'", long12 == 1856L);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(readableDuration36, (int) (byte) 0);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime38);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gJChronology40);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property10 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = localDate11.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19691231T������.000" + "'", str8.equals("19691231T������.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691231T������.000" + "'", str9.equals("19691231T������.000"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(1L, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, (int) (byte) 10);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.minusYears((int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = localDate16.toString("18", locale20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone23);
        int[] intArray25 = localDate24.getValues();
        int[] intArray26 = localDate24.getValues();
        int int27 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localDate16, intArray26);
        long long29 = offsetDateTimeField12.roundHalfFloor((-1295999990L));
        int int31 = offsetDateTimeField12.get(1856L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 345600001L + "'", long10 == 345600001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "18" + "'", str21.equals("18"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1267200000L) + "'", long29 == (-1267200000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 41 + "'", int31 == 41);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (byte) -1, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) 0, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int9 = julianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField10, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology15);
        int int17 = localDate16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology20);
        int int22 = localDate21.getYearOfEra();
        int int23 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone25);
        org.joda.time.LocalDate localDate28 = localDate26.minusYears((int) 'a');
        boolean boolean29 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate16.minus(readablePeriod30);
        org.joda.time.LocalDate localDate33 = localDate16.minusDays((int) (short) 10);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale35);
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate16.getFields();
        int int38 = localDate16.getDayOfMonth();
        int int39 = localDate16.getDayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = copticChronology0.toString();
        try {
            long long10 = copticChronology0.getDateTimeMillis((int) (byte) 10, 30, (-1), 100, (int) (byte) -1, 12, 1852);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        int[] intArray3 = localDate2.getValues();
        int[] intArray4 = localDate2.getValues();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.minus(readablePeriod5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.LocalDate localDate9 = localDate6.withField(dateTimeFieldType7, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("CopticChronology[UTC]", (java.lang.Number) 100, (java.lang.Number) (-3155674021999L), number3);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CopticChronology[UTC]" + "'", str5.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate15.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int19 = julianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology18.getZone();
        long long24 = dateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime25 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int27 = julianChronology26.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology26.getZone();
        long long32 = dateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime25.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime25.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(readableDuration36, (int) (byte) 0);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DurationField durationField41 = gJChronology40.days();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears((int) 'a');
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 100);
        org.joda.time.DateTime dateTime12 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.minus(100L);
        org.joda.time.DateTime dateTime17 = dateTime12.withYear(12);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) iSOChronology2);
        int int4 = localDate3.getYearOfEra();
        int int5 = localDate3.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks(0);
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = localDate7.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) 1);
        org.joda.time.DurationField durationField15 = property12.getDurationField();
        org.joda.time.LocalDate localDate16 = property12.getLocalDate();
        org.joda.time.DurationField durationField17 = property12.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(durationField17);
    }
}

