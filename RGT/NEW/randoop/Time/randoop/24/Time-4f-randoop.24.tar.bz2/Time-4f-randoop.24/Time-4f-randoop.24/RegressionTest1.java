import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
//        org.joda.time.LocalDate localDate21 = property19.getLocalDate();
//        org.joda.time.LocalDate.Property property22 = localDate21.yearOfEra();
//        java.lang.String str24 = localDate21.toString("2019");
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = julianChronology0.equals(obj1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusSeconds(1);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField12);
//        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDate14, 0, locale16);
//        int int20 = skipDateTimeField13.getDifference((long) (short) -1, (long) 0);
//        int int21 = dateTime6.get((org.joda.time.DateTimeField) skipDateTimeField13);
//        org.joda.time.DateTime dateTime23 = dateTime6.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(readableDuration24, 1686);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str31 = dateTimeZone29.getName(10L);
//        org.joda.time.DateTime dateTime32 = dateTime26.toDateTime(dateTimeZone29);
//        java.lang.String str34 = dateTimeZone29.getName((long) 79767435);
//        org.joda.time.Chronology chronology35 = julianChronology0.withZone(dateTimeZone29);
//        int int36 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1686 + "'", int21 == 1686);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-01:01" + "'", str31.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-01:01" + "'", str34.equals("-01:01"));
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        long long5 = dateTimeZone3.convertUTCToLocal((long) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(0L, 58216037);
//        org.joda.time.DateTime dateTime28 = dateTime23.withTimeAtStartOfDay();
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime23.withMonthOfYear((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1970-01-01T��:��:��.000", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01T��:��:��.000\" is malformed at \"-01-01T��:��:��.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58216037);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
//        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        java.util.Date date24 = dateTime23.toDate();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
//        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
//        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str36 = dateTimeZone34.getName(10L);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        java.util.Date date38 = dateTime37.toDate();
//        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
//        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
//        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DurationField durationField52 = gJChronology51.millis();
//        long long55 = durationField52.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
//        org.joda.time.DurationField durationField59 = remainderDateTimeField58.getLeapDurationField();
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        java.util.Date date61 = dateTime60.toDate();
//        org.joda.time.DateTime dateTime63 = dateTime60.minusSeconds(1);
//        java.util.TimeZone timeZone64 = null;
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone65);
//        long long70 = dateTimeZone65.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime71 = dateTime63.withZoneRetainFields(dateTimeZone65);
//        org.joda.time.LocalDate localDate72 = org.joda.time.LocalDate.now(dateTimeZone65);
//        org.joda.time.LocalDate localDate74 = localDate72.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate76 = localDate74.plusWeeks((int) (short) 0);
//        java.util.TimeZone timeZone77 = null;
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forTimeZone(timeZone77);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology79 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone78);
//        long long83 = dateTimeZone78.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime84 = localDate74.toDateTimeAtStartOfDay(dateTimeZone78);
//        org.joda.time.LocalDate localDate86 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate88 = localDate86.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.Partial partial89 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate86);
//        org.joda.time.LocalDate localDate91 = localDate86.plusYears(79760412);
//        int int92 = localDate91.getMonthOfYear();
//        org.joda.time.LocalDate localDate93 = localDate74.withFields((org.joda.time.ReadablePartial) localDate91);
//        int int94 = remainderDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) localDate74);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
//        org.junit.Assert.assertNull(durationField59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(buddhistChronology66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 3660001L + "'", long70 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(localDate74);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(buddhistChronology79);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 3660001L + "'", long83 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertNotNull(localDate91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 12 + "'", int92 == 12);
//        org.junit.Assert.assertNotNull(localDate93);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.Instant instant3 = instant1.toInstant();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTime5.toString("0", locale7);
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTime dateTime12 = property9.setCopy(365);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTime5.toString("0", locale7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime2 = property1.roundFloorCopy();
        org.joda.time.DateTime dateTime3 = property1.roundFloorCopy();
        org.joda.time.DateTime dateTime5 = dateTime3.minusMillis(1735);
        org.joda.time.Instant instant6 = dateTime3.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str13 = dateTimeZone11.getName(10L);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField29 = gJChronology28.millis();
//        long long32 = durationField29.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
//        try {
//            java.lang.String str35 = unsupportedDateTimeField33.getAsText((long) 58216037);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        boolean boolean19 = skipDateTimeField10.isLenient();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
//        int int24 = localDate21.size();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
//        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
//        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
//        long long31 = skipDateTimeField10.roundHalfFloor(10098428340000L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10088758860000L + "'", long31 == 10088758860000L);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField7.getType();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField23);
//        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDate25, 0, locale27);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate25, locale29);
//        org.joda.time.DateTimeField dateTimeField31 = skipDateTimeField14.getWrappedField();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        java.util.Date date33 = dateTime32.toDate();
//        org.joda.time.DateTime dateTime35 = dateTime32.minusSeconds(1);
//        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
//        org.joda.time.DateTime.Property property37 = dateTime35.dayOfMonth();
//        org.joda.time.DateTime dateTime39 = property37.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property37.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str45 = dateTimeZone43.getName(10L);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        java.util.Date date47 = dateTime46.toDate();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusSeconds(1);
//        java.util.TimeZone timeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forTimeZone(timeZone50);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone51);
//        long long56 = dateTimeZone51.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime57 = dateTime49.withZoneRetainFields(dateTimeZone51);
//        org.joda.time.DateTime dateTime59 = dateTime49.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DurationField durationField61 = gJChronology60.millis();
//        long long64 = durationField61.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField61);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField67 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 76107435);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder69.appendFractionOfSecond((int) '#', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder72.appendFractionOfHour(58210407, 58211980);
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now();
//        java.util.Date date77 = dateTime76.toDate();
//        org.joda.time.DateTime dateTime79 = dateTime76.minusSeconds(1);
//        org.joda.time.LocalDate localDate80 = dateTime79.toLocalDate();
//        org.joda.time.DateTime.Property property81 = dateTime79.dayOfMonth();
//        org.joda.time.DateTime dateTime83 = property81.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property81.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder75.appendText(dateTimeFieldType84);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField86 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField67, dateTimeFieldType84);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, dateTimeFieldType84, 69);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-01:01" + "'", str45.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 3660001L + "'", long56 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-79761428L) + "'", long64 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(localDate80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(dateTimeFieldType84);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime25 = property24.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.DateTime dateTime5 = dateTime3.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillis(10L);
//        org.joda.time.DateTime dateTime9 = dateTime3.minusHours(3);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str14 = dateTimeZone12.getName(10L);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusSeconds(1);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
//        long long25 = dateTimeZone20.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime26 = dateTime18.withZoneRetainFields(dateTimeZone20);
//        org.joda.time.DateTime dateTime28 = dateTime18.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.minuteOfHour();
//        org.joda.time.DateTime dateTime31 = dateTime3.withChronology((org.joda.time.Chronology) gJChronology29);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-01:01" + "'", str14.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3660001L + "'", long25 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        long long5 = dateTime0.getMillis();
//        org.joda.time.Chronology chronology6 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime0.toDateMidnight();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneName();
//        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder9.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendFractionOfSecond((int) '#', (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitYear(58206900);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTimeZoneShortName(strMap17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendTimeZoneOffset("America/Los_Angeles", "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", true, 58210407, 58218768);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        java.util.Date date27 = dateTime26.toDate();
//        org.joda.time.DateTime dateTime29 = dateTime26.minusSeconds(1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.DateTime.Property property31 = dateTime29.dayOfMonth();
//        org.joda.time.DateTime dateTime33 = property31.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder19.appendFraction(dateTimeFieldType34, (int) 'a', 365);
//        int int38 = dateMidnight8.get(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 79767435L + "'", long5 == 79767435L);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeParser11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(strMap17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 0, 2922789);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withDate(69, (-3660001), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3660001 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
//        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        java.util.Date date24 = dateTime23.toDate();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
//        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
//        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str36 = dateTimeZone34.getName(10L);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        java.util.Date date38 = dateTime37.toDate();
//        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
//        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
//        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DurationField durationField52 = gJChronology51.millis();
//        long long55 = durationField52.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder59.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder60.appendFractionOfSecond((int) '#', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder63.appendFractionOfHour(58210407, 58211980);
//        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now();
//        java.util.Date date68 = dateTime67.toDate();
//        org.joda.time.DateTime dateTime70 = dateTime67.minusSeconds(1);
//        org.joda.time.LocalDate localDate71 = dateTime70.toLocalDate();
//        org.joda.time.DateTime.Property property72 = dateTime70.dayOfMonth();
//        org.joda.time.DateTime dateTime74 = property72.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property72.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType75);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField58, dateTimeFieldType75);
//        java.util.Locale locale80 = null;
//        try {
//            long long81 = dividedDateTimeField77.set((long) 999, "America/Los_Angeles", locale80);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeFieldType75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
//        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
//        boolean boolean24 = skipDateTimeField15.isLenient();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
//        int int29 = localDate26.size();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
//        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
//        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
//        boolean boolean35 = skipDateTimeField15.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
//        org.joda.time.DurationField durationField37 = null;
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
//        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
//        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
//        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str51 = dateTimeZone49.getName(10L);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        java.util.Date date53 = dateTime52.toDate();
//        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
//        java.util.TimeZone timeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
//        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
//        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DurationField durationField67 = gJChronology66.millis();
//        long long70 = durationField67.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
//        long long79 = offsetDateTimeField77.remainder((long) 195);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField77.getAsShortText((long) 70, locale81);
//        int int84 = offsetDateTimeField77.getLeapAmount((long) 79772937);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3660001L + "'", long62 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(gJChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 195L + "'", long79 == 195L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10" + "'", str82.equals("10"));
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        boolean boolean19 = skipDateTimeField10.isLenient();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
//        int int24 = localDate21.size();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
//        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
//        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
//        boolean boolean30 = skipDateTimeField10.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        java.util.Date date34 = dateTime33.toDate();
//        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
//        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        int int44 = localDate43.getYearOfEra();
//        java.util.Locale locale46 = null;
//        try {
//            java.lang.String str47 = unsupportedDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate43, 0, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1970 + "'", int44 == 1970);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis((-25200000), 76107435, 1735, 79763238, 79759888, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79763238 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) dateTime5);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        boolean boolean3 = buddhistChronology0.equals((java.lang.Object) date2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.weekyearOfCentury();
        java.lang.String str7 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[UTC]" + "'", str7.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury((-25200000), 76107435);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str28 = dateTimeZone26.getName(10L);
//        org.joda.time.DateTime dateTime29 = dateTime23.toDateTime(dateTimeZone26);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((-3660001));
//        int int32 = dateTime29.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-01:01" + "'", str28.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 26 + "'", int32 == 26);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-25200000));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
//        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
//        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.withCenturyOfEra(0);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        java.util.Date date21 = dateTime20.toDate();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusSeconds(1);
//        org.joda.time.LocalDate localDate24 = dateTime23.toLocalDate();
//        org.joda.time.DateTime.Property property25 = dateTime23.dayOfMonth();
//        org.joda.time.DateTime dateTime27 = property25.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
//        int int29 = localDate17.get(dateTimeFieldType28);
//        try {
//            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(58208198);
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter3.printTo(writer4, (long) 58208573);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(33);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
//        org.joda.time.DateTime dateTime27 = property24.withMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        org.joda.time.DateTime dateTime5 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime7 = property2.setCopy("100");
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
//        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
//        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
//        boolean boolean23 = skipDateTimeField14.isLenient();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
//        int int28 = localDate25.size();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
//        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
//        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
//        java.lang.String str39 = partial38.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970-01-01" + "'", str39.equals("1970-01-01"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.Chronology chronology4 = localDate3.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str5 = dateTimeZone3.getName(10L);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone3);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 69, dateTimeZone3);
        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundCeilingCopy();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate13 = localDate11.withCenturyOfEra((int) (byte) 0);
        int int14 = localDate13.getCenturyOfEra();
        boolean boolean15 = localDate9.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        long long5 = dateTime0.getMillis();
//        org.joda.time.Chronology chronology6 = dateTime0.getChronology();
//        org.joda.time.DateTime.Property property7 = dateTime0.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 79767435L + "'", long5 == 79767435L);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str13 = dateTimeZone11.getName(10L);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField29 = gJChronology28.millis();
//        long long32 = durationField29.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
//        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField33.getRangeDurationField();
//        long long40 = unsupportedDateTimeField33.add((long) 58215989, 79760412);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 137976401L + "'", long40 == 137976401L);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        org.joda.time.DateTime dateTime6 = property2.addToCopy(100);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("0");
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.minus(readablePeriod2);
        int int4 = localDate3.getCenturyOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray6 = localDate3.getFieldTypes();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.minuteOfHour();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        boolean boolean19 = skipDateTimeField10.isLenient();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
//        int int24 = localDate21.size();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
//        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
//        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
//        boolean boolean30 = skipDateTimeField10.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
//        org.joda.time.DurationField durationField32 = null;
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        java.util.Date date34 = dateTime33.toDate();
//        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
//        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
//        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
//        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str46 = dateTimeZone44.getName(10L);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        java.util.Date date48 = dateTime47.toDate();
//        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
//        java.util.TimeZone timeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
//        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
//        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DurationField durationField62 = gJChronology61.millis();
//        long long65 = durationField62.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
//        int int69 = dividedDateTimeField68.getMinimumValue();
//        int int71 = dividedDateTimeField68.get((long) 7);
//        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate75 = localDate73.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.LocalDate localDate77 = localDate75.minusMonths(10);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = dividedDateTimeField68.getAsShortText((org.joda.time.ReadablePartial) localDate75, 58216037, locale79);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 84 + "'", int71 == 84);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "58216037" + "'", str80.equals("58216037"));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField15);
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate17, 0, locale19);
//        int int23 = skipDateTimeField16.getDifference((long) (short) -1, (long) 0);
//        int int24 = dateTime9.get((org.joda.time.DateTimeField) skipDateTimeField16);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.DateTime dateTime28 = dateTime25.minusSeconds(1);
//        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
//        org.joda.time.DateTime.Property property30 = dateTime28.dayOfMonth();
//        org.joda.time.DateTime dateTime32 = property30.addToCopy((long) (short) -1);
//        int int33 = dateTime32.getEra();
//        boolean boolean34 = dateTime9.equals((java.lang.Object) int33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.Instant instant39 = org.joda.time.Instant.parse("0");
//        org.joda.time.DateTimeZone dateTimeZone40 = instant39.getZone();
//        org.joda.time.Chronology chronology41 = gregorianChronology37.withZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime42 = dateTime9.toDateTime(dateTimeZone40);
//        try {
//            org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((-79767435), 0, 58210108, (int) (short) -1, 79784588, 4, dateTimeZone40);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1686 + "'", int24 == 1686);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(instant39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str5 = dateTimeZone3.getName(10L);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone3);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 69, dateTimeZone3);
        int int8 = localDate7.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        long long14 = dateTimeZone9.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime15 = dateTime7.withZoneRetainFields(dateTimeZone9);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone9);
//        org.joda.time.LocalDate localDate18 = localDate16.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate22 = localDate20.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property23 = localDate22.dayOfYear();
//        org.joda.time.LocalDate localDate24 = property23.withMinimumValue();
//        int int25 = localDate24.getDayOfWeek();
//        try {
//            dateTimeFormatter1.printTo(appendable3, (org.joda.time.ReadablePartial) localDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(int2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3660001L + "'", long14 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
//        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
//        int int11 = skipDateTimeField5.get(28800001L);
//        int int13 = skipDateTimeField5.getMinimumValue((long) (byte) -1);
//        boolean boolean14 = skipDateTimeField5.isLenient();
//        long long16 = skipDateTimeField5.roundHalfCeiling((long) 58216680);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9673140000L) + "'", long16 == (-9673140000L));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Chronology chronology4 = buddhistChronology2.withUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology2.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime5.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime5.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 79766435L + "'", long11 == 79766435L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
//        java.util.Date date20 = dateTime8.toDate();
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.fromDateFields(date20);
//        org.joda.time.LocalDate localDate23 = localDate21.withWeekyear((int) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
        org.joda.time.LocalDate localDate6 = localDate3.withCenturyOfEra(2000);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
//        long long23 = dateTimeZone18.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime24 = localDate14.toDateTimeAtStartOfDay(dateTimeZone18);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        int int26 = dateTime25.getMillisOfDay();
//        int int27 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        boolean boolean29 = dateTime25.isEqual((long) 79783214);
//        int int30 = dateTime25.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3660001L + "'", long23 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 76107435 + "'", int26 == 76107435);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-3660000) + "'", int27 == (-3660000));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 76107 + "'", int30 == 76107);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("15");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("15");
//        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        java.lang.String str5 = jodaTimePermission3.getActions();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        long long16 = dateTimeZone11.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime17 = dateTime9.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(dateTimeZone11);
//        org.joda.time.LocalDate localDate20 = localDate18.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate22 = localDate20.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate24 = localDate22.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property25 = localDate24.dayOfYear();
//        org.joda.time.LocalDate localDate26 = property25.withMinimumValue();
//        org.joda.time.LocalDate localDate28 = property25.addToCopy((int) (short) -1);
//        org.joda.time.LocalDate localDate29 = property25.roundFloorCopy();
//        boolean boolean30 = jodaTimePermission3.equals((java.lang.Object) property25);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3660001L + "'", long16 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        java.lang.String str5 = property2.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[centuryOfEra]" + "'", str5.equals("Property[centuryOfEra]"));
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str13 = dateTimeZone11.getName(10L);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField29 = gJChronology28.millis();
//        long long32 = durationField29.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
//        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
//        try {
//            long long38 = unsupportedDateTimeField33.roundHalfCeiling((long) 79763238);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
//        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
//        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
//        boolean boolean23 = skipDateTimeField14.isLenient();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
//        int int28 = localDate25.size();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
//        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
//        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
//        int[] intArray39 = partial38.getValues();
//        int[] intArray40 = partial38.getValues();
//        int int41 = partial38.size();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(dateTimeZone44);
//        org.joda.time.DateMidnight dateMidnight46 = localDate45.toDateMidnight();
//        boolean boolean47 = partial38.isAfter((org.joda.time.ReadablePartial) localDate45);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        java.util.Date date49 = dateTime48.toDate();
//        org.joda.time.DateTime dateTime51 = dateTime48.minusSeconds(1);
//        java.util.TimeZone timeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forTimeZone(timeZone52);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone53);
//        long long58 = dateTimeZone53.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime59 = dateTime51.withZoneRetainFields(dateTimeZone53);
//        org.joda.time.DateTime dateTime61 = dateTime51.plusSeconds(10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = null;
//        boolean boolean63 = dateTime51.isSupported(dateTimeFieldType62);
//        org.joda.time.DateTime dateTime65 = dateTime51.minusMonths(6);
//        org.joda.time.DateTime dateTime67 = dateTime65.withWeekyear((-3660000));
//        org.joda.time.DateTime dateTime69 = dateTime67.minusDays(58215989);
//        boolean boolean70 = partial38.isMatch((org.joda.time.ReadableInstant) dateTime67);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 3660001L + "'", long58 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(24, 37, 76107435);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 76107423 + "'", int3 == 76107423);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
//        java.lang.String str27 = property24.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property24.getFieldType();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
//        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
//        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
//        boolean boolean23 = skipDateTimeField14.isLenient();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
//        int int28 = localDate25.size();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
//        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
//        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType40 = partial38.getFieldType(58218768);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58218768");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        int int17 = localDate16.getYearOfEra();
//        org.joda.time.LocalDate.Property property18 = localDate16.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.LocalDate localDate6 = localDate1.plusYears(79760412);
//        int int7 = localDate6.getMonthOfYear();
//        java.lang.String str8 = localDate6.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str10 = localDate6.toString(dateTimeFormatter9);
//        java.io.Writer writer11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("0");
//        org.joda.time.DateTimeZone dateTimeZone17 = instant16.getZone();
//        org.joda.time.Chronology chronology18 = gregorianChronology14.withZone(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.era();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        java.util.Date date21 = dateTime20.toDate();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusSeconds(1);
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        long long30 = dateTimeZone25.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime31 = dateTime23.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone25);
//        org.joda.time.LocalDate localDate34 = localDate32.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate36 = localDate34.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate38 = localDate36.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property39 = localDate38.dayOfYear();
//        org.joda.time.LocalDate localDate40 = property39.withMinimumValue();
//        org.joda.time.LocalDate localDate42 = property39.addToCopy((int) (short) -1);
//        int[] intArray44 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDate42, 1560640233993L);
//        int int45 = localDate42.getDayOfYear();
//        try {
//            dateTimeFormatter9.printTo(writer11, (org.joda.time.ReadablePartial) localDate42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "79762381-12-31" + "'", str8.equals("79762381-12-31"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "��:��:��" + "'", str10.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3660001L + "'", long30 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
//        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        java.util.Date date24 = dateTime23.toDate();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
//        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
//        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str36 = dateTimeZone34.getName(10L);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        java.util.Date date38 = dateTime37.toDate();
//        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
//        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
//        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DurationField durationField52 = gJChronology51.millis();
//        long long55 = durationField52.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
//        org.joda.time.DurationField durationField59 = remainderDateTimeField58.getLeapDurationField();
//        int int60 = remainderDateTimeField58.getMaximumValue();
//        long long62 = remainderDateTimeField58.roundCeiling(79769707L);
//        org.joda.time.DurationField durationField63 = remainderDateTimeField58.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
//        org.junit.Assert.assertNull(durationField59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 76107434 + "'", int60 == 76107434);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 21862860000L + "'", long62 == 21862860000L);
//        org.junit.Assert.assertNotNull(durationField63);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        java.util.Date date21 = dateTime20.toDate();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusSeconds(1);
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        long long30 = dateTimeZone25.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime31 = dateTime23.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.DateTime dateTime32 = dateTime8.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime34 = dateTime8.plusSeconds(12);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3660001L + "'", long30 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime5.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime13 = dateTime5.minusYears((-1));
//        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusWeeks(1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        java.util.Locale locale20 = null;
//        int int21 = property19.getMaximumTextLength(locale20);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
//        org.joda.time.Instant instant2 = instant1.toInstant();
//        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) instant2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        long long14 = dateTimeZone9.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime15 = dateTime7.withZoneRetainFields(dateTimeZone9);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone9);
//        boolean boolean18 = dateTimeZone9.isStandardOffset((long) 58206900);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) instant3, dateTimeZone9);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3660001L + "'", long14 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
//        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
//        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
//        boolean boolean23 = skipDateTimeField14.isLenient();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
//        int int28 = localDate25.size();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
//        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
//        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
//        java.lang.String str40 = partial38.toString("-01:01");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendTimeZoneName();
//        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatterBuilder41.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendFractionOfSecond((int) '#', (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendTwoDigitYear(58206900);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap49 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder46.appendTimeZoneShortName(strMap49);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder51.appendTimeZoneOffset("America/Los_Angeles", "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", true, 58210407, 58218768);
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
//        java.util.Date date59 = dateTime58.toDate();
//        org.joda.time.DateTime dateTime61 = dateTime58.minusSeconds(1);
//        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
//        org.joda.time.DateTime.Property property63 = dateTime61.dayOfMonth();
//        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property63.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder51.appendFraction(dateTimeFieldType66, (int) 'a', 365);
//        org.joda.time.Partial.Property property70 = partial38.property(dateTimeFieldType66);
//        java.util.TimeZone timeZone71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.forTimeZone(timeZone71);
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now();
//        java.util.Date date74 = dateTime73.toDate();
//        org.joda.time.DateTime dateTime76 = dateTime73.minusSeconds(1);
//        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.now();
//        java.util.Date date78 = dateTime77.toDate();
//        int int79 = dateTime76.compareTo((org.joda.time.ReadableInstant) dateTime77);
//        int int80 = dateTimeZone72.getOffset((org.joda.time.ReadableInstant) dateTime76);
//        int int81 = dateTime76.getYearOfCentury();
//        boolean boolean82 = partial38.isMatch((org.joda.time.ReadableInstant) dateTime76);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-01:01" + "'", str40.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeParser43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(strMap49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-3660000) + "'", int80 == (-3660000));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 70 + "'", int81 == 70);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(31, 0, 33, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) "", dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText((long) 58208573, locale14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField5.getAsShortText(4, locale17);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1686" + "'", str15.equals("1686"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str13 = dateTimeZone11.getName(10L);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField29 = gJChronology28.millis();
//        long long32 = durationField29.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
//        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField33.getRangeDurationField();
//        long long40 = unsupportedDateTimeField33.add((long) 'a', 79769610);
//        java.lang.String str41 = unsupportedDateTimeField33.toString();
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int44 = localDate43.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray45 = localDate43.getFieldTypes();
//        org.joda.time.LocalDate localDate47 = localDate43.withYearOfCentury((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone49);
//        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.secondOfDay();
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate55 = localDate53.withCenturyOfEra((int) (byte) 0);
//        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int58 = localDate57.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray59 = localDate57.getFieldTypes();
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        java.util.Date date61 = dateTime60.toDate();
//        org.joda.time.DateTime dateTime63 = dateTime60.minusSeconds(1);
//        org.joda.time.LocalDate localDate64 = dateTime63.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone66);
//        org.joda.time.DateTimeField dateTimeField68 = copticChronology67.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField69 = copticChronology67.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField70 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology65, dateTimeField69);
//        org.joda.time.LocalDate localDate71 = org.joda.time.LocalDate.now();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = skipDateTimeField70.getAsShortText((org.joda.time.ReadablePartial) localDate71, 0, locale73);
//        int int77 = skipDateTimeField70.getDifference((long) (short) -1, (long) 0);
//        int int78 = dateTime63.get((org.joda.time.DateTimeField) skipDateTimeField70);
//        boolean boolean79 = skipDateTimeField70.isLenient();
//        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate83 = localDate81.withCenturyOfEra((int) (byte) 0);
//        int int84 = localDate81.size();
//        org.joda.time.chrono.GJChronology gJChronology85 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate86 = org.joda.time.LocalDate.now();
//        int[] intArray88 = gJChronology85.get((org.joda.time.ReadablePartial) localDate86, (long) 0);
//        int int89 = skipDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localDate81, intArray88);
//        org.joda.time.DateTimeZone dateTimeZone90 = null;
//        org.joda.time.chrono.CopticChronology copticChronology91 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone90);
//        org.joda.time.DateTimeField dateTimeField92 = copticChronology91.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField93 = copticChronology91.clockhourOfHalfday();
//        org.joda.time.Partial partial94 = new org.joda.time.Partial(dateTimeFieldTypeArray59, intArray88, (org.joda.time.Chronology) copticChronology91);
//        copticChronology50.validate((org.joda.time.ReadablePartial) localDate55, intArray88);
//        try {
//            int[] intArray97 = unsupportedDateTimeField33.addWrapPartial((org.joda.time.ReadablePartial) localDate43, (-3660000), intArray88, 58215989);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 79769707L + "'", long40 == 79769707L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 70 + "'", int44 == 70);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray45);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(copticChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 70 + "'", int58 == 70);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(copticChronology67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0" + "'", str74.equals("0"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1686 + "'", int78 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(localDate83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 3 + "'", int84 == 3);
//        org.junit.Assert.assertNotNull(gJChronology85);
//        org.junit.Assert.assertNotNull(localDate86);
//        org.junit.Assert.assertNotNull(intArray88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//        org.junit.Assert.assertNotNull(copticChronology91);
//        org.junit.Assert.assertNotNull(dateTimeField92);
//        org.junit.Assert.assertNotNull(dateTimeField93);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime11 = dateTime5.plusHours(0);
        org.joda.time.DateTime.Property property12 = dateTime5.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.TimeZone timeZone3 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
//        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
//        boolean boolean24 = skipDateTimeField15.isLenient();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
//        int int29 = localDate26.size();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
//        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
//        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
//        boolean boolean35 = skipDateTimeField15.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
//        org.joda.time.DurationField durationField37 = null;
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
//        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
//        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
//        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str51 = dateTimeZone49.getName(10L);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        java.util.Date date53 = dateTime52.toDate();
//        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
//        java.util.TimeZone timeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
//        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
//        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DurationField durationField67 = gJChronology66.millis();
//        long long70 = durationField67.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
//        long long79 = offsetDateTimeField77.remainder((long) 195);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField77.getAsShortText((long) 70, locale81);
//        long long84 = offsetDateTimeField77.roundCeiling(0L);
//        long long86 = offsetDateTimeField77.roundHalfEven(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(gJChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 195L + "'", long79 == 195L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10" + "'", str82.equals("10"));
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
//        int int22 = skipDateTimeField10.getMaximumValue();
//        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
//        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
//        int[] intArray38 = new int[] { 'a', 58210108 };
//        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.LocalDate localDate41 = localDate31.minus(readablePeriod40);
//        org.joda.time.LocalDate.Property property42 = localDate31.dayOfYear();
//        org.joda.time.Interval interval43 = property42.toInterval();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(copticChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(interval43);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime2 = property1.roundHalfEvenCopy();
        java.lang.String str3 = property1.getAsString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "0", "1970-01-01");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", "79762381-12-31");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        try {
            int int16 = localDate14.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 52");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        int int4 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime0.dayOfYear();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readablePeriod10);
//        org.joda.time.DateTime dateTime12 = dateTime11.toDateTimeISO();
//        boolean boolean13 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.LocalDateTime localDateTime14 = dateTime12.toLocalDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79767435 + "'", int4 == 79767435);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(localDateTime14);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneId();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra(69);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int11 = skipDateTimeField5.get(28800001L);
        long long14 = skipDateTimeField5.set((long) '#', 292272708);
        long long17 = skipDateTimeField5.set(58208573L, 7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372003910400035L + "'", long14 == 9223372003910400035L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-52985173791427L) + "'", long17 == (-52985173791427L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight16 = dateTime15.toDateMidnight();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
//        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
//        boolean boolean24 = skipDateTimeField15.isLenient();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
//        int int29 = localDate26.size();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
//        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
//        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
//        boolean boolean35 = skipDateTimeField15.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
//        org.joda.time.DurationField durationField37 = null;
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
//        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
//        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
//        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str51 = dateTimeZone49.getName(10L);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        java.util.Date date53 = dateTime52.toDate();
//        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
//        java.util.TimeZone timeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
//        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
//        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DurationField durationField67 = gJChronology66.millis();
//        long long70 = durationField67.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
//        long long79 = offsetDateTimeField77.remainder((long) 195);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField77.getAsShortText((long) 70, locale81);
//        long long84 = offsetDateTimeField77.roundCeiling(0L);
//        long long86 = offsetDateTimeField77.roundCeiling((long) 4);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField77.getAsText((long) 'a', locale88);
//        org.joda.time.DurationField durationField90 = offsetDateTimeField77.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3660001L + "'", long62 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(gJChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 195L + "'", long79 == 195L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10" + "'", str82.equals("10"));
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 3600000L + "'", long86 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNull(durationField90);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
//        org.joda.time.DateMidnight dateMidnight27 = dateTime26.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("GregorianChronology[UTC]");
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str13 = dateTimeZone11.getName(10L);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField29 = gJChronology28.millis();
//        long long32 = durationField29.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
//        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField33.getRangeDurationField();
//        long long40 = unsupportedDateTimeField33.add((long) 'a', 79769610);
//        java.lang.String str41 = unsupportedDateTimeField33.toString();
//        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now();
//        int int43 = localDate42.size();
//        int int44 = localDate42.getYearOfCentury();
//        java.util.Locale locale45 = null;
//        try {
//            java.lang.String str46 = unsupportedDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 79769707L + "'", long40 == 79769707L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 70 + "'", int44 == 70);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now();
//        int int21 = localDate20.size();
//        int int22 = localDate20.getYearOfCentury();
//        boolean boolean23 = localDate18.equals((java.lang.Object) int22);
//        try {
//            org.joda.time.DateTimeField dateTimeField25 = localDate18.getField(365);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 365");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant4 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone5 = instant4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.era();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        long long18 = dateTimeZone13.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime19 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.LocalDate localDate22 = localDate20.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = localDate22.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate26 = localDate24.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property27 = localDate26.dayOfYear();
        org.joda.time.LocalDate localDate28 = property27.withMinimumValue();
        org.joda.time.LocalDate localDate30 = property27.addToCopy((int) (short) -1);
        int[] intArray32 = gregorianChronology2.get((org.joda.time.ReadablePartial) localDate30, 1560640233993L);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate35 = localDate30.withFields((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.LocalDate.Property property36 = localDate30.year();
        java.util.Locale locale38 = null;
        org.joda.time.LocalDate localDate39 = property36.setCopy("79769610", locale38);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3660001L + "'", long18 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate39);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int11 = skipDateTimeField5.get(28800001L);
        org.joda.time.DurationField durationField12 = skipDateTimeField5.getDurationField();
        long long15 = skipDateTimeField5.add(873103500L, 79777231);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2517577945900303500L + "'", long15 == 2517577945900303500L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfEra(58211405);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfDay(58208198);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        boolean boolean3 = buddhistChronology0.equals((java.lang.Object) date2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.monthOfYear();
        org.joda.time.DurationField durationField6 = buddhistChronology0.seconds();
        try {
            long long9 = durationField6.subtract((long) 58210407, 1560640241426L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        int int7 = skipDateTimeField5.get((long) 58216680);
        org.joda.time.DurationField durationField8 = skipDateTimeField5.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1686 + "'", int7 == 1686);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("15");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        java.lang.String str4 = gregorianChronology2.toString();
        jodaTimePermission1.checkGuard((java.lang.Object) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
//        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
//        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
//        boolean boolean24 = skipDateTimeField15.isLenient();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
//        int int29 = localDate26.size();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
//        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
//        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
//        boolean boolean35 = skipDateTimeField15.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
//        org.joda.time.DurationField durationField37 = null;
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
//        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
//        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
//        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str51 = dateTimeZone49.getName(10L);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        java.util.Date date53 = dateTime52.toDate();
//        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
//        java.util.TimeZone timeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
//        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
//        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DurationField durationField67 = gJChronology66.millis();
//        long long70 = durationField67.subtract(0L, (long) 79761428);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
//        long long79 = offsetDateTimeField77.remainder((long) 195);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField77.getAsShortText((long) 70, locale81);
//        try {
//            long long85 = offsetDateTimeField77.add(3600000L, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for dayOfMonth must be in the range [79772937,33]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3660001L + "'", long62 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(gJChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 195L + "'", long79 == 195L);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10" + "'", str82.equals("10"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField7);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate9, 0, locale11);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField8, 1);
        try {
            long long19 = gJChronology0.getDateTimeMillis(79772937, 1, 195, 79781426);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 195 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (long) 0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gJChronology0.get(readablePeriod5, (long) (-58215990));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
//        boolean boolean19 = skipDateTimeField10.isLenient();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
//        int int24 = localDate21.size();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
//        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
//        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
//        boolean boolean30 = skipDateTimeField10.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        java.util.Date date34 = dateTime33.toDate();
//        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
//        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
//        java.util.Locale locale41 = null;
//        try {
//            java.lang.String str42 = unsupportedDateTimeField39.getAsShortText((long) (-79767435), locale41);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(58210407, 58211980);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendHourOfHalfday(69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfMinute((int) (byte) 10);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField21 = property19.getField();
        org.joda.time.LocalDate localDate22 = property19.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate24 = localDate22.minusDays(6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime5.toDateTime(dateTimeZone12);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime5.withDurationAdded(readableDuration14, 12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 79766435L + "'", long11 == 79766435L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = copticChronology15.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField17);
//        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate19, 0, locale21);
//        int int25 = skipDateTimeField18.getDifference((long) (short) -1, (long) 0);
//        int int26 = dateTime11.get((org.joda.time.DateTimeField) skipDateTimeField18);
//        boolean boolean27 = skipDateTimeField18.isLenient();
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate31 = localDate29.withCenturyOfEra((int) (byte) 0);
//        int int32 = localDate29.size();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now();
//        int[] intArray36 = gJChronology33.get((org.joda.time.ReadablePartial) localDate34, (long) 0);
//        int int37 = skipDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate29, intArray36);
//        boolean boolean38 = skipDateTimeField18.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField18.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType39, 79768574, 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1686 + "'", int26 == 1686);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//    }
//}

