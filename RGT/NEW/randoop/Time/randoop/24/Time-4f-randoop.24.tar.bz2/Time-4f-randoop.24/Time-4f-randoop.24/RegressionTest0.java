import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType1, (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) 0.0d, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0, (java.lang.Number) 100.0f, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (-1), 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", false, (int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(100, (-1), (int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) -1, (int) (short) 0, 10, (int) (short) 1, (int) '#', (int) 'a', (int) '4', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, (int) (short) 100, 1, (int) (short) 1, 0, (-10), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) '4', (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.secondOfDay();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, (-1), (-1), (-1), (int) (byte) 1, (org.joda.time.Chronology) copticChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withEra((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "hi!", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (long) 0);
        try {
            long long8 = gJChronology0.getDateTimeMillis(10, 100, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        try {
            org.joda.time.LocalDate localDate5 = localDate1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.millis();
        org.joda.time.Chronology chronology3 = copticChronology1.withUTC();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-01:01");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-01:01/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeDivide(100L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime.Property property5 = dateTime0.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560640208181L + "'", long0 == 1560640208181L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.LocalTime localTime10 = null;
        try {
            org.joda.time.LocalDateTime localDateTime11 = localDate6.toLocalDateTime(localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 1, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1735);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210716856000000L) + "'", long1 == (-210716856000000L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy(58208573);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58208573 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        long long6 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false, (-1L));
//        try {
//            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 0L, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800001L + "'", long6 == 28800001L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.yearOfEra();
        try {
            long long11 = copticChronology1.getDateTimeMillis(58208573, 1686, (int) (short) 100, (int) (byte) 100, 10, 58208573, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimePrinter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 100, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.millis();
        try {
            long long10 = copticChronology1.getDateTimeMillis(0, (int) (byte) 1, (int) 'a', 58208198, (int) (short) 100, (int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58208198 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime5 = dateTime3.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours(58210407);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        try {
//            org.joda.time.DateTime dateTime4 = dateTime0.withWeekOfWeekyear(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58211690 + "'", int1 == 58211690);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant4 = instant2.plus((long) 58208573);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimePrinter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(3);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType3, (int) (short) 1, 58212218);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.toString();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        java.lang.String str6 = dateTimeZone3.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:01" + "'", str6.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.Interval interval9 = localDate1.toInterval(dateTimeZone8);
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(readableInterval10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField11);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now();
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate13, 0, locale15);
        int int19 = skipDateTimeField12.getDifference((long) (short) -1, (long) 0);
        int int20 = dateTime5.get((org.joda.time.DateTimeField) skipDateTimeField12);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1735 + "'", int20 == 1735);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
//        long long23 = dateTimeZone18.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateMidnight dateMidnight24 = localDate14.toDateMidnight(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800001L + "'", long10 == 28800001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800001L + "'", long23 == 28800001L);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 100, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (byte) 100);
        int int42 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 292272708 + "'", int42 == 292272708);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
//        java.lang.String str5 = dateTimeZone3.getName(10L);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        long long16 = dateTimeZone11.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime17 = dateTime9.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.DateTime dateTime19 = dateTime9.plusSeconds(10);
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DurationField durationField21 = gJChronology20.millis();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField21, dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800001L + "'", long16 == 28800001L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int12 = skipDateTimeField5.getDifference((long) (short) -1, (long) 0);
        long long15 = skipDateTimeField5.add((long) (short) 0, (long) '#');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1104537600000L + "'", long15 == 1104537600000L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), (long) 58215434);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-58215435L) + "'", long2 == (-58215435L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusSeconds((-25200000));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        int int10 = dateTime5.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-25200000) + "'", int9 == (-25200000));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 58216037 + "'", int10 == 58216037);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        int[] intArray5 = new int[] { 58216037 };
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField10);
        org.joda.time.DurationField durationField12 = gJChronology6.months();
        try {
            org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray5, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.halfdays();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = copticChronology1.get(readablePeriod3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology8 = dateTime3.getChronology();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        int int4 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime0.withMillis(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        try {
//            org.joda.time.DateTime.Property property8 = dateTime6.property(dateTimeFieldType7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 58218642 + "'", int4 == 58218642);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate8 = localDate1.withCenturyOfEra(1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gJChronology1.getDateTimeMillis((-10), 2922789, (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
//        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
//        boolean boolean18 = property2.equals((java.lang.Object) int17);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58218768 + "'", int1 == 58218768);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.halfdays();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = copticChronology1.get(readablePeriod3, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = copticChronology1.get(readablePeriod4, (long) 1686, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText((long) 58208573, locale14);
        java.util.Locale locale18 = null;
        try {
            long long19 = skipDateTimeField5.set((long) 4, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1686" + "'", str15.equals("1686"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField10.getAsText((int) 'a', locale20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "97" + "'", str21.equals("97"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        int int7 = localDate5.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        org.joda.time.DateTime.Property property5 = dateTime0.millisOfSecond();
//        int int6 = property5.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79759888 + "'", int1 == 79759888);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 999 + "'", int6 == 999);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfMinute((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        int int40 = localDate31.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 20 + "'", int40 == 20);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone2);
        java.lang.Class<?> wildcardClass6 = localDate5.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1686");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) 100, 58210407);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79760412 + "'", int1 == 79760412);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 58206900, (long) 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 873103500 + "'", int2 == 873103500);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        try {
            org.joda.time.LocalDate localDate5 = localDate1.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
        boolean boolean27 = property24.isLeap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.halfdays();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = copticChronology1.get(readablePeriod3, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePeriod2, (-58215435L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 79759888);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime13 = dateTime3.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property20 = dateTime8.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.LocalDate.Property property22 = localDate20.property(dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology3.withUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology3.eras();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        int int5 = property2.getMaximumValueOverall();
//        int int6 = property2.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79763238 + "'", int1 == 79763238);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2922789 + "'", int6 == 2922789);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatterBuilder1.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNull(dateTimePrinter5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        java.util.Locale locale22 = null;
        try {
            org.joda.time.LocalDate localDate23 = property19.setCopy("", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = localDate5.getFieldTypes();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.secondOfDay();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology15.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField17);
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now();
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate19, 0, locale21);
        int int25 = skipDateTimeField18.getDifference((long) (short) -1, (long) 0);
        int int26 = dateTime11.get((org.joda.time.DateTimeField) skipDateTimeField18);
        boolean boolean27 = skipDateTimeField18.isLenient();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate31 = localDate29.withCenturyOfEra((int) (byte) 0);
        int int32 = localDate29.size();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now();
        int[] intArray36 = gJChronology33.get((org.joda.time.ReadablePartial) localDate34, (long) 0);
        int int37 = skipDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate29, intArray36);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = copticChronology39.secondOfDay();
        org.joda.time.DateTimeField dateTimeField41 = copticChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial42 = new org.joda.time.Partial(dateTimeFieldTypeArray7, intArray36, (org.joda.time.Chronology) copticChronology39);
        int[] intArray43 = partial42.getValues();
        int[] intArray44 = partial42.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean47 = iSOChronology45.equals((java.lang.Object) 28800001L);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.minuteOfHour();
        org.joda.time.Partial partial49 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray44, (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DurationFieldType durationFieldType50 = null;
        try {
            org.joda.time.Partial partial52 = partial49.withFieldAdded(durationFieldType50, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1735 + "'", int26 == 1735);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTimeField48);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        long long16 = dateTimeZone11.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime17 = dateTime9.withZoneRetainFields(dateTimeZone11);
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now(dateTimeZone11);
        java.lang.String str19 = dateTimeZone11.toString();
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(58216037, 0, 58208573, 292272708, 2922789, 58211980, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272708 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3660001L + "'", long16 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-01:01" + "'", str19.equals("-01:01"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(58208198);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = dateTime3.isSupported(dateTimeFieldType14);
        try {
            org.joda.time.DateTime dateTime17 = dateTime3.withEra(79762727);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79762727 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfMinute((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, 79761428);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate8 = localDate5.minusMonths(58208198);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        try {
            java.lang.String str20 = localDate18.toString("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(8, 3, (int) '4', 1735, 19, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        long long20 = skipDateTimeField10.remainder((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9673140001L + "'", long20 == 9673140001L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        int int4 = localDate3.getWeekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType14 = localDate12.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        int int21 = dateTime20.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-3660000), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3660001) + "'", int2 == (-3660001));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 873103500, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 873103510L + "'", long2 == 873103510L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        java.util.Locale locale25 = null;
        int int26 = property24.getMaximumShortTextLength(locale25);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.DateTime dateTime3 = instant1.toDateTime();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withFieldAdded(durationFieldType4, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        java.lang.String str6 = dateTimeZone2.getName((long) 0);
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, 10L, 58216680);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58216680");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:01" + "'", str6.equals("-01:01"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder2.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds(1);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        java.util.Date date12 = dateTime11.toDate();
        int int13 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime15 = dateTime10.withYearOfEra(58211405);
        try {
            java.lang.String str16 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(58216037, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) '#', (org.joda.time.Chronology) copticChronology2);
        java.lang.String str4 = copticChronology2.toString();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[-01:01]" + "'", str4.equals("CopticChronology[-01:01]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        try {
//            org.joda.time.DateTime dateTime4 = dateTime0.withMinuteOfHour(79761428);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79761428 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79766463 + "'", int1 == 79766463);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        int int26 = skipDateTimeField10.get(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = copticChronology28.halfdays();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField29, dateTimeFieldType30, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1686 + "'", int26 == 1686);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        org.joda.time.LocalDate localDate21 = property19.getLocalDate();
        org.joda.time.LocalDate localDate22 = property19.roundHalfEvenCopy();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = buddhistChronology25.minutes();
        org.joda.time.Chronology chronology27 = buddhistChronology25.withUTC();
        boolean boolean28 = property19.equals((java.lang.Object) buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        org.joda.time.DateTime.Property property5 = dateTime0.millisOfSecond();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime0.withEra(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79767329 + "'", int1 == 79767329);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = copticChronology18.millis();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.era();
        try {
            org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((java.lang.Object) (short) 0, (org.joda.time.Chronology) copticChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        boolean boolean31 = localDate21.isSupported(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        illegalFieldValueException2.prependMessage("America/Los_Angeles");
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 0L, 58210407);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58210407");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        java.lang.String str8 = property5.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15" + "'", str8.equals("15"));
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 100);
//        int int5 = property2.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime6 = property2.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79769610 + "'", int1 == 79769610);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        int int26 = skipDateTimeField10.get(0L);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.DateTime dateTime30 = dateTime27.minusSeconds(1);
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        long long37 = dateTimeZone32.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime38 = dateTime30.withZoneRetainFields(dateTimeZone32);
        org.joda.time.LocalDate localDate39 = org.joda.time.LocalDate.now(dateTimeZone32);
        org.joda.time.LocalDate localDate41 = localDate39.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate43 = localDate41.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate45 = localDate43.withCenturyOfEra(0);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate45, (int) (short) 0, locale47);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1686 + "'", int26 == 1686);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3660001L + "'", long37 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
//        boolean boolean9 = dateTime7.isEqualNow();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusSeconds(1);
//        int int14 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property15 = dateTime10.dayOfYear();
//        int int16 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property17 = dateTime7.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 79770099 + "'", int14 == 79770099);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number9 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfEra(58211405);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 58210407, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.DateTime dateTime10 = localDate6.toDateTimeAtMidnight();
        int int11 = localDate6.size();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime21 = dateTime8.withWeekyear(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.DateTime dateTime24 = dateTime21.withField(dateTimeFieldType22, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        int int4 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime0.dayOfYear();
//        int int6 = dateTime0.getMonthOfYear();
//        org.joda.time.DateTime.Property property7 = dateTime0.hourOfDay();
//        int int8 = dateTime0.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79772937 + "'", int4 == 79772937);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        long long23 = skipDateTimeField10.roundCeiling((long) (-1));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 21862860000L + "'", long23 == 21862860000L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-25200000), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str5 = dateTimeZone3.getName(10L);
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) gJChronology0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 999, 19, 79762727);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.secondOfDay();
        org.joda.time.DateTime dateTime8 = instant3.toDateTime((org.joda.time.Chronology) copticChronology6);
        try {
            org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldType0, 79760412, (org.joda.time.Chronology) copticChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        int int20 = localDate18.getYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendHourOfDay(69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType12, 79770099, 79762727);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTime5.toString("0", locale7);
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        boolean boolean12 = dateTime10.isAfter(873103510L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, 1686);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendLiteral("America/Los_Angeles");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) instant2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = instant5.toDateTime();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime3.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) gJChronology0, dateTimeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfDay(69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        boolean boolean9 = dateTime7.isEqualNow();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes(2019);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendOptional(dateTimeParser9);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.append(dateTimePrinter3, dateTimeParser9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        org.joda.time.LocalDate localDate22 = property19.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate23 = property19.withMaximumValue();
        org.joda.time.LocalDate localDate24 = property19.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
        boolean boolean23 = skipDateTimeField14.isLenient();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
        int int28 = localDate25.size();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
        int[] intArray39 = partial38.getValues();
        int[] intArray40 = partial38.getValues();
        java.lang.String str41 = partial38.toString();
        java.lang.String str42 = partial38.toString();
        org.joda.time.ReadablePartial readablePartial43 = null;
        try {
            boolean boolean44 = partial38.isMatch(readablePartial43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1735 + "'", int22 == 1735);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970-01-01" + "'", str41.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1970-01-01" + "'", str42.equals("1970-01-01"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        java.util.GregorianCalendar gregorianCalendar2 = dateTime0.toGregorianCalendar();
        int int3 = dateTime0.getYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.DurationField durationField6 = gJChronology0.months();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(79762727, 70, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendFractionOfSecond(1735, 79763238);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime5.minusYears((-1));
        org.joda.time.DateTime dateTime14 = dateTime5.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        try {
            org.joda.time.LocalDate localDate22 = property19.setCopy(58212218);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58212218 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("0");
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) ' ');
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.String str18 = localDate14.toString(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "������.000" + "'", str18.equals("������.000"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime17 = dateTime8.plusHours(3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        java.lang.String str13 = dateTimeZone5.toString();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(buddhistChronology14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 58206900, 69, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58206900 for yearOfEra must be in the range [69,20]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
//        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
//        boolean boolean9 = dateTime7.isEqualNow();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusSeconds(1);
//        int int14 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property15 = dateTime10.dayOfYear();
//        int int16 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime18 = dateTime10.plusDays((int) ' ');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 79777231 + "'", int14 == 79777231);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) instant2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant2.plus(readableDuration4);
        org.joda.time.Instant instant7 = instant2.withMillis((long) 3);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant10 = instant2.withDurationAdded(readableDuration8, 1735);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        int int5 = localDate1.getDayOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        java.lang.String str6 = dateTimeZone3.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray12 = gJChronology0.get(readablePeriod9, (long) 10, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:01" + "'", str6.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        boolean boolean15 = dateTime11.isEqual((long) (-1));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 37 + "'", int12 == 37);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        java.lang.String str13 = dateTimeZone5.toString();
        long long16 = dateTimeZone5.adjustOffset((long) 58210108, false);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 58210108L + "'", long16 == 58210108L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.Interval interval7 = localDate1.toInterval();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.LocalDate.Property property9 = localDate1.property(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        java.lang.String str8 = dateTimeZone5.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology9 = copticChronology2.withZone(dateTimeZone5);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-3660000), dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-01:01" + "'", str8.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 58211980);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440588.1737497686d + "'", double1 == 2440588.1737497686d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime4.toCalendar(locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(calendar8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("2019", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
//        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone10);
//        java.lang.String str18 = dateTimeZone10.toString();
//        org.joda.time.Chronology chronology19 = copticChronology2.withZone(dateTimeZone10);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(obj0, dateTimeZone10);
//        int int21 = localDate20.getWeekOfWeekyear();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (byte) 100);
//        int int24 = localDate23.getYearOfCentury();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray25 = localDate23.getFieldTypes();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        java.util.Date date27 = dateTime26.toDate();
//        org.joda.time.DateTime dateTime29 = dateTime26.minusSeconds(1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField35);
//        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate37, 0, locale39);
//        int int43 = skipDateTimeField36.getDifference((long) (short) -1, (long) 0);
//        int int44 = dateTime29.get((org.joda.time.DateTimeField) skipDateTimeField36);
//        boolean boolean45 = skipDateTimeField36.isLenient();
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100);
//        org.joda.time.LocalDate localDate49 = localDate47.withCenturyOfEra((int) (byte) 0);
//        int int50 = localDate47.size();
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now();
//        int[] intArray54 = gJChronology51.get((org.joda.time.ReadablePartial) localDate52, (long) 0);
//        int int55 = skipDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) localDate47, intArray54);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone56);
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology57.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField59 = copticChronology57.clockhourOfHalfday();
//        org.joda.time.Partial partial60 = new org.joda.time.Partial(dateTimeFieldTypeArray25, intArray54, (org.joda.time.Chronology) copticChronology57);
//        java.lang.String str62 = partial60.toString("1686");
//        boolean boolean63 = localDate20.isBefore((org.joda.time.ReadablePartial) partial60);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-01:01" + "'", str18.equals("-01:01"));
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 69 + "'", int24 == 69);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1735 + "'", int44 == 1735);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(copticChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1686" + "'", str62.equals("1686"));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        boolean boolean16 = dateTime15.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.LocalDate localDate16 = localDate14.withFields(readablePartial15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.LocalDate localDate19 = localDate14.withFieldAdded(durationFieldType17, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField21 = property19.getField();
        org.joda.time.LocalDate localDate22 = property19.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(localDate22);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
//        long long5 = dateTime0.getMillis();
//        org.joda.time.Chronology chronology6 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.yearOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField12);
//        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDate14, 0, locale16);
//        int int19 = skipDateTimeField13.get(28800001L);
//        int int21 = skipDateTimeField13.getMinimumValue((long) (byte) -1);
//        int int22 = dateTime0.get((org.joda.time.DateTimeField) skipDateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79781426 + "'", int1 == 79781426);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560640241426L + "'", long5 == 1560640241426L);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1686 + "'", int19 == 1686);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1735 + "'", int22 == 1735);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            org.joda.time.Partial partial1 = new org.joda.time.Partial(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.toString();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        java.util.Date date10 = dateTime9.toDate();
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime13 = dateTime8.withYearOfEra(58211405);
        int int14 = dateMidnight4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1735, (java.lang.Number) 37, (java.lang.Number) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(24, 79768574);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DurationField durationField20 = gJChronology19.minutes();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology19);
        try {
            org.joda.time.LocalDate localDate23 = localDate21.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, 1686);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("", "-01:01", false, 79767435, 58211980);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfYear();
        try {
            long long8 = gJChronology0.getDateTimeMillis(0, 365, 79763238, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.LocalDate.Property property3 = localDate1.monthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.remainder((long) 2);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        try {
            org.joda.time.LocalDate localDate4 = localDate1.withEra(3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.DurationField durationField20 = property19.getLeapDurationField();
        org.joda.time.LocalDate localDate21 = property19.getLocalDate();
        org.joda.time.LocalDate localDate22 = property19.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        long long12 = dateTimeZone7.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime13 = dateTime5.withZoneRetainFields(dateTimeZone7);
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now(dateTimeZone7);
        org.joda.time.LocalDate localDate16 = localDate14.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate18 = localDate16.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate20 = localDate18.withCenturyOfEra(0);
        org.joda.time.LocalDate localDate22 = localDate20.plusMonths(79777231);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660001L + "'", long12 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant4 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone5 = instant4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.era();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        long long18 = dateTimeZone13.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime19 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.LocalDate localDate22 = localDate20.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate24 = localDate22.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate26 = localDate24.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property27 = localDate26.dayOfYear();
        org.joda.time.LocalDate localDate28 = property27.withMinimumValue();
        org.joda.time.LocalDate localDate30 = property27.addToCopy((int) (short) -1);
        int[] intArray32 = gregorianChronology2.get((org.joda.time.ReadablePartial) localDate30, 1560640233993L);
        org.joda.time.DateMidnight dateMidnight33 = localDate30.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3660001L + "'", long18 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(dateMidnight33);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        boolean boolean9 = dateTime7.isEqualNow();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfMonth();
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        long long20 = skipDateTimeField10.remainder((long) (byte) 1);
        java.lang.String str22 = skipDateTimeField10.getAsText((long) 69);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1735 + "'", int18 == 1735);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9673140001L + "'", long20 == 9673140001L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1686" + "'", str22.equals("1686"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = dateTime3.withDate(58216680, 0, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime2 = property1.roundFloorCopy();
        int int3 = property1.getMaximumValueOverall();
        try {
            org.joda.time.DateTime dateTime5 = property1.addToCopy(1560640241426L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1560640241426 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[-01:01]" + "'", str3.equals("GregorianChronology[-01:01]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 0, (long) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology2.add(readablePeriod3, 0L, 2);
        try {
            long long14 = gregorianChronology2.getDateTimeMillis(2019, 58211980, 79770099, 79777231, 12, 0, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79777231 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.DurationField durationField6 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        int int4 = dateTime3.getDayOfWeek();
//        org.joda.time.DateTime dateTime6 = dateTime3.withDayOfYear(10);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded(readableDuration7, 79769610);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((java.lang.Object) 24, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendDecimal(dateTimeFieldType6, 0, 58211405);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-3660001), (-79761428L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 291926906241428");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
//        int int4 = dateTime0.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime0.dayOfYear();
//        org.joda.time.DateTime dateTime6 = property5.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79785262 + "'", int4 == 79785262);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        java.util.Date date23 = dateTime22.toDate();
        org.joda.time.DateTime dateTime25 = dateTime22.minusSeconds(1);
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone27);
        long long32 = dateTimeZone27.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime33 = dateTime25.withZoneRetainFields(dateTimeZone27);
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now(dateTimeZone27);
        org.joda.time.LocalDate localDate36 = localDate34.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate38 = localDate36.plusWeeks((int) (short) 0);
        int int39 = localDate38.getYearOfEra();
        int int40 = localDate16.compareTo((org.joda.time.ReadablePartial) localDate38);
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = localDate38.toString("1970-W01-4T21:08:30.099-01:01", locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3660001L + "'", long32 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(0, 6);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendYearOfEra((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (long) 0);
        long long7 = gJChronology0.add(0L, (long) 79772937, 79783214);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 6364541304079518L + "'", long7 == 6364541304079518L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (byte) 100);
        int int36 = localDate35.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray37 = localDate35.getFieldTypes();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        java.util.Date date39 = dateTime38.toDate();
        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = copticChronology45.secondOfDay();
        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField47);
        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now();
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipDateTimeField48.getAsShortText((org.joda.time.ReadablePartial) localDate49, 0, locale51);
        int int55 = skipDateTimeField48.getDifference((long) (short) -1, (long) 0);
        int int56 = dateTime41.get((org.joda.time.DateTimeField) skipDateTimeField48);
        boolean boolean57 = skipDateTimeField48.isLenient();
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate61 = localDate59.withCenturyOfEra((int) (byte) 0);
        int int62 = localDate59.size();
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now();
        int[] intArray66 = gJChronology63.get((org.joda.time.ReadablePartial) localDate64, (long) 0);
        int int67 = skipDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) localDate59, intArray66);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone68);
        org.joda.time.DateTimeField dateTimeField70 = copticChronology69.secondOfDay();
        org.joda.time.DateTimeField dateTimeField71 = copticChronology69.clockhourOfHalfday();
        org.joda.time.Partial partial72 = new org.joda.time.Partial(dateTimeFieldTypeArray37, intArray66, (org.joda.time.Chronology) copticChronology69);
        int[] intArray73 = partial72.getValues();
        int[] intArray74 = partial72.getValues();
        java.util.Locale locale75 = null;
        try {
            java.lang.String str76 = unsupportedDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) partial72, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 69 + "'", int36 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1735 + "'", int56 == 1735);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 3 + "'", int62 == 3);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(copticChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.LocalDate localDate6 = localDate1.plusYears(79760412);
        int int7 = localDate1.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int11 = skipDateTimeField5.get(28800001L);
        org.joda.time.DurationField durationField12 = skipDateTimeField5.getDurationField();
        int int13 = skipDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
        boolean boolean23 = skipDateTimeField14.isLenient();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
        int int28 = localDate25.size();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
        int[] intArray39 = partial38.getValues();
        org.joda.time.DurationFieldType durationFieldType40 = null;
        try {
            org.joda.time.Partial partial42 = partial38.withFieldAdded(durationFieldType40, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1735 + "'", int22 == 1735);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 79767435);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        java.util.GregorianCalendar gregorianCalendar2 = dateTime0.toGregorianCalendar();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.withDurationAdded(readableDuration3, 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitYear(79760412);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate19 = localDate17.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
        org.joda.time.DurationField durationField21 = property20.getLeapDurationField();
        org.joda.time.LocalDate localDate22 = property20.getLocalDate();
        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) property20);
        org.joda.time.DurationField durationField24 = property20.getLeapDurationField();
        boolean boolean25 = property20.isLeap();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime5 = dateTime3.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.withMillis(10L);
        java.util.GregorianCalendar gregorianCalendar8 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        try {
            java.lang.String str35 = unsupportedDateTimeField33.getAsShortText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str6 = dateTimeZone4.getName(10L);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds(1);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        long long17 = dateTimeZone12.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime18 = dateTime10.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime20 = dateTime10.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DurationField durationField22 = gJChronology21.millis();
        long long25 = durationField22.subtract(0L, (long) 79761428);
        boolean boolean26 = gJChronology0.equals((java.lang.Object) long25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        try {
            int[] intArray30 = gJChronology0.get(readablePeriod27, (long) (short) 10, (long) 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:01" + "'", str6.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3660001L + "'", long17 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-79761428L) + "'", long25 == (-79761428L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 79770099);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.DateTime dateTime6 = dateTime3.minusSeconds(1);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime14 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now(dateTimeZone8);
        org.joda.time.LocalDate localDate17 = localDate15.plusMonths((int) (byte) 1);
        int int18 = localDate15.getEra();
        int int19 = localDate15.getMonthOfYear();
        org.joda.time.Instant instant21 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant22 = instant21.toInstant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant((java.lang.Object) instant22);
        org.joda.time.DateTime dateTime24 = localDate15.toDateTime((org.joda.time.ReadableInstant) instant22);
        java.lang.String str25 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-4T21:08:30.099-01:01" + "'", str2.equals("1970-W01-4T21:08:30.099-01:01"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3660001L + "'", long13 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-W01-4T��:��:��.000" + "'", str25.equals("1970-W01-4T��:��:��.000"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField7);
        try {
            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(12, 3, (int) '#', (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        try {
            org.joda.time.LocalDate localDate8 = localDate5.withDayOfYear((-3660001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3660001 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 1560640208181L, 58210108);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime3.minuteOfDay();
        org.joda.time.DateTime.Property property15 = dateTime3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.Instant instant20 = new org.joda.time.Instant((java.lang.Object) dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        long long21 = skipDateTimeField14.getDifferenceAsLong((long) 58211980, (long) 1735);
        int int23 = skipDateTimeField14.getLeapAmount((long) 58212218);
        long long25 = skipDateTimeField14.remainder((long) 70);
        int int26 = skipDateTimeField14.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, (org.joda.time.DateTimeField) skipDateTimeField14);
        long long30 = skipUndoDateTimeField27.set(0L, 58208198);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:01" + "'", str7.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9673140070L + "'", long25 == 9673140070L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1836857823091200000L + "'", long30 == 1836857823091200000L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.centuries();
        try {
            long long4 = durationField1.subtract((long) 58211405, 79761428);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -7976142800");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("GregorianChronology[-01:01]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[-01:01]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.Interval interval13 = localDate12.toInterval();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate17 = localDate15.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial18 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate20 = localDate15.plusYears(79760412);
        boolean boolean21 = localDate12.isEqual((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray22 = localDate12.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.DurationField durationField32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str46 = dateTimeZone44.getName(10L);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        java.util.Date date48 = dateTime47.toDate();
        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DurationField durationField62 = gJChronology61.millis();
        long long65 = durationField62.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
        java.util.Locale locale71 = null;
        try {
            long long72 = dividedDateTimeField68.set((long) (byte) 10, "", locale71);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime5 = dateTime3.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.withMillis(10L);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) (short) 10);
        boolean boolean14 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(999, 69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68931 + "'", int2 == 68931);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendTimeZoneOffset("GregorianChronology[-01:01]", true, 79781426, 1735);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Chronology chronology4 = buddhistChronology2.withUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology2.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 3660001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970-01-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970-01-01' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(79767435);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-79767435) + "'", int1 == (-79767435));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
        try {
            org.joda.time.DateTime dateTime28 = dateTime26.withDayOfWeek((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.era();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = localDate5.getFieldTypes();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.secondOfDay();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology15.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField17);
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now();
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate19, 0, locale21);
        int int25 = skipDateTimeField18.getDifference((long) (short) -1, (long) 0);
        int int26 = dateTime11.get((org.joda.time.DateTimeField) skipDateTimeField18);
        boolean boolean27 = skipDateTimeField18.isLenient();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate31 = localDate29.withCenturyOfEra((int) (byte) 0);
        int int32 = localDate29.size();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now();
        int[] intArray36 = gJChronology33.get((org.joda.time.ReadablePartial) localDate34, (long) 0);
        int int37 = skipDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate29, intArray36);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = copticChronology39.secondOfDay();
        org.joda.time.DateTimeField dateTimeField41 = copticChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial42 = new org.joda.time.Partial(dateTimeFieldTypeArray7, intArray36, (org.joda.time.Chronology) copticChronology39);
        int[] intArray43 = partial42.getValues();
        int[] intArray44 = partial42.getValues();
        java.lang.String str45 = partial42.toString();
        java.lang.String str46 = partial42.toString();
        long long48 = copticChronology1.set((org.joda.time.ReadablePartial) partial42, (long) 58208573);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1686 + "'", int26 == 1686);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970-01-01" + "'", str45.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1970-01-01" + "'", str46.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 8952739808573L + "'", long48 == 8952739808573L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField7);
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate9, 0, locale11);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField8, 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 58212218);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58212218 + "'", int1 == 58212218);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate19 = localDate17.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
        org.joda.time.DurationField durationField21 = property20.getLeapDurationField();
        org.joda.time.LocalDate localDate22 = property20.getLocalDate();
        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) property20);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.Chronology chronology26 = gregorianChronology0.withZone(dateTimeZone24);
        try {
            long long31 = gregorianChronology0.getDateTimeMillis(1, 20, 79785262, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.LocalDate localDate6 = localDate1.plusYears(79760412);
        try {
            org.joda.time.LocalDate localDate8 = localDate1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 79770099);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        int int4 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readablePeriod10);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTimeISO();
        boolean boolean13 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.plusMinutes(1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76107435 + "'", int4 == 76107435);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
        boolean boolean23 = skipDateTimeField14.isLenient();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
        int int28 = localDate25.size();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
        java.lang.String str40 = partial38.toString("-01:01");
        java.lang.String str41 = partial38.toStringList();
        try {
            int int43 = partial38.getValue(79768574);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79768574");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-01:01" + "'", str40.equals("-01:01"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "[year=1970, monthOfYear=1, dayOfMonth=1]" + "'", str41.equals("[year=1970, monthOfYear=1, dayOfMonth=1]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
        try {
            boolean boolean38 = unsupportedDateTimeField33.isLeap(315619200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(0, 6);
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.append(dateTimePrinter15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int12 = skipDateTimeField5.getDifference((long) (short) -1, (long) 0);
        java.lang.String str14 = skipDateTimeField5.getAsShortText((long) 6);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (byte) 100);
        int int17 = localDate16.getYearOfCentury();
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, (int) (byte) 100, locale19);
        int int21 = localDate16.getDayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1686" + "'", str14.equals("1686"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1560640233993L, "");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        int int41 = skipDateTimeField10.get((long) (byte) 100);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate45 = localDate43.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100);
        int int48 = localDate43.compareTo((org.joda.time.ReadablePartial) localDate47);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
        org.joda.time.Interval interval51 = localDate43.toInterval(dateTimeZone50);
        java.util.Date date52 = localDate43.toDate();
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate43, 0, locale54);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1686 + "'", int41 == 1686);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(interval51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime11 = dateTime5.plusHours(0);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology8 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:01" + "'", str7.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        java.util.Date date21 = dateTime20.toDate();
        org.joda.time.DateTime dateTime23 = dateTime20.minusSeconds(1);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
        long long30 = dateTimeZone25.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime31 = dateTime23.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime8.toDateTime(dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3660001L + "'", long30 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (int) (byte) 0, 4, 79769610, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79769610 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int11 = skipDateTimeField5.get(28800001L);
        int int13 = skipDateTimeField5.getMinimumValue((long) (byte) -1);
        long long16 = skipDateTimeField5.addWrapField(0L, 2922789);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 92236206124800000L + "'", long16 == 92236206124800000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        org.joda.time.ReadablePartial readablePartial40 = null;
        try {
            int int41 = unsupportedDateTimeField39.getMinimumValue(readablePartial40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.Interval interval9 = localDate1.toInterval(dateTimeZone8);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.DateTime dateTime11 = localDate1.toDateTime(localTime10);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.Interval interval9 = localDate1.toInterval(dateTimeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone8.getShortName((long) 79759888, locale11);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-01:01" + "'", str12.equals("-01:01"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
        long long5 = dateTime0.getMillis();
        org.joda.time.DateTime.Property property6 = dateTime0.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 79767435L + "'", long5 == 79767435L);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTime5.toString("0", locale7);
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        long long11 = dateTime10.getMillis();
        org.joda.time.DateTime.Property property12 = dateTime10.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31798860000L + "'", long11 == 31798860000L);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.Interval interval9 = localDate1.toInterval(dateTimeZone8);
        java.util.Date date10 = localDate1.toDate();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = localDate1.isSupported(durationFieldType11);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        org.joda.time.LocalDate localDate22 = property19.addToCopy((int) (short) -1);
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        org.joda.time.DateTime dateTime25 = localDate22.toDateTimeAtCurrentTime(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(0L, 58216037);
        java.util.GregorianCalendar gregorianCalendar28 = dateTime27.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianCalendar28);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.LocalDate localDate16 = localDate14.withFields(readablePartial15);
        org.joda.time.LocalDate localDate18 = localDate14.plusMonths(79773993);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.DateTime dateTime22 = dateTime19.minusSeconds(1);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.DateTime.Property property24 = dateTime22.dayOfMonth();
        org.joda.time.DateTime dateTime26 = property24.addToCopy((long) (short) -1);
        int int27 = dateTime26.getEra();
        boolean boolean28 = dateTime3.equals((java.lang.Object) int27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.Instant instant33 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone34 = instant33.getZone();
        org.joda.time.Chronology chronology35 = gregorianChronology31.withZone(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = dateTime3.toDateTime(dateTimeZone34);
        org.joda.time.DurationFieldType durationFieldType37 = null;
        try {
            org.joda.time.DateTime dateTime39 = dateTime3.withFieldAdded(durationFieldType37, 79784588);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (long) 0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 79781426);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6682248446400000L + "'", long1 == 6682248446400000L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.DurationField durationField32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str46 = dateTimeZone44.getName(10L);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        java.util.Date date48 = dateTime47.toDate();
        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DurationField durationField62 = gJChronology61.millis();
        long long65 = durationField62.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate72 = localDate70.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial73 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate70);
        org.joda.time.LocalDate localDate75 = localDate70.plusYears(79760412);
        org.joda.time.LocalDate localDate77 = localDate75.minusWeeks(79763238);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval79 = localDate75.toInterval(dateTimeZone78);
        int[] intArray81 = null;
        try {
            int[] intArray83 = dividedDateTimeField68.add((org.joda.time.ReadablePartial) localDate75, 2, intArray81, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(interval79);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "-01:01");
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
        try {
            long long38 = unsupportedDateTimeField33.roundCeiling((long) 79759888);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate19 = localDate17.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
        org.joda.time.DurationField durationField21 = property20.getLeapDurationField();
        org.joda.time.LocalDate localDate22 = property20.getLocalDate();
        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) property20);
        org.joda.time.DurationField durationField24 = property20.getLeapDurationField();
        try {
            org.joda.time.LocalDate localDate26 = property20.setCopy(873103500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 873103500 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis(2922789, 79783214, 365, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79783214 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime17 = dateTime8.plusWeeks(58211980);
        org.joda.time.DateTime.Property property18 = dateTime8.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(79768574);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(58208573);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("15");
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfMonth();
        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) property7);
        java.lang.String str9 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone2);
        int int7 = dateTimeZone2.getOffsetFromLocal(1104537600000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3660000) + "'", int7 == (-3660000));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 79781426, 195, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now();
        int[] intArray3 = gJChronology0.get((org.joda.time.ReadablePartial) localDate1, (long) 0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        long long14 = dateTimeZone9.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime15 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone9);
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate16.getFields();
        boolean boolean18 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3660001L + "'", long14 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant0);
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 79767435L + "'", long1 == 79767435L);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
        org.joda.time.DateTime.Property property5 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property5.setCopy(20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(79766435L, (long) 79768574);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2139L) + "'", long2 == (-2139L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime5 = dateTime3.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.withMillis(10L);
        org.joda.time.DateTime dateTime9 = dateTime7.plusYears(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "0", "1970-01-01");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "-01:01", "GJChronology[UTC]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField33.getAsText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        try {
            long long41 = unsupportedDateTimeField39.roundCeiling((long) (-3660000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        java.util.Date date23 = dateTime22.toDate();
        org.joda.time.DateTime dateTime25 = dateTime22.minusSeconds(1);
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone27);
        long long32 = dateTimeZone27.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime33 = dateTime25.withZoneRetainFields(dateTimeZone27);
        int int34 = dateTime33.getSecondOfMinute();
        org.joda.time.LocalDateTime localDateTime35 = dateTime33.toLocalDateTime();
        int[] intArray37 = null;
        try {
            int[] intArray39 = skipDateTimeField5.set((org.joda.time.ReadablePartial) localDateTime35, (int) 'a', intArray37, 58216037);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3660001L + "'", long32 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
        org.junit.Assert.assertNotNull(localDateTime35);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        int int7 = skipDateTimeField5.get((long) 58216680);
        int int9 = skipDateTimeField5.getMaximumValue((long) 58206900);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1686 + "'", int7 == 1686);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292272708 + "'", int9 == 292272708);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendPattern("24");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = dateTime3.isSupported(dateTimeFieldType14);
        org.joda.time.DateTime dateTime17 = dateTime3.minusMonths(6);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear((-3660000));
        java.util.GregorianCalendar gregorianCalendar20 = dateTime17.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        int int4 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime0.dayOfYear();
        int int6 = dateTime0.getMonthOfYear();
        org.joda.time.DateTime.Property property7 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 76107435 + "'", int4 == 76107435);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1836857823091200000L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.DurationField durationField32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str46 = dateTimeZone44.getName(10L);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        java.util.Date date48 = dateTime47.toDate();
        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DurationField durationField62 = gJChronology61.millis();
        long long65 = durationField62.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
        long long71 = dividedDateTimeField68.set((long) (-3660000), 100);
        int int73 = dividedDateTimeField68.getMinimumValue((long) 79763238);
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str79 = dateTimeZone77.getName(10L);
        org.joda.time.LocalDate localDate80 = org.joda.time.LocalDate.now(dateTimeZone77);
        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate((long) 69, dateTimeZone77);
        org.joda.time.LocalDate localDate83 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate85 = localDate83.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate87 = new org.joda.time.LocalDate((long) (byte) 100);
        int int88 = localDate83.compareTo((org.joda.time.ReadablePartial) localDate87);
        boolean boolean89 = localDate81.isBefore((org.joda.time.ReadablePartial) localDate87);
        java.util.Locale locale91 = null;
        java.lang.String str92 = dividedDateTimeField68.getAsText((org.joda.time.ReadablePartial) localDate87, 79769610, locale91);
        long long94 = dividedDateTimeField68.remainder((long) 58208573);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 10098428340000L + "'", long71 == 10098428340000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "-01:01" + "'", str79.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(localDate85);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "79769610" + "'", str92.equals("79769610"));
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 58208573L + "'", long94 == 58208573L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.LocalDate localDate6 = localDate1.plusYears(79760412);
        int int7 = localDate6.getMonthOfYear();
        org.joda.time.LocalDate localDate9 = localDate6.plusWeeks(58216037);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
        java.util.Date date41 = dateTime40.toDate();
        org.joda.time.DateTime dateTime43 = dateTime40.minusSeconds(1);
        java.util.TimeZone timeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
        long long50 = dateTimeZone45.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime51 = dateTime43.withZoneRetainFields(dateTimeZone45);
        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone45);
        org.joda.time.LocalDate localDate54 = localDate52.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate56 = localDate54.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate58 = localDate56.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property59 = localDate58.dayOfYear();
        try {
            int int60 = unsupportedDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3660001L + "'", long50 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(property59);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTime dateTime9 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = property5.addToCopy(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        int int41 = skipDateTimeField10.get((long) (byte) 100);
        org.joda.time.DurationField durationField42 = skipDateTimeField10.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1686 + "'", int41 == 1686);
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        int int4 = dateTime3.getDayOfWeek();
        int int5 = dateTime3.getDayOfMonth();
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withMonthOfYear((-79767435));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -79767435 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.getID();
        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:01" + "'", str7.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
        try {
            long long25 = skipDateTimeField5.set((long) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        long long2 = property1.remainder();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 76107435L + "'", long2 == 76107435L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfEra(58211405);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.yearOfEra();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.DateTime dateTime16 = dateTime13.minusSeconds(1);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        long long23 = dateTimeZone18.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime24 = dateTime16.withZoneRetainFields(dateTimeZone18);
        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str26 = dateTimeZone18.toString();
        org.joda.time.Chronology chronology27 = copticChronology10.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime28 = dateTime8.toDateTime((org.joda.time.Chronology) copticChronology10);
        boolean boolean30 = dateTime8.isEqual((long) 58210108);
        org.joda.time.DateTime dateTime32 = dateTime8.withMinuteOfHour((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3660001L + "'", long23 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-01:01" + "'", str26.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.append(dateTimeFormatter8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(0L, 58216037);
        org.joda.time.DateTime dateTime28 = dateTime23.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.plus(readablePeriod29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int32 = gregorianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
        org.joda.time.DateTime dateTime34 = dateTime30.withZoneRetainFields(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
        java.util.Date date41 = dateTime40.toDate();
        org.joda.time.DateTime dateTime43 = dateTime40.minusSeconds(1);
        java.util.TimeZone timeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
        long long50 = dateTimeZone45.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime51 = dateTime43.withZoneRetainFields(dateTimeZone45);
        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now(dateTimeZone45);
        org.joda.time.LocalDate localDate54 = localDate52.plusMonths((int) (byte) 1);
        int int55 = localDate52.getEra();
        int int56 = localDate52.getMonthOfYear();
        org.joda.time.Instant instant58 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant59 = instant58.toInstant();
        org.joda.time.Instant instant60 = new org.joda.time.Instant((java.lang.Object) instant59);
        org.joda.time.DateTime dateTime61 = localDate52.toDateTime((org.joda.time.ReadableInstant) instant59);
        int[] intArray62 = new int[] {};
        try {
            int int63 = unsupportedDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate52, intArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3660001L + "'", long50 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(instant58);
        org.junit.Assert.assertNotNull(instant59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(intArray62);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("��:��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��:��:��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendOptional(dateTimeParser13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.append(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        int int14 = skipDateTimeField5.getLeapAmount((long) 58212218);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField5.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(obj0, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime11.withMillis(10L);
        org.joda.time.DateTime dateTime17 = dateTime11.minusHours(3);
        org.joda.time.DateTime dateTime18 = localDate7.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(58212218);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        java.util.Date date23 = dateTime22.toDate();
        boolean boolean24 = buddhistChronology21.equals((java.lang.Object) date23);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology21.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology21.monthOfYear();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology21.weekyearOfCentury();
        org.joda.time.DateTime dateTime28 = dateTime20.toDateTime((org.joda.time.Chronology) buddhistChronology21);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone10);
        java.lang.String str18 = dateTimeZone10.toString();
        org.joda.time.Chronology chronology19 = copticChronology2.withZone(dateTimeZone10);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(obj0, dateTimeZone10);
        int int21 = localDate20.getWeekOfWeekyear();
        java.lang.String str23 = localDate20.toString("15");
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-01:01" + "'", str18.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "15" + "'", str23.equals("15"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(873103500, 2019, 33, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendPattern("1686");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        java.lang.String str5 = dateTimeZone2.getShortName((long) (short) 100);
        long long9 = dateTimeZone2.convertLocalToUTC((long) 79762727, false, (long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 83422727L + "'", long9 == 83422727L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        org.joda.time.DateTime dateTime20 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 1686);
        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
        int int27 = property24.get();
        java.lang.String str28 = property24.getAsString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) instant2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant2.plus(readableDuration4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField10);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now();
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate12, 0, locale14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField20);
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate22, 0, locale24);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate22, locale26);
        org.joda.time.DateTimeField dateTimeField28 = skipDateTimeField11.getWrappedField();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        java.util.Date date30 = dateTime29.toDate();
        org.joda.time.DateTime dateTime32 = dateTime29.minusSeconds(1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime.Property property34 = dateTime32.dayOfMonth();
        org.joda.time.DateTime dateTime36 = property34.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str42 = dateTimeZone40.getName(10L);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        java.util.Date date44 = dateTime43.toDate();
        org.joda.time.DateTime dateTime46 = dateTime43.minusSeconds(1);
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
        long long53 = dateTimeZone48.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime54 = dateTime46.withZoneRetainFields(dateTimeZone48);
        org.joda.time.DateTime dateTime56 = dateTime46.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, (org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DurationField durationField58 = gJChronology57.millis();
        long long61 = durationField58.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField58);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField28, dateTimeFieldType37, 76107435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder65.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder66.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder69.appendFractionOfHour(58210407, 58211980);
        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now();
        java.util.Date date74 = dateTime73.toDate();
        org.joda.time.DateTime dateTime76 = dateTime73.minusSeconds(1);
        org.joda.time.LocalDate localDate77 = dateTime76.toLocalDate();
        org.joda.time.DateTime.Property property78 = dateTime76.dayOfMonth();
        org.joda.time.DateTime dateTime80 = property78.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = property78.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder72.appendText(dateTimeFieldType81);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField64, dateTimeFieldType81);
        boolean boolean84 = instant2.isSupported(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970" + "'", str27.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-01:01" + "'", str42.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3660001L + "'", long53 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-79761428L) + "'", long61 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 24, 9223372003910400035L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 24 * 9223372003910400035");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        boolean boolean14 = dateTimeZone5.isStandardOffset((long) 58206900);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        try {
            int[] intArray18 = gJChronology15.get(readablePeriod16, 1560640233993L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(gJChronology15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = buddhistChronology3.centuries();
        try {
            org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(79777231, (int) (short) 1, 79759888, (org.joda.time.Chronology) buddhistChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79759888 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-210866760000000L), chronology1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendOptional(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1686", (java.lang.Number) 10L, (java.lang.Number) 58212218, (java.lang.Number) 100.0f);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfDay(69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        long long23 = dateTimeZone18.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime24 = localDate14.toDateTimeAtStartOfDay(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        java.util.Date date26 = dateTime25.toDate();
        org.joda.time.DateTime dateTime28 = dateTime25.minusSeconds(1);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField34);
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now();
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate36, 0, locale38);
        int int42 = skipDateTimeField35.getDifference((long) (short) -1, (long) 0);
        int int43 = dateTime28.get((org.joda.time.DateTimeField) skipDateTimeField35);
        org.joda.time.DateTime dateTime45 = dateTime28.plusHours((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withDurationAdded(readableDuration46, 1686);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str53 = dateTimeZone51.getName(10L);
        org.joda.time.DateTime dateTime54 = dateTime48.toDateTime(dateTimeZone51);
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) dateTime54);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3660001L + "'", long23 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1686 + "'", int43 == 1686);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "-01:01" + "'", str53.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(gJChronology55);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
        java.lang.String str2 = illegalInstantException1.toString();
        java.lang.Throwable[] throwableArray3 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: hi!" + "'", str2.equals("org.joda.time.IllegalInstantException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        java.util.Date date7 = dateTime6.toDate();
        int int8 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property10 = dateTime5.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3660000) + "'", int9 == (-3660000));
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder2.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser4);
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            java.lang.String str8 = dateTimeFormatter6.print(readableInstant7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        long long20 = skipDateTimeField10.roundCeiling((long) 292272708);
        long long23 = skipDateTimeField10.add(0L, (long) (byte) 10);
        org.joda.time.DurationField durationField24 = skipDateTimeField10.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 21862860000L + "'", long20 == 21862860000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 315619200000L + "'", long23 == 315619200000L);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withMinuteOfHour(79762727);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79762727 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str5 = dateTimeZone3.getName(10L);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone3);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(obj0, dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        org.joda.time.LocalDate localDate22 = property19.addToCopy((int) (short) -1);
        org.joda.time.DateTimeField dateTimeField23 = property19.getField();
        int int24 = property19.getMinimumValue();
        org.joda.time.LocalDate localDate26 = property19.addWrapFieldToCopy(58208198);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(localDate26);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType6);
        try {
            long long10 = delegatedDateTimeField7.set(0L, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        try {
            long long42 = skipDateTimeField10.set((-210716856000000L), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime4 = dateTime0.minusMillis(6);
        long long5 = dateTime0.getMillis();
        org.joda.time.Chronology chronology6 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight8 = dateTime0.toDateMidnight();
        int int9 = dateMidnight8.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76107435 + "'", int1 == 76107435);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 79767435L + "'", long5 == 79767435L);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate19 = localDate17.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
        org.joda.time.DurationField durationField21 = property20.getLeapDurationField();
        org.joda.time.LocalDate localDate22 = property20.getLocalDate();
        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) property20);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.Chronology chronology26 = gregorianChronology0.withZone(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
        boolean boolean24 = skipDateTimeField15.isLenient();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
        int int29 = localDate26.size();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
        boolean boolean35 = skipDateTimeField15.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
        org.joda.time.DurationField durationField37 = null;
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        java.util.Date date39 = dateTime38.toDate();
        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str51 = dateTimeZone49.getName(10L);
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
        java.util.Date date53 = dateTime52.toDate();
        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
        java.util.TimeZone timeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DurationField durationField67 = gJChronology66.millis();
        long long70 = durationField67.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
        int int78 = offsetDateTimeField77.getMaximumValue();
        try {
            long long81 = offsetDateTimeField77.add(58210108L, 0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for dayOfMonth must be in the range [79772937,33]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3660001L + "'", long62 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 33 + "'", int78 == 33);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        long long20 = skipDateTimeField10.remainder((long) (byte) 1);
        java.lang.String str22 = skipDateTimeField10.getAsText(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9673140001L + "'", long20 == 9673140001L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1686" + "'", str22.equals("1686"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        java.util.GregorianCalendar gregorianCalendar2 = dateTime0.toGregorianCalendar();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar2);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        java.lang.String str23 = skipDateTimeField10.getAsText((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1686" + "'", str23.equals("1686"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int12 = skipDateTimeField5.getDifference((long) (short) -1, (long) 0);
        java.lang.String str14 = skipDateTimeField5.getAsShortText((long) 6);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (byte) 100);
        int int17 = localDate16.getYearOfCentury();
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, (int) (byte) 100, locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField5.getMaximumTextLength(locale21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1686" + "'", str14.equals("1686"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText((long) 58208573, locale14);
        long long17 = skipDateTimeField5.roundHalfCeiling(21884400000L);
        boolean boolean19 = skipDateTimeField5.isLeap((long) 365);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1686" + "'", str15.equals("1686"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 21862860000L + "'", long17 == 21862860000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = dateTime3.isSupported(dateTimeFieldType14);
        org.joda.time.DateTime dateTime17 = dateTime3.minusMonths(6);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, 69);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str4 = dateTimeZone2.getName(10L);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime16 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime18 = dateTime8.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        java.util.Date date21 = dateTime20.toDate();
        org.joda.time.DateTime dateTime23 = dateTime20.minusSeconds(1);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
        long long30 = dateTimeZone25.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime31 = dateTime23.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime8.toDateTime(dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str38 = dateTimeZone36.getName(10L);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        java.util.Date date40 = dateTime39.toDate();
        org.joda.time.DateTime dateTime42 = dateTime39.minusSeconds(1);
        java.util.TimeZone timeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone44);
        long long49 = dateTimeZone44.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime50 = dateTime42.withZoneRetainFields(dateTimeZone44);
        org.joda.time.DateTime dateTime52 = dateTime42.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime55 = dateTime42.withMillisOfDay(70);
        boolean boolean56 = iSOChronology33.equals((java.lang.Object) dateTime42);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology33.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:01" + "'", str4.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3660001L + "'", long15 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3660001L + "'", long30 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-01:01" + "'", str38.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 3660001L + "'", long49 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeField57);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser10);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder13.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser15);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatterBuilder18.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatterBuilder22.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder25.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatterBuilder31.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser33);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray35 = new org.joda.time.format.DateTimeParser[] { dateTimeParser10, dateTimeParser15, dateTimeParser20, dateTimeParser24, dateTimeParser27, dateTimeParser33 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder5.append(dateTimePrinter6, dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(4, 79767435, (int) (byte) -1, 68931, 15, 58215989, 0, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68931 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalFieldValueException10.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException10.getDateTimeFieldType();
        java.lang.Number number16 = illegalFieldValueException10.getIllegalNumberValue();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.joda.time.DurationFieldType durationFieldType18 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNull(durationFieldType18);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        int int11 = skipDateTimeField5.get(28800001L);
        int int13 = skipDateTimeField5.getMinimumValue((long) (byte) -1);
        boolean boolean14 = skipDateTimeField5.isLenient();
        java.lang.String str15 = skipDateTimeField5.toString();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.secondOfDay();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate24 = localDate22.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
        int int27 = localDate26.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray28 = localDate26.getFieldTypes();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        java.util.Date date30 = dateTime29.toDate();
        org.joda.time.DateTime dateTime32 = dateTime29.minusSeconds(1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = copticChronology36.secondOfDay();
        org.joda.time.DateTimeField dateTimeField38 = copticChronology36.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField38);
        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now();
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) localDate40, 0, locale42);
        int int46 = skipDateTimeField39.getDifference((long) (short) -1, (long) 0);
        int int47 = dateTime32.get((org.joda.time.DateTimeField) skipDateTimeField39);
        boolean boolean48 = skipDateTimeField39.isLenient();
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate52 = localDate50.withCenturyOfEra((int) (byte) 0);
        int int53 = localDate50.size();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate55 = org.joda.time.LocalDate.now();
        int[] intArray57 = gJChronology54.get((org.joda.time.ReadablePartial) localDate55, (long) 0);
        int int58 = skipDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate50, intArray57);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = copticChronology60.secondOfDay();
        org.joda.time.DateTimeField dateTimeField62 = copticChronology60.clockhourOfHalfday();
        org.joda.time.Partial partial63 = new org.joda.time.Partial(dateTimeFieldTypeArray28, intArray57, (org.joda.time.Chronology) copticChronology60);
        copticChronology19.validate((org.joda.time.ReadablePartial) localDate24, intArray57);
        try {
            int[] intArray66 = skipDateTimeField5.addWrapField(readablePartial16, 79777231, intArray57, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79777231");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[yearOfEra]" + "'", str15.equals("DateTimeField[yearOfEra]"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 69 + "'", int27 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1686 + "'", int47 == 1686);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(copticChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str7 = dateTimeZone5.getName(10L);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        long long18 = dateTimeZone13.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime19 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTime dateTime21 = dateTime11.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        long long33 = dateTimeZone28.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime34 = dateTime26.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTime dateTime35 = dateTime11.toDateTime(dateTimeZone28);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        try {
            org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(58216680, 1686, 7, (org.joda.time.Chronology) iSOChronology36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-01:01" + "'", str7.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3660001L + "'", long18 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3660001L + "'", long33 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology36);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str36 = dateTimeZone34.getName(10L);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        java.util.Date date38 = dateTime37.toDate();
        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
        java.util.TimeZone timeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DurationField durationField52 = gJChronology51.millis();
        long long55 = durationField52.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
        int int59 = remainderDateTimeField58.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.DurationField durationField4 = buddhistChronology2.eras();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.hourOfDay();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate9 = localDate7.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate localDate12 = localDate7.plusYears(79760412);
        int int13 = localDate12.getMonthOfYear();
        java.lang.String str14 = localDate12.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str16 = localDate12.toString(dateTimeFormatter15);
        int[] intArray18 = buddhistChronology2.get((org.joda.time.ReadablePartial) localDate12, (long) 58210407);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "79762381-12-31" + "'", str14.equals("79762381-12-31"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "��:��:��" + "'", str16.equals("��:��:��"));
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMinimumValue();
        org.joda.time.LocalDate localDate22 = property19.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate23 = property19.withMaximumValue();
        org.joda.time.DurationField durationField24 = property19.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        long long12 = skipDateTimeField5.getDifferenceAsLong((long) 58211980, (long) 1735);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText((long) 58208573, locale14);
        org.joda.time.DurationField durationField16 = skipDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1686" + "'", str15.equals("1686"));
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-210716856000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology25.secondOfDay();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology25.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField27);
        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.now();
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate29, 0, locale31);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField37);
        org.joda.time.LocalDate localDate39 = org.joda.time.LocalDate.now();
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate39, 0, locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate39, locale43);
        org.joda.time.DateTimeField dateTimeField45 = skipDateTimeField28.getWrappedField();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        java.util.Date date47 = dateTime46.toDate();
        org.joda.time.DateTime dateTime49 = dateTime46.minusSeconds(1);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        org.joda.time.DateTime.Property property51 = dateTime49.dayOfMonth();
        org.joda.time.DateTime dateTime53 = property51.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property51.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str59 = dateTimeZone57.getName(10L);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
        java.util.Date date61 = dateTime60.toDate();
        org.joda.time.DateTime dateTime63 = dateTime60.minusSeconds(1);
        java.util.TimeZone timeZone64 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone65);
        long long70 = dateTimeZone65.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime71 = dateTime63.withZoneRetainFields(dateTimeZone65);
        org.joda.time.DateTime dateTime73 = dateTime63.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, (org.joda.time.ReadableInstant) dateTime63);
        org.joda.time.DurationField durationField75 = gJChronology74.millis();
        long long78 = durationField75.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType54, durationField75);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField81 = new org.joda.time.field.RemainderDateTimeField(dateTimeField45, dateTimeFieldType54, 76107435);
        org.joda.time.DurationField durationField82 = remainderDateTimeField81.getLeapDurationField();
        org.joda.time.DurationField durationField83 = remainderDateTimeField81.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, durationField83, dateTimeFieldType84, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970" + "'", str44.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "-01:01" + "'", str59.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(buddhistChronology66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 3660001L + "'", long70 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-79761428L) + "'", long78 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
        org.junit.Assert.assertNull(durationField82);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (byte) 100);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = localDate1.isSupported(durationFieldType7);
        java.util.Date date9 = localDate1.toDate();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(58212218);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58212218 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.DurationField durationField32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str46 = dateTimeZone44.getName(10L);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        java.util.Date date48 = dateTime47.toDate();
        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DurationField durationField62 = gJChronology61.millis();
        long long65 = durationField62.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
        long long70 = dividedDateTimeField68.remainder((long) 873103500);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 873103500L + "'", long70 == 873103500L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime8.withZone(dateTimeZone11);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        int int24 = skipDateTimeField10.get((long) 9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1686 + "'", int24 == 1686);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
        boolean boolean23 = skipDateTimeField14.isLenient();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
        int int28 = localDate25.size();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
        int[] intArray39 = partial38.getValues();
        int[] intArray40 = partial38.getValues();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        try {
            org.joda.time.Partial partial43 = partial38.withFieldAddWrapped(durationFieldType41, 79770099);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
        org.joda.time.LocalDate localDate20 = property19.withMaximumValue();
        try {
            org.joda.time.LocalDate localDate22 = localDate20.withDayOfMonth((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(79770099, 0, 79783214, 0, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.centuries();
        long long4 = durationField1.subtract((long) (-3660001), 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3660001L) + "'", long4 == (-3660001L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.minusSeconds(1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime12 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 1);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate13);
        boolean boolean17 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3660001L + "'", long11 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970-01-01T��:��:��.000" + "'", str16.equals("1970-01-01T��:��:��.000"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(10);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.plus(readableDuration16);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField33.getAsShortText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
        try {
            int int38 = unsupportedDateTimeField33.getMinimumValue((long) 79777231);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str36 = dateTimeZone34.getName(10L);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        java.util.Date date38 = dateTime37.toDate();
        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
        java.util.TimeZone timeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DurationField durationField52 = gJChronology51.millis();
        long long55 = durationField52.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = remainderDateTimeField58.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1686, (-79767435), 2, 58215434, (int) (byte) 0, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58215434 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019", "15");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField10);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now();
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDate12, 0, locale14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField20);
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDate22, 0, locale24);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate22, locale26);
        org.joda.time.DateTimeField dateTimeField28 = skipDateTimeField11.getWrappedField();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        java.util.Date date30 = dateTime29.toDate();
        org.joda.time.DateTime dateTime32 = dateTime29.minusSeconds(1);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        org.joda.time.DateTime.Property property34 = dateTime32.dayOfMonth();
        org.joda.time.DateTime dateTime36 = property34.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str42 = dateTimeZone40.getName(10L);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        java.util.Date date44 = dateTime43.toDate();
        org.joda.time.DateTime dateTime46 = dateTime43.minusSeconds(1);
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
        long long53 = dateTimeZone48.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime54 = dateTime46.withZoneRetainFields(dateTimeZone48);
        org.joda.time.DateTime dateTime56 = dateTime46.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, (org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DurationField durationField58 = gJChronology57.millis();
        long long61 = durationField58.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField58);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField28, dateTimeFieldType37, 76107435);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType37, (int) (byte) -1, 58210407);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970" + "'", str27.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-01:01" + "'", str42.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3660001L + "'", long53 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-79761428L) + "'", long61 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfEra(58211405);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.yearOfEra();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.DateTime dateTime16 = dateTime13.minusSeconds(1);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        long long23 = dateTimeZone18.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime24 = dateTime16.withZoneRetainFields(dateTimeZone18);
        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now(dateTimeZone18);
        java.lang.String str26 = dateTimeZone18.toString();
        org.joda.time.Chronology chronology27 = copticChronology10.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime28 = dateTime8.toDateTime((org.joda.time.Chronology) copticChronology10);
        org.joda.time.Instant instant29 = dateTime28.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3660001L + "'", long23 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-01:01" + "'", str26.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(instant29);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        java.lang.String str6 = dateTimeZone3.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        try {
            long long13 = copticChronology8.getDateTimeMillis((int) (byte) -1, 33, 79784588, 58211405);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:01" + "'", str6.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField29);
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale33);
        org.joda.time.DateTime dateTime35 = localDate31.toDateTimeAtMidnight();
        int[] intArray38 = new int[] { 'a', 58210108 };
        int int39 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate31, intArray38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate41 = localDate31.minus(readablePeriod40);
        org.joda.time.Interval interval42 = localDate41.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(interval42);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(58210407, 58211980);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        org.joda.time.DateTime.Property property13 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType16);
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.append(dateTimePrinter18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100);
        int int39 = localDate38.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray40 = localDate38.getFieldTypes();
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (byte) 100);
        int int43 = localDate42.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray44 = localDate42.getFieldTypes();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        java.util.Date date46 = dateTime45.toDate();
        org.joda.time.DateTime dateTime48 = dateTime45.minusSeconds(1);
        org.joda.time.LocalDate localDate49 = dateTime48.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.secondOfDay();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology52.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology50, dateTimeField54);
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.now();
        java.util.Locale locale58 = null;
        java.lang.String str59 = skipDateTimeField55.getAsShortText((org.joda.time.ReadablePartial) localDate56, 0, locale58);
        int int62 = skipDateTimeField55.getDifference((long) (short) -1, (long) 0);
        int int63 = dateTime48.get((org.joda.time.DateTimeField) skipDateTimeField55);
        boolean boolean64 = skipDateTimeField55.isLenient();
        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate68 = localDate66.withCenturyOfEra((int) (byte) 0);
        int int69 = localDate66.size();
        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate71 = org.joda.time.LocalDate.now();
        int[] intArray73 = gJChronology70.get((org.joda.time.ReadablePartial) localDate71, (long) 0);
        int int74 = skipDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) localDate66, intArray73);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.chrono.CopticChronology copticChronology76 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone75);
        org.joda.time.DateTimeField dateTimeField77 = copticChronology76.secondOfDay();
        org.joda.time.DateTimeField dateTimeField78 = copticChronology76.clockhourOfHalfday();
        org.joda.time.Partial partial79 = new org.joda.time.Partial(dateTimeFieldTypeArray44, intArray73, (org.joda.time.Chronology) copticChronology76);
        int[] intArray80 = partial79.getValues();
        int[] intArray81 = partial79.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology82 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean84 = iSOChronology82.equals((java.lang.Object) 28800001L);
        org.joda.time.DateTimeField dateTimeField85 = iSOChronology82.minuteOfHour();
        org.joda.time.Partial partial86 = new org.joda.time.Partial(dateTimeFieldTypeArray40, intArray81, (org.joda.time.Chronology) iSOChronology82);
        org.joda.time.ReadablePeriod readablePeriod87 = null;
        org.joda.time.Partial partial89 = partial86.withPeriodAdded(readablePeriod87, 79762727);
        java.util.Locale locale91 = null;
        try {
            java.lang.String str92 = unsupportedDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) partial86, (-3660000), locale91);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 69 + "'", int43 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1686 + "'", int63 == 1686);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
        org.junit.Assert.assertNotNull(gJChronology70);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(copticChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(iSOChronology82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(partial89);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone5);
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localDate12.getFields();
        org.joda.time.LocalDate.Property property14 = localDate12.weekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(58216680, 68931, (-25200000), (int) '4', 0, 79760412, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now();
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate6, 0, locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate16, locale20);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField5.getWrappedField();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTime dateTime26 = dateTime23.minusSeconds(1);
        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfMonth();
        org.joda.time.DateTime dateTime30 = property28.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str36 = dateTimeZone34.getName(10L);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        java.util.Date date38 = dateTime37.toDate();
        org.joda.time.DateTime dateTime40 = dateTime37.minusSeconds(1);
        java.util.TimeZone timeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
        long long47 = dateTimeZone42.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime48 = dateTime40.withZoneRetainFields(dateTimeZone42);
        org.joda.time.DateTime dateTime50 = dateTime40.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DurationField durationField52 = gJChronology51.millis();
        long long55 = durationField52.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField52);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 76107435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder59.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder60.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder63.appendFractionOfHour(58210407, 58211980);
        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now();
        java.util.Date date68 = dateTime67.toDate();
        org.joda.time.DateTime dateTime70 = dateTime67.minusSeconds(1);
        org.joda.time.LocalDate localDate71 = dateTime70.toLocalDate();
        org.joda.time.DateTime.Property property72 = dateTime70.dayOfMonth();
        org.joda.time.DateTime dateTime74 = property72.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property72.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType75);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField58, dateTimeFieldType75);
        try {
            long long80 = dividedDateTimeField77.add((long) (short) 1, 84);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2098058930 for year must be in the range [-292269337,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-01:01" + "'", str36.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3660001L + "'", long47 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-79761428L) + "'", long55 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 79770099);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean6 = iSOChronology4.equals((java.lang.Object) 28800001L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone3, (org.joda.time.Chronology) iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-4T21:08:30.099-01:01" + "'", str2.equals("1970-W01-4T21:08:30.099-01:01"));
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.Instant instant2 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) instant3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant3.plus(readableDuration5);
        org.joda.time.Instant instant8 = instant3.withMillis((long) 3);
        org.joda.time.MutableDateTime mutableDateTime9 = instant3.toMutableDateTime();
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "hi!", 58215989);
        java.io.Writer writer13 = null;
        try {
            dateTimeFormatter0.printTo(writer13, 21862860000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-58215990) + "'", int12 == (-58215990));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks((int) (short) 0);
        org.joda.time.LocalDate localDate18 = localDate16.withCenturyOfEra(0);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.DateTime dateTime22 = dateTime19.minusSeconds(1);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        org.joda.time.DateTime.Property property24 = dateTime22.dayOfMonth();
        org.joda.time.DateTime dateTime26 = property24.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        int int28 = localDate16.get(dateTimeFieldType27);
        boolean boolean29 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate16);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(68931);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.DurationField durationField32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(1);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        org.joda.time.DateTime.Property property38 = dateTime36.dayOfMonth();
        org.joda.time.DateTime dateTime40 = property38.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str46 = dateTimeZone44.getName(10L);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        java.util.Date date48 = dateTime47.toDate();
        org.joda.time.DateTime dateTime50 = dateTime47.minusSeconds(1);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
        long long57 = dateTimeZone52.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime58 = dateTime50.withZoneRetainFields(dateTimeZone52);
        org.joda.time.DateTime dateTime60 = dateTime50.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DurationField durationField62 = gJChronology61.millis();
        long long65 = durationField62.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField62);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, durationField32, dateTimeFieldType41, 20);
        long long71 = dividedDateTimeField68.set((long) (-3660000), 100);
        int int73 = dividedDateTimeField68.getMinimumValue((long) 79763238);
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str79 = dateTimeZone77.getName(10L);
        org.joda.time.LocalDate localDate80 = org.joda.time.LocalDate.now(dateTimeZone77);
        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate((long) 69, dateTimeZone77);
        org.joda.time.LocalDate localDate83 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate85 = localDate83.withCenturyOfEra((int) (byte) 0);
        org.joda.time.LocalDate localDate87 = new org.joda.time.LocalDate((long) (byte) 100);
        int int88 = localDate83.compareTo((org.joda.time.ReadablePartial) localDate87);
        boolean boolean89 = localDate81.isBefore((org.joda.time.ReadablePartial) localDate87);
        java.util.Locale locale91 = null;
        java.lang.String str92 = dividedDateTimeField68.getAsText((org.joda.time.ReadablePartial) localDate87, 79769610, locale91);
        int int93 = localDate87.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-01:01" + "'", str46.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3660001L + "'", long57 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-79761428L) + "'", long65 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 10098428340000L + "'", long71 == 10098428340000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "-01:01" + "'", str79.equals("-01:01"));
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(localDate85);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "79769610" + "'", str92.equals("79769610"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 31 + "'", int93 == 31);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str5 = dateTimeZone3.getName(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 58211405, dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-01:01" + "'", str5.equals("-01:01"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder15.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder19.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitYear(58206900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatterBuilder30.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder24.append(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser40 = dateTimeFormatterBuilder38.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder36.appendOptional(dateTimeParser40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder42.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatterBuilder47.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder45.appendOptional(dateTimeParser49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder42.appendOptional(dateTimeParser49);
        org.joda.time.format.DateTimePrinter dateTimePrinter52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder53.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatterBuilder53.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter52, dateTimeParser55);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray57 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17, dateTimeParser32, dateTimeParser40, dateTimeParser49, dateTimeParser55 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder8.append(dateTimePrinter13, dateTimeParserArray57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeParser40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeParser55);
        org.junit.Assert.assertNotNull(dateTimeParserArray57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("America/Los_Angeles", "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", true, 58210407, 58218768);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYearOfEra(58211980, 79770099);
        boolean boolean20 = dateTimeFormatterBuilder16.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        int int10 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime8);
        int int11 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime12 = dateTime7.withEarlierOffsetAtOverlap();
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime7.plusMonths(0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3660000) + "'", int11 == (-3660000));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 79766435L + "'", long13 == 79766435L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("0");
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.minus(readablePeriod2);
        int int4 = localDate3.getCenturyOfEra();
        org.joda.time.DateMidnight dateMidnight5 = localDate3.toDateMidnight();
        org.joda.time.MutableDateTime mutableDateTime6 = dateMidnight5.toMutableDateTime();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 58218768, 58208198);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58208198");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("15");
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(1);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfMonth();
        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) property7);
        org.joda.time.DurationField durationField9 = property7.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(1, (-3660001), 79773993, 1686, 79767435, 79760412, 79768574);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfWeek();
        java.util.GregorianCalendar gregorianCalendar2 = dateTime0.toGregorianCalendar();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.fromCalendarFields((java.util.Calendar) gregorianCalendar2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = copticChronology5.millis();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.era();
        boolean boolean8 = localDate3.equals((java.lang.Object) copticChronology5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        int int21 = skipDateTimeField10.getDifference((long) 10, (long) 6);
        int int22 = skipDateTimeField10.getMaximumValue();
        boolean boolean24 = skipDateTimeField10.isLeap((long) (-1));
        int int26 = skipDateTimeField10.get(2440588L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272708 + "'", int22 == 292272708);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1686 + "'", int26 == 1686);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(58206900);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimePrinter8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str13 = dateTimeZone11.getName(10L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTime dateTime17 = dateTime14.minusSeconds(1);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime25 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime17.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        long long32 = durationField29.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField29);
        long long36 = unsupportedDateTimeField33.getDifferenceAsLong((long) 'a', (long) 4);
        org.joda.time.DurationField durationField37 = unsupportedDateTimeField33.getRangeDurationField();
        long long40 = unsupportedDateTimeField33.add((long) 'a', 79769610);
        java.util.Locale locale41 = null;
        try {
            int int42 = unsupportedDateTimeField33.getMaximumShortTextLength(locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:01" + "'", str13.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3660001L + "'", long24 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-79761428L) + "'", long32 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 93L + "'", long36 == 93L);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 79769707L + "'", long40 == 79769707L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 28800001L);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(1);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate16, 0, locale18);
        int int22 = skipDateTimeField15.getDifference((long) (short) -1, (long) 0);
        int int23 = dateTime8.get((org.joda.time.DateTimeField) skipDateTimeField15);
        boolean boolean24 = skipDateTimeField15.isLenient();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate28 = localDate26.withCenturyOfEra((int) (byte) 0);
        int int29 = localDate26.size();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now();
        int[] intArray33 = gJChronology30.get((org.joda.time.ReadablePartial) localDate31, (long) 0);
        int int34 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray33);
        boolean boolean35 = skipDateTimeField15.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField15.getType();
        org.joda.time.DurationField durationField37 = null;
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        java.util.Date date39 = dateTime38.toDate();
        org.joda.time.DateTime dateTime41 = dateTime38.minusSeconds(1);
        org.joda.time.LocalDate localDate42 = dateTime41.toLocalDate();
        org.joda.time.DateTime.Property property43 = dateTime41.dayOfMonth();
        org.joda.time.DateTime dateTime45 = property43.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        java.lang.String str51 = dateTimeZone49.getName(10L);
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
        java.util.Date date53 = dateTime52.toDate();
        org.joda.time.DateTime dateTime55 = dateTime52.minusSeconds(1);
        java.util.TimeZone timeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone57);
        long long62 = dateTimeZone57.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime63 = dateTime55.withZoneRetainFields(dateTimeZone57);
        org.joda.time.DateTime dateTime65 = dateTime55.plusSeconds(10);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DurationField durationField67 = gJChronology66.millis();
        long long70 = durationField67.subtract(0L, (long) 79761428);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField67);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, durationField37, dateTimeFieldType46, 20);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType46, (int) (byte) 10, 79772937, 79759888);
        long long79 = offsetDateTimeField77.remainder((long) 195);
        java.util.Locale locale81 = null;
        java.lang.String str82 = offsetDateTimeField77.getAsShortText((long) 70, locale81);
        try {
            long long85 = offsetDateTimeField77.set(10098428340000L, "1970");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfMonth must be in the range [79772937,33]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1686 + "'", int23 == 1686);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-01:01" + "'", str51.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3660001L + "'", long62 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-79761428L) + "'", long70 == (-79761428L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 195L + "'", long79 == 195L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10" + "'", str82.equals("10"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(58210407, 58211980);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.minusSeconds(1);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        org.joda.time.DateTime.Property property13 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfDay(3, 70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant4 = org.joda.time.Instant.parse("0");
        org.joda.time.DateTimeZone dateTimeZone5 = instant4.getZone();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        java.util.Date date10 = dateTime9.toDate();
        org.joda.time.DateTime dateTime12 = dateTime9.minusSeconds(1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        java.util.Date date14 = dateTime13.toDate();
        int int15 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime13);
        int int16 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime17 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        java.util.Date date19 = dateTime18.toDate();
        org.joda.time.DateTime dateTime21 = dateTime18.minusSeconds(1);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        long long28 = dateTimeZone23.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime29 = dateTime21.withZoneRetainFields(dateTimeZone23);
        org.joda.time.DateTime dateTime31 = dateTime21.plusSeconds(10);
        try {
            org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-3660000) + "'", int16 == (-3660000));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3660001L + "'", long28 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        int int3 = localDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        boolean boolean19 = skipDateTimeField10.isLenient();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate23 = localDate21.withCenturyOfEra((int) (byte) 0);
        int int24 = localDate21.size();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now();
        int[] intArray28 = gJChronology25.get((org.joda.time.ReadablePartial) localDate26, (long) 0);
        int int29 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate21, intArray28);
        boolean boolean30 = skipDateTimeField10.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField10.getType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        java.util.Date date34 = dateTime33.toDate();
        boolean boolean35 = buddhistChronology32.equals((java.lang.Object) date34);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField38 = buddhistChronology32.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType31, durationField38);
        try {
            long long41 = unsupportedDateTimeField39.roundHalfFloor(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime7.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField9);
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDate11, 0, locale13);
        int int17 = skipDateTimeField10.getDifference((long) (short) -1, (long) 0);
        int int18 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField10);
        long long20 = skipDateTimeField10.roundCeiling((long) 292272708);
        long long23 = skipDateTimeField10.add(0L, (long) (byte) 10);
        int int24 = skipDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1686 + "'", int18 == 1686);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 21862860000L + "'", long20 == 21862860000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 315619200000L + "'", long23 == 315619200000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292272708 + "'", int24 == 292272708);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime3 = dateTime0.minusSeconds(1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (-1L));
        org.joda.time.DateTime dateTime11 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (byte) 1);
        int int15 = localDate12.getEra();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) -1);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
        java.lang.String str23 = dateTimeZone20.getShortName((long) (short) 100);
        org.joda.time.Chronology chronology24 = copticChronology17.withZone(dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTime dateTime26 = localDate12.toDateTimeAtStartOfDay(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3660001L + "'", long10 == 3660001L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-01:01" + "'", str23.equals("-01:01"));
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (byte) 100);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = localDate1.getFieldTypes();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.minusSeconds(1);
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDate15, 0, locale17);
        int int21 = skipDateTimeField14.getDifference((long) (short) -1, (long) 0);
        int int22 = dateTime7.get((org.joda.time.DateTimeField) skipDateTimeField14);
        boolean boolean23 = skipDateTimeField14.isLenient();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100);
        org.joda.time.LocalDate localDate27 = localDate25.withCenturyOfEra((int) (byte) 0);
        int int28 = localDate25.size();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now();
        int[] intArray32 = gJChronology29.get((org.joda.time.ReadablePartial) localDate30, (long) 0);
        int int33 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate25, intArray32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.secondOfDay();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.clockhourOfHalfday();
        org.joda.time.Partial partial38 = new org.joda.time.Partial(dateTimeFieldTypeArray3, intArray32, (org.joda.time.Chronology) copticChronology35);
        java.lang.String str40 = partial38.toString("-01:01");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendTimeZoneName();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatterBuilder41.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendFractionOfSecond((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendTwoDigitYear(58206900);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap49 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder46.appendTimeZoneShortName(strMap49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder51.appendTimeZoneOffset("America/Los_Angeles", "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", true, 58210407, 58218768);
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
        java.util.Date date59 = dateTime58.toDate();
        org.joda.time.DateTime dateTime61 = dateTime58.minusSeconds(1);
        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
        org.joda.time.DateTime.Property property63 = dateTime61.dayOfMonth();
        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property63.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder51.appendFraction(dateTimeFieldType66, (int) 'a', 365);
        org.joda.time.Partial.Property property70 = partial38.property(dateTimeFieldType66);
        try {
            org.joda.time.Partial partial72 = property70.setCopy("-01:01");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-01:01\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-01:01" + "'", str40.equals("-01:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(strMap49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(property70);
    }
}

