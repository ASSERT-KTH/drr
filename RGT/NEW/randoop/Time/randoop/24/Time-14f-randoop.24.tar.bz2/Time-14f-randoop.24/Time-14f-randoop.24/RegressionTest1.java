import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        int int4 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        org.joda.time.Chronology chronology20 = limitChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        int int22 = cachedDateTimeZone19.getStandardOffset(28800040L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime14 = property10.addToCopy((long) (-28800000));
        long long15 = property10.remainder();
        java.util.Locale locale16 = null;
        int int17 = property10.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime5.yearOfEra();
        org.joda.time.LocalTime localTime11 = dateTime5.toLocalTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = dateTime5.withChronology((org.joda.time.Chronology) buddhistChronology12);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        long long46 = zeroIsMaxDateTimeField32.getDifferenceAsLong((-1817717760000422000L), (-891583653400010L));
//        int int48 = zeroIsMaxDateTimeField32.getMinimumValue((-1861920000000L));
//        long long51 = zeroIsMaxDateTimeField32.add((long) 100, 139);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-21028080744L) + "'", long46 == (-21028080744L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 12009600100L + "'", long51 == 12009600100L);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 10.0f, (org.joda.time.Chronology) copticChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = limitChronology4.withUTC();
        org.joda.time.DurationField durationField6 = limitChronology4.days();
        org.joda.time.Chronology chronology7 = limitChronology4.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        boolean boolean18 = dateTime16.isEqual(0L);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay.Property property23 = monthDay17.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = copticChronology24.getZone();
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.chrono.LimitChronology limitChronology28 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology24, readableDateTime26, readableDateTime27);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField(chronology29, dateTimeField32, (int) '#');
        int int36 = skipUndoDateTimeField34.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology28, (org.joda.time.DateTimeField) skipUndoDateTimeField34, 3);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withZoneRetainFields(dateTimeZone41);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone43 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone41);
        org.joda.time.Chronology chronology44 = limitChronology28.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone43);
        org.joda.time.MonthDay monthDay45 = monthDay17.withChronologyRetainFields(chronology44);
        org.joda.time.ReadablePartial readablePartial46 = null;
        try {
            int int47 = monthDay17.compareTo(readablePartial46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(limitChronology28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 69 + "'", int36 == 69);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(cachedDateTimeZone43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(monthDay45);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = julianChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekOfWeekyear();
        java.lang.String str11 = buddhistChronology9.toString();
        boolean boolean12 = julianChronology3.equals((java.lang.Object) str11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long18 = dateTimeZone14.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.Chronology chronology20 = julianChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(30);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone22);
        long long25 = cachedDateTimeZone19.getMillisKeepLocal(dateTimeZone22, 0L);
        org.joda.time.Chronology chronology26 = gJChronology0.withZone(dateTimeZone22);
        org.joda.time.DurationField durationField27 = gJChronology0.seconds();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BuddhistChronology[UTC]" + "'", str11.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-108000000L) + "'", long25 == (-108000000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean3 = instant2.isEqualNow();
        org.joda.time.Instant instant6 = instant2.withDurationAdded((long) (-28800000), (-28800000));
        int int7 = instant0.compareTo((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Instant instant8 = instant6.toInstant();
        org.joda.time.Instant instant11 = instant6.withDurationAdded(21550L, 40);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.Instant instant7 = instant5.plus(0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYear(28253, (int) ' ');
        dateTimeFormatterBuilder9.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        int int72 = dividedDateTimeField69.getDifference((-1817717760000422000L), 25L);
        long long75 = dividedDateTimeField69.addWrapField(0L, (int) '4');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1920000) + "'", int72 == (-1920000));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "0000-10-01T00:01:40.000", 1, 1);
        int int6 = fixedDateTimeZone4.getOffset((-62167219622000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = delegatedDateTimeField4.getAsShortText(readablePartial8, 0, locale10);
//        java.lang.String str13 = delegatedDateTimeField4.getAsText((long) 69);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "24" + "'", str13.equals("24"));
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
//        java.lang.String str8 = buddhistChronology6.toString();
//        boolean boolean9 = julianChronology0.equals((java.lang.Object) str8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long15 = dateTimeZone11.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.Chronology chronology17 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(30);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        long long22 = cachedDateTimeZone16.getMillisKeepLocal(dateTimeZone19, 0L);
//        java.lang.String str24 = cachedDateTimeZone16.getName((-108000000L));
//        java.lang.Object obj25 = null;
//        boolean boolean26 = cachedDateTimeZone16.equals(obj25);
//        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        int int28 = monthDay27.getDayOfMonth();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[UTC]" + "'", str8.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-108000000L) + "'", long22 == (-108000000L));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordinated Universal Time" + "'", str24.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType28, (int) (byte) 0, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatterBuilder32.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (int) (byte) 1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.ReadableDateTime readableDateTime5 = null;
//        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
//        int int11 = monthDay9.getValue(0);
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
//        java.lang.String str13 = monthDay12.toString();
//        boolean boolean14 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay12);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(limitChronology6);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "--01-02" + "'", str13.equals("--01-02"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        long long45 = zeroIsMaxDateTimeField32.roundHalfCeiling(0L);
//        long long47 = zeroIsMaxDateTimeField32.roundCeiling((long) (short) 100);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 86400000L + "'", long47 == 86400000L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumShortTextLength(locale10);
        java.lang.String str12 = property9.getAsString();
        org.joda.time.DurationField durationField13 = property9.getDurationField();
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        org.joda.time.DurationField durationField44 = zeroIsMaxDateTimeField32.getLeapDurationField();
//        int int45 = zeroIsMaxDateTimeField32.getMinimumValue();
//        try {
//            long long48 = zeroIsMaxDateTimeField32.add((-62167190825000L), (-1861948799968L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -1861948799968 * 86400000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.millis();
        try {
            long long9 = julianChronology0.getDateTimeMillis(3, 102, (-1920000), 9, 6, (int) (short) 100, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
//        long long16 = offsetDateTimeField11.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
//        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime23 = dateTime21.plusSeconds((int) (byte) 100);
//        int int24 = dateTime21.getYearOfEra();
//        boolean boolean25 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime27 = dateTime1.plusMillis(31);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.Chronology chronology34 = copticChronology29.withZone(dateTimeZone32);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime1.toMutableDateTime(chronology34);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(copticChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        int int12 = property9.getMinimumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property9.getAsShortText(locale13);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "3" + "'", str14.equals("3"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        try {
            long long9 = gJChronology0.getDateTimeMillis(10, 139, 275, 6, 10, 9, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 28378000, 1152000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1180378000L + "'", long2 == 1180378000L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology10);
        int int16 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay15);
        long long18 = skipUndoDateTimeField5.roundCeiling((-21600000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime26 = dateTime24.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime32 = dateTime30.withWeekOfWeekyear(1);
        int int33 = property9.compareTo((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = copticChronology36.getZone();
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.ReadableDateTime readableDateTime39 = null;
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology36, readableDateTime38, readableDateTime39);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology36);
        org.joda.time.MonthDay.Property property42 = monthDay41.monthOfYear();
        org.joda.time.MonthDay.Property property43 = monthDay41.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone47 = copticChronology46.getZone();
        org.joda.time.ReadableDateTime readableDateTime48 = null;
        org.joda.time.ReadableDateTime readableDateTime49 = null;
        org.joda.time.chrono.LimitChronology limitChronology50 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology46, readableDateTime48, readableDateTime49);
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology46);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        boolean boolean53 = monthDay51.isSupported(dateTimeFieldType52);
        java.lang.String str55 = monthDay51.toString("0");
        int int56 = property43.compareTo((org.joda.time.ReadablePartial) monthDay51);
        org.joda.time.MonthDay.Property property57 = monthDay51.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = copticChronology58.getZone();
        org.joda.time.ReadableDateTime readableDateTime60 = null;
        org.joda.time.ReadableDateTime readableDateTime61 = null;
        org.joda.time.chrono.LimitChronology limitChronology62 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology58, readableDateTime60, readableDateTime61);
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.chrono.JulianChronology julianChronology64 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology64.getZone();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology64.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField(chronology63, dateTimeField66, (int) '#');
        int int70 = skipUndoDateTimeField68.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField72 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology62, (org.joda.time.DateTimeField) skipUndoDateTimeField68, 3);
        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime76 = dateTime73.withZoneRetainFields(dateTimeZone75);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone77 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone75);
        org.joda.time.Chronology chronology78 = limitChronology62.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone77);
        org.joda.time.MonthDay monthDay79 = monthDay51.withChronologyRetainFields(chronology78);
        int int80 = property9.compareTo((org.joda.time.ReadablePartial) monthDay79);
        int int81 = monthDay79.getMonthOfYear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(limitChronology50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(limitChronology62);
        org.junit.Assert.assertNotNull(julianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 69 + "'", int70 == 69);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(cachedDateTimeZone77);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 3 + "'", int81 == 3);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        long long12 = offsetDateTimeField7.add((long) '4', 19);
//        int int13 = offsetDateTimeField7.getMaximumValue();
//        long long15 = offsetDateTimeField7.roundHalfEven((long) (short) -1);
//        long long17 = offsetDateTimeField7.roundHalfEven((long) (-1987199800));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1015200000L + "'", long15 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1015200000L + "'", long17 == 1015200000L);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DurationField durationField2 = gJChronology0.hours();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
//        boolean boolean12 = gJChronology0.equals((java.lang.Object) dateTime10);
//        java.lang.String str13 = gJChronology0.toString();
//        try {
//            long long21 = gJChronology0.getDateTimeMillis((int) (byte) -1, 200, 0, (-28378000), 53, 100, 28253);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GJChronology[+30:00]" + "'", str13.equals("GJChronology[+30:00]"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.weekyearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime14 = dateTime11.withMillis(829440000000010L);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField26, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, 100);
        java.util.Locale locale31 = null;
        int int32 = offsetDateTimeField30.getMaximumTextLength(locale31);
        long long35 = offsetDateTimeField30.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, dateTimeFieldType36);
        int int38 = dateTime14.get(dateTimeFieldType36);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField40 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType36, 30);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        boolean boolean50 = monthDay48.isSupported(dateTimeFieldType49);
        java.lang.String str52 = monthDay48.toString("0");
        int int53 = monthDay48.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField55 = monthDay48.getField((int) (short) 1);
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime59 = dateTime57.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime61 = dateTime59.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime63 = dateTime61.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime65 = dateTime61.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property66 = dateTime61.secondOfDay();
        java.util.Locale locale67 = null;
        int int68 = property66.getMaximumTextLength(locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property66.getFieldType();
        int int70 = monthDay48.indexOf(dateTimeFieldType69);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField40, dateTimeFieldType69);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) dividedDateTimeField71);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 599616000052L + "'", long35 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(limitChronology47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 5 + "'", int68 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
//        java.lang.String str7 = delegatedDateTimeField4.getName();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        int int9 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = delegatedDateTimeField4.getAsShortText((long) 2513, locale11);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-21600000L) + "'", long6 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "24" + "'", str12.equals("24"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        boolean boolean8 = copticChronology0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
        java.lang.String str8 = buddhistChronology6.toString();
        boolean boolean9 = julianChronology0.equals((java.lang.Object) str8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long15 = dateTimeZone11.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.Chronology chronology17 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        java.util.TimeZone timeZone18 = cachedDateTimeZone16.toTimeZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[UTC]" + "'", str8.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        int int71 = dividedDateTimeField69.get((-30520800000L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
//        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
//        int int21 = dateTime20.getMinuteOfHour();
//        org.joda.time.DateTime.Property property22 = dateTime20.hourOfDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "6" + "'", str24.equals("6"));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        org.joda.time.DurationField durationField12 = property9.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, 0, 6, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [6,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        boolean boolean5 = delegatedDateTimeField4.isLenient();
//        boolean boolean6 = delegatedDateTimeField4.isLenient();
//        long long9 = delegatedDateTimeField4.set((long) (short) 100, "10");
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1209599900L) + "'", long9 == (-1209599900L));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfHour(5, 0);
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatterBuilder20.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder20.appendHourOfDay(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendYear(19, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
//        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime19 = dateTime17.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime23 = dateTime19.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property24 = dateTime19.secondOfDay();
//        java.util.Locale locale25 = null;
//        int int26 = property24.getMaximumTextLength(locale25);
//        org.joda.time.DateTime dateTime28 = property24.addToCopy((long) (-28800000));
//        org.joda.time.LocalTime localTime29 = dateTime28.toLocalTime();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
//        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, dateTimeField34, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, 100);
//        boolean boolean40 = offsetDateTimeField38.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField38.getWrappedField();
//        long long44 = offsetDateTimeField38.add((long) (short) 10, (long) 100);
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone47 = copticChronology46.getZone();
//        org.joda.time.ReadableDateTime readableDateTime48 = null;
//        org.joda.time.ReadableDateTime readableDateTime49 = null;
//        org.joda.time.chrono.LimitChronology limitChronology50 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology46, readableDateTime48, readableDateTime49);
//        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone52 = copticChronology51.getZone();
//        org.joda.time.Chronology chronology53 = limitChronology50.withZone(dateTimeZone52);
//        long long57 = dateTimeZone52.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
//        org.joda.time.Chronology chronology59 = null;
//        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone61 = julianChronology60.getZone();
//        org.joda.time.DateTimeField dateTimeField62 = julianChronology60.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField(chronology59, dateTimeField62, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField64, 100);
//        java.util.Locale locale67 = null;
//        int int68 = offsetDateTimeField66.getMaximumTextLength(locale67);
//        long long71 = offsetDateTimeField66.add((long) '4', 19);
//        org.joda.time.chrono.CopticChronology copticChronology74 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone75 = copticChronology74.getZone();
//        org.joda.time.ReadableDateTime readableDateTime76 = null;
//        org.joda.time.ReadableDateTime readableDateTime77 = null;
//        org.joda.time.chrono.LimitChronology limitChronology78 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology74, readableDateTime76, readableDateTime77);
//        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology74);
//        org.joda.time.ReadablePeriod readablePeriod80 = null;
//        org.joda.time.MonthDay monthDay81 = monthDay79.minus(readablePeriod80);
//        java.util.Locale locale83 = null;
//        java.lang.String str84 = offsetDateTimeField66.getAsText((org.joda.time.ReadablePartial) monthDay81, (int) 'a', locale83);
//        int[] intArray91 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
//        gregorianChronology58.validate((org.joda.time.ReadablePartial) monthDay81, intArray91);
//        int int93 = offsetDateTimeField38.getMinimumValue(readablePartial45, intArray91);
//        java.util.Locale locale95 = null;
//        try {
//            int[] intArray96 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) localTime29, 102, intArray91, "30", locale95);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for yearOfCentury must be in the range [102,200]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localTime29);
//        org.junit.Assert.assertNotNull(julianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3155760000010L + "'", long44 == 3155760000010L);
//        org.junit.Assert.assertNotNull(copticChronology46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(limitChronology50);
//        org.junit.Assert.assertNotNull(copticChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-136800000L) + "'", long57 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(julianChronology60);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 599616000052L + "'", long71 == 599616000052L);
//        org.junit.Assert.assertNotNull(copticChronology74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(limitChronology78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "97" + "'", str84.equals("97"));
//        org.junit.Assert.assertNotNull(intArray91);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 102 + "'", int93 == 102);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-57600000L), dateTimeZone1);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
//        int int10 = offsetDateTimeField7.getMaximumValue();
//        int int12 = offsetDateTimeField7.getMaximumValue((-21600000L));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1015200000L + "'", long9 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 200 + "'", int10 == 200);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 200 + "'", int12 == 200);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        java.lang.String str11 = property10.getAsShortText();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeField12, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField6 = julianChronology0.centuries();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
//        long long16 = offsetDateTimeField11.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
//        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime23 = dateTime21.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime27 = dateTime25.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime29 = dateTime25.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property30 = dateTime25.secondOfDay();
//        java.util.Locale locale31 = null;
//        int int32 = property30.getMaximumTextLength(locale31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property30.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType33, (int) (byte) 100, 1, 28253);
//        int int38 = dateTime1.get(dateTimeFieldType33);
//        int int39 = dateTime1.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType28, (int) (byte) 0, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendSecondOfDay((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.Instant instant4 = mutableDateTime2.toInstant();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        long long72 = dividedDateTimeField69.getDifferenceAsLong((long) 6, 0L);
        java.lang.String str73 = dividedDateTimeField69.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str73.equals("DateTimeField[yearOfCentury]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendDayOfMonth(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean6 = instant5.isEqualNow();
        org.joda.time.Instant instant9 = instant5.withDurationAdded((long) (-28800000), (-28800000));
        int int10 = instant3.compareTo((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = instant9.toInstant();
        boolean boolean12 = jodaTimePermission1.equals((java.lang.Object) instant11);
        java.security.Permission permission13 = null;
        boolean boolean14 = jodaTimePermission1.implies(permission13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(28253);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumShortTextLength(locale10);
        java.lang.String str12 = property9.getAsString();
        org.joda.time.DurationField durationField13 = property9.getDurationField();
        long long16 = durationField13.subtract((long) (-28800000), (long) 999);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField18 = new org.joda.time.field.DecoratedDurationField(durationField13, durationFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2424758400000L) + "'", long16 == (-2424758400000L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay monthDay23 = property9.getMonthDay();
        int int24 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long7 = gregorianChronology2.getDateTimeMillis((-97), 2, 33, 102);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.DateTime dateTime5 = dateTime1.plusHours(0);
//        int int6 = dateTime1.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
//        boolean boolean2 = instant1.isEqualNow();
//        long long3 = instant1.getMillis();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTime(chronology4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        boolean boolean7 = mutableDateTime5.isSupported(dateTimeFieldType6);
//        int int8 = mutableDateTime5.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusDays((int) (short) 1);
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167327200000L) + "'", long8 == (-62167327200000L));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.yearOfCentury();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
        org.joda.time.DateTime dateTime16 = dateTime13.withMillis(829440000000010L);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField20, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, 100);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = julianChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology26.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField(chronology25, dateTimeField28, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField30, 100);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField32.getMaximumTextLength(locale33);
        long long37 = offsetDateTimeField32.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, dateTimeFieldType38);
        int int40 = dateTime16.get(dateTimeFieldType38);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType38, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder43.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = julianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField53 = julianChronology51.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField(chronology50, dateTimeField53, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField55, 100);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology59.getZone();
        org.joda.time.DateTimeField dateTimeField61 = julianChronology59.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField(chronology58, dateTimeField61, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField63, 100);
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField65.getMaximumTextLength(locale66);
        long long70 = offsetDateTimeField65.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = offsetDateTimeField65.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField55, dateTimeFieldType71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder49.appendFraction(dateTimeFieldType71, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField76 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType71);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField76);
        int int79 = dividedDateTimeField76.get((-31535999948L));
        org.joda.time.chrono.CopticChronology copticChronology82 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone83 = copticChronology82.getZone();
        org.joda.time.ReadableDateTime readableDateTime84 = null;
        org.joda.time.ReadableDateTime readableDateTime85 = null;
        org.joda.time.chrono.LimitChronology limitChronology86 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology82, readableDateTime84, readableDateTime85);
        org.joda.time.MonthDay monthDay87 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology82);
        org.joda.time.MonthDay.Property property88 = monthDay87.monthOfYear();
        org.joda.time.MonthDay.Property property89 = monthDay87.monthOfYear();
        java.lang.String str90 = property89.toString();
        org.joda.time.DurationField durationField91 = property89.getRangeDurationField();
        org.joda.time.DurationField durationField92 = property89.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = property89.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField94 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField76, dateTimeFieldType93);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder97 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType93, 4, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 599616000052L + "'", long37 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 599616000052L + "'", long70 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertNotNull(copticChronology82);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(limitChronology86);
        org.junit.Assert.assertNotNull(property88);
        org.junit.Assert.assertNotNull(property89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Property[monthOfYear]" + "'", str90.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertNotNull(durationField92);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder97);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = limitChronology4.hourOfDay();
        org.joda.time.DurationField durationField9 = limitChronology4.seconds();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField17.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = copticChronology22.getZone();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology22);
        org.joda.time.MonthDay.Property property28 = monthDay27.monthOfYear();
        org.joda.time.MonthDay.Property property29 = monthDay27.monthOfYear();
        int int30 = offsetDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) monthDay27);
        boolean boolean31 = limitChronology4.equals((java.lang.Object) int30);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 102 + "'", int30 == 102);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        boolean boolean12 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime11.minusMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = julianChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekOfWeekyear();
        java.lang.String str11 = buddhistChronology9.toString();
        boolean boolean12 = julianChronology3.equals((java.lang.Object) str11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long18 = dateTimeZone14.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.Chronology chronology20 = julianChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(30);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone22);
        long long25 = cachedDateTimeZone19.getMillisKeepLocal(dateTimeZone22, 0L);
        org.joda.time.Chronology chronology26 = gJChronology0.withZone(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology0.millisOfSecond();
        try {
            long long35 = gJChronology0.getDateTimeMillis((-28800000), 102, 19, 139, 0, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 139 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BuddhistChronology[UTC]" + "'", str11.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-108000000L) + "'", long25 == (-108000000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitYear(169);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1152000000L, (java.lang.Number) (-28800000), (java.lang.Number) (byte) -1);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) -1 + "'", number6.equals((byte) -1));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
//        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
//        org.joda.time.DurationField durationField15 = limitChronology4.millis();
//        java.lang.String str16 = limitChronology4.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LimitChronology[CopticChronology[+30:00], NoLimit, NoLimit]" + "'", str16.equals("LimitChronology[CopticChronology[+30:00], NoLimit, NoLimit]"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "0000-10-01T00:01:40.000", 1, 1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(35L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        boolean boolean15 = skipDateTimeField14.isLenient();
        int int16 = skipDateTimeField14.getMinimumValue();
        org.joda.time.DurationField durationField17 = skipDateTimeField14.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(durationField17);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.ReadableDateTime readableDateTime5 = null;
//        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.dayOfYear();
//        org.joda.time.DurationField durationField12 = copticChronology10.years();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology10.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        long long16 = delegatedDateTimeField14.roundHalfEven((long) 0);
//        java.lang.String str17 = delegatedDateTimeField14.getName();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
//        int int19 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
//        boolean boolean20 = monthDay7.isBefore((org.joda.time.ReadablePartial) monthDay18);
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now();
//        boolean boolean22 = monthDay7.isBefore((org.joda.time.ReadablePartial) monthDay21);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(limitChronology6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-21600000L) + "'", long16 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfMonth" + "'", str17.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 30 + "'", int19 == 30);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology10);
        int int16 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay15);
        long long18 = skipUndoDateTimeField5.roundFloor((long) (byte) 0);
        int int20 = skipUndoDateTimeField5.getMinimumValue((-2424758400000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        boolean boolean7 = buddhistChronology0.equals((java.lang.Object) dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology3.getZone();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField17.getMaximumShortTextLength(locale18);
        long long22 = skipDateTimeField17.set(62167190822000L, 39);
        org.joda.time.DurationField durationField23 = skipDateTimeField17.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 62167190822000L + "'", long22 == 62167190822000L);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfDay(39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatterBuilder11.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.append(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("0");
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        int int4 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField12.getMaximumTextLength(locale13);
//        long long17 = offsetDateTimeField12.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField12.getType();
//        org.joda.time.DateTime dateTime20 = dateTime2.withField(dateTimeFieldType18, (int) 'a');
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime24 = dateTime22.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime24.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime30 = dateTime26.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property31 = dateTime26.secondOfDay();
//        java.util.Locale locale32 = null;
//        int int33 = property31.getMaximumTextLength(locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType34, (int) (byte) 100, 1, 28253);
//        int int39 = dateTime2.get(dateTimeFieldType34);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167327200000L) + "'", long3 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 599616000052L + "'", long17 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = property17.getMaximumValueOverall();
        java.util.Locale locale20 = null;
        try {
            org.joda.time.DateTime dateTime21 = property17.setCopy("1970-01-01T00", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01-01T00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology13, readableDateTime15, readableDateTime16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology13);
        org.joda.time.MonthDay.Property property19 = monthDay18.monthOfYear();
        org.joda.time.MonthDay.Property property20 = monthDay18.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = copticChronology23.getZone();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime25, readableDateTime26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology23);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = monthDay28.isSupported(dateTimeFieldType29);
        java.lang.String str32 = monthDay28.toString("0");
        int int33 = property20.compareTo((org.joda.time.ReadablePartial) monthDay28);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime37 = dateTime35.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime37.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime41 = dateTime39.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime43 = dateTime41.withWeekOfWeekyear(1);
        int int44 = property20.compareTo((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone48 = copticChronology47.getZone();
        org.joda.time.ReadableDateTime readableDateTime49 = null;
        org.joda.time.ReadableDateTime readableDateTime50 = null;
        org.joda.time.chrono.LimitChronology limitChronology51 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology47, readableDateTime49, readableDateTime50);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology47);
        org.joda.time.MonthDay.Property property53 = monthDay52.monthOfYear();
        org.joda.time.MonthDay.Property property54 = monthDay52.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = copticChronology57.getZone();
        org.joda.time.ReadableDateTime readableDateTime59 = null;
        org.joda.time.ReadableDateTime readableDateTime60 = null;
        org.joda.time.chrono.LimitChronology limitChronology61 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology57, readableDateTime59, readableDateTime60);
        org.joda.time.MonthDay monthDay62 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology57);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = null;
        boolean boolean64 = monthDay62.isSupported(dateTimeFieldType63);
        java.lang.String str66 = monthDay62.toString("0");
        int int67 = property54.compareTo((org.joda.time.ReadablePartial) monthDay62);
        org.joda.time.MonthDay.Property property68 = monthDay62.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone70 = copticChronology69.getZone();
        org.joda.time.ReadableDateTime readableDateTime71 = null;
        org.joda.time.ReadableDateTime readableDateTime72 = null;
        org.joda.time.chrono.LimitChronology limitChronology73 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology69, readableDateTime71, readableDateTime72);
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.chrono.JulianChronology julianChronology75 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone76 = julianChronology75.getZone();
        org.joda.time.DateTimeField dateTimeField77 = julianChronology75.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField(chronology74, dateTimeField77, (int) '#');
        int int81 = skipUndoDateTimeField79.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField83 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology73, (org.joda.time.DateTimeField) skipUndoDateTimeField79, 3);
        org.joda.time.DateTime dateTime84 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone86 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime87 = dateTime84.withZoneRetainFields(dateTimeZone86);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone88 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone86);
        org.joda.time.Chronology chronology89 = limitChronology73.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone88);
        org.joda.time.MonthDay monthDay90 = monthDay62.withChronologyRetainFields(chronology89);
        int int91 = property20.compareTo((org.joda.time.ReadablePartial) monthDay90);
        int[] intArray96 = new int[] { 28253, (byte) 100, (short) 100 };
        try {
            int[] intArray98 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay90, 33, intArray96, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(limitChronology51);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(limitChronology61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "0" + "'", str66.equals("0"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(copticChronology69);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(limitChronology73);
        org.junit.Assert.assertNotNull(julianChronology75);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 69 + "'", int81 == 69);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(dateTimeZone86);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(cachedDateTimeZone88);
        org.junit.Assert.assertNotNull(chronology89);
        org.junit.Assert.assertNotNull(monthDay90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 10);
        java.lang.String str19 = dateTime13.toString(dateTimeFormatter18);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime23 = dateTime21.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        org.joda.time.DateTime dateTime26 = dateTime23.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        org.joda.time.DateTime dateTime28 = dateTime13.withFields((org.joda.time.ReadablePartial) localDateTime27);
        boolean boolean29 = dateTimeZone7.isLocalDateTimeGap(localDateTime27);
        int[] intArray30 = new int[] {};
        try {
            julianChronology0.validate((org.joda.time.ReadablePartial) localDateTime27, intArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0000-10-01T00:01:40.000" + "'", str19.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfDay();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean5 = instant4.isEqualNow();
        org.joda.time.Instant instant8 = instant4.withDurationAdded((long) (-28800000), (-28800000));
        int int9 = instant2.compareTo((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = instant8.toInstant();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField1, (java.lang.Object) instant8);
        java.lang.Class<?> wildcardClass12 = dateTimeField1.getClass();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1814399800L), (java.lang.Number) 990316800100L, (java.lang.Number) (-1987199800L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.plus(readableDuration8);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant12 = instant9.withDurationAdded(readableDuration10, 2513);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.Chronology chronology18 = julianChronology13.withZone(dateTimeZone16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.weekOfWeekyear();
        java.lang.String str21 = buddhistChronology19.toString();
        boolean boolean22 = julianChronology13.equals((java.lang.Object) str21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long28 = dateTimeZone24.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone24);
        org.joda.time.Chronology chronology30 = julianChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = instant12.toMutableDateTime(chronology30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BuddhistChronology[UTC]" + "'", str21.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime13 = dateTime5.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) '4', 28253);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) (-97));
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.MonthDay monthDay11 = property8.addWrapFieldToCopy((int) (byte) 0);
        int int12 = property8.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology10);
        int int16 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay15);
        long long18 = skipUndoDateTimeField5.roundFloor((long) (byte) 0);
        int int20 = skipUndoDateTimeField5.get((long) 102);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField5.getAsText(3155760000010L, locale22);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Wednesday" + "'", str23.equals("Wednesday"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        java.lang.String str11 = property9.toString();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[monthOfYear]" + "'", str11.equals("Property[monthOfYear]"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
//        long long9 = limitChronology4.getDateTimeMillis(28378000, 4, 3, 3);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 895488364893600003L + "'", long9 == 895488364893600003L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime7.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property12 = dateTime7.secondOfDay();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        org.joda.time.DateTime dateTime15 = property12.roundFloorCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((-28800000));
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay13.minus(readablePeriod23);
        org.joda.time.Chronology chronology25 = monthDay13.getChronology();
        org.joda.time.MonthDay.Property property26 = monthDay13.dayOfMonth();
        java.util.Locale locale28 = null;
        try {
            org.joda.time.MonthDay monthDay29 = property26.setCopy("", locale28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.era();
        org.joda.time.Chronology chronology17 = copticChronology15.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = copticChronology23.getZone();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime25, readableDateTime26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology23);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = monthDay28.isSupported(dateTimeFieldType29);
        java.lang.String str32 = monthDay28.toString("0");
        int int33 = monthDay28.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField35 = monthDay28.getField((int) (short) 1);
        int[] intArray36 = new int[] {};
        int int37 = skipUndoDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) monthDay28, intArray36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay28.minus(readablePeriod38);
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = copticChronology41.era();
        org.joda.time.Chronology chronology43 = copticChronology41.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField45);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = copticChronology49.getZone();
        org.joda.time.ReadableDateTime readableDateTime51 = null;
        org.joda.time.ReadableDateTime readableDateTime52 = null;
        org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology49, readableDateTime51, readableDateTime52);
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology49);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = null;
        boolean boolean56 = monthDay54.isSupported(dateTimeFieldType55);
        java.lang.String str58 = monthDay54.toString("0");
        int int59 = monthDay54.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField61 = monthDay54.getField((int) (short) 1);
        int[] intArray62 = new int[] {};
        int int63 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray62);
        try {
            int[] intArray65 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay28, 0, intArray62, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(limitChronology53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay2 = monthDay0.plusMonths((-1987199800));
        org.joda.time.MonthDay monthDay4 = monthDay2.minusMonths((-28800000));
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean4 = instant3.isEqualNow();
        org.joda.time.Instant instant7 = instant3.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.minus(readableDuration8);
        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology25, readableDateTime27, readableDateTime28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = monthDay30.isSupported(dateTimeFieldType31);
        java.lang.String str34 = monthDay30.toString("0");
        boolean boolean35 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology36.dayOfYear();
        org.joda.time.DateTimeField dateTimeField38 = copticChronology36.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone40 = copticChronology39.getZone();
        org.joda.time.Chronology chronology41 = copticChronology36.withZone(dateTimeZone40);
        org.joda.time.MonthDay monthDay42 = monthDay30.withChronologyRetainFields((org.joda.time.Chronology) copticChronology36);
        org.joda.time.DateTimeField dateTimeField43 = copticChronology36.weekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(dateTimeField43);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
//        java.lang.String str9 = cachedDateTimeZone6.getName(100L);
//        java.lang.String str10 = cachedDateTimeZone6.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, readableInstant7);
//        org.joda.time.Chronology chronology9 = dateTime3.getChronology();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime15 = dateTime13.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime15.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property20 = dateTime15.secondOfDay();
//        java.util.Locale locale21 = null;
//        int int22 = property20.getMaximumTextLength(locale21);
//        org.joda.time.Interval interval23 = property20.toInterval();
//        org.joda.time.DurationField durationField24 = property20.getRangeDurationField();
//        org.joda.time.DateTime dateTime26 = property20.addToCopy(100);
//        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
//        boolean boolean28 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        java.util.GregorianCalendar gregorianCalendar29 = dateTime3.toGregorianCalendar();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = null;
//        java.lang.String str31 = dateTime3.toString(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
//        org.junit.Assert.assertNotNull(interval23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0000-01-01T00:01:40.000+30:00" + "'", str31.equals("0000-01-01T00:01:40.000+30:00"));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime3, readableDateTime4);
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology6.getZone();
//        org.joda.time.Chronology chronology8 = limitChronology5.withZone(dateTimeZone7);
//        long long12 = dateTimeZone7.convertLocalToUTC((long) (-28800000), false, 1L);
//        boolean boolean14 = dateTimeZone7.isStandardOffset((-31535999948L));
//        boolean boolean15 = buddhistChronology0.equals((java.lang.Object) dateTimeZone7);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(limitChronology5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-136800000L) + "'", long12 == (-136800000L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 0, (-28799968L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28799968L) + "'", long2 == (-28799968L));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
//        long long30 = offsetDateTimeField25.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
//        int int33 = dateTime9.get(dateTimeFieldType31);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
//        java.util.Locale locale59 = null;
//        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
//        long long63 = offsetDateTimeField58.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
//        org.joda.time.MonthDay monthDay70 = org.joda.time.MonthDay.now();
//        java.lang.String str71 = monthDay70.toString();
//        int[] intArray79 = new int[] { 19, 102, 53, (-97), 30, 169 };
//        int[] intArray81 = remainderDateTimeField35.add((org.joda.time.ReadablePartial) monthDay70, 2, intArray79, 0);
//        org.joda.time.MonthDay monthDay83 = monthDay70.minusDays(33);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertNotNull(monthDay70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "--01-02" + "'", str71.equals("--01-02"));
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertNotNull(monthDay83);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime13 = dateTime5.withZoneRetainFields(dateTimeZone12);
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = dateTime5.toString("GregorianChronology[+100:00]", locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundFloorCopy();
        org.joda.time.DateTime dateTime14 = property10.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime16 = property10.setCopy(39);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property10.getFieldType();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        boolean boolean6 = instant5.isEqualNow();
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime();
        int int8 = mutableDateTime7.getYearOfEra();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = mutableDateTime7.toCalendar(locale9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 28253 + "'", int8 == 28253);
        org.junit.Assert.assertNotNull(calendar10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1", "0000-10-01T00:01:40.000", 1, 1);
        int int6 = fixedDateTimeZone4.getOffset(599616000052L);
        int int8 = fixedDateTimeZone4.getOffset((long) '#');
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0000-10-01T00:01:40.000" + "'", str10.equals("0000-10-01T00:01:40.000"));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
//        int int8 = delegatedDateTimeField4.getMaximumValue();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 39, locale10);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.Chronology chronology17 = julianChronology12.withZone(dateTimeZone15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.weekOfWeekyear();
//        java.lang.String str20 = buddhistChronology18.toString();
//        boolean boolean21 = julianChronology12.equals((java.lang.Object) str20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long27 = dateTimeZone23.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
//        org.joda.time.Chronology chronology29 = julianChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours(30);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now(dateTimeZone31);
//        long long34 = cachedDateTimeZone28.getMillisKeepLocal(dateTimeZone31, 0L);
//        java.lang.String str36 = cachedDateTimeZone28.getName((-108000000L));
//        java.lang.Object obj37 = null;
//        boolean boolean38 = cachedDateTimeZone28.equals(obj37);
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone28);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay39, 200, locale41);
//        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(33);
//        org.joda.time.MonthDay.Property property45 = monthDay39.dayOfMonth();
//        int int46 = property45.get();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "24" + "'", str11.equals("24"));
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BuddhistChronology[UTC]" + "'", str20.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-108000000L) + "'", long34 == (-108000000L));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Coordinated Universal Time" + "'", str36.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "200" + "'", str42.equals("200"));
//        org.junit.Assert.assertNotNull(monthDay44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology3.getZone();
//        java.lang.String str8 = dateTimeZone6.getShortName(40L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+30:00" + "'", str8.equals("+30:00"));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.MonthDay monthDay11 = property8.addWrapFieldToCopy((int) (byte) 0);
        java.lang.String str12 = property8.getAsText();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        int int17 = property10.getLeapAmount();
        java.lang.String str18 = property10.getAsString();
        boolean boolean19 = property10.isLeap();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-28378000), 0, 0, 100, 40, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        illegalFieldValueException2.prependMessage("52");
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.clockhourOfHalfday();
//        org.joda.time.DurationField durationField5 = copticChronology0.days();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.secondOfDay();
//        java.lang.String str7 = copticChronology0.toString();
//        try {
//            long long12 = copticChronology0.getDateTimeMillis(4, (-1987199800), 169, 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1987199800 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CopticChronology[+30:00]" + "'", str7.equals("CopticChronology[+30:00]"));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.DateTime dateTime19 = dateTime16.withFieldAdded(durationFieldType17, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property7 = dateTime3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, 2000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200000L + "'", long2 == 200000L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, 100);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumTextLength(locale27);
        long long31 = offsetDateTimeField26.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType32, (int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter36 = dateTimeFormatterBuilder35.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000052L + "'", long31 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimePrinter36);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.DateTime dateTime5 = dateTime1.plusHours(0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.minus(readableDuration6);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        java.lang.String str18 = skipUndoDateTimeField10.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str18.equals("DateTimeField[yearOfCentury]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime5.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime13 = dateTime5.withWeekyear((-97));
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
//        org.joda.time.ReadableDateTime readableDateTime7 = null;
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology5, readableDateTime7, readableDateTime8);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
//        org.joda.time.Chronology chronology12 = limitChronology9.withZone(dateTimeZone11);
//        long long16 = dateTimeZone11.convertLocalToUTC((long) (-28800000), false, 1L);
//        java.util.TimeZone timeZone17 = dateTimeZone11.toTimeZone();
//        try {
//            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(200, (int) (byte) 100, 0, (int) (byte) 10, 0, dateTimeZone11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(limitChronology9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-136800000L) + "'", long16 == (-136800000L));
//        org.junit.Assert.assertNotNull(timeZone17);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
//        java.lang.String str8 = buddhistChronology6.toString();
//        boolean boolean9 = julianChronology0.equals((java.lang.Object) str8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long15 = dateTimeZone11.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.Chronology chronology17 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(30);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        long long22 = cachedDateTimeZone16.getMillisKeepLocal(dateTimeZone19, 0L);
//        java.lang.String str24 = cachedDateTimeZone16.getName((-108000000L));
//        java.lang.Object obj25 = null;
//        boolean boolean26 = cachedDateTimeZone16.equals(obj25);
//        java.lang.String str27 = cachedDateTimeZone16.getID();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[UTC]" + "'", str8.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-108000000L) + "'", long22 == (-108000000L));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordinated Universal Time" + "'", str24.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField17.getMaximumShortTextLength(locale18);
        int int21 = skipDateTimeField17.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        java.lang.String str12 = offsetDateTimeField7.getName();
        int int13 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "yearOfCentury" + "'", str12.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
//        org.joda.time.ReadableDateTime readableDateTime10 = null;
//        org.joda.time.ReadableDateTime readableDateTime11 = null;
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
//        org.joda.time.Chronology chronology15 = limitChronology12.withZone(dateTimeZone14);
//        long long19 = dateTimeZone14.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 100);
//        java.util.Locale locale29 = null;
//        int int30 = offsetDateTimeField28.getMaximumTextLength(locale29);
//        long long33 = offsetDateTimeField28.add((long) '4', 19);
//        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone37 = copticChronology36.getZone();
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology36, readableDateTime38, readableDateTime39);
//        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology36);
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.MonthDay monthDay43 = monthDay41.minus(readablePeriod42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay43, (int) 'a', locale45);
//        int[] intArray53 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
//        gregorianChronology20.validate((org.joda.time.ReadablePartial) monthDay43, intArray53);
//        boolean boolean55 = cachedDateTimeZone6.equals((java.lang.Object) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone56 = gregorianChronology20.getZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(limitChronology12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136800000L) + "'", long19 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 599616000052L + "'", long33 == 599616000052L);
//        org.junit.Assert.assertNotNull(copticChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(limitChronology40);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "97" + "'", str46.equals("97"));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay13.minus(readablePeriod23);
        org.joda.time.Chronology chronology25 = monthDay13.getChronology();
        org.joda.time.MonthDay.Property property26 = monthDay13.dayOfMonth();
        int[] intArray27 = monthDay13.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter28.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter28.getParser();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = copticChronology31.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) copticChronology31);
        org.joda.time.MonthDay monthDay34 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) copticChronology31);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(monthDay34);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0000-10-01T00:01:40.000", (java.lang.Number) 28378000, (java.lang.Number) 25L, (java.lang.Number) 12009600100L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int72 = dividedDateTimeField69.get((-31535999948L));
        java.util.Locale locale74 = null;
        java.lang.String str75 = dividedDateTimeField69.getAsShortText(0, locale74);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
//        org.joda.time.ReadableDateTime readableDateTime10 = null;
//        org.joda.time.ReadableDateTime readableDateTime11 = null;
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
//        org.joda.time.Chronology chronology15 = limitChronology12.withZone(dateTimeZone14);
//        long long19 = dateTimeZone14.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, 100);
//        java.util.Locale locale29 = null;
//        int int30 = offsetDateTimeField28.getMaximumTextLength(locale29);
//        long long33 = offsetDateTimeField28.add((long) '4', 19);
//        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone37 = copticChronology36.getZone();
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology36, readableDateTime38, readableDateTime39);
//        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology36);
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.MonthDay monthDay43 = monthDay41.minus(readablePeriod42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay43, (int) 'a', locale45);
//        int[] intArray53 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
//        gregorianChronology20.validate((org.joda.time.ReadablePartial) monthDay43, intArray53);
//        boolean boolean55 = cachedDateTimeZone6.equals((java.lang.Object) gregorianChronology20);
//        int int56 = gregorianChronology20.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(limitChronology12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-136800000L) + "'", long19 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 599616000052L + "'", long33 == 599616000052L);
//        org.junit.Assert.assertNotNull(copticChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(limitChronology40);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "97" + "'", str46.equals("97"));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        long long3 = instant1.getMillis();
        boolean boolean5 = instant1.isBefore(0L);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant8 = instant1.withDurationAdded(readableDuration6, 28253);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(0, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0f, (java.lang.Number) (short) 1, (java.lang.Number) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean2 = dateTimeFormatter1.isParser();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("GJChronology[+30:00]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[+30:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = julianChronology4.withZone(dateTimeZone7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekOfWeekyear();
//        java.lang.String str12 = buddhistChronology10.toString();
//        boolean boolean13 = julianChronology4.equals((java.lang.Object) str12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long19 = dateTimeZone15.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.Chronology chronology21 = julianChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(30);
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now(dateTimeZone23);
//        long long26 = cachedDateTimeZone20.getMillisKeepLocal(dateTimeZone23, 0L);
//        java.lang.String str28 = cachedDateTimeZone20.getName((-108000000L));
//        org.joda.time.Chronology chronology29 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+100:00]" + "'", str3.equals("GregorianChronology[+100:00]"));
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[UTC]" + "'", str12.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-108000000L) + "'", long26 == (-108000000L));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology29);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        int int6 = dateTime5.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 364 + "'", int6 == 364);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.Chronology chronology15 = limitChronology4.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100000) + "'", int1 == (-100000));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("+30:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+30:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (byte) 100);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, readableDateTime3, readableDateTime4);
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology6.getZone();
//        org.joda.time.Chronology chronology8 = limitChronology5.withZone(dateTimeZone7);
//        long long12 = dateTimeZone7.convertLocalToUTC((long) (-28800000), false, 1L);
//        boolean boolean14 = dateTimeZone7.isStandardOffset((-31535999948L));
//        boolean boolean15 = buddhistChronology0.equals((java.lang.Object) dateTimeZone7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(limitChronology5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-136800000L) + "'", long12 == (-136800000L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        long long11 = offsetDateTimeField7.roundHalfEven((-1861948799968L));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1860904800000L) + "'", long11 == (-1860904800000L));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.append(dateTimeParser38);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendFractionOfSecond((-28800000), (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
//        long long12 = offsetDateTimeField7.addWrapField((-1L), (int) (byte) 1);
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.ReadableDateTime readableDateTime18 = null;
//        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology15);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.minus(readablePeriod21);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = monthDay20.getFieldTypes();
//        int int24 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay20);
//        org.joda.time.MonthDay monthDay26 = monthDay20.plusDays((int) (byte) -1);
//        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.dayOfYear();
//        org.joda.time.DurationField durationField29 = copticChronology27.years();
//        org.joda.time.DateTimeField dateTimeField30 = copticChronology27.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField31.getAsText((int) '4', locale33);
//        int int35 = delegatedDateTimeField31.getMaximumValue();
//        long long38 = delegatedDateTimeField31.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology40.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField(chronology39, dateTimeField42, (int) '#');
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = skipUndoDateTimeField44.getAsText(0, locale46);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField44.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField31, dateTimeFieldType48);
//        int int50 = monthDay26.indexOf(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31535999999L + "'", long12 == 31535999999L);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(limitChronology19);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 102 + "'", int24 == 102);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(copticChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "52" + "'", str34.equals("52"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 30 + "'", int35 == 30);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1987199800L) + "'", long38 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
//        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-136800000L) + "'", long11 == (-136800000L));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
        org.joda.time.DateTime dateTime13 = dateTime5.plus(1152000000L);
        int int14 = dateTime13.getMillisOfSecond();
        org.joda.time.DateTime.Property property15 = dateTime13.year();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(property15);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.ReadableDateTime readableDateTime10 = null;
//        org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology7, readableDateTime9, readableDateTime10);
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology7);
//        org.joda.time.MonthDay.Property property13 = monthDay12.monthOfYear();
//        java.lang.String str14 = property13.getAsString();
//        org.joda.time.MonthDay monthDay16 = property13.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology19.getZone();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology19, readableDateTime21, readableDateTime22);
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology19);
//        org.joda.time.MonthDay.Property property25 = monthDay24.monthOfYear();
//        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now();
//        int int27 = property25.compareTo((org.joda.time.ReadablePartial) monthDay26);
//        boolean boolean28 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay26);
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology30.getZone();
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField(chronology29, dateTimeField32, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, 100);
//        boolean boolean38 = offsetDateTimeField36.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField39 = offsetDateTimeField36.getWrappedField();
//        long long42 = offsetDateTimeField36.add((long) (short) 10, (long) 100);
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = copticChronology44.getZone();
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.ReadableDateTime readableDateTime47 = null;
//        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology44, readableDateTime46, readableDateTime47);
//        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone50 = copticChronology49.getZone();
//        org.joda.time.Chronology chronology51 = limitChronology48.withZone(dateTimeZone50);
//        long long55 = dateTimeZone50.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone50);
//        org.joda.time.Chronology chronology57 = null;
//        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone59 = julianChronology58.getZone();
//        org.joda.time.DateTimeField dateTimeField60 = julianChronology58.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField(chronology57, dateTimeField60, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField62, 100);
//        java.util.Locale locale65 = null;
//        int int66 = offsetDateTimeField64.getMaximumTextLength(locale65);
//        long long69 = offsetDateTimeField64.add((long) '4', 19);
//        org.joda.time.chrono.CopticChronology copticChronology72 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone73 = copticChronology72.getZone();
//        org.joda.time.ReadableDateTime readableDateTime74 = null;
//        org.joda.time.ReadableDateTime readableDateTime75 = null;
//        org.joda.time.chrono.LimitChronology limitChronology76 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology72, readableDateTime74, readableDateTime75);
//        org.joda.time.MonthDay monthDay77 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology72);
//        org.joda.time.ReadablePeriod readablePeriod78 = null;
//        org.joda.time.MonthDay monthDay79 = monthDay77.minus(readablePeriod78);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField64.getAsText((org.joda.time.ReadablePartial) monthDay79, (int) 'a', locale81);
//        int[] intArray89 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
//        gregorianChronology56.validate((org.joda.time.ReadablePartial) monthDay79, intArray89);
//        int int91 = offsetDateTimeField36.getMinimumValue(readablePartial43, intArray89);
//        gregorianChronology2.validate((org.joda.time.ReadablePartial) monthDay16, intArray89);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(limitChronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "3" + "'", str14.equals("3"));
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(copticChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(limitChronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3155760000010L + "'", long42 == 3155760000010L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(limitChronology48);
//        org.junit.Assert.assertNotNull(copticChronology49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-136800000L) + "'", long55 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(julianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 599616000052L + "'", long69 == 599616000052L);
//        org.junit.Assert.assertNotNull(copticChronology72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(limitChronology76);
//        org.junit.Assert.assertNotNull(monthDay79);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "97" + "'", str82.equals("97"));
//        org.junit.Assert.assertNotNull(intArray89);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 102 + "'", int91 == 102);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
//        int int10 = dateTimeZone8.getOffsetFromLocal((long) 'a');
//        long long12 = dateTimeZone8.convertUTCToLocal((long) ' ');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        java.lang.String str15 = dateTimeZone8.getName((long) 10);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, (int) '#', 33, (int) (byte) 100, 6, 102, 0, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 108000000 + "'", int10 == 108000000);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 108000032L + "'", long12 == 108000032L);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+30:00" + "'", str15.equals("+30:00"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime5.toCalendar(locale8);
        org.joda.time.DateTime.Property property10 = dateTime5.millisOfSecond();
        boolean boolean11 = dateTime5.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
//        java.lang.String str7 = delegatedDateTimeField4.getName();
//        java.util.Locale locale8 = null;
//        int int9 = delegatedDateTimeField4.getMaximumTextLength(locale8);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-21600000L) + "'", long6 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        java.lang.String str4 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        long long23 = offsetDateTimeField18.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField18.getType();
        int int25 = dateTime9.get(dateTimeFieldType24);
        java.util.Locale locale26 = null;
        java.util.Calendar calendar27 = dateTime9.toCalendar(locale26);
        org.joda.time.DateTime dateTime29 = dateTime9.withWeekOfWeekyear(19);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 599616000052L + "'", long23 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(calendar27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime5.toCalendar(locale8);
        org.joda.time.DateTime dateTime11 = dateTime5.withMillisOfDay(29);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumTextLength(locale11);
//        org.joda.time.Interval interval13 = property10.toInterval();
//        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
//        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
//        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
//        int int18 = property17.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime24 = dateTime22.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusMonths((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withPivotYear((java.lang.Integer) 10);
//        java.lang.String str30 = dateTime24.toString(dateTimeFormatter29);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillis(829440000000010L);
//        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
//        org.joda.time.DateTime dateTime39 = dateTime24.withFields((org.joda.time.ReadablePartial) localDateTime38);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.lang.String str43 = dateTime41.toString(dateTimeFormatter42);
//        long long44 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime46 = dateTime41.minus((long) 28253);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//        org.junit.Assert.assertNotNull(interval13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0000-10-01T00:01:40.000" + "'", str30.equals("0000-10-01T00:01:40.000"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28253-11-29T06:00:00" + "'", str43.equals("28253-11-29T06:00:00"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-891583653400010L) + "'", long44 == (-891583653400010L));
//        org.junit.Assert.assertNotNull(dateTime46);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendPattern("1");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long7 = skipUndoDateTimeField5.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology10);
        int int16 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay15);
        long long18 = skipUndoDateTimeField5.roundFloor((long) (byte) 0);
        java.lang.String str20 = skipUndoDateTimeField5.getAsShortText((long) 169);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Thu" + "'", str20.equals("Thu"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusDays((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withSecondOfMinute((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime6.withYear(10);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        java.lang.String str11 = property10.getAsShortText();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.joda.time.DateTime dateTime13 = property10.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology25, readableDateTime27, readableDateTime28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = monthDay30.isSupported(dateTimeFieldType31);
        java.lang.String str34 = monthDay30.toString("0");
        boolean boolean35 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay30);
        try {
            int int37 = monthDay13.getValue(153);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        long long72 = dividedDateTimeField69.getDifferenceAsLong((long) 6, 0L);
        int int75 = dividedDateTimeField69.getDifference((-1814399800L), 10L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-1814399800L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1814399800) + "'", int1 == (-1814399800));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("BuddhistChronology[UTC]", (-28800000), 139, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for BuddhistChronology[UTC] must be in the range [139,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime5, readableDateTime6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property9 = monthDay8.monthOfYear();
        long long11 = gJChronology0.set((org.joda.time.ReadablePartial) monthDay8, (-57600000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-26409600000L) + "'", long11 == (-26409600000L));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.ReadableDateTime readableDateTime3 = null;
//        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
//        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(limitChronology4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-136800000L) + "'", long11 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(monthDay13);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long5 = gJChronology0.getDateTimeMillis((int) (byte) 1, (-97), 999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(200);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfDay((int) (short) 100, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfDay();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.getAsText();
        java.lang.String str11 = property9.toString();
        int int12 = property9.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[monthOfYear]" + "'", str11.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField5.getAsText(100, locale7);
        int int10 = skipUndoDateTimeField5.getMaximumValue((-2424758400000L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
//        long long11 = offsetDateTimeField7.roundHalfFloor((long) 2);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1015200000L + "'", long9 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1015200000L + "'", long11 == 1015200000L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.getAsText();
        int int11 = property9.getMaximumValue();
        java.lang.String str12 = property9.getAsString();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
//        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
//        long long16 = offsetDateTimeField7.add(0L, (-57600000L));
//        long long18 = offsetDateTimeField7.roundHalfCeiling(0L);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1817717760000000000L) + "'", long16 == (-1817717760000000000L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1015200000L + "'", long18 == 1015200000L);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        org.joda.time.DurationField durationField44 = zeroIsMaxDateTimeField32.getLeapDurationField();
//        int int46 = zeroIsMaxDateTimeField32.getMaximumValue((-62167219622000L));
//        long long49 = zeroIsMaxDateTimeField32.getDifferenceAsLong((long) 28378000, (long) 100);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 8 + "'", int46 == 8);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        long long45 = zeroIsMaxDateTimeField32.roundHalfCeiling(0L);
//        int int47 = zeroIsMaxDateTimeField32.getMaximumValue(8640000000L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 8 + "'", int47 == 8);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
//        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.ReadableDateTime readableDateTime18 = null;
//        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
//        org.joda.time.Chronology chronology22 = limitChronology19.withZone(dateTimeZone21);
//        long long26 = dateTimeZone21.convertLocalToUTC((long) (-28800000), false, 1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
//        java.util.Locale locale36 = null;
//        int int37 = offsetDateTimeField35.getMaximumTextLength(locale36);
//        long long40 = offsetDateTimeField35.add((long) '4', 19);
//        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
//        org.joda.time.ReadableDateTime readableDateTime45 = null;
//        org.joda.time.ReadableDateTime readableDateTime46 = null;
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.MonthDay monthDay50 = monthDay48.minus(readablePeriod49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = offsetDateTimeField35.getAsText((org.joda.time.ReadablePartial) monthDay50, (int) 'a', locale52);
//        int[] intArray60 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
//        gregorianChronology27.validate((org.joda.time.ReadablePartial) monthDay50, intArray60);
//        int int62 = offsetDateTimeField7.getMinimumValue(readablePartial14, intArray60);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = offsetDateTimeField7.getAsText((long) 8, locale64);
//        long long68 = offsetDateTimeField7.add((long) (-28378000), 0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(limitChronology19);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-136800000L) + "'", long26 == (-136800000L));
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000052L + "'", long40 == 599616000052L);
//        org.junit.Assert.assertNotNull(copticChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "97" + "'", str53.equals("97"));
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 102 + "'", int62 == 102);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "169" + "'", str65.equals("169"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-28378000L) + "'", long68 == (-28378000L));
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "30");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.ReadableDateTime readableDateTime5 = null;
//        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
//        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
//        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.ReadableDateTime readableDateTime15 = null;
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
//        java.lang.String str21 = monthDay17.toString("0");
//        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.dayOfYear();
//        org.joda.time.DurationField durationField25 = copticChronology23.years();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology23.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
//        long long29 = delegatedDateTimeField27.roundHalfEven((long) 0);
//        java.lang.String str30 = delegatedDateTimeField27.getName();
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now();
//        int int32 = delegatedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) monthDay31);
//        boolean boolean33 = monthDay17.isAfter((org.joda.time.ReadablePartial) monthDay31);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(limitChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-21600000L) + "'", long29 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "dayOfMonth" + "'", str30.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 30 + "'", int32 == 30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumTextLength(locale11);
//        org.joda.time.Interval interval13 = property10.toInterval();
//        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
//        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
//        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
//        int int18 = property17.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("0");
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        int int22 = property17.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//        org.junit.Assert.assertNotNull(interval13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167327200000L) + "'", long21 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime5.withZoneRetainFields(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        boolean boolean15 = skipDateTimeField14.isLenient();
        long long18 = skipDateTimeField14.set((long) 100000, (int) '#');
        java.util.Locale locale19 = null;
        int int20 = skipDateTimeField14.getMaximumTextLength(locale19);
        int int22 = skipDateTimeField14.get(97L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1104537500000L) + "'", long18 == (-1104537500000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.dayOfYear();
//        org.joda.time.DurationField durationField3 = copticChronology1.years();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        long long7 = delegatedDateTimeField5.roundHalfEven((long) 0);
//        java.lang.String str8 = delegatedDateTimeField5.getName();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        int int10 = delegatedDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay9);
//        try {
//            java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay9);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-21600000L) + "'", long7 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfMonth" + "'", str8.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int72 = dividedDateTimeField69.get((-31535999948L));
        org.joda.time.chrono.CopticChronology copticChronology75 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone76 = copticChronology75.getZone();
        org.joda.time.ReadableDateTime readableDateTime77 = null;
        org.joda.time.ReadableDateTime readableDateTime78 = null;
        org.joda.time.chrono.LimitChronology limitChronology79 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology75, readableDateTime77, readableDateTime78);
        org.joda.time.MonthDay monthDay80 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology75);
        org.joda.time.MonthDay.Property property81 = monthDay80.monthOfYear();
        org.joda.time.MonthDay.Property property82 = monthDay80.monthOfYear();
        java.lang.String str83 = property82.toString();
        org.joda.time.DurationField durationField84 = property82.getRangeDurationField();
        org.joda.time.DurationField durationField85 = property82.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = property82.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField87 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69, dateTimeFieldType86);
        int int89 = dividedDateTimeField69.get(97L);
        int int91 = dividedDateTimeField69.get((long) 275);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertNotNull(copticChronology75);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(limitChronology79);
        org.junit.Assert.assertNotNull(property81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "Property[monthOfYear]" + "'", str83.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2 + "'", int89 == 2);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2 + "'", int91 == 2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long8 = skipUndoDateTimeField5.set((long) 1, 4);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology11, readableDateTime13, readableDateTime14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
        java.lang.String str20 = monthDay16.toString("0");
        int int21 = monthDay16.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField23 = monthDay16.getField((int) (short) 1);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime27 = dateTime25.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime33 = dateTime29.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property34 = dateTime29.secondOfDay();
        java.util.Locale locale35 = null;
        int int36 = property34.getMaximumTextLength(locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
        int int38 = monthDay16.indexOf(dateTimeFieldType37);
        int int39 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
//        java.lang.String str7 = delegatedDateTimeField4.getName();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        int int9 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay8);
//        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 10);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-21600000L) + "'", long6 == (-21600000L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "24" + "'", str11.equals("24"));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        java.lang.String str3 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology4 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter10.getPrinter();
        java.io.Writer writer13 = null;
        try {
            dateTimeFormatter10.printTo(writer13, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        long long4 = copticChronology0.add((long) 1, (long) (short) -1, (-97));
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 98L + "'", long4 == 98L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.DateTime dateTime15 = limitChronology4.getLowerLimit();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNull(dateTime15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "Pacific Standard Time", true, 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        java.lang.String str1 = buddhistChronology0.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[+30:00]" + "'", str1.equals("BuddhistChronology[+30:00]"));
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        org.joda.time.ReadableDateTime readableDateTime4 = null;
//        org.joda.time.ReadableDateTime readableDateTime5 = null;
//        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
//        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
//        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.ReadableDateTime readableDateTime15 = null;
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
//        java.lang.String str21 = monthDay17.toString("0");
//        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("0");
//        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
//        int int26 = dateTime24.getDayOfWeek();
//        org.joda.time.DateTime dateTime28 = dateTime24.plusHours(0);
//        int int29 = property9.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(limitChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62167327200000L) + "'", long25 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-40) + "'", int1 == (-40));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        try {
            long long6 = dateTimeFormatter0.parseMillis("--12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 895488364893600003L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology1.getZone();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(3061065621550L, (org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime();
        int int9 = dateTime6.getYear();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime6.toMutableDateTime((org.joda.time.Chronology) copticChronology10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 28253 + "'", int9 == 28253);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
//        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.lang.String str24 = dateTime22.toString(dateTimeFormatter23);
//        java.lang.Appendable appendable25 = null;
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        try {
//            dateTimeFormatter23.printTo(appendable25, readablePartial26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "28253-11-29T06:00:00" + "'", str24.equals("28253-11-29T06:00:00"));
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.append(dateTimeParser38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder41.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendLiteral('a');
        org.joda.time.format.DateTimePrinter dateTimePrinter50 = dateTimeFormatterBuilder49.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder40.append(dateTimePrinter50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimePrinter50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
//        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.lang.String str24 = dateTime22.toString(dateTimeFormatter23);
//        org.joda.time.DateTime.Property property25 = dateTime22.weekOfWeekyear();
//        int int26 = dateTime22.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "28253-11-29T06:00:00" + "'", str24.equals("28253-11-29T06:00:00"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 360 + "'", int26 == 360);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        int int12 = dateTime11.getEra();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(19);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        org.joda.time.DurationField durationField44 = zeroIsMaxDateTimeField32.getLeapDurationField();
//        int int46 = zeroIsMaxDateTimeField32.getMaximumValue((-62167219622000L));
//        int int48 = zeroIsMaxDateTimeField32.getMaximumValue((-30520800000L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 8 + "'", int46 == 8);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        java.lang.String str11 = monthDay7.toString("0");
        int int12 = monthDay7.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = monthDay7.getField((int) (short) 1);
        int[] intArray15 = monthDay7.getValues();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = julianChronology0.years();
        try {
            long long10 = julianChronology0.getDateTimeMillis((-28800000), (int) (short) 10, 2000, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.era();
//        org.joda.time.Chronology chronology5 = copticChronology3.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField7);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology11, readableDateTime13, readableDateTime14);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
//        java.lang.String str20 = monthDay16.toString("0");
//        int int21 = monthDay16.getDayOfMonth();
//        org.joda.time.DateTimeField dateTimeField23 = monthDay16.getField((int) (short) 1);
//        int[] intArray24 = new int[] {};
//        int int25 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) monthDay16, intArray24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.MonthDay monthDay27 = monthDay16.minus(readablePeriod26);
//        long long29 = copticChronology0.set((org.joda.time.ReadablePartial) monthDay27, 0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4579200000L) + "'", long29 == (-4579200000L));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendFractionOfHour(1, 999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 33);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = null;
//        java.lang.String str9 = dateTime5.toString(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0001-12-30T18:00:00.000Z" + "'", str9.equals("-0001-12-30T18:00:00.000Z"));
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfMinute();
//        int int11 = copticChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) copticChronology9);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 108000000 + "'", int8 == 108000000);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        int int30 = dateTime6.get(dateTimeFieldType28);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, dateTimeField34, (int) '#');
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField36.getAsText(0, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField36.getType();
        org.joda.time.DateTime.Property property41 = dateTime6.property(dateTimeFieldType40);
        org.joda.time.DurationField durationField42 = property41.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property41.getFieldType();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime26 = dateTime24.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime32 = dateTime30.withWeekOfWeekyear(1);
        int int33 = property9.compareTo((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTimeZone dateTimeZone34 = dateTime32.getZone();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone34);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
//        long long30 = offsetDateTimeField25.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
//        int int33 = dateTime9.get(dateTimeFieldType31);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
//        java.util.Locale locale59 = null;
//        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
//        long long63 = offsetDateTimeField58.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
//        int int70 = remainderDateTimeField35.getDivisor();
//        int int72 = remainderDateTimeField35.get((long) 2);
//        long long74 = remainderDateTimeField35.remainder(0L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 30 + "'", int70 == 30);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 9 + "'", int72 == 9);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 30520800000L + "'", long74 == 30520800000L);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
//        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology6.getZone();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime8, readableDateTime9);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
//        org.joda.time.Chronology chronology13 = limitChronology10.withZone(dateTimeZone12);
//        long long17 = dateTimeZone12.convertLocalToUTC((long) (-28800000), false, 1L);
//        boolean boolean19 = dateTimeZone12.isStandardOffset((-31535999948L));
//        boolean boolean20 = buddhistChronology5.equals((java.lang.Object) dateTimeZone12);
//        org.joda.time.Chronology chronology21 = iSOChronology0.withZone(dateTimeZone12);
//        long long24 = dateTimeZone12.adjustOffset(108000032L, false);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeParser3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-136800000L) + "'", long17 == (-136800000L));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 108000032L + "'", long24 == 108000032L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+100:00" + "'", str2.equals("+100:00"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
        try {
            long long6 = dateTimeFormatter2.parseMillis("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField12.getAsText(0, locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField12.getType();
        org.joda.time.DateTime.Property property17 = dateTime5.property(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = copticChronology0.days();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField8, (int) ' ');
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = copticChronology23.getZone();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime25, readableDateTime26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology23);
        org.joda.time.MonthDay.Property property29 = monthDay28.monthOfYear();
        org.joda.time.MonthDay.Property property30 = monthDay28.monthOfYear();
        int int31 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay28);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipDateTimeField10.getAsText((org.joda.time.ReadablePartial) monthDay28, 9, locale33);
        int int35 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 102 + "'", int31 == 102);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9" + "'", str34.equals("9"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-292268512) + "'", int35 == (-292268512));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
//        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
//        int int15 = offsetDateTimeField7.getMaximumValue();
//        long long17 = offsetDateTimeField7.remainder(3155760000010L);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 200 + "'", int15 == 200);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 30520800010L + "'", long17 == 30520800010L);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
//        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
//        int int15 = offsetDateTimeField7.getMaximumValue();
//        long long17 = offsetDateTimeField7.roundHalfFloor(0L);
//        int int19 = offsetDateTimeField7.getMaximumValue(12009600100L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField7.getAsShortText(0, locale21);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 200 + "'", int15 == 200);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1015200000L + "'", long17 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 200 + "'", int19 == 200);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        int int10 = property9.getMinimumValueOverall();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) durationField11, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology$LimitDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.ReadableDateTime readableDateTime15 = null;
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
//        org.joda.time.MonthDay.Property property18 = monthDay17.monthOfYear();
//        org.joda.time.MonthDay.Property property19 = monthDay17.monthOfYear();
//        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
//        long long22 = offsetDateTimeField7.roundHalfCeiling(0L);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray24 = null;
//        int int25 = offsetDateTimeField7.getMaximumValue(readablePartial23, intArray24);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 102 + "'", int20 == 102);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1015200000L + "'", long22 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 200 + "'", int25 == 200);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(33, 999, 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime5.toCalendar(locale8);
        int int10 = dateTime5.getEra();
        org.joda.time.DateTime dateTime12 = dateTime5.withHourOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = julianChronology11.withZone(dateTimeZone14);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekOfWeekyear();
//        java.lang.String str19 = buddhistChronology17.toString();
//        boolean boolean20 = julianChronology11.equals((java.lang.Object) str19);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long26 = dateTimeZone22.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
//        org.joda.time.Chronology chronology28 = julianChronology11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours(30);
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone30);
//        long long33 = cachedDateTimeZone27.getMillisKeepLocal(dateTimeZone30, 0L);
//        java.lang.String str35 = cachedDateTimeZone27.getName((-108000000L));
//        java.lang.Object obj36 = null;
//        boolean boolean37 = cachedDateTimeZone27.equals(obj36);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone27);
//        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) cachedDateTimeZone27);
//        java.util.Locale locale40 = null;
//        try {
//            java.lang.String str41 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay39, locale40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1015200000L + "'", long9 == 1015200000L);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28800000L + "'", long26 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-108000000L) + "'", long33 == (-108000000L));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordinated Universal Time" + "'", str35.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(monthDay39);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        java.lang.String str14 = property10.getName();
        org.joda.time.DateTime dateTime15 = property10.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "secondOfDay" + "'", str14.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.ReadableDateTime readableDateTime15 = null;
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
//        org.joda.time.MonthDay.Property property18 = monthDay17.monthOfYear();
//        org.joda.time.MonthDay.Property property19 = monthDay17.monthOfYear();
//        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
//        long long22 = offsetDateTimeField7.roundHalfCeiling(0L);
//        int int24 = offsetDateTimeField7.get((long) 2513);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 102 + "'", int20 == 102);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1015200000L + "'", long22 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 169 + "'", int24 == 169);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) 10L);
//        boolean boolean3 = instant2.isEqualNow();
//        org.joda.time.Instant instant6 = instant2.withDurationAdded((long) (-28800000), (-28800000));
//        int int7 = instant0.compareTo((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Instant instant8 = instant6.toInstant();
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
//        org.joda.time.ReadableDateTime readableDateTime11 = null;
//        org.joda.time.ReadableDateTime readableDateTime12 = null;
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology9, readableDateTime11, readableDateTime12);
//        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology14.getZone();
//        org.joda.time.Chronology chronology16 = limitChronology13.withZone(dateTimeZone15);
//        long long20 = dateTimeZone15.convertLocalToUTC((long) (-28800000), false, 1L);
//        boolean boolean22 = dateTimeZone15.isStandardOffset((-31535999948L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) instant8, (org.joda.time.DateTimeZone) cachedDateTimeZone23);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(copticChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-136800000L) + "'", long20 == (-136800000L));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
        try {
            long long10 = gregorianChronology2.getDateTimeMillis(0, 0, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumShortTextLength(locale10);
        java.util.Locale locale13 = null;
        org.joda.time.MonthDay monthDay14 = property9.setCopy("3", locale13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = property9.getAsText(locale15);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3" + "'", str16.equals("3"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.joda.time.DurationField durationField4 = copticChronology0.months();
        try {
            long long12 = copticChronology0.getDateTimeMillis((-1920000), 69, 30, 29, 108000000, 999, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
//        long long30 = offsetDateTimeField25.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
//        int int33 = dateTime9.get(dateTimeFieldType31);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
//        java.util.Locale locale59 = null;
//        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
//        long long63 = offsetDateTimeField58.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
//        int int70 = remainderDateTimeField35.getDivisor();
//        int int71 = remainderDateTimeField35.getMaximumValue();
//        long long73 = remainderDateTimeField35.roundHalfEven((long) 10);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 30 + "'", int70 == 30);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 29 + "'", int71 == 29);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1015200000L + "'", long73 == 1015200000L);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
//        long long12 = offsetDateTimeField7.remainder((-1209599900L));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 29311200100L + "'", long12 == 29311200100L);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        boolean boolean13 = offsetDateTimeField7.isLeap((long) 0);
        long long16 = offsetDateTimeField7.add(12009600100L, 31);
        int int17 = offsetDateTimeField7.getMaximumValue();
        int int19 = offsetDateTimeField7.getMaximumValue((-28378000L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 990316800100L + "'", long16 == 990316800100L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 200 + "'", int17 == 200);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 200 + "'", int19 == 200);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property10 = dateTime9.year();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
//        java.util.Locale locale19 = null;
//        int int20 = offsetDateTimeField18.getMaximumTextLength(locale19);
//        long long23 = offsetDateTimeField18.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField18.getType();
//        int int25 = dateTime9.get(dateTimeFieldType24);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long31 = dateTimeZone27.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone33 = cachedDateTimeZone32.getUncachedZone();
//        java.lang.String str35 = cachedDateTimeZone32.getName(100L);
//        org.joda.time.DateTime dateTime36 = dateTime9.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone32);
//        org.joda.time.DateTime dateTime38 = dateTime9.withDayOfYear(33);
//        org.joda.time.DateTime.Property property39 = dateTime38.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 599616000052L + "'", long23 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800000L + "'", long31 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordinated Universal Time" + "'", str35.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withPeriodAdded(readablePeriod13, 6);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+30:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+30:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property10 = dateTime9.year();
//        java.lang.String str11 = property10.getAsShortText();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime((org.joda.time.Chronology) gregorianChronology18);
//        int int20 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
//        int int22 = property10.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 108000000 + "'", int20 == 108000000);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
//        long long16 = offsetDateTimeField11.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
//        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime23 = dateTime21.plusSeconds((int) (byte) 100);
//        int int24 = dateTime21.getYearOfEra();
//        boolean boolean25 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        int int26 = dateTime21.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear(200);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendYearOfEra(3, (-97));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        org.joda.time.DateTime dateTime14 = property10.roundCeilingCopy();
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        org.joda.time.Chronology chronology20 = limitChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        boolean boolean21 = cachedDateTimeZone19.isFixed();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
//        long long16 = offsetDateTimeField11.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
//        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime1.withZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime25 = dateTime1.minusYears(108000000);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendHourOfDay(13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendCenturyOfEra(0, 40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        int int13 = property10.getMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property10.getAsShortText(locale14);
        org.joda.time.DateTime dateTime16 = property10.getDateTime();
        org.joda.time.DateTime dateTime17 = dateTime16.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.DateTime.Property property12 = dateTime5.millisOfSecond();
        boolean boolean13 = dateTime5.isBeforeNow();
        org.joda.time.DateTime dateTime15 = dateTime5.plusDays(29);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear(9, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime14 = dateTime11.withMillis(829440000000010L);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField26, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, 100);
        java.util.Locale locale31 = null;
        int int32 = offsetDateTimeField30.getMaximumTextLength(locale31);
        long long35 = offsetDateTimeField30.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, dateTimeFieldType36);
        int int38 = dateTime14.get(dateTimeFieldType36);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone41 = julianChronology40.getZone();
        org.joda.time.DateTimeField dateTimeField42 = julianChronology40.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField(chronology39, dateTimeField42, (int) '#');
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField44.getAsText(0, locale46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField44.getType();
        org.joda.time.DateTime.Property property49 = dateTime14.property(dateTimeFieldType48);
        try {
            int int50 = localTime7.get(dateTimeFieldType48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 599616000052L + "'", long35 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property49);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        int int72 = dividedDateTimeField69.getDifference((-1817717760000422000L), 25L);
        boolean boolean73 = dividedDateTimeField69.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1920000) + "'", int72 == (-1920000));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("secondOfDay", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"secondOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        int int17 = property10.getLeapAmount();
        int int18 = property10.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
//        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.dayOfYear();
//        org.joda.time.DurationField durationField8 = copticChronology6.years();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        long long12 = delegatedDateTimeField10.roundHalfEven((long) 0);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField10, 169);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-21600000L) + "'", long12 == (-21600000L));
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
//        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getLeapDurationField();
//        long long13 = offsetDateTimeField7.roundCeiling(0L);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1015200000L + "'", long13 == 1015200000L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology4.getZone();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime6, readableDateTime7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField12, (int) '#');
        int int16 = skipUndoDateTimeField14.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField14, 3);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime22 = dateTime19.withZoneRetainFields(dateTimeZone21);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        org.joda.time.Chronology chronology24 = limitChronology8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone23);
        try {
            long long27 = dateTimeFormatter25.parseMillis("-0001-12-30T18:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-0001-12-30T18:00:00.000Z\" is malformed at \"-12-30T18:00:00.000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter1.getZone();
        try {
            org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("JulianChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay.Property property23 = monthDay17.monthOfYear();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsShortText(locale24);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3" + "'", str25.equals("3"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, 100);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumTextLength(locale27);
        long long31 = offsetDateTimeField26.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType32, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000052L + "'", long31 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getLeapDurationField();
        long long14 = offsetDateTimeField7.addWrapField((-62167190822000L), 13);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62577418022000L) + "'", long14 == (-62577418022000L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = gregorianChronology2.toString();
        long long8 = gregorianChronology2.getDateTimeMillis((int) (byte) -1, 6, 1, 0);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekOfWeekyear(1);
        int int19 = dateTime18.getMinuteOfHour();
        org.joda.time.DateTime dateTime21 = dateTime18.plusDays(4);
        boolean boolean22 = gregorianChronology2.equals((java.lang.Object) dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+100:00]" + "'", str3.equals("GregorianChronology[+100:00]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62186068800000L) + "'", long8 == (-62186068800000L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        long long46 = zeroIsMaxDateTimeField32.getDifferenceAsLong((-1817717760000422000L), (-891583653400010L));
//        int int48 = zeroIsMaxDateTimeField32.getMinimumValue((-1861920000000L));
//        long long51 = zeroIsMaxDateTimeField32.add((-26409600000L), 86399);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-21028080744L) + "'", long46 == (-21028080744L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 7438464000000L + "'", long51 == 7438464000000L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("LimitChronology[CopticChronology[+30:00], NoLimit, NoLimit]");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "GregorianChronology[UTC]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime20 = dateTime18.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime22.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property27 = dateTime22.secondOfDay();
        int int28 = property10.getDifference((org.joda.time.ReadableInstant) dateTime22);
        try {
            org.joda.time.DateTime dateTime30 = dateTime22.withEra((-40));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -40 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        long long3 = instant1.getMillis();
        boolean boolean5 = instant1.isBefore(0L);
        boolean boolean7 = instant1.isBefore((-101L));
        org.joda.time.DateTime dateTime8 = instant1.toDateTime();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology15);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.minus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay22, (int) 'a', locale24);
        int int27 = offsetDateTimeField7.getMinimumValue(0L);
        org.joda.time.DurationField durationField28 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone32 = copticChronology31.getZone();
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.ReadableDateTime readableDateTime34 = null;
        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology31, readableDateTime33, readableDateTime34);
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology31);
        org.joda.time.MonthDay.Property property37 = monthDay36.monthOfYear();
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay36);
        int int39 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay36);
        int int42 = offsetDateTimeField7.getDifference((-829439999999910L), 97L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "97" + "'", str25.equals("97"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 102 + "'", int27 == 102);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(limitChronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 102 + "'", int39 == 102);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-26283) + "'", int42 == (-26283));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        org.joda.time.DurationField durationField44 = zeroIsMaxDateTimeField32.getLeapDurationField();
//        int int46 = zeroIsMaxDateTimeField32.getMaximumValue((-62167219622000L));
//        long long48 = zeroIsMaxDateTimeField32.roundHalfCeiling((long) 39);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 8 + "'", int46 == 8);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime14 = property10.addToCopy((long) (-28800000));
        org.joda.time.DateTime dateTime15 = property10.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property10.getFieldType();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        int int6 = skipUndoDateTimeField5.getMinimumValue();
        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
        long long10 = skipUndoDateTimeField5.roundCeiling(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        long long4 = copticChronology0.add((long) 1, (long) (short) -1, (-97));
        try {
            long long12 = copticChronology0.getDateTimeMillis(3, 0, (int) (short) 0, 17, (int) (byte) 10, 30, (-40));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -40 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 98L + "'", long4 == 98L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfMonth();
        org.joda.time.LocalTime localTime9 = dateTime1.toLocalTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            boolean boolean11 = localTime9.isEqual(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localTime9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        boolean boolean6 = instant5.isEqualNow();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant5.plus(readableDuration7);
        org.joda.time.Instant instant9 = instant8.toInstant();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) (-97));
        int int6 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime3.yearOfEra();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsText(locale8);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 40 + "'", int6 == 40);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DurationField durationField2 = copticChronology0.years();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
//        int int8 = delegatedDateTimeField4.getMaximumValue();
//        long long11 = delegatedDateTimeField4.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = skipUndoDateTimeField17.getAsText(0, locale19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField17.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType21);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology25, readableDateTime27, readableDateTime28);
//        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology25);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.MonthDay monthDay32 = monthDay30.minus(readablePeriod31);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.MonthDay monthDay42 = monthDay40.minus(readablePeriod41);
//        boolean boolean43 = monthDay32.isBefore((org.joda.time.ReadablePartial) monthDay42);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay42, locale44);
//        java.lang.String str46 = delegatedDateTimeField4.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1987199800L) + "'", long11 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1" + "'", str45.equals("1"));
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str46.equals("DateTimeField[dayOfMonth]"));
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
//        long long30 = offsetDateTimeField25.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
//        int int33 = dateTime9.get(dateTimeFieldType31);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
//        java.util.Locale locale59 = null;
//        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
//        long long63 = offsetDateTimeField58.add((long) '4', 19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
//        org.joda.time.MonthDay monthDay70 = org.joda.time.MonthDay.now();
//        java.lang.String str71 = monthDay70.toString();
//        int[] intArray79 = new int[] { 19, 102, 53, (-97), 30, 169 };
//        int[] intArray81 = remainderDateTimeField35.add((org.joda.time.ReadablePartial) monthDay70, 2, intArray79, 0);
//        int int83 = remainderDateTimeField35.get(0L);
//        long long85 = remainderDateTimeField35.remainder((long) (-1));
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertNotNull(monthDay70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "--01-02" + "'", str71.equals("--01-02"));
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 9 + "'", int83 == 9);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 30520799999L + "'", long85 == 30520799999L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        int int13 = property10.getMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property10.getAsShortText(locale14);
        org.joda.time.DurationField durationField16 = property10.getDurationField();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 1);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        boolean boolean12 = gJChronology0.equals((java.lang.Object) dateTime10);
        int int13 = dateTime10.getWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime10.plusHours((-1814399800));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
//        long long10 = offsetDateTimeField7.add((long) 'a', (int) (short) 10);
//        long long12 = offsetDateTimeField7.roundCeiling(86400000L);
//        int int14 = offsetDateTimeField7.getLeapAmount(30520800069L);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315532800097L + "'", long10 == 315532800097L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1015200000L + "'", long12 == 1015200000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.lang.String str9 = skipUndoDateTimeField5.getAsText((long) '4');
        java.util.Locale locale12 = null;
        long long13 = skipUndoDateTimeField5.set((-28799968L), "10", locale12);
        int int15 = skipUndoDateTimeField5.getMaximumValue((long) 1);
        java.lang.String str17 = skipUndoDateTimeField5.getAsShortText(315532800097L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1861948799968L) + "'", long13 == (-1861948799968L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "79" + "'", str17.equals("79"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendTimeZoneOffset("-0001-12-30T18:00:00.000Z", "24", false, 0, (-26283));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[+30:00]", "", (-26283), (int) (short) 10);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) 'a');
//        long long5 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long13 = dateTimeZone9.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        org.joda.time.Chronology chronology16 = iSOChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology6.yearOfEra();
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
//        org.joda.time.Chronology chronology20 = iSOChronology6.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime24 = dateTime22.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime24.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime30 = dateTime26.plusMillis((int) (short) -1);
//        org.joda.time.DateTime.Property property31 = dateTime26.secondOfDay();
//        java.util.Locale locale32 = null;
//        int int33 = property31.getMaximumTextLength(locale32);
//        org.joda.time.DateTime dateTime34 = property31.roundFloorCopy();
//        org.joda.time.DateTime dateTime36 = dateTime34.plusDays((-28800000));
//        int int37 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime34);
//        int int38 = dateTime34.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 108000000 + "'", int3 == 108000000);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 108000032L + "'", long5 == 108000032L);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 108000000 + "'", int37 == 108000000);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 39 + "'", int38 == 39);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime dateTime18 = dateTime16.plusSeconds(53);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = dateTime16.toString("Coordinated Universal Time", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        boolean boolean11 = property10.isLeap();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        int int11 = dateTime9.getYearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.plusWeeks((int) '#');
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "169");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay monthDay10 = property8.addToCopy(5);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-30520800000L), 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-183124800000L) + "'", long2 == (-183124800000L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        int int17 = property10.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property10.setCopy((int) (short) 0);
        java.util.Locale locale20 = null;
        int int21 = property10.getMaximumShortTextLength(locale20);
        java.lang.String str22 = property10.getAsShortText();
        org.joda.time.DateTime dateTime23 = property10.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfMonth();
        org.joda.time.LocalTime localTime9 = dateTime1.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks(17);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
        int int21 = dateTime20.getMinuteOfHour();
        org.joda.time.DateTime.Property property22 = dateTime20.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        int int28 = gregorianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime29 = dateTime20.withChronology((org.joda.time.Chronology) gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Sun");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = monthDay17.getDayOfMonth();
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay17, 0, locale24);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField7.getMaximumShortTextLength(locale26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField7.getAsShortText((-108000000L), locale29);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "169" + "'", str30.equals("169"));
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
//        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
//        int int6 = skipUndoDateTimeField5.getMinimumValue();
//        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
//        org.joda.time.DurationField durationField11 = copticChronology9.years();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
//        int int17 = delegatedDateTimeField13.getMaximumValue();
//        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
//        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
//        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
//        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        int int45 = zeroIsMaxDateTimeField32.get(0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(limitChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
//        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
//        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.lang.String str24 = dateTime22.toString(dateTimeFormatter23);
//        org.joda.time.DateTime.Property property25 = dateTime22.weekOfWeekyear();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime22.toLocalDateTime();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "28253-11-29T06:00:00" + "'", str24.equals("28253-11-29T06:00:00"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime24 = dateTime22.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime26 = dateTime24.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime30 = dateTime26.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime32 = dateTime26.withYearOfEra(39);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
        org.joda.time.MonthDay.Property property42 = monthDay40.monthOfYear();
        java.lang.String str43 = property42.toString();
        org.joda.time.DurationField durationField44 = property42.getRangeDurationField();
        org.joda.time.DurationField durationField45 = property42.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
        org.joda.time.DateTime.Property property47 = dateTime32.property(dateTimeFieldType46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType46, 28378000, 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Property[monthOfYear]" + "'", str43.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }
}

