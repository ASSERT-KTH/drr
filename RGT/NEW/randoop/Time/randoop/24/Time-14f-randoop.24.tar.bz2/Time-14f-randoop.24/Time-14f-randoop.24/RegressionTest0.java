import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 10, (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "hi!", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) '4', (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for  must be in the range [32,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) 10L);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) (short) 0, (int) (short) 100, 0, (-1), (int) '4', 0, (org.joda.time.Chronology) copticChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = julianChronology0.set(readablePartial3, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '#', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 1, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 100, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hi! must be in the range [-1,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 1, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-34L) + "'", long2 == (-34L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.ReadableInstant readableInstant6 = null;
        try {
            int int7 = instant5.compareTo(readableInstant6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
        try {
            long long12 = offsetDateTimeField7.set((long) 4, "1");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1152000000L + "'", long9 == 1152000000L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 35L + "'", long0 == 35L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long11 = julianChronology0.getDateTimeMillis(10, (int) (short) 1, (int) ' ', (int) (byte) 0, (int) (byte) 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean3 = instant2.isEqualNow();
        org.joda.time.Instant instant6 = instant2.withDurationAdded((long) (-28800000), (-28800000));
        int int7 = instant0.compareTo((org.joda.time.ReadableInstant) instant6);
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant6);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 829440000000010L + "'", long8 == 829440000000010L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = skipUndoDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter2.parseLocalDate("52");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"52\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 3, (java.lang.Number) (-97), (java.lang.Number) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.clockhourOfHalfday();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) (-28799968L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology4.getZone();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime6, readableDateTime7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField2 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.Chronology chronology9 = limitChronology6.withZone(dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC((long) (-28800000), false, 1L);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withTime((int) '#', 100, (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int[] intArray24 = new int[] { (-1) };
        try {
            int[] intArray26 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay17, (int) (short) -1, intArray24, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (short) 100, 1, (int) (short) 0, (int) (byte) 10, (int) '#', 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withField(dateTimeFieldType8, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology5, readableDateTime7, readableDateTime8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology5);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.minus(readablePeriod11);
        int int14 = monthDay12.getValue(0);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.era();
        org.joda.time.Chronology chronology10 = copticChronology8.withUTC();
        try {
            org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) dateTimeZone6, chronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        java.lang.String str11 = monthDay7.toString("0");
        int int12 = monthDay7.getDayOfMonth();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.MonthDay monthDay15 = monthDay7.withFieldAdded(durationFieldType13, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withWeekOfWeekyear((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int int8 = property6.compareTo(readablePartial7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        boolean boolean12 = offsetDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        long long6 = durationField3.subtract((long) 200, (int) (byte) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (byte) 0, (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "97");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology13, readableDateTime15, readableDateTime16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology13);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = monthDay18.isSupported(dateTimeFieldType19);
        java.lang.String str22 = monthDay18.toString("0");
        int int23 = monthDay18.getDayOfMonth();
        int[] intArray26 = new int[] { ' ' };
        try {
            int[] intArray28 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay18, (int) (byte) 1, intArray26, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(10, (-97), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (long) 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField8.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField8.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField8.getType();
        try {
            org.joda.time.MonthDay.Property property15 = monthDay0.property(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 599616000052L + "'", long13 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTime.Property property16 = dateTime11.yearOfEra();
        org.joda.time.LocalTime localTime17 = dateTime11.toLocalTime();
        int[] intArray20 = new int[] { (short) 100 };
        try {
            int[] intArray22 = offsetDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) localTime17, (int) (short) 100, intArray20, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        int int8 = dateTime1.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime5, readableDateTime6);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.Chronology chronology10 = limitChronology7.withZone(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = instant1.toMutableDateTime((org.joda.time.Chronology) limitChronology7);
        try {
            long long19 = limitChronology7.getDateTimeMillis((int) (short) 100, (int) '#', (int) (byte) 1, 100, (-1), (int) (short) 0, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.LocalDateTime localDateTime8 = null;
        try {
            boolean boolean9 = dateTimeZone6.isLocalDateTimeGap(localDateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("0000-10-01T00:01:40.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0000-10-01T00:01:40.000\" is malformed at \"T00:01:40.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTimeISO();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology4.getZone();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime6, readableDateTime7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
        org.joda.time.Chronology chronology11 = limitChronology8.withZone(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = instant2.toMutableDateTime((org.joda.time.Chronology) limitChronology8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) limitChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "52", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "52", "52");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "0", "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        try {
            int[] intArray20 = copticChronology0.get(readablePeriod18, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = monthDay7.getFieldTypes();
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = monthDay7.toString("", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (-62167190822000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62167190822000L + "'", long2 == 62167190822000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: O");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        long long25 = skipUndoDateTimeField5.getDifferenceAsLong(1L, (-1861948799968L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 21550L + "'", long25 == 21550L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology4.getZone();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime6, readableDateTime7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
        org.joda.time.MonthDay.Property property11 = monthDay9.monthOfYear();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0000-10-01T00:01:40.000");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withFieldAdded(durationFieldType9, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.era();
        org.joda.time.Chronology chronology15 = copticChronology13.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField17);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = copticChronology21.getZone();
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime23, readableDateTime24);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology21);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = monthDay26.isSupported(dateTimeFieldType27);
        java.lang.String str30 = monthDay26.toString("0");
        int int31 = monthDay26.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField33 = monthDay26.getField((int) (short) 1);
        int[] intArray34 = new int[] {};
        int int35 = skipUndoDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray34);
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = copticChronology38.getZone();
        org.joda.time.ReadableDateTime readableDateTime40 = null;
        org.joda.time.ReadableDateTime readableDateTime41 = null;
        org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology38, readableDateTime40, readableDateTime41);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        java.lang.String str47 = monthDay43.toString("0");
        boolean boolean48 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay43);
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.era();
        org.joda.time.Chronology chronology52 = copticChronology50.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField(chronology52, dateTimeField54);
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = copticChronology58.getZone();
        org.joda.time.ReadableDateTime readableDateTime60 = null;
        org.joda.time.ReadableDateTime readableDateTime61 = null;
        org.joda.time.chrono.LimitChronology limitChronology62 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology58, readableDateTime60, readableDateTime61);
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology58);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = null;
        boolean boolean65 = monthDay63.isSupported(dateTimeFieldType64);
        java.lang.String str67 = monthDay63.toString("0");
        int int68 = monthDay63.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField70 = monthDay63.getField((int) (short) 1);
        int[] intArray71 = new int[] {};
        int int72 = skipUndoDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) monthDay63, intArray71);
        try {
            int[] intArray74 = offsetDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay26, 1, intArray71, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(limitChronology25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(limitChronology42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(limitChronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField19.getMaximumTextLength(locale20);
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = copticChronology24.getZone();
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.chrono.LimitChronology limitChronology28 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology24, readableDateTime26, readableDateTime27);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology24);
        org.joda.time.MonthDay.Property property30 = monthDay29.monthOfYear();
        org.joda.time.MonthDay.Property property31 = monthDay29.monthOfYear();
        int int32 = offsetDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay29);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay29, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(limitChronology28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 102 + "'", int32 == 102);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfMonth();
        int int9 = dateTime1.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.String str4 = dateTimeFormatter0.print((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969365" + "'", str4.equals("1969365"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.lang.String str9 = skipUndoDateTimeField5.getAsText((long) '4');
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField5, (int) ' ', (-97), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for yearOfCentury must be in the range [-97,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        try {
            org.joda.time.DateTime dateTime12 = dateTime5.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4, (int) '#');
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField6.getAsText(0, locale8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipUndoDateTimeField6.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.lang.String str9 = skipUndoDateTimeField5.getAsText((long) '4');
        java.lang.String str10 = skipUndoDateTimeField5.toString();
        java.util.Locale locale13 = null;
        try {
            long long14 = skipUndoDateTimeField5.set((-62167190822000L), "", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str10.equals("DateTimeField[yearOfCentury]"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str4 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str4.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        try {
            org.joda.time.MonthDay monthDay3 = monthDay1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        long long3 = instant1.getMillis();
        org.joda.time.Instant instant5 = instant1.minus((long) ' ');
        long long6 = instant1.getMillis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        long long3 = instant1.getMillis();
        boolean boolean5 = instant1.isBefore(0L);
        try {
            org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((java.lang.Object) boolean5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay13.minus(readablePeriod23);
        try {
            int int26 = monthDay13.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(monthDay24);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) 39, locale10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField17.getAsText(0, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField17.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "22" + "'", str11.equals("22"));
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = julianChronology0.get(readablePeriod2, (long) 6, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        int int1 = monthDay0.getDayOfMonth();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime22, readableDateTime23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        java.lang.String str29 = monthDay25.toString("0");
        int int30 = monthDay25.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = monthDay25.getField((int) (short) 1);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) (short) -1, locale34);
        org.joda.time.DurationField durationField36 = skipUndoDateTimeField10.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = copticChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            java.lang.String str5 = dateTimeFormatter0.print(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getRangeDurationField();
        try {
            long long15 = offsetDateTimeField7.set((-31535999948L), "22");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        int int5 = dateTimeZone3.getOffsetFromLocal((long) 'a');
        long long7 = dateTimeZone3.convertUTCToLocal((long) ' ');
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology9 = julianChronology0.withZone(dateTimeZone3);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799968L) + "'", long7 == (-28799968L));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology16.getZone();
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology16, readableDateTime18, readableDateTime19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology16);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        boolean boolean23 = monthDay21.isSupported(dateTimeFieldType22);
        java.lang.String str25 = monthDay21.toString("0");
        int int26 = monthDay21.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField28 = monthDay21.getField((int) (short) 1);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = copticChronology30.getZone();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology30, readableDateTime32, readableDateTime33);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.Chronology chronology37 = limitChronology34.withZone(dateTimeZone36);
        long long41 = dateTimeZone36.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        java.util.Locale locale51 = null;
        int int52 = offsetDateTimeField50.getMaximumTextLength(locale51);
        long long55 = offsetDateTimeField50.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = copticChronology58.getZone();
        org.joda.time.ReadableDateTime readableDateTime60 = null;
        org.joda.time.ReadableDateTime readableDateTime61 = null;
        org.joda.time.chrono.LimitChronology limitChronology62 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology58, readableDateTime60, readableDateTime61);
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology58);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.minus(readablePeriod64);
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField50.getAsText((org.joda.time.ReadablePartial) monthDay65, (int) 'a', locale67);
        int[] intArray75 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology42.validate((org.joda.time.ReadablePartial) monthDay65, intArray75);
        try {
            int[] intArray78 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) monthDay21, (int) (byte) 1, intArray75, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 599616000052L + "'", long55 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(limitChronology62);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "97" + "'", str68.equals("97"));
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        boolean boolean10 = dateTime9.isBeforeNow();
        long long11 = dateTime9.getMillis();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62143517122001L) + "'", long11 == (-62143517122001L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) copticChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        java.lang.String str2 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField7.getAsText((int) 'a', locale13);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "97" + "'", str14.equals("97"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        int int10 = offsetDateTimeField7.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 200 + "'", int10 == 200);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 100, 829440000000010L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-829439999999910L) + "'", long2 == (-829439999999910L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfDay();
        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, 100);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumTextLength(locale16);
        long long20 = offsetDateTimeField15.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField15.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType21);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime26 = dateTime24.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime28 = dateTime26.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((java.lang.Integer) 10);
        java.lang.String str34 = dateTime28.toString(dateTimeFormatter33);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime38 = dateTime36.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
        org.joda.time.DateTime dateTime41 = dateTime38.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
        org.joda.time.DateTime dateTime43 = dateTime28.withFields((org.joda.time.ReadablePartial) localDateTime42);
        int[] intArray45 = null;
        try {
            int[] intArray47 = skipUndoDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDateTime42, 6, intArray45, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 599616000052L + "'", long20 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0000-10-01T00:01:40.000" + "'", str34.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(chronology2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) '#', (-28378000), 1, (int) '#', 0, 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.MonthDay.Property property18 = monthDay17.monthOfYear();
        org.joda.time.MonthDay.Property property19 = monthDay17.monthOfYear();
        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
        long long22 = offsetDateTimeField7.roundHalfEven((long) 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 102 + "'", int20 == 102);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.era();
        org.joda.time.Chronology chronology16 = copticChronology14.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology16, dateTimeField18);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = copticChronology22.getZone();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        boolean boolean29 = monthDay27.isSupported(dateTimeFieldType28);
        java.lang.String str31 = monthDay27.toString("0");
        int int32 = monthDay27.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField34 = monthDay27.getField((int) (short) 1);
        int[] intArray35 = new int[] {};
        int int36 = skipUndoDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay27, intArray35);
        try {
            int int37 = property10.compareTo((org.joda.time.ReadablePartial) monthDay27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.LocalDate localDate5 = dateTime3.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100L, (java.lang.Number) 100.0f, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay13.minus(readablePeriod23);
        try {
            org.joda.time.MonthDay monthDay26 = monthDay13.withDayOfMonth((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(monthDay24);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay7.getFields();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        try {
            org.joda.time.MonthDay monthDay13 = property9.setCopy("22");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.halfdays();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.yearOfEra();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTwoDigitYear(28378000, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("UTC", "3940-01-01T08:07:02");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
        try {
            long long13 = copticChronology2.getDateTimeMillis(19, (int) (short) 1, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.MonthDay monthDay11 = property8.addWrapFieldToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        boolean boolean5 = delegatedDateTimeField4.isLenient();
        try {
            long long8 = delegatedDateTimeField4.set(0L, "52");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property8.getAsText(locale11);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        long long8 = dateTimeZone4.adjustOffset((long) (short) 0, false);
        long long11 = dateTimeZone4.convertLocalToUTC((long) 40, true);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800040L + "'", long11 == 28800040L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendPattern("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long13 = dateTimeZone9.convertLocalToUTC(28800000L, true, 0L);
        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) ' ');
        java.lang.String str16 = dateTimeZone9.getID();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) 'a', (int) (byte) 10, 0, 5, (int) 'a', (int) (short) 100, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28799968L) + "'", long15 == (-28799968L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology14.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, dateTimeField16, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, 100);
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField20.getMaximumTextLength(locale21);
        long long25 = offsetDateTimeField20.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = copticChronology28.getZone();
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology28, readableDateTime30, readableDateTime31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology28);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.minus(readablePeriod34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField20.getAsText((org.joda.time.ReadablePartial) monthDay35, (int) 'a', locale37);
        int[] intArray45 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology12.validate((org.joda.time.ReadablePartial) monthDay35, intArray45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay48 = monthDay35.plus(readablePeriod47);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime52 = dateTime50.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime54 = dateTime52.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime56 = dateTime54.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime58 = dateTime54.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property59 = dateTime54.secondOfDay();
        java.util.Locale locale60 = null;
        int int61 = property59.getMaximumTextLength(locale60);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property59.getFieldType();
        try {
            org.joda.time.MonthDay monthDay64 = monthDay35.withField(dateTimeFieldType62, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 599616000052L + "'", long25 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "97" + "'", str38.equals("97"));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField19.getMaximumTextLength(locale20);
        long long24 = offsetDateTimeField19.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField19.getType();
        int int26 = dateTime10.get(dateTimeFieldType25);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 599616000052L + "'", long24 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4, (int) '#');
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField6.getAsText(0, locale8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipUndoDateTimeField6.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (short) 100, "CopticChronology[America/Los_Angeles]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "GregorianChronology[+100:00]");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField16 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        long long16 = durationField13.subtract((-62167190822000L), 3);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62167190825000L) + "'", long16 == (-62167190825000L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField4.getWrappedField();
        try {
            long long12 = delegatedDateTimeField4.getDifferenceAsLong(3061065621550L, (-62167190822000L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The subtrahend instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 39, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 19, (int) '#', 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
        java.lang.String str8 = buddhistChronology6.toString();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0, (int) (byte) 10, 1, 2, 102, 0, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 102 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[UTC]" + "'", str8.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundFloorCopy();
        org.joda.time.ReadableInstant readableInstant14 = null;
        try {
            int int15 = property10.getDifference(readableInstant14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -62143517122");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 'a');
        long long5 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28799968L) + "'", long5 == (-28799968L));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 2, 0, 31, (-28378000), (int) '#', 39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.lang.String str9 = skipUndoDateTimeField5.getAsText((long) '4');
        java.util.Locale locale12 = null;
        long long13 = skipUndoDateTimeField5.set((-28799968L), "10", locale12);
        int int15 = skipUndoDateTimeField5.getMaximumValue((long) 1);
        int int17 = skipUndoDateTimeField5.get((-1817717760000422000L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1861948799968L) + "'", long13 == (-1861948799968L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 33 + "'", int17 == 33);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        long long11 = delegatedDateTimeField4.set((long) 200, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1814399800L) + "'", long11 == (-1814399800L));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        boolean boolean15 = offsetDateTimeField7.isLeap((-1817717760000422000L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime3 = dateTime0.withZoneRetainFields(dateTimeZone2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
        long long9 = dateTime7.getMillis();
        org.joda.time.DateTime dateTime11 = dateTime7.plusWeeks(10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62146109122000L) + "'", long9 == (-62146109122000L));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.MonthDay.Property property18 = monthDay17.monthOfYear();
        org.joda.time.MonthDay.Property property19 = monthDay17.monthOfYear();
        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
        try {
            long long23 = offsetDateTimeField7.set((long) (-1), "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 102 + "'", int20 == 102);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        try {
            long long16 = offsetDateTimeField7.set(0L, "JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
        java.lang.String str7 = delegatedDateTimeField4.getName();
        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800000L + "'", long6 == 28800000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        long long12 = offsetDateTimeField7.roundHalfFloor(31535999999L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1152000000L + "'", long9 == 1152000000L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32688000000L + "'", long12 == 32688000000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long8 = skipUndoDateTimeField5.set((long) 1, 4);
        long long10 = skipUndoDateTimeField5.roundHalfCeiling((-1861948799968L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1861920000000L) + "'", long10 == (-1861920000000L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
        java.lang.Appendable appendable5 = null;
        org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTimeISO();
        boolean boolean9 = instant7.isAfterNow();
        try {
            dateTimeFormatter2.printTo(appendable5, (org.joda.time.ReadableInstant) instant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.plusMillis((int) '#');
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 'a');
        long long5 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            long long11 = iSOChronology6.getDateTimeMillis((int) (byte) 100, 31, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28799968L) + "'", long5 == (-28799968L));
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYear(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) '4');
        int int8 = dateTime5.getMillisOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime5.getZone();
        boolean boolean11 = dateTime5.isBefore((-1814399800L));
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 28378000 + "'", int8 == 28378000);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField3 = buddhistChronology0.halfdays();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.dayOfYear();
        org.joda.time.DurationField durationField13 = copticChronology11.years();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.dayOfYear();
        org.joda.time.DurationField durationField16 = copticChronology14.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType10, durationField13, durationField16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.String str3 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "12/31/69" + "'", str3.equals("12/31/69"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(30);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "52", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "52", "52");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        int int15 = offsetDateTimeField7.get(0L);
        long long18 = offsetDateTimeField7.getDifferenceAsLong((long) 4, (long) (-97));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 169 + "'", int15 == 169);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = limitChronology4.hourOfDay();
        org.joda.time.DurationField durationField9 = limitChronology4.seconds();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.Chronology chronology17 = limitChronology14.withZone(dateTimeZone16);
        long long21 = dateTimeZone16.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) limitChronology4, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-136800000L) + "'", long21 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology22);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField5.getAsShortText((-1861920000000L), locale24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Sun" + "'", str25.equals("Sun"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        org.joda.time.DateTime dateTime14 = property10.roundCeilingCopy();
        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortTime();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("10", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        try {
            long long10 = gJChronology0.getDateTimeMillis(19, 2, 100, (int) (short) -1, 19, 39, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.dayOfYear();
        org.joda.time.DurationField durationField3 = copticChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((int) '4', locale7);
        int int9 = delegatedDateTimeField5.getMaximumValue();
        long long12 = delegatedDateTimeField5.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology14.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, dateTimeField16, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText(0, locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField18.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType22);
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1987199800L) + "'", long12 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField17.getMaximumShortTextLength(locale18);
        long long22 = skipDateTimeField17.set(62167190822000L, 39);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField17.getAsShortText(10L, locale24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 62167190822000L + "'", long22 == 62167190822000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "69" + "'", str25.equals("69"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        dateTimeFormatterBuilder10.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        try {
            org.joda.time.LocalDateTime localDateTime7 = dateTimeFormatter5.parseLocalDateTime("Sun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Sun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = offsetDateTimeField7.getMinimumValue(readablePartial8);
        try {
            long long12 = offsetDateTimeField7.set(62167190822000L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 102 + "'", int9 == 102);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 'a');
        long long5 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 108000000 + "'", int3 == 108000000);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 108000032L + "'", long5 == 108000032L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+30:00" + "'", str7.equals("+30:00"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.String str3 = instant1.toString(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00" + "'", str3.equals("1970-01-01T00"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 1);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        boolean boolean12 = gJChronology0.equals((java.lang.Object) dateTime10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withMinuteOfHour(169);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 169 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"hi!\")/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.eras();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 10, (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipDateTimeField14.getAsText(30, locale16);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30" + "'", str17.equals("30"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.DateTime.Property property12 = dateTime5.millisOfSecond();
        int int13 = dateTime5.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = buddhistChronology0.weeks();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        long long12 = offsetDateTimeField7.addWrapField((-1L), (int) (byte) 1);
        long long14 = offsetDateTimeField7.roundFloor((long) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31535999999L + "'", long12 == 31535999999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-30520800000L) + "'", long14 == (-30520800000L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
        int int10 = offsetDateTimeField7.getMaximumValue();
        try {
            long long13 = offsetDateTimeField7.add(0L, 32688000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 32688000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1015200000L + "'", long9 == 1015200000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 200 + "'", int10 == 200);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        java.lang.String str6 = copticChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology9, readableDateTime11, readableDateTime12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = monthDay14.isSupported(dateTimeFieldType15);
        int[] intArray18 = new int[] { 3 };
        try {
            copticChronology0.validate((org.joda.time.ReadablePartial) monthDay14, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[+30:00]" + "'", str6.equals("CopticChronology[+30:00]"));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime22, readableDateTime23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        java.lang.String str29 = monthDay25.toString("0");
        int int30 = monthDay25.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = monthDay25.getField((int) (short) 1);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) (short) -1, locale34);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime39 = dateTime37.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime41 = dateTime39.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime43 = dateTime41.minusMonths((int) (byte) 1);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        try {
            boolean boolean45 = monthDay25.isBefore((org.joda.time.ReadablePartial) localDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean11 = instant10.isEqualNow();
        org.joda.time.Instant instant14 = instant10.withDurationAdded((long) (-28800000), (-28800000));
        boolean boolean15 = instant14.isEqualNow();
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Instant instant17 = instant14.plus(readableDuration16);
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) instant14, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 108000000 + "'", int8 == 108000000);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(instant17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        java.lang.String str7 = dateTime5.toString();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-0001-12-30T18:00:00.000Z" + "'", str7.equals("-0001-12-30T18:00:00.000Z"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        boolean boolean5 = delegatedDateTimeField4.isLenient();
        long long7 = delegatedDateTimeField4.roundFloor((long) (short) 0);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime12, readableDateTime13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology10);
        org.joda.time.MonthDay.Property property16 = monthDay15.monthOfYear();
        java.lang.String str17 = property16.getAsString();
        org.joda.time.MonthDay monthDay19 = property16.addWrapFieldToCopy((int) (byte) 0);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = copticChronology21.getZone();
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime23, readableDateTime24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = copticChronology26.getZone();
        org.joda.time.Chronology chronology28 = limitChronology25.withZone(dateTimeZone27);
        long long32 = dateTimeZone27.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = julianChronology35.getZone();
        org.joda.time.DateTimeField dateTimeField37 = julianChronology35.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField(chronology34, dateTimeField37, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField39, 100);
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField41.getMaximumTextLength(locale42);
        long long46 = offsetDateTimeField41.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = copticChronology49.getZone();
        org.joda.time.ReadableDateTime readableDateTime51 = null;
        org.joda.time.ReadableDateTime readableDateTime52 = null;
        org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology49, readableDateTime51, readableDateTime52);
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology49);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.MonthDay monthDay56 = monthDay54.minus(readablePeriod55);
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField41.getAsText((org.joda.time.ReadablePartial) monthDay56, (int) 'a', locale58);
        int[] intArray66 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology33.validate((org.joda.time.ReadablePartial) monthDay56, intArray66);
        try {
            int[] intArray69 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) monthDay19, 31, intArray66, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-21600000L) + "'", long7 == (-21600000L));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3" + "'", str17.equals("3"));
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(limitChronology25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-136800000L) + "'", long32 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 599616000052L + "'", long46 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(limitChronology53);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "97" + "'", str59.equals("97"));
        org.junit.Assert.assertNotNull(intArray66);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (-1));
        org.joda.time.DurationField durationField10 = offsetDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1015200000L + "'", long9 == 1015200000L);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long10 = gregorianChronology2.getDateTimeMillis(108000000, (int) (byte) 0, (int) '#', (-97), (int) (byte) 100, (-1), 40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText(readablePartial8, 0, locale10);
        java.lang.String str13 = delegatedDateTimeField4.getAsText(1L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "24" + "'", str13.equals("24"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology13, readableDateTime15, readableDateTime16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology13);
        org.joda.time.MonthDay.Property property19 = monthDay18.monthOfYear();
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        long long4 = copticChronology0.add((long) 1, (long) (short) -1, (-97));
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = copticChronology0.set(readablePartial5, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 98L + "'", long4 == 98L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime7.plusMillis((int) (short) -1);
        boolean boolean12 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime16 = dateTime14.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.plus((long) (-97));
        int int19 = dateTime16.getSecondOfMinute();
        try {
            org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 40 + "'", int19 == 40);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendTimeZoneOffset("0", "", true, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        long long11 = offsetDateTimeField7.roundHalfEven(829440000000010L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 829429437600000L + "'", long11 == 829429437600000L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField4.getWrappedField();
        boolean boolean10 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 108000000 + "'", int8 == 108000000);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendFractionOfMinute(6, 28253);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 100);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long6 = dateTimeZone2.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        java.lang.String str10 = cachedDateTimeZone7.getShortName(25L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800000L + "'", long6 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.days();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) '4', (-28800000), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for yearOfCentury must be in the range [-28800000,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.addWrapField((long) '4', (-1));
        long long12 = offsetDateTimeField7.roundFloor(10L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535999948L) + "'", long10 == (-31535999948L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-30520800000L) + "'", long12 == (-30520800000L));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        java.lang.String str10 = monthDay7.toString();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "--03-01" + "'", str10.equals("--03-01"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        int int4 = dateTime1.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withEra((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfEra(39);
        int int12 = dateTime5.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100000 + "'", int12 == 100000);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.dayOfYear();
        org.joda.time.DurationField durationField3 = copticChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = copticChronology1.days();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.secondOfDay();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) 33, (org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = limitChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = limitChronology4.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(0, 2);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10, 102, (int) 'a', 33, 53, 4, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(69, 100000, (int) (short) 1, (int) (short) 1, 0, (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(28378000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-28378000) + "'", int1 == (-28378000));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField17.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = copticChronology22.getZone();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        boolean boolean29 = monthDay27.isSupported(dateTimeFieldType28);
        java.lang.String str31 = monthDay27.toString("0");
        int int32 = monthDay27.getDayOfMonth();
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay27, 0, locale34);
        boolean boolean36 = monthDay7.isEqual((org.joda.time.ReadablePartial) monthDay27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay38 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology37);
        try {
            org.joda.time.MonthDay monthDay40 = monthDay38.plusMonths(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(monthDay38);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        int int11 = delegatedDateTimeField4.getDifference((long) 53, (long) 19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long8 = skipUndoDateTimeField5.set((long) 1, 4);
        java.util.Locale locale11 = null;
        try {
            long long12 = skipUndoDateTimeField5.set(829429437600000L, "+30:00", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+30:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser3);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, 100);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumTextLength(locale27);
        long long31 = offsetDateTimeField26.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType32);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType32, (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000052L + "'", long31 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(6, 0, (int) (short) 1, 102, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 102 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 102);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField7.getAsText((-62167190822000L), locale16);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "102" + "'", str17.equals("102"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withFieldAdded(durationFieldType6, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekOfWeekyear(1);
        int int10 = dateTime9.getMinuteOfHour();
        java.lang.Class<?> wildcardClass11 = dateTime9.getClass();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("0");
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        int int5 = dateTime3.getDayOfWeek();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62167327200000L) + "'", long4 == (-62167327200000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("UTC", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.Instant instant15 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean16 = instant15.isEqualNow();
        long long17 = instant15.getMillis();
        org.joda.time.Instant instant19 = instant15.minus((long) ' ');
        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) instant15);
        java.util.Locale locale22 = null;
        try {
            org.joda.time.DateTime dateTime23 = property10.setCopy("", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143653500L) + "'", long20 == (-62143653500L));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        boolean boolean6 = instant5.isEqualNow();
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.era();
        org.joda.time.Chronology chronology10 = copticChronology8.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12);
        long long15 = skipUndoDateTimeField13.roundHalfCeiling(0L);
        int int16 = instant5.get((org.joda.time.DateTimeField) skipUndoDateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        int int13 = offsetDateTimeField7.getMaximumValue();
        long long15 = offsetDateTimeField7.roundHalfEven((long) (short) -1);
        long long18 = offsetDateTimeField7.getDifferenceAsLong(98L, (long) 2);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1015200000L + "'", long15 == 1015200000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        java.lang.String str5 = dateTimeZone3.getName((-1L));
        long long7 = dateTimeZone3.convertUTCToLocal((long) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+30:00" + "'", str5.equals("+30:00"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 108000000L + "'", long7 == 108000000L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((-2424758400000L), locale3);
//        long long6 = dateTimeZone1.convertUTCToLocal((-1861948799968L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1861948799968L) + "'", long6 == (-1861948799968L));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime15.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.DateTime dateTime20 = dateTime5.withFields((org.joda.time.ReadablePartial) localDateTime19);
        int int21 = dateTime20.getMinuteOfHour();
        org.joda.time.DateTime dateTime23 = dateTime20.plus((long) 10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime22, readableDateTime23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        java.lang.String str29 = monthDay25.toString("0");
        int int30 = monthDay25.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = monthDay25.getField((int) (short) 1);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) (short) -1, locale34);
        boolean boolean37 = skipUndoDateTimeField10.isLeap(28800000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        boolean boolean15 = skipDateTimeField14.isLenient();
        long long18 = skipDateTimeField14.set((long) 100000, (int) '#');
        try {
            long long21 = skipDateTimeField14.add((long) 28378000, (-891583653400010L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -891583653400010");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1104537500000L) + "'", long18 == (-1104537500000L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.DateTime.Property property12 = dateTime5.millisOfSecond();
        java.lang.String str13 = property12.getAsText();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getShortName(0L, locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.getAsText();
        java.lang.String str11 = property9.getAsText();
        int int12 = property9.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        try {
            org.joda.time.MonthDay monthDay11 = monthDay7.minusMonths(200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((-28378000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        int int7 = dateTimeZone4.getOffsetFromLocal((long) 2);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfCentury((int) '4');
        int int16 = dateTime13.getMillisOfDay();
        try {
            org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 108000000 + "'", int7 == 108000000);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64800000 + "'", int16 == 64800000);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekOfWeekyear(1);
        int int10 = dateTime9.getMinuteOfHour();
        java.util.Date date11 = dateTime9.toDate();
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) 'a', (int) (short) 10);
        java.lang.String str12 = offsetDateTimeField7.getAsText((-34L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315532800097L + "'", long10 == 315532800097L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "169" + "'", str12.equals("169"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusMillis(0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.appendTimeZoneOffset("UTC", "102", false, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateMidnight4);
        int int6 = dateMidnight4.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.ReadableInstant readableInstant2 = null;
        boolean boolean3 = instant1.isEqual(readableInstant2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime14 = property10.addToCopy((long) (-28800000));
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.plus(readableDuration16);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime5.toCalendar(locale8);
        int int10 = dateTime5.getYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.era();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-136800000L) + "'", long11 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter0.parseDateTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        int int3 = dateTimeFormatter2.getDefaultYear();
        boolean boolean4 = gJChronology0.equals((java.lang.Object) int3);
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) int3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.String str3 = dateTimeFormatter1.print(62167190822000L);
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("+30:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+30:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3940-01-02T22:07:02" + "'", str3.equals("3940-01-02T22:07:02"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime5, readableDateTime6);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.Chronology chronology10 = limitChronology7.withZone(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = instant1.toMutableDateTime((org.joda.time.Chronology) limitChronology7);
        try {
            long long16 = limitChronology7.getDateTimeMillis(0, 31, (int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        java.lang.String str13 = offsetDateTimeField7.getAsShortText((long) (short) -1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "169" + "'", str13.equals("169"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        int int30 = dateTime6.get(dateTimeFieldType28);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, dateTimeField34, (int) '#');
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField36.getAsText(0, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField36.getType();
        org.joda.time.DateTime.Property property41 = dateTime6.property(dateTimeFieldType40);
        java.lang.String str42 = property41.getName();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "yearOfCentury" + "'", str42.equals("yearOfCentury"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime3 = dateTime0.withZoneRetainFields(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        int int13 = offsetDateTimeField7.getMaximumValue();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        int[] intArray19 = new int[] { (byte) -1, (-28378000), 2 };
        try {
            int[] intArray21 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay14, (int) (short) -1, intArray19, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology6 = julianChronology1.withZone(dateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.weekOfWeekyear();
        java.lang.String str9 = buddhistChronology7.toString();
        boolean boolean10 = julianChronology1.equals((java.lang.Object) str9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long16 = dateTimeZone12.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        org.joda.time.Chronology chronology18 = julianChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        java.lang.Appendable appendable20 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = copticChronology23.getZone();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime25, readableDateTime26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology23);
        org.joda.time.MonthDay.Property property29 = monthDay28.monthOfYear();
        org.joda.time.MonthDay.Property property30 = monthDay28.monthOfYear();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, dateTimeField34, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, 100);
        java.util.Locale locale39 = null;
        int int40 = offsetDateTimeField38.getMaximumTextLength(locale39);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        boolean boolean50 = monthDay48.isSupported(dateTimeFieldType49);
        java.lang.String str52 = monthDay48.toString("0");
        int int53 = monthDay48.getDayOfMonth();
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) monthDay48, 0, locale55);
        boolean boolean57 = monthDay28.isEqual((org.joda.time.ReadablePartial) monthDay48);
        try {
            dateTimeFormatter0.printTo(appendable20, (org.joda.time.ReadablePartial) monthDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BuddhistChronology[UTC]" + "'", str9.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(limitChronology47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendFractionOfDay(28253, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.Chronology chronology22 = limitChronology19.withZone(dateTimeZone21);
        long long26 = dateTimeZone21.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField35.getMaximumTextLength(locale36);
        long long40 = offsetDateTimeField35.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay48.minus(readablePeriod49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField35.getAsText((org.joda.time.ReadablePartial) monthDay50, (int) 'a', locale52);
        int[] intArray60 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology27.validate((org.joda.time.ReadablePartial) monthDay50, intArray60);
        int int62 = offsetDateTimeField7.getMinimumValue(readablePartial14, intArray60);
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField7.getAsText((long) 8, locale64);
        long long67 = offsetDateTimeField7.roundHalfEven((long) 'a');
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-136800000L) + "'", long26 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000052L + "'", long40 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(limitChronology47);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "97" + "'", str53.equals("97"));
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 102 + "'", int62 == 102);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "169" + "'", str65.equals("169"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1015200000L + "'", long67 == 1015200000L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology13, readableDateTime15, readableDateTime16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology13);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = copticChronology23.getZone();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime25, readableDateTime26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology23);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.minus(readablePeriod29);
        boolean boolean31 = monthDay20.isBefore((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.Chronology chronology32 = monthDay20.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = copticChronology33.getZone();
        org.joda.time.ReadableDateTime readableDateTime35 = null;
        org.joda.time.ReadableDateTime readableDateTime36 = null;
        org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology33, readableDateTime35, readableDateTime36);
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = copticChronology38.getZone();
        org.joda.time.Chronology chronology40 = limitChronology37.withZone(dateTimeZone39);
        long long44 = dateTimeZone39.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology47.getZone();
        org.joda.time.DateTimeField dateTimeField49 = julianChronology47.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField(chronology46, dateTimeField49, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, 100);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField53.getMaximumTextLength(locale54);
        long long58 = offsetDateTimeField53.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology61 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone62 = copticChronology61.getZone();
        org.joda.time.ReadableDateTime readableDateTime63 = null;
        org.joda.time.ReadableDateTime readableDateTime64 = null;
        org.joda.time.chrono.LimitChronology limitChronology65 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology61, readableDateTime63, readableDateTime64);
        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology61);
        org.joda.time.ReadablePeriod readablePeriod67 = null;
        org.joda.time.MonthDay monthDay68 = monthDay66.minus(readablePeriod67);
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) monthDay68, (int) 'a', locale70);
        int[] intArray78 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology45.validate((org.joda.time.ReadablePartial) monthDay68, intArray78);
        int int80 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay20, intArray78);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(limitChronology37);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-136800000L) + "'", long44 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 599616000052L + "'", long58 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(limitChronology65);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "97" + "'", str71.equals("97"));
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 200 + "'", int80 == 200);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        int int3 = dateTime1.getDayOfWeek();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
        long long16 = offsetDateTimeField11.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
        org.joda.time.DateTime.Property property20 = dateTime19.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        int int13 = offsetDateTimeField7.getMaximumValue();
        try {
            long long16 = offsetDateTimeField7.set(599616000052L, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-1987199800L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1987199800) + "'", int1 == (-1987199800));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.era();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.monthOfYear();
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        int int3 = dateTime1.getDayOfWeek();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, 100);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumTextLength(locale12);
        long long16 = offsetDateTimeField11.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
        org.joda.time.DateTime dateTime19 = dateTime1.withField(dateTimeFieldType17, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime1.withZone(dateTimeZone21);
        int int24 = dateTime1.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167327200000L) + "'", long2 == (-62167327200000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000052L + "'", long16 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean3 = instant2.isEqualNow();
        org.joda.time.Instant instant6 = instant2.withDurationAdded((long) (-28800000), (-28800000));
        int int7 = instant0.compareTo((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Instant instant8 = instant6.toInstant();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant11 = instant8.withDurationAdded(readableDuration9, (int) (short) 0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        java.lang.String str3 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int int11 = property9.compareTo(readablePartial10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        org.joda.time.DateTime dateTime14 = property10.roundCeilingCopy();
        int int15 = dateTime14.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, 100);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumTextLength(locale16);
        long long20 = offsetDateTimeField15.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField15.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType21);
        int int24 = skipUndoDateTimeField5.getLeapAmount((-1L));
        boolean boolean25 = skipUndoDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 599616000052L + "'", long20 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, 100);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField15.getMaximumTextLength(locale16);
        long long20 = offsetDateTimeField15.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField15.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType21);
        java.lang.String str24 = delegatedDateTimeField22.getAsShortText((-1814399800L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 599616000052L + "'", long20 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "69" + "'", str24.equals("69"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        try {
            org.joda.time.DateTimeField dateTimeField11 = monthDay9.getField(28253);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 28253");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.Chronology chronology7 = limitChronology4.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology(chronology7);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        java.lang.String str11 = property8.getAsString();
        org.joda.time.MonthDay monthDay13 = property8.addWrapFieldToCopy(13);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(169, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        long long7 = dateTime6.getMillis();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withCenturyOfEra((-1987199800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1987199800 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 829440000000010L + "'", long7 == 829440000000010L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        try {
            org.joda.time.MonthDay monthDay13 = property9.addToCopy((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        int int6 = skipUndoDateTimeField5.getMinimumValue();
        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
        org.joda.time.DurationField durationField11 = copticChronology9.years();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
        int int17 = delegatedDateTimeField13.getMaximumValue();
        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
        long long46 = zeroIsMaxDateTimeField32.getDifferenceAsLong((-1817717760000422000L), (-891583653400010L));
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology47.era();
        org.joda.time.Chronology chronology49 = copticChronology47.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology49, dateTimeField51);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone56 = copticChronology55.getZone();
        org.joda.time.ReadableDateTime readableDateTime57 = null;
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.chrono.LimitChronology limitChronology59 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology55, readableDateTime57, readableDateTime58);
        org.joda.time.MonthDay monthDay60 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology55);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = null;
        boolean boolean62 = monthDay60.isSupported(dateTimeFieldType61);
        java.lang.String str64 = monthDay60.toString("0");
        int int65 = monthDay60.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField67 = monthDay60.getField((int) (short) 1);
        int[] intArray68 = new int[] {};
        int int69 = skipUndoDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) monthDay60, intArray68);
        org.joda.time.chrono.CopticChronology copticChronology72 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone73 = copticChronology72.getZone();
        org.joda.time.ReadableDateTime readableDateTime74 = null;
        org.joda.time.ReadableDateTime readableDateTime75 = null;
        org.joda.time.chrono.LimitChronology limitChronology76 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology72, readableDateTime74, readableDateTime75);
        org.joda.time.MonthDay monthDay77 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology72);
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = null;
        boolean boolean79 = monthDay77.isSupported(dateTimeFieldType78);
        java.lang.String str81 = monthDay77.toString("0");
        boolean boolean82 = monthDay60.isEqual((org.joda.time.ReadablePartial) monthDay77);
        int int83 = zeroIsMaxDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay60);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-21028080744L) + "'", long46 == (-21028080744L));
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(limitChronology59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(copticChronology72);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(limitChronology76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "0" + "'", str81.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime14 = dateTime12.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime14.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime20 = dateTime16.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology23.getZone();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology23.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology22, dateTimeField25, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField27, 100);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField29.getMaximumTextLength(locale30);
        long long34 = offsetDateTimeField29.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField29.getType();
        int int36 = dateTime20.get(dateTimeFieldType35);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime40 = dateTime38.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime41 = dateTime40.toDateTime();
        org.joda.time.DateTime dateTime43 = dateTime40.withMillis(829440000000010L);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = julianChronology45.getZone();
        org.joda.time.DateTimeField dateTimeField47 = julianChronology45.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField(chronology44, dateTimeField47, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, 100);
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone54 = julianChronology53.getZone();
        org.joda.time.DateTimeField dateTimeField55 = julianChronology53.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField(chronology52, dateTimeField55, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField57, 100);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField59.getMaximumTextLength(locale60);
        long long64 = offsetDateTimeField59.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = offsetDateTimeField59.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType65);
        int int67 = dateTime43.get(dateTimeFieldType65);
        int int68 = dateTime20.get(dateTimeFieldType65);
        boolean boolean69 = dateTime9.isSupported(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 599616000052L + "'", long34 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 3 + "'", int61 == 3);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 599616000052L + "'", long64 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        int int72 = dividedDateTimeField69.getDifference((-1817717760000422000L), 25L);
        long long74 = dividedDateTimeField69.roundFloor((long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1920000) + "'", int72 == (-1920000));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-314604000000L) + "'", long74 == (-314604000000L));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = copticChronology0.days();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField8, (int) ' ');
        int int12 = skipDateTimeField10.get((long) 28253);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2513 + "'", int12 == 2513);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        int int30 = dateTime6.get(dateTimeFieldType28);
        try {
            org.joda.time.DateTime dateTime32 = dateTime6.withWeekOfWeekyear((-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime14 = property10.addToCopy((long) (-28800000));
        long long15 = property10.remainder();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property10.getFieldType();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.DurationField durationField23 = skipUndoDateTimeField5.getDurationField();
        try {
            long long26 = skipUndoDateTimeField5.set(315532800097L, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for dayOfWeek must be in the range [0,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = monthDay17.getDayOfMonth();
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay17, 0, locale24);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField7.getMaximumShortTextLength(locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-28799968L), "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology9, readableDateTime11, readableDateTime12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = monthDay14.isSupported(dateTimeFieldType15);
        java.lang.String str18 = monthDay14.toString("0");
        int int19 = monthDay14.getDayOfMonth();
        org.joda.time.DateTime dateTime20 = dateTime3.withFields((org.joda.time.ReadablePartial) monthDay14);
        try {
            org.joda.time.DateTime dateTime25 = dateTime20.withTime(102, (int) (byte) 1, 108000000, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 102 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = julianChronology0.years();
        try {
            long long13 = julianChronology0.getDateTimeMillis(108000000, (-1920000), 0, 6, (int) ' ', 0, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1920000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.Chronology chronology22 = limitChronology19.withZone(dateTimeZone21);
        long long26 = dateTimeZone21.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField35.getMaximumTextLength(locale36);
        long long40 = offsetDateTimeField35.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay48.minus(readablePeriod49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField35.getAsText((org.joda.time.ReadablePartial) monthDay50, (int) 'a', locale52);
        int[] intArray60 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology27.validate((org.joda.time.ReadablePartial) monthDay50, intArray60);
        int int62 = offsetDateTimeField7.getMinimumValue(readablePartial14, intArray60);
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField7.getAsText((long) 8, locale64);
        long long67 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-136800000L) + "'", long26 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000052L + "'", long40 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(limitChronology47);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "97" + "'", str53.equals("97"));
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 102 + "'", int62 == 102);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "169" + "'", str65.equals("169"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1015200000L + "'", long67 == 1015200000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, (int) (byte) 100);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime5, readableDateTime6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = monthDay8.isSupported(dateTimeFieldType9);
        java.lang.String str12 = monthDay8.toString("0");
        int int13 = monthDay8.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = monthDay8.getField((int) (short) 1);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime19 = dateTime17.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime25 = dateTime21.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property26 = dateTime21.secondOfDay();
        java.util.Locale locale27 = null;
        int int28 = property26.getMaximumTextLength(locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        int int30 = monthDay8.indexOf(dateTimeFieldType29);
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology6 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField7 = copticChronology1.eras();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfDay();
        try {
            long long13 = julianChronology0.getDateTimeMillis((int) (short) -1, (int) 'a', (-28800000), (int) (byte) 0, (-1987199800), 33, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1987199800 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = julianChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekOfWeekyear();
        java.lang.String str11 = buddhistChronology9.toString();
        boolean boolean12 = julianChronology3.equals((java.lang.Object) str11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long18 = dateTimeZone14.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.Chronology chronology20 = julianChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(30);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone22);
        long long25 = cachedDateTimeZone19.getMillisKeepLocal(dateTimeZone22, 0L);
        org.joda.time.Chronology chronology26 = gJChronology0.withZone(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology0.millisOfSecond();
        java.lang.String str28 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BuddhistChronology[UTC]" + "'", str11.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-108000000L) + "'", long25 == (-108000000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GJChronology[+30:00]" + "'", str28.equals("GJChronology[+30:00]"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("12/31/69");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12/31/69\" is malformed at \"/31/69\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int72 = dividedDateTimeField69.get((-31535999948L));
        try {
            long long75 = dividedDateTimeField69.add(1152000000L, 28800000L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 864001970 for year must be in the range [-292269054,292272992]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withFieldAdded(durationFieldType8, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int72 = dividedDateTimeField69.get((-31535999948L));
        long long74 = dividedDateTimeField69.roundCeiling((long) 28253);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 632167200000L + "'", long74 == 632167200000L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        boolean boolean14 = offsetDateTimeField7.isLeap(31535999999L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 'a');
        long long5 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str7 = iSOChronology6.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 108000000 + "'", int3 == 108000000);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 108000032L + "'", long5 == 108000032L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[+30:00]" + "'", str7.equals("ISOChronology[+30:00]"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendCenturyOfEra(0, 40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendHourOfHalfday(108000000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear(1);
        int int13 = dateTime12.getMinuteOfHour();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundFloorCopy();
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        long long14 = property10.remainder();
        java.lang.String str15 = property10.getAsString();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property10.getAsShortText(locale16);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-101L) + "'", long2 == (-101L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        int int6 = skipUndoDateTimeField5.getMinimumValue();
        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
        org.joda.time.DurationField durationField11 = copticChronology9.years();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
        int int17 = delegatedDateTimeField13.getMaximumValue();
        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
        long long46 = zeroIsMaxDateTimeField32.getDifferenceAsLong((-1817717760000422000L), (-891583653400010L));
        int int48 = zeroIsMaxDateTimeField32.getMinimumValue((-1861920000000L));
        long long50 = zeroIsMaxDateTimeField32.roundCeiling((-1104537500000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-21028080744L) + "'", long46 == (-21028080744L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1104451200000L) + "'", long50 == (-1104451200000L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
        int int15 = offsetDateTimeField7.getMaximumValue();
        int int17 = offsetDateTimeField7.getMaximumValue((long) 1);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsShortText((long) (short) -1, locale19);
        long long22 = offsetDateTimeField7.roundCeiling((long) 4);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 200 + "'", int15 == 200);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 200 + "'", int17 == 200);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "169" + "'", str20.equals("169"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1015200000L + "'", long22 == 1015200000L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = copticChronology38.getZone();
        org.joda.time.ReadableDateTime readableDateTime40 = null;
        org.joda.time.ReadableDateTime readableDateTime41 = null;
        org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology38, readableDateTime40, readableDateTime41);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        java.lang.String str47 = monthDay43.toString("0");
        int int48 = monthDay43.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField50 = monthDay43.getField((int) (short) 1);
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime54 = dateTime52.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime56 = dateTime54.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime58 = dateTime56.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime60 = dateTime56.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property61 = dateTime56.secondOfDay();
        java.util.Locale locale62 = null;
        int int63 = property61.getMaximumTextLength(locale62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property61.getFieldType();
        int int65 = monthDay43.indexOf(dateTimeFieldType64);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        int int68 = dividedDateTimeField66.get((-21028080744L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(limitChronology42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5 + "'", int63 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatterBuilder6.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        org.joda.time.Chronology chronology20 = limitChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.Chronology chronology9 = limitChronology6.withZone(dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = copticChronology30.getZone();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology30, readableDateTime32, readableDateTime33);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology30);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay37 = monthDay35.minus(readablePeriod36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField22.getAsText((org.joda.time.ReadablePartial) monthDay37, (int) 'a', locale39);
        int[] intArray47 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology14.validate((org.joda.time.ReadablePartial) monthDay37, intArray47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay37.plus(readablePeriod49);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-136800000L) + "'", long13 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "97" + "'", str40.equals("97"));
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(monthDay50);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField17.getMaximumShortTextLength(locale18);
        long long22 = skipDateTimeField17.set(62167190822000L, 39);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipDateTimeField17.getAsText((-1814399800L), locale24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 62167190822000L + "'", long22 == 62167190822000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "69" + "'", str25.equals("69"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology15);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.minus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay22, (int) 'a', locale24);
        long long27 = offsetDateTimeField7.roundCeiling(0L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "97" + "'", str25.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1015200000L + "'", long27 == 1015200000L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, 0, 0, 0, (int) (short) 100, 200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, 829429437600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(108000000, 200, 6, 9, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField17.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = copticChronology22.getZone();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology22, readableDateTime24, readableDateTime25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        boolean boolean29 = monthDay27.isSupported(dateTimeFieldType28);
        java.lang.String str31 = monthDay27.toString("0");
        int int32 = monthDay27.getDayOfMonth();
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay27, 0, locale34);
        boolean boolean36 = monthDay7.isEqual((org.joda.time.ReadablePartial) monthDay27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay38 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology37);
        try {
            org.joda.time.LocalDate localDate40 = monthDay7.toLocalDate((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(monthDay38);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gJChronology0.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.MonthDay monthDay11 = property8.addWrapFieldToCopy((int) (byte) 0);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.Chronology chronology14 = julianChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology12.yearOfEra();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology12.halfdayOfDay();
        org.joda.time.MonthDay monthDay17 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) julianChronology12);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3" + "'", str9.equals("3"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay17);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 100);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.yearOfCentury();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime14 = dateTime11.withMillis(829440000000010L);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField26, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, 100);
        java.util.Locale locale31 = null;
        int int32 = offsetDateTimeField30.getMaximumTextLength(locale31);
        long long35 = offsetDateTimeField30.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, dateTimeFieldType36);
        int int38 = dateTime14.get(dateTimeFieldType36);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField40 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType36, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder41.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = julianChronology49.getZone();
        org.joda.time.DateTimeField dateTimeField51 = julianChronology49.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField(chronology48, dateTimeField51, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField53, 100);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = julianChronology57.getZone();
        org.joda.time.DateTimeField dateTimeField59 = julianChronology57.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField(chronology56, dateTimeField59, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField61, 100);
        java.util.Locale locale64 = null;
        int int65 = offsetDateTimeField63.getMaximumTextLength(locale64);
        long long68 = offsetDateTimeField63.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = offsetDateTimeField63.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField53, dateTimeFieldType69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder47.appendFraction(dateTimeFieldType69, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField40, dateTimeFieldType69);
        org.joda.time.MonthDay monthDay75 = org.joda.time.MonthDay.now();
        java.lang.String str76 = monthDay75.toString();
        int[] intArray84 = new int[] { 19, 102, 53, (-97), 30, 169 };
        int[] intArray86 = remainderDateTimeField40.add((org.joda.time.ReadablePartial) monthDay75, 2, intArray84, 0);
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadablePartial) monthDay75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 599616000052L + "'", long35 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 599616000052L + "'", long68 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "--01-02" + "'", str76.equals("--01-02"));
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray86);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType24 = monthDay13.getFieldType(999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        long long8 = skipUndoDateTimeField5.set((long) 1, 4);
        int int10 = skipUndoDateTimeField5.getLeapAmount((-62143517122001L));
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = skipUndoDateTimeField5.getAsText((-1), locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        long long71 = remainderDateTimeField35.roundHalfFloor((long) 3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1015200000L + "'", long71 == 1015200000L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Pacific Standard Time", 5, (int) (byte) -1, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for Pacific Standard Time must be in the range [-1,-28800000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, 100);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField18, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, 100);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField22.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType28, (int) (byte) 0, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMillisOfSecond((int) (short) 100);
        boolean boolean35 = dateTimeFormatterBuilder32.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000052L + "'", long27 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        try {
            long long6 = copticChronology0.getDateTimeMillis(0, (int) (byte) 10, 40, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        int int7 = dateTime3.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        boolean boolean9 = offsetDateTimeField7.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField7.getWrappedField();
        long long13 = offsetDateTimeField7.add((long) (short) 10, (long) 100);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.Chronology chronology22 = limitChronology19.withZone(dateTimeZone21);
        long long26 = dateTimeZone21.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField35.getMaximumTextLength(locale36);
        long long40 = offsetDateTimeField35.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = copticChronology43.getZone();
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime45, readableDateTime46);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology43);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay48.minus(readablePeriod49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField35.getAsText((org.joda.time.ReadablePartial) monthDay50, (int) 'a', locale52);
        int[] intArray60 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology27.validate((org.joda.time.ReadablePartial) monthDay50, intArray60);
        int int62 = offsetDateTimeField7.getMinimumValue(readablePartial14, intArray60);
        long long64 = offsetDateTimeField7.remainder((long) 69);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-136800000L) + "'", long26 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000052L + "'", long40 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(limitChronology47);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "97" + "'", str53.equals("97"));
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 102 + "'", int62 == 102);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 30520800069L + "'", long64 == 30520800069L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
        java.lang.String str8 = buddhistChronology6.toString();
        boolean boolean9 = julianChronology0.equals((java.lang.Object) str8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long15 = dateTimeZone11.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.Chronology chronology17 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[UTC]" + "'", str8.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime26 = dateTime24.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withPivotYear((java.lang.Integer) 10);
        java.lang.String str30 = dateTime24.toString(dateTimeFormatter29);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
        org.joda.time.DateTime dateTime37 = dateTime34.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        org.joda.time.DateTime dateTime39 = dateTime24.withFields((org.joda.time.ReadablePartial) localDateTime38);
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.String str43 = dateTime41.toString(dateTimeFormatter42);
        long long44 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime45 = property17.getDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0000-10-01T00:01:40.000" + "'", str30.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28253-11-29T06:00:00" + "'", str43.equals("28253-11-29T06:00:00"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-891583653400010L) + "'", long44 == (-891583653400010L));
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.era();
        org.joda.time.Chronology chronology8 = copticChronology6.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10);
        long long13 = skipUndoDateTimeField11.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology16.getZone();
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology16, readableDateTime18, readableDateTime19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology16);
        int int22 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        int[] intArray24 = julianChronology0.get((org.joda.time.ReadablePartial) monthDay21, (-31535999948L));
        try {
            long long29 = julianChronology0.getDateTimeMillis(0, 100, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        long long11 = delegatedDateTimeField4.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField17.getAsText(0, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField17.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType21);
        java.lang.String str24 = delegatedDateTimeField4.getAsText(3155760000010L);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
        int int28 = dateTimeZone26.getOffsetFromLocal((long) 'a');
        long long30 = dateTimeZone26.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(dateTimeZone26);
        int[] intArray33 = null;
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) monthDay31, 28378000, intArray33, "102", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 102 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1987199800L) + "'", long11 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "24" + "'", str24.equals("24"));
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 108000000 + "'", int28 == 108000000);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 108000032L + "'", long30 == 108000032L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) 19);
        long long9 = delegatedDateTimeField4.add(0L, (int) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8640000000L + "'", long9 == 8640000000L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(829429437600000L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 829429437599995L + "'", long2 == 829429437599995L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((java.lang.Integer) 10);
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.append(dateTimePrinter19);
        boolean boolean21 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0000-10-01T00:01:40.000" + "'", str18.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology15);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.minus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay22, (int) 'a', locale24);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = copticChronology28.getZone();
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology28, readableDateTime30, readableDateTime31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology28);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        boolean boolean35 = monthDay33.isSupported(dateTimeFieldType34);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology36.dayOfYear();
        org.joda.time.DurationField durationField38 = copticChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = copticChronology36.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        long long42 = delegatedDateTimeField40.roundHalfEven((long) 0);
        java.lang.String str43 = delegatedDateTimeField40.getName();
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        int int45 = delegatedDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) monthDay44);
        boolean boolean46 = monthDay33.isBefore((org.joda.time.ReadablePartial) monthDay44);
        int int47 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay33);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "97" + "'", str25.equals("97"));
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21600000L) + "'", long42 == (-21600000L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "dayOfMonth" + "'", str43.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 30 + "'", int45 == 30);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 102 + "'", int47 == 102);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "52", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "52", "52");
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) str8, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.Chronology chronology13 = gregorianChronology11.withUTC();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
        java.lang.String str7 = delegatedDateTimeField4.getName();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
        int int9 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.yearOfCentury();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime16 = dateTime14.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
        org.joda.time.DateTime dateTime19 = dateTime16.withMillis(829440000000010L);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology21.getZone();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology21.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField23, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, 100);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField35.getMaximumTextLength(locale36);
        long long40 = offsetDateTimeField35.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField35.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, dateTimeFieldType41);
        int int43 = dateTime19.get(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, dateTimeFieldType41, 30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType41, (int) ' ', (int) (byte) 10, 0);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        int int51 = gJChronology50.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.hourOfDay();
        try {
            org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((java.lang.Object) (byte) 10, (org.joda.time.Chronology) gJChronology50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-21600000L) + "'", long6 == (-21600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000052L + "'", long40 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeField52);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 200, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        try {
            boolean boolean10 = delegatedDateTimeField4.isLeap((-829439999999910L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        try {
            org.joda.time.DateTimeField dateTimeField24 = monthDay13.getField(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 100");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((int) '4', locale6);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        long long11 = delegatedDateTimeField4.set((long) 200, (int) (short) 1);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        try {
            long long15 = delegatedDateTimeField4.add((long) 1, (-136800000L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1987199800L) + "'", long11 == (-1987199800L));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.Instant instant5 = instant1.withDurationAdded((long) (-28800000), (-28800000));
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.parse("0");
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime9.getDayOfWeek();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField19.getMaximumTextLength(locale20);
        long long24 = offsetDateTimeField19.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField19.getType();
        org.joda.time.DateTime dateTime27 = dateTime9.withField(dateTimeFieldType25, (int) 'a');
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime31 = dateTime29.plusSeconds((int) (byte) 100);
        int int32 = dateTime29.getYearOfEra();
        boolean boolean33 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime35 = dateTime9.plusMillis(31);
        org.joda.time.DateTime dateTime37 = dateTime35.minusHours(28378000);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone40 = julianChronology39.getZone();
        org.joda.time.DateTimeField dateTimeField41 = julianChronology39.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField(chronology38, dateTimeField41, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int int47 = offsetDateTimeField45.getMinimumValue(readablePartial46);
        int int48 = dateTime37.get((org.joda.time.DateTimeField) offsetDateTimeField45);
        int int49 = instant7.get((org.joda.time.DateTimeField) offsetDateTimeField45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167327200000L) + "'", long10 == (-62167327200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 599616000052L + "'", long24 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 102 + "'", int47 == 102);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 139 + "'", int48 == 139);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 153 + "'", int49 == 153);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long13 = dateTimeZone9.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        boolean boolean7 = skipUndoDateTimeField5.isLeap(1152000000L);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField5.getAsText(readablePartial8, 169, locale10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.era();
        org.joda.time.Chronology chronology14 = copticChronology12.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime22, readableDateTime23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        java.lang.String str29 = monthDay25.toString("0");
        int int30 = monthDay25.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = monthDay25.getField((int) (short) 1);
        int[] intArray33 = new int[] {};
        int int34 = skipUndoDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray33);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology36.getZone();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology36.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField(chronology35, dateTimeField38, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField40, 100);
        boolean boolean44 = offsetDateTimeField42.isLeap(0L);
        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField42.getWrappedField();
        long long48 = offsetDateTimeField42.add((long) (short) 10, (long) 100);
        org.joda.time.ReadablePartial readablePartial49 = null;
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone51 = copticChronology50.getZone();
        org.joda.time.ReadableDateTime readableDateTime52 = null;
        org.joda.time.ReadableDateTime readableDateTime53 = null;
        org.joda.time.chrono.LimitChronology limitChronology54 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology50, readableDateTime52, readableDateTime53);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone56 = copticChronology55.getZone();
        org.joda.time.Chronology chronology57 = limitChronology54.withZone(dateTimeZone56);
        long long61 = dateTimeZone56.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.chrono.JulianChronology julianChronology64 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone65 = julianChronology64.getZone();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology64.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField(chronology63, dateTimeField66, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField68, 100);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumTextLength(locale71);
        long long75 = offsetDateTimeField70.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology78 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone79 = copticChronology78.getZone();
        org.joda.time.ReadableDateTime readableDateTime80 = null;
        org.joda.time.ReadableDateTime readableDateTime81 = null;
        org.joda.time.chrono.LimitChronology limitChronology82 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology78, readableDateTime80, readableDateTime81);
        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology78);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.MonthDay monthDay85 = monthDay83.minus(readablePeriod84);
        java.util.Locale locale87 = null;
        java.lang.String str88 = offsetDateTimeField70.getAsText((org.joda.time.ReadablePartial) monthDay85, (int) 'a', locale87);
        int[] intArray95 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology62.validate((org.joda.time.ReadablePartial) monthDay85, intArray95);
        int int97 = offsetDateTimeField42.getMinimumValue(readablePartial49, intArray95);
        int int98 = skipUndoDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay25, intArray95);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "169" + "'", str11.equals("169"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3155760000010L + "'", long48 == 3155760000010L);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(limitChronology54);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-136800000L) + "'", long61 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(julianChronology64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 3 + "'", int72 == 3);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 599616000052L + "'", long75 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology78);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(limitChronology82);
        org.junit.Assert.assertNotNull(monthDay85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "97" + "'", str88.equals("97"));
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 102 + "'", int97 == 102);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 100 + "'", int98 == 100);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        boolean boolean9 = dateTime6.isEqual((long) 999);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology52.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology51, dateTimeField54, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, 100);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField58.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField58.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField58.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, dateTimeFieldType64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder42.appendFraction(dateTimeFieldType64, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int71 = remainderDateTimeField70.getDivisor();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 599616000052L + "'", long63 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 30 + "'", int71 == 30);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = property17.getMinimumValueOverall();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime26 = dateTime24.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withPivotYear((java.lang.Integer) 10);
        java.lang.String str30 = dateTime24.toString(dateTimeFormatter29);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
        org.joda.time.DateTime dateTime37 = dateTime34.withMillis(829440000000010L);
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        org.joda.time.DateTime dateTime39 = dateTime24.withFields((org.joda.time.ReadablePartial) localDateTime38);
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.String str43 = dateTime41.toString(dateTimeFormatter42);
        long long44 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.parse("0");
        long long47 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime46);
        int int48 = dateTime46.getDayOfWeek();
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone51 = julianChronology50.getZone();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology50.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField(chronology49, dateTimeField52, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField54, 100);
        java.util.Locale locale57 = null;
        int int58 = offsetDateTimeField56.getMaximumTextLength(locale57);
        long long61 = offsetDateTimeField56.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField56.getType();
        org.joda.time.DateTime dateTime64 = dateTime46.withField(dateTimeFieldType62, (int) 'a');
        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime68 = dateTime66.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime70 = dateTime68.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime72 = dateTime70.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime74 = dateTime70.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property75 = dateTime70.secondOfDay();
        java.util.Locale locale76 = null;
        int int77 = property75.getMaximumTextLength(locale76);
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property75.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType78, (int) (byte) 100, 1, 28253);
        int int83 = dateTime46.get(dateTimeFieldType78);
        int int84 = property17.compareTo((org.joda.time.ReadableInstant) dateTime46);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0000-10-01T00:01:40.000" + "'", str30.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "28253-11-29T06:00:00" + "'", str43.equals("28253-11-29T06:00:00"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-891583653400010L) + "'", long44 == (-891583653400010L));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62167327200000L) + "'", long47 == (-62167327200000L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 599616000052L + "'", long61 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 5 + "'", int77 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval13);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = julianChronology0.years();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter30.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder29.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder18.append(dateTimePrinter28, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.appendFractionOfSecond(28253, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long7 = dateTimeZone3.convertLocalToUTC(28800000L, true, 0L);
        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (byte) 1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 139);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 139");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 108000032L + "'", long9 == 108000032L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        java.lang.String str11 = dateTime5.toString(dateTimeFormatter10);
        int int12 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime5.withDayOfWeek(4);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0000-10-01T00:01:40.000" + "'", str11.equals("0000-10-01T00:01:40.000"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39 + "'", int12 == 39);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType31, (int) (byte) 0, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendMillisOfSecond((int) (short) 100);
        boolean boolean38 = julianChronology0.equals((java.lang.Object) dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(dateTimeZone8);
        long long11 = dateTimeZone8.convertUTCToLocal((long) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 108000000L + "'", long11 == 108000000L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYear(10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) ' ');
        int int14 = dateTime11.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundFloorCopy();
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth(6);
        boolean boolean17 = dateTime13.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-28800000), (-62167190822000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62167219622000L) + "'", long2 == (-62167219622000L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 0);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology9, readableDateTime11, readableDateTime12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology9);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        boolean boolean16 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay18 = monthDay14.minus(readablePeriod17);
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay14, locale19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-21600000L) + "'", long6 == (-21600000L));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = monthDay7.isSupported(dateTimeFieldType8);
        java.lang.String str11 = monthDay7.toString("0");
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay7.withPeriodAdded(readablePeriod12, 0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime17, readableDateTime18);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology15);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.minus(readablePeriod21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay22, (int) 'a', locale24);
        int int27 = offsetDateTimeField7.getMinimumValue(0L);
        org.joda.time.DurationField durationField28 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone32 = copticChronology31.getZone();
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.ReadableDateTime readableDateTime34 = null;
        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology31, readableDateTime33, readableDateTime34);
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology31);
        org.joda.time.MonthDay.Property property37 = monthDay36.monthOfYear();
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay36);
        int int39 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) monthDay36);
        long long42 = offsetDateTimeField7.add((long) 40, 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "97" + "'", str25.equals("97"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 102 + "'", int27 == 102);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(limitChronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 102 + "'", int39 == 102);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 40L + "'", long42 == 40L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime1.minusSeconds((int) (byte) 0);
        try {
            java.lang.String str10 = dateTime1.toString("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime14 = property10.addToCopy((long) (-28800000));
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        try {
            java.lang.String str17 = dateTime14.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillis(829440000000010L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField13, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, 100);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField25.getMaximumTextLength(locale26);
        long long30 = offsetDateTimeField25.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType31);
        int int33 = dateTime9.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType31, 30);
        int int36 = remainderDateTimeField35.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000052L + "'", long30 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 29 + "'", int36 == 29);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.lang.String str9 = skipUndoDateTimeField5.getAsText((long) '4');
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology10);
        int int12 = monthDay11.getDayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.Chronology chronology18 = julianChronology13.withZone(dateTimeZone16);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.era();
        org.joda.time.Chronology chronology21 = copticChronology19.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField23);
        long long26 = skipUndoDateTimeField24.roundHalfCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = copticChronology29.getZone();
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime31, readableDateTime32);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology29);
        int int35 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay34);
        int[] intArray37 = julianChronology13.get((org.joda.time.ReadablePartial) monthDay34, (-31535999948L));
        int int38 = skipUndoDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay11, intArray37);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(limitChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime14, readableDateTime15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        boolean boolean19 = monthDay17.isSupported(dateTimeFieldType18);
        java.lang.String str21 = monthDay17.toString("0");
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay monthDay23 = property9.getMonthDay();
        try {
            org.joda.time.MonthDay monthDay25 = monthDay23.plusDays(100000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(monthDay23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology25, readableDateTime27, readableDateTime28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = monthDay30.isSupported(dateTimeFieldType31);
        java.lang.String str34 = monthDay30.toString("0");
        boolean boolean35 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = copticChronology36.dayOfYear();
        org.joda.time.DateTimeField dateTimeField38 = copticChronology36.millisOfSecond();
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone40 = copticChronology39.getZone();
        org.joda.time.Chronology chronology41 = copticChronology36.withZone(dateTimeZone40);
        org.joda.time.MonthDay monthDay42 = monthDay30.withChronologyRetainFields((org.joda.time.Chronology) copticChronology36);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField48, 100);
        java.util.Locale locale51 = null;
        int int52 = offsetDateTimeField50.getMaximumTextLength(locale51);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone56 = copticChronology55.getZone();
        org.joda.time.ReadableDateTime readableDateTime57 = null;
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.chrono.LimitChronology limitChronology59 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology55, readableDateTime57, readableDateTime58);
        org.joda.time.MonthDay monthDay60 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology55);
        org.joda.time.MonthDay.Property property61 = monthDay60.monthOfYear();
        org.joda.time.MonthDay.Property property62 = monthDay60.monthOfYear();
        int int63 = offsetDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) monthDay60);
        boolean boolean64 = monthDay42.isBefore((org.joda.time.ReadablePartial) monthDay60);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(limitChronology59);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 102 + "'", int63 == 102);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-62167327200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        java.lang.String str12 = property9.getAsString();
        org.joda.time.DurationField durationField13 = property9.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime4, readableDateTime5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
        org.joda.time.MonthDay.Property property9 = monthDay7.monthOfYear();
        java.lang.String str10 = property9.toString();
        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
        org.joda.time.DurationField durationField12 = property9.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        int int14 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[monthOfYear]" + "'", str10.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.dayOfYear();
        org.joda.time.DurationField durationField3 = copticChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = copticChronology1.centuries();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.MonthDay.Property property14 = monthDay13.monthOfYear();
        org.joda.time.MonthDay.Property property15 = monthDay13.monthOfYear();
        java.lang.String str16 = property15.toString();
        org.joda.time.DurationField durationField17 = property15.getRangeDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField5, durationField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Property[monthOfYear]" + "'", str16.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField7.getType();
        int int15 = offsetDateTimeField7.get(0L);
        int int17 = offsetDateTimeField7.getLeapAmount(98L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000052L + "'", long12 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 169 + "'", int15 == 169);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100000, 2513, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        int int6 = skipUndoDateTimeField5.getMinimumValue();
        long long8 = skipUndoDateTimeField5.roundHalfFloor(0L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
        org.joda.time.DurationField durationField11 = copticChronology9.years();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology9.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField13.getAsText((int) '4', locale15);
        int int17 = delegatedDateTimeField13.getMaximumValue();
        long long20 = delegatedDateTimeField13.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField24, (int) '#');
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField26.getAsText(0, locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType30);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, dateTimeFieldType30);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
        org.joda.time.MonthDay.Property property41 = monthDay40.monthOfYear();
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay40);
        int int43 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
        long long46 = zeroIsMaxDateTimeField32.getDifferenceAsLong((-1817717760000422000L), (-891583653400010L));
        long long48 = zeroIsMaxDateTimeField32.roundCeiling((-62143517122001L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1987199800L) + "'", long20 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-21028080744L) + "'", long46 == (-21028080744L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62143459200000L) + "'", long48 == (-62143459200000L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology8, readableDateTime10, readableDateTime11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology8);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = monthDay13.isSupported(dateTimeFieldType14);
        java.lang.String str17 = monthDay13.toString("0");
        int int18 = monthDay13.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = monthDay13.getField((int) (short) 1);
        int[] intArray21 = new int[] {};
        int int22 = skipUndoDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay13.minus(readablePeriod23);
        org.joda.time.Chronology chronology25 = monthDay13.getChronology();
        java.lang.String str26 = monthDay13.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "--03-01" + "'", str26.equals("--03-01"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        int int13 = property10.getMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property10.getAsShortText(locale14);
        org.joda.time.DateTime dateTime16 = property10.getDateTime();
        org.joda.time.DateTimeField dateTimeField17 = property10.getField();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime21 = dateTime19.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime23 = dateTime21.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime27 = dateTime23.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime23.secondOfDay();
        java.util.Locale locale29 = null;
        int int30 = property28.getMaximumTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType31, (int) (byte) 100, 1, 28253);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(0, 200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime5.secondOfDay();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.Interval interval13 = property10.toInterval();
        org.joda.time.DurationField durationField14 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime16 = property10.addToCopy(100);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        int int18 = dateTime16.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 275 + "'", int18 == 275);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            long long2 = dateTimeFormatter0.parseMillis("--12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYearOfEra(3, (int) 'a');
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, 100);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumTextLength(locale27);
        long long31 = offsetDateTimeField26.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField26.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType32, (int) (short) 10);
        dateTimeFormatterBuilder35.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000052L + "'", long31 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime1.yearOfEra();
        org.joda.time.LocalTime localTime7 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfMonth();
        org.joda.time.LocalTime localTime9 = dateTime1.toLocalTime();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.era();
        org.joda.time.Chronology chronology12 = copticChronology10.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField14);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology18, readableDateTime20, readableDateTime21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology18);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay23.isSupported(dateTimeFieldType24);
        java.lang.String str27 = monthDay23.toString("0");
        int int28 = monthDay23.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = monthDay23.getField((int) (short) 1);
        int[] intArray31 = new int[] {};
        int int32 = skipUndoDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) monthDay23, intArray31);
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = copticChronology35.getZone();
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime37, readableDateTime38);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology35);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        boolean boolean42 = monthDay40.isSupported(dateTimeFieldType41);
        java.lang.String str44 = monthDay40.toString("0");
        boolean boolean45 = monthDay23.isEqual((org.joda.time.ReadablePartial) monthDay40);
        try {
            boolean boolean46 = localTime9.isEqual((org.joda.time.ReadablePartial) monthDay23);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(limitChronology39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 100);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        int int11 = offsetDateTimeField7.getMaximumValue((long) 4);
        long long14 = offsetDateTimeField7.add(21550L, (int) 'a');
        int int15 = offsetDateTimeField7.getMaximumValue();
        long long17 = offsetDateTimeField7.roundHalfFloor(0L);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology20, readableDateTime22, readableDateTime23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = monthDay25.isSupported(dateTimeFieldType26);
        java.lang.String str29 = monthDay25.toString("0");
        int int30 = monthDay25.getDayOfMonth();
        org.joda.time.DateTimeField dateTimeField32 = monthDay25.getField((int) (short) 1);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = copticChronology34.getZone();
        org.joda.time.ReadableDateTime readableDateTime36 = null;
        org.joda.time.ReadableDateTime readableDateTime37 = null;
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology34, readableDateTime36, readableDateTime37);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone40 = copticChronology39.getZone();
        org.joda.time.Chronology chronology41 = limitChronology38.withZone(dateTimeZone40);
        long long45 = dateTimeZone40.convertLocalToUTC((long) (-28800000), false, 1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone49 = julianChronology48.getZone();
        org.joda.time.DateTimeField dateTimeField50 = julianChronology48.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology47, dateTimeField50, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField52, 100);
        java.util.Locale locale55 = null;
        int int56 = offsetDateTimeField54.getMaximumTextLength(locale55);
        long long59 = offsetDateTimeField54.add((long) '4', 19);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone63 = copticChronology62.getZone();
        org.joda.time.ReadableDateTime readableDateTime64 = null;
        org.joda.time.ReadableDateTime readableDateTime65 = null;
        org.joda.time.chrono.LimitChronology limitChronology66 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology62, readableDateTime64, readableDateTime65);
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(3, 1, (org.joda.time.Chronology) copticChronology62);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.MonthDay monthDay69 = monthDay67.minus(readablePeriod68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = offsetDateTimeField54.getAsText((org.joda.time.ReadablePartial) monthDay69, (int) 'a', locale71);
        int[] intArray79 = new int[] { 3, 5, 28378000, (-28800000), 6, 5 };
        gregorianChronology46.validate((org.joda.time.ReadablePartial) monthDay69, intArray79);
        try {
            int[] intArray82 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay25, 2, intArray79, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [102,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 200 + "'", int11 == 200);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3061065621550L + "'", long14 == 3061065621550L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 200 + "'", int15 == 200);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1015200000L + "'", long17 == 1015200000L);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-136800000L) + "'", long45 == (-136800000L));
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 3 + "'", int56 == 3);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 599616000052L + "'", long59 == 599616000052L);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(limitChronology66);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "97" + "'", str72.equals("97"));
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser3);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1L, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1L + "'", number5.equals(1L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(19, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMillisOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        int int12 = skipUndoDateTimeField10.get((long) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField10, 3);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "52", "52");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "52", "52");
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) str8, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DurationField durationField13 = gregorianChronology11.seconds();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((int) '#', 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendFractionOfDay((int) '4', (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendYearOfCentury(1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) 10L);
        boolean boolean6 = instant5.isEqualNow();
        long long7 = instant5.getMillis();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = instant5.toMutableDateTime(chronology8);
        java.lang.String str10 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-01T00:00:00.010" + "'", str10.equals("1970-01-01T00:00:00.010"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long5 = dateTimeZone1.convertLocalToUTC(28800000L, true, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
        long long10 = dateTimeZone7.convertLocalToUTC((long) 'a', false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusDays((int) (short) 1);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.era();
        org.joda.time.Chronology chronology10 = copticChronology8.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12);
        int int14 = skipUndoDateTimeField13.getMinimumValue();
        long long16 = skipUndoDateTimeField13.roundHalfFloor(0L);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.dayOfYear();
        org.joda.time.DurationField durationField19 = copticChronology17.years();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology17.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText((int) '4', locale23);
        int int25 = delegatedDateTimeField21.getMaximumValue();
        long long28 = delegatedDateTimeField21.set((long) 200, (int) (short) 1);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField(chronology29, dateTimeField32, (int) '#');
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField34.getAsText(0, locale36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21, dateTimeFieldType38);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType38);
        int int41 = dateTime1.get(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "52" + "'", str24.equals("52"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1987199800L) + "'", long28 == (-1987199800L));
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser3);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 100);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((int) (byte) 10, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (int) (byte) 1);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.yearOfCentury();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime24 = dateTime22.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.DateTime dateTime27 = dateTime24.withMillis(829440000000010L);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, 100);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology37.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology36, dateTimeField39, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, 100);
        java.util.Locale locale44 = null;
        int int45 = offsetDateTimeField43.getMaximumTextLength(locale44);
        long long48 = offsetDateTimeField43.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = offsetDateTimeField43.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType49);
        int int51 = dateTime27.get(dateTimeFieldType49);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dateTimeField20, dateTimeFieldType49, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder54.appendFractionOfSecond(28378000, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder54.appendWeekyear((int) '#', 4);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone63 = julianChronology62.getZone();
        org.joda.time.DateTimeField dateTimeField64 = julianChronology62.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField(chronology61, dateTimeField64, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField66, 100);
        org.joda.time.Chronology chronology69 = null;
        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone71 = julianChronology70.getZone();
        org.joda.time.DateTimeField dateTimeField72 = julianChronology70.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField74 = new org.joda.time.field.SkipUndoDateTimeField(chronology69, dateTimeField72, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField74, 100);
        java.util.Locale locale77 = null;
        int int78 = offsetDateTimeField76.getMaximumTextLength(locale77);
        long long81 = offsetDateTimeField76.add((long) '4', 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = offsetDateTimeField76.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField83 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField66, dateTimeFieldType82);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType82, (int) (byte) 0, 30);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField53, dateTimeFieldType82);
        int int88 = remainderDateTimeField53.getDivisor();
        boolean boolean89 = copticChronology0.equals((java.lang.Object) remainderDateTimeField53);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 599616000052L + "'", long48 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 53 + "'", int51 == 53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(julianChronology62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(julianChronology70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 599616000052L + "'", long81 == 599616000052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 30 + "'", int88 == 30);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 100);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[+30:00]" + "'", str1.equals("GJChronology[+30:00]"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology6.getZone();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime8, readableDateTime9);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.Chronology chronology13 = limitChronology10.withZone(dateTimeZone12);
        long long17 = dateTimeZone12.convertLocalToUTC((long) (-28800000), false, 1L);
        boolean boolean19 = dateTimeZone12.isStandardOffset((-31535999948L));
        boolean boolean20 = buddhistChronology5.equals((java.lang.Object) dateTimeZone12);
        org.joda.time.Chronology chronology21 = iSOChronology0.withZone(dateTimeZone12);
        org.joda.time.Chronology chronology22 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-136800000L) + "'", long17 == (-136800000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.chrono.LimitChronology limitChronology4 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime2, readableDateTime3);
        org.joda.time.Chronology chronology5 = limitChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology4.millisOfSecond();
        try {
            long long11 = limitChronology4.getDateTimeMillis(5, (-1), (int) (short) 10, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(limitChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (byte) 100);
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateMidnight4);
        boolean boolean7 = dateMidnight4.isBefore(0L);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }
}

