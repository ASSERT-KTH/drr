import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
        org.joda.time.DateTimeField dateTimeField5 = null;
        mutableDateTime4.setRounding(dateTimeField5, 19);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.year();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.weekOfWeekyear();
        int int12 = mutableDateTime10.getYear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
//        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
//        org.joda.time.DateTime.Property property7 = dateTime5.secondOfDay();
//        java.lang.String str8 = property7.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        boolean boolean10 = mutableDateTime3.isSupported(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "57600" + "'", str8.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
//        long long31 = offsetDateTimeField28.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField28.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) offsetDateTimeField28);
//        java.util.Locale locale36 = null;
//        long long37 = skipUndoDateTimeField33.set((long) 19, "10", locale36);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay42 = dateTime38.toYearMonthDay();
//        int[] intArray47 = new int[] { '4', 321, (short) 10 };
//        int[] intArray49 = skipUndoDateTimeField33.addWrapField((org.joda.time.ReadablePartial) yearMonthDay42, 0, intArray47, (int) (byte) 10);
//        gregorianChronology1.validate((org.joda.time.ReadablePartial) localDate15, intArray49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology1.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology53, locale54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.minuteOfHour();
//        org.joda.time.DurationField durationField57 = gregorianChronology53.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology59, locale60);
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, (int) (byte) -1);
//        long long67 = offsetDateTimeField64.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField68 = offsetDateTimeField64.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField69 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, (org.joda.time.DateTimeField) offsetDateTimeField64);
//        java.util.Locale locale72 = null;
//        long long73 = skipUndoDateTimeField69.set((long) 19, "10", locale72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = skipUndoDateTimeField69.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, dateTimeFieldType74, 19);
//        int int78 = offsetDateTimeField76.getMinimumValue((long) 637);
//        long long81 = offsetDateTimeField76.add((long) 5, 28800100L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 660019L + "'", long37 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(yearMonthDay42);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 660019L + "'", long73 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-292275035) + "'", int78 == (-292275035));
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 908843373360000005L + "'", long81 == 908843373360000005L);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
//        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
//        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
//        java.lang.String str12 = offsetDateTimeField6.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
//        int int16 = gregorianChronology14.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.minuteOfHour();
//        org.joda.time.DurationField durationField22 = gregorianChronology18.weekyears();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology18.millisOfDay();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime28 = dateTime24.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime24.minus(readableDuration29);
//        int int31 = dateTime30.getDayOfWeek();
//        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale35 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology34, locale35);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.minuteOfHour();
//        org.joda.time.DurationField durationField38 = gregorianChronology34.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology40, locale41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
//        long long48 = offsetDateTimeField45.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField45.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, (org.joda.time.DateTimeField) offsetDateTimeField45);
//        java.util.Locale locale53 = null;
//        long long54 = skipUndoDateTimeField50.set((long) 19, "10", locale53);
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property56 = dateTime55.weekyear();
//        org.joda.time.DateTime dateTime58 = dateTime55.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay59 = dateTime55.toYearMonthDay();
//        int[] intArray64 = new int[] { '4', 321, (short) 10 };
//        int[] intArray66 = skipUndoDateTimeField50.addWrapField((org.joda.time.ReadablePartial) yearMonthDay59, 0, intArray64, (int) (byte) 10);
//        gregorianChronology18.validate((org.joda.time.ReadablePartial) localDate32, intArray66);
//        int[] intArray69 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDate32, (long) '#');
//        java.lang.String str70 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) localDate32);
//        int int71 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 660019L + "'", long54 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(yearMonthDay59);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1970-W01-3" + "'", str70.equals("1970-W01-3"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 58 + "'", int71 == 58);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 19, locale7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        int int11 = cachedDateTimeZone9.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone9.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone9.getUncachedZone();
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((-1), 55, 321, 100, 0, dateTimeZone14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600000 + "'", int1 == 57600000);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.DurationField durationField12 = gregorianChronology8.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        long long22 = offsetDateTimeField19.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField23 = offsetDateTimeField19.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeField) offsetDateTimeField19);
        java.util.Locale locale27 = null;
        long long28 = skipUndoDateTimeField24.set((long) 19, "10", locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType30, 19329);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.hourOfHalfday();
        org.joda.time.DurationField durationField35 = gJChronology33.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime41 = dateTime37.plusYears(2019);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.DateTime dateTime43 = dateTime37.withChronology(chronology42);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale48 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket49 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology47, locale48);
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.minuteOfHour();
        org.joda.time.DurationField durationField51 = gregorianChronology47.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale54 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology53, locale54);
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (byte) -1);
        long long61 = offsetDateTimeField58.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField62 = offsetDateTimeField58.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, (org.joda.time.DateTimeField) offsetDateTimeField58);
        java.util.Locale locale66 = null;
        long long67 = skipUndoDateTimeField63.set((long) 19, "10", locale66);
        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property69 = dateTime68.weekyear();
        org.joda.time.DateTime dateTime71 = dateTime68.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay72 = dateTime68.toYearMonthDay();
        int[] intArray77 = new int[] { '4', 321, (short) 10 };
        int[] intArray79 = skipUndoDateTimeField63.addWrapField((org.joda.time.ReadablePartial) yearMonthDay72, 0, intArray77, (int) (byte) 10);
        try {
            int[] intArray81 = unsupportedDateTimeField36.addWrapPartial((org.joda.time.ReadablePartial) localDate44, 0, intArray77, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 660019L + "'", long28 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 660019L + "'", long67 == 660019L);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(yearMonthDay72);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = dateTime0.equals(obj9);
        try {
            org.joda.time.DateTime dateTime15 = dateTime0.withTime((int) 'a', (int) (byte) 10, 22, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2, (java.lang.Integer) 53);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.monthOfYear();
        org.joda.time.DurationField durationField6 = julianChronology1.hours();
        int int7 = julianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property19 = dateTime18.weekyear();
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime18.toYearMonthDay();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay22, (int) (byte) 0, locale24);
        boolean boolean26 = skipUndoDateTimeField17.isLenient();
        org.joda.time.DurationField durationField27 = skipUndoDateTimeField17.getLeapDurationField();
        int int29 = skipUndoDateTimeField17.getMinimumValue(25980000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.DateTime dateTime6 = dateTime0.withMonthOfYear(3);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, 3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusYears(1439);
//        int int4 = dateTime0.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime0.plus(122401140000L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(0);
//        org.joda.time.Chronology chronology7 = null;
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(100L, chronology7, locale8, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.joda.time.DateTime.Property property14 = dateTime12.secondOfDay();
//        java.lang.String str15 = property14.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
//        java.util.Locale locale18 = null;
//        dateTimeParserBucket11.saveField(dateTimeFieldType16, "+00:00:02.019", locale18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType16, 4, 637);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "57600" + "'", str15.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute((int) '#', 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(0);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime11.secondOfDay();
//        java.lang.String str14 = property13.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendSignedDecimal(dateTimeFieldType15, 2000, 0);
//        dateTimeFormatterBuilder10.clear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder10.appendEraText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "57600" + "'", str14.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int11 = fixedDateTimeZone9.getStandardOffset(1560342124707L);
        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        mutableDateTime4.addHours(4);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime4.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime17 = property15.add((-1L));
        try {
            mutableDateTime17.setHourOfDay(26005701);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26005701 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int11 = fixedDateTimeZone9.getStandardOffset(1560342124707L);
        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        mutableDateTime4.addHours(4);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded(readableDuration5, (int) (short) 10);
        org.joda.time.DateTime.Property property8 = dateTime0.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfYear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.year();
//        mutableDateTime6.setRounding(dateTimeField11);
//        mutableDateTime6.setMillisOfDay(2000);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime6.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:02.019" + "'", str3.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime3 = property2.getMutableDateTime();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfDay();
//        java.lang.String str7 = property6.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        boolean boolean9 = mutableDateTime3.isSupported(dateTimeFieldType8);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField10 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "57600" + "'", str7.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        int int6 = gJChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField7 = gJChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.minuteOfDay();
        java.lang.String str9 = gJChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GJChronology[UTC]" + "'", str9.equals("GJChronology[UTC]"));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Instant instant1 = dateTime0.toInstant();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
//        long long3 = instant1.getMillis();
//        org.joda.time.Instant instant5 = instant1.withMillis(360156L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(instant5);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(26005701, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26005753 + "'", int2 == 26005753);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        long long60 = dateTimeParserBucket5.computeMillis();
//        dateTimeParserBucket5.setOffset((java.lang.Integer) 58);
//        org.joda.time.Chronology chronology63 = dateTimeParserBucket5.getChronology();
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-60431501221900L) + "'", long60 == (-60431501221900L));
//        org.junit.Assert.assertNotNull(chronology63);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        int int2 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusSeconds((int) (short) 0);
//        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime4.toTimeOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTimeISO();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        java.lang.String str3 = property2.getAsString();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property2.getAsText(locale4);
//        org.joda.time.Interval interval6 = property2.toInterval();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "57600" + "'", str3.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600" + "'", str5.equals("57600"));
//        org.junit.Assert.assertNotNull(interval6);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property2.addToCopy((-292275035));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "57600" + "'", str3.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        long long19 = skipUndoDateTimeField17.remainder((long) 32);
        int int21 = skipUndoDateTimeField17.get(122401140000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 18 + "'", int21 == 18);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) 19, locale8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        mutableDateTime11.setWeekOfWeekyear((int) '4');
//        boolean boolean15 = mutableDateTime11.isAfter((long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.era();
//        mutableDateTime11.setRounding(dateTimeField20);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        long long25 = dateTimeZone22.convertLocalToUTC((long) (byte) -1, true);
//        mutableDateTime11.setZoneRetainFields(dateTimeZone22);
//        org.joda.time.Chronology chronology27 = iSOChronology4.withZone(dateTimeZone22);
//        org.joda.time.Chronology chronology28 = iSOChronology4.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfEra((int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DurationField durationField9 = gJChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-210866500800000L), (org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.hourOfDay();
        mutableDateTime11.addSeconds((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:02.019" + "'", str3.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        org.joda.time.DurationField durationField70 = unsupportedDateTimeField68.getRangeDurationField();
//        org.joda.time.DurationField durationField71 = unsupportedDateTimeField68.getRangeDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = dateTimeZone73.getName((long) 19, locale75);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone77 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone73);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = dateTimeFormatter72.withZone(dateTimeZone73);
//        org.joda.time.DateTime dateTime79 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property80 = dateTime79.weekyear();
//        org.joda.time.DateTime dateTime82 = dateTime79.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property83 = dateTime79.year();
//        org.joda.time.DateTime dateTime84 = dateTime79.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property85 = dateTime84.era();
//        org.joda.time.LocalDateTime localDateTime86 = dateTime84.toLocalDateTime();
//        boolean boolean87 = dateTimeZone73.isLocalDateTimeGap(localDateTime86);
//        int[] intArray89 = new int[] {};
//        try {
//            int[] intArray91 = unsupportedDateTimeField68.addWrapField((org.joda.time.ReadablePartial) localDateTime86, 16, intArray89, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertNull(durationField70);
//        org.junit.Assert.assertNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeFormatter72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Coordinated Universal Time" + "'", str76.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone77);
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(property85);
//        org.junit.Assert.assertNotNull(localDateTime86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(intArray89);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        int int2 = dateTime1.getWeekyear();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime5 = dateTime1.withEra(0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) 19, locale8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.DateTime dateTime11 = dateTime1.toDateTime(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime0.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        long long68 = remainderDateTimeField66.roundHalfFloor((long) 637);
//        long long71 = remainderDateTimeField66.set(100L, (int) (short) 1);
//        int int73 = remainderDateTimeField66.get((long) 18);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-536457599900L) + "'", long71 == (-536457599900L));
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 18 + "'", int73 == 18);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute(0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str5 = dateTimeZone4.getID();
//        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withSecondOfMinute(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology17.millisOfDay();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime27 = dateTime23.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime23.minus(readableDuration28);
//        int int30 = dateTime29.getDayOfWeek();
//        org.joda.time.LocalDate localDate31 = dateTime29.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DurationField durationField37 = gregorianChronology33.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology39, locale40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
//        long long47 = offsetDateTimeField44.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField44.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, (org.joda.time.DateTimeField) offsetDateTimeField44);
//        java.util.Locale locale52 = null;
//        long long53 = skipUndoDateTimeField49.set((long) 19, "10", locale52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.weekyear();
//        org.joda.time.DateTime dateTime57 = dateTime54.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay58 = dateTime54.toYearMonthDay();
//        int[] intArray63 = new int[] { '4', 321, (short) 10 };
//        int[] intArray65 = skipUndoDateTimeField49.addWrapField((org.joda.time.ReadablePartial) yearMonthDay58, 0, intArray63, (int) (byte) 10);
//        gregorianChronology17.validate((org.joda.time.ReadablePartial) localDate31, intArray65);
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology17.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology69, locale70);
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology69.minuteOfHour();
//        org.joda.time.DurationField durationField73 = gregorianChronology69.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale76 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology75, locale76);
//        org.joda.time.DateTimeField dateTimeField78 = gregorianChronology75.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField78, (int) (byte) -1);
//        long long83 = offsetDateTimeField80.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField84 = offsetDateTimeField80.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology69, (org.joda.time.DateTimeField) offsetDateTimeField80);
//        java.util.Locale locale88 = null;
//        long long89 = skipUndoDateTimeField85.set((long) 19, "10", locale88);
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = skipUndoDateTimeField85.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, dateTimeFieldType90, 19);
//        org.joda.time.DateTime.Property property93 = dateTime13.property(dateTimeFieldType90);
//        mutableDateTime12.set(dateTimeFieldType90, (int) (short) 10);
//        int int96 = dateTime6.get(dateTimeFieldType90);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:02.019" + "'", str5.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 660019L + "'", long53 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(yearMonthDay58);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(gregorianChronology75);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 660019L + "'", long89 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//        org.junit.Assert.assertNotNull(property93);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        int[] intArray31 = new int[] { '4', 321, (short) 10 };
        int[] intArray33 = skipUndoDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay26, 0, intArray31, (int) (byte) 10);
        boolean boolean34 = skipUndoDateTimeField17.isSupported();
        boolean boolean35 = skipUndoDateTimeField17.isSupported();
        long long37 = skipUndoDateTimeField17.remainder((long) (short) 1);
        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField17.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute((int) '#', 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYear(53, 22);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime.Property property16 = dateTime14.secondOfDay();
//        java.lang.String str17 = property16.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType18, 9, (int) (short) 1);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "57600" + "'", str17.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.minusYears(6);
        org.joda.time.DateTime dateTime7 = dateTime2.withEra((int) (short) 0);
        java.util.Date date8 = dateTime2.toDate();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(53);
        org.joda.time.DateTime dateTime10 = dateTime6.withDayOfMonth(18);
        try {
            org.joda.time.DateTime dateTime12 = dateTime6.withHourOfDay(425760);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 425760 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
//        long long31 = offsetDateTimeField28.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField28.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) offsetDateTimeField28);
//        java.util.Locale locale36 = null;
//        long long37 = skipUndoDateTimeField33.set((long) 19, "10", locale36);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay42 = dateTime38.toYearMonthDay();
//        int[] intArray47 = new int[] { '4', 321, (short) 10 };
//        int[] intArray49 = skipUndoDateTimeField33.addWrapField((org.joda.time.ReadablePartial) yearMonthDay42, 0, intArray47, (int) (byte) 10);
//        gregorianChronology1.validate((org.joda.time.ReadablePartial) localDate15, intArray49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology1.yearOfEra();
//        org.joda.time.Chronology chronology52 = gregorianChronology1.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 660019L + "'", long37 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(yearMonthDay42);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(chronology52);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime6.add(readableDuration9, (int) 'a');
//        mutableDateTime6.setMonthOfYear((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.getMutableDateTime();
//        mutableDateTime6.setMillis((org.joda.time.ReadableInstant) mutableDateTime16);
//        mutableDateTime6.setWeekyear(5);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        mutableDateTime6.add(readablePeriod20, 19);
//        try {
//            mutableDateTime6.setDayOfMonth(637);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 637 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property70 = dateTime69.weekyear();
//        org.joda.time.DateTime dateTime72 = dateTime69.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property73 = dateTime69.year();
//        org.joda.time.DateTime dateTime74 = dateTime69.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property75 = dateTime74.era();
//        org.joda.time.LocalDateTime localDateTime76 = dateTime74.toLocalDateTime();
//        try {
//            int int77 = unsupportedDateTimeField68.getMaximumValue((org.joda.time.ReadablePartial) localDateTime76);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(localDateTime76);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        int int8 = property7.getMaximumValueOverall();
        boolean boolean9 = property7.isLeap();
        org.joda.time.DateTimeField dateTimeField10 = property7.getField();
        org.joda.time.DateTime dateTime11 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime16 = dateTime11.withTime((int) (byte) 10, 26, 0, 321);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime11.toMutableDateTime(dateTimeZone18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        mutableDateTime19.setDate(readableInstant20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2, (java.lang.Integer) 53);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology6, locale7);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(100L, chronology10, locale11, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology16, locale17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.minuteOfHour();
//        org.joda.time.DurationField durationField20 = gregorianChronology16.weekyears();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology16.millisOfDay();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime26 = dateTime22.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime22.minus(readableDuration27);
//        int int29 = dateTime28.getDayOfWeek();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
//        org.joda.time.DurationField durationField36 = gregorianChronology32.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale39 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology38, locale39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) -1);
//        long long46 = offsetDateTimeField43.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField47 = offsetDateTimeField43.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology32, (org.joda.time.DateTimeField) offsetDateTimeField43);
//        java.util.Locale locale51 = null;
//        long long52 = skipUndoDateTimeField48.set((long) 19, "10", locale51);
//        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property54 = dateTime53.weekyear();
//        org.joda.time.DateTime dateTime56 = dateTime53.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay57 = dateTime53.toYearMonthDay();
//        int[] intArray62 = new int[] { '4', 321, (short) 10 };
//        int[] intArray64 = skipUndoDateTimeField48.addWrapField((org.joda.time.ReadablePartial) yearMonthDay57, 0, intArray62, (int) (byte) 10);
//        gregorianChronology16.validate((org.joda.time.ReadablePartial) localDate30, intArray64);
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology16.year();
//        dateTimeParserBucket14.saveField(dateTimeField66, 55);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property70 = dateTime69.weekyear();
//        org.joda.time.DateTime.Property property71 = dateTime69.secondOfDay();
//        java.lang.String str72 = property71.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property71.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField(dateTimeField66, dateTimeFieldType73, (int) ' ');
//        long long77 = remainderDateTimeField75.roundHalfFloor((long) 321);
//        int int79 = remainderDateTimeField75.get(660019L);
//        int int81 = remainderDateTimeField75.get(28800010L);
//        int int82 = remainderDateTimeField75.getMinimumValue();
//        int int83 = remainderDateTimeField75.getMaximumValue();
//        java.lang.String str84 = remainderDateTimeField75.getName();
//        dateTimeParserBucket8.saveField((org.joda.time.DateTimeField) remainderDateTimeField75, 0);
//        dateTimeParserBucket4.saveField((org.joda.time.DateTimeField) remainderDateTimeField75, 1969);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 660019L + "'", long52 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(yearMonthDay57);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "57600" + "'", str72.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 18 + "'", int79 == 18);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 18 + "'", int81 == 18);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "secondOfDay" + "'", str84.equals("secondOfDay"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(53);
        org.joda.time.DateTime dateTime10 = dateTime6.withMinuteOfHour(59);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMinutes(19329);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(25980000L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.DurationField durationField12 = gregorianChronology8.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        long long22 = offsetDateTimeField19.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField23 = offsetDateTimeField19.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeField) offsetDateTimeField19);
        java.util.Locale locale27 = null;
        long long28 = skipUndoDateTimeField24.set((long) 19, "10", locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType30, 19329);
        org.joda.time.Chronology chronology35 = null;
        java.util.Locale locale36 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket(100L, chronology35, locale36, (java.lang.Integer) 2019, 0);
        boolean boolean41 = dateTimeParserBucket39.restoreState((java.lang.Object) 100.0d);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
        dateTimeParserBucket39.setZone(dateTimeZone44);
        java.util.Locale locale46 = dateTimeParserBucket39.getLocale();
        java.lang.String str47 = remainderDateTimeField32.getAsText(31, locale46);
        org.joda.time.DateTimeField dateTimeField48 = remainderDateTimeField32.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 660019L + "'", long28 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31" + "'", str47.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField48);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone1.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        int int7 = gJChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField8 = gJChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.minuteOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(360000L, (org.joda.time.Chronology) gJChronology5);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getDurationField();
//        try {
//            java.lang.String str71 = unsupportedDateTimeField68.getAsText((long) 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "America/Los_Angeles", 2019, 1005108);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
        java.lang.Object obj4 = null;
        boolean boolean5 = property1.equals(obj4);
        org.joda.time.DateTime dateTime7 = property1.addToCopy(26);
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DurationField durationField9 = property8.getLeapDurationField();
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("ISOChronology[+00:00:02.019]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[+00:00:02.019]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        mutableDateTime6.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime6.monthOfYear();
//        mutableDateTime6.addHours(0);
//        boolean boolean17 = mutableDateTime6.isAfter(86340000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
//        long long5 = property1.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) '4');
//        int int8 = dateTime4.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatterBuilder12.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneName();
        boolean boolean21 = dateTimeFormatterBuilder19.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder19.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder23.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder23.append(dateTimeFormatter32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendTimeZoneName();
        boolean boolean38 = dateTimeFormatterBuilder36.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder40.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter47 = dateTimeFormatterBuilder46.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder50.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder54.appendTimeZoneName();
        boolean boolean56 = dateTimeFormatterBuilder54.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder54.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder58.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder64.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser67 = dateTimeFormatter66.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter65, dateTimeParser67);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder51.appendOptional(dateTimeParser67);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder23.append(dateTimePrinter47, dateTimeParser67);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimePrinter47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertNotNull(dateTimeParser67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        int int2 = dateTime1.getWeekyear();
//        boolean boolean3 = dateTime1.isBeforeNow();
//        org.joda.time.DateTime dateTime5 = dateTime1.plusHours(19);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long8 = offsetDateTimeField6.roundHalfFloor((long) (byte) 0);
        int int10 = offsetDateTimeField6.get((long) 'a');
        int int13 = offsetDateTimeField6.getDifference(1560342114588L, 2000L);
        int int15 = offsetDateTimeField6.get(1560342120000L);
        int int17 = offsetDateTimeField6.getMinimumValue((long) 322);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 26005701 + "'", int13 == 26005701);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 21 + "'", int15 == 21);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str11 = dateTimeZone10.toString();
        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone10);
        mutableDateTime1.setZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str16 = dateTimeZone15.getID();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        java.util.TimeZone timeZone19 = dateTimeZone15.toTimeZone();
        long long21 = dateTimeZone10.getMillisKeepLocal(dateTimeZone15, (-2018L));
        long long24 = dateTimeZone10.convertLocalToUTC((long) 2000, false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:02.019" + "'", str16.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28804037L) + "'", long21 == (-28804037L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28802000L + "'", long24 == 28802000L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundFloor((long) 4);
        long long13 = offsetDateTimeField6.roundFloor(32L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime14.minus(readableDuration19);
        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfDay();
        org.joda.time.LocalDateTime localDateTime22 = dateTime20.toLocalDateTime();
        int int23 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        org.joda.time.DurationField durationField70 = unsupportedDateTimeField68.getRangeDurationField();
//        org.joda.time.DurationField durationField71 = unsupportedDateTimeField68.getRangeDurationField();
//        try {
//            long long74 = unsupportedDateTimeField68.addWrapField((long) '4', 1990);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertNull(durationField70);
//        org.junit.Assert.assertNull(durationField71);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(120052L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, (-1));
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
//        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
//        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        java.util.TimeZone timeZone18 = fixedDateTimeZone13.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName((long) 19, locale22);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        mutableDateTime25.setWeekOfWeekyear((int) '4');
//        boolean boolean29 = mutableDateTime25.isAfter((long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale32 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology31, locale32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.era();
//        mutableDateTime25.setRounding(dateTimeField34);
//        boolean boolean36 = fixedDateTimeZone13.equals((java.lang.Object) dateTimeField34);
//        boolean boolean38 = fixedDateTimeZone13.equals((java.lang.Object) "BuddhistChronology[America/Los_Angeles]");
//        boolean boolean39 = fixedDateTimeZone13.isFixed();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordinated Universal Time" + "'", str23.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        int int8 = gregorianChronology6.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(16, 0, (int) (byte) 1, 2019, (int) (byte) 1, 22, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology2, locale3, (java.lang.Integer) 53);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.monthOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField6, 1975);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
//        java.lang.Object obj4 = null;
//        boolean boolean5 = property1.equals(obj4);
//        java.lang.String str6 = property1.getAsText();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DurationField durationField4 = property2.getLeapDurationField();
//        java.lang.String str5 = property2.getAsShortText();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        int int7 = property2.getDifference(readableInstant6);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "57600" + "'", str3.equals("57600"));
//        org.junit.Assert.assertNull(durationField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600" + "'", str5.equals("57600"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusYears(1439);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 19, locale7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
//        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.millisOfDay();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime20.minus(readableDuration25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale31 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology30, locale31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.minuteOfHour();
//        org.joda.time.DurationField durationField34 = gregorianChronology30.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale37 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology36, locale37);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) -1);
//        long long44 = offsetDateTimeField41.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField41.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, (org.joda.time.DateTimeField) offsetDateTimeField41);
//        java.util.Locale locale49 = null;
//        long long50 = skipUndoDateTimeField46.set((long) 19, "10", locale49);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property52 = dateTime51.weekyear();
//        org.joda.time.DateTime dateTime54 = dateTime51.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime51.toYearMonthDay();
//        int[] intArray60 = new int[] { '4', 321, (short) 10 };
//        int[] intArray62 = skipUndoDateTimeField46.addWrapField((org.joda.time.ReadablePartial) yearMonthDay55, 0, intArray60, (int) (byte) 10);
//        gregorianChronology14.validate((org.joda.time.ReadablePartial) localDate28, intArray62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology14.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology66, locale67);
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology66.minuteOfHour();
//        org.joda.time.DurationField durationField70 = gregorianChronology66.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale73 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology72, locale73);
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology72.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, (int) (byte) -1);
//        long long80 = offsetDateTimeField77.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField81 = offsetDateTimeField77.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField82 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology66, (org.joda.time.DateTimeField) offsetDateTimeField77);
//        java.util.Locale locale85 = null;
//        long long86 = skipUndoDateTimeField82.set((long) 19, "10", locale85);
//        org.joda.time.DateTimeFieldType dateTimeFieldType87 = skipUndoDateTimeField82.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, dateTimeFieldType87, 19);
//        mutableDateTime10.set(dateTimeFieldType87, (int) (byte) 0);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType87, (int) (short) 100, (int) (short) 100, 150);
//        int int96 = dateTime3.get(dateTimeFieldType87);
//        org.joda.time.DateTime dateTime98 = dateTime3.minusHours(16);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 660019L + "'", long50 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 660019L + "'", long86 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType87);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
//        org.junit.Assert.assertNotNull(dateTime98);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder6.appendFractionOfDay(0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendHourOfDay(32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear(26005701);
        boolean boolean21 = dateTimeFormatterBuilder20.canBuildFormatter();
        boolean boolean22 = dateTimeFormatterBuilder20.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        long long68 = remainderDateTimeField66.roundHalfFloor((long) 321);
//        int int70 = remainderDateTimeField66.get(660019L);
//        int int72 = remainderDateTimeField66.get(28800010L);
//        int int73 = remainderDateTimeField66.getMinimumValue();
//        int int74 = remainderDateTimeField66.getMaximumValue();
//        java.lang.String str75 = remainderDateTimeField66.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = remainderDateTimeField66.getType();
//        boolean boolean77 = remainderDateTimeField66.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 18 + "'", int70 == 18);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 18 + "'", int72 == 18);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 31 + "'", int74 == 31);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "secondOfDay" + "'", str75.equals("secondOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        int[] intArray31 = new int[] { '4', 321, (short) 10 };
        int[] intArray33 = skipUndoDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay26, 0, intArray31, (int) (byte) 10);
        int int35 = skipUndoDateTimeField17.get((-210866500800000L));
        int int37 = skipUndoDateTimeField17.get(1560342114588L);
        java.lang.String str38 = skipUndoDateTimeField17.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20 + "'", int37 == 20);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "minuteOfHour" + "'", str38.equals("minuteOfHour"));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 19, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) 19, locale11);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        mutableDateTime8.setZoneRetainFields(dateTimeZone9);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime8.monthOfYear();
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.year();
//        mutableDateTime6.setRounding(dateTimeField11);
//        mutableDateTime6.setMillisOfDay(2000);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime6.secondOfDay();
//        mutableDateTime6.setDate((long) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = property2.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int12 = fixedDateTimeZone10.getStandardOffset(1560342124707L);
        mutableDateTime5.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Chronology chronology14 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology6, locale7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.minuteOfHour();
        org.joda.time.DurationField durationField10 = gregorianChronology6.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology12, locale13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        long long20 = offsetDateTimeField17.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField17.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) offsetDateTimeField17);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
        org.joda.time.DateTime dateTime26 = dateTime23.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay27 = dateTime23.toYearMonthDay();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay27, (int) (byte) 0, locale29);
        try {
            dateTimeFormatter2.printTo(stringBuffer4, (org.joda.time.ReadablePartial) yearMonthDay27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(yearMonthDay27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime21.toYearMonthDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay25, (int) (byte) 0, locale27);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.DateTimeField dateTimeField30 = gJChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getDurationField();
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property71 = dateTime70.weekyear();
//        org.joda.time.DateTime dateTime73 = dateTime70.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property74 = dateTime70.year();
//        org.joda.time.DateTime dateTime75 = dateTime70.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property76 = dateTime75.era();
//        org.joda.time.LocalDateTime localDateTime77 = dateTime75.toLocalDateTime();
//        org.joda.time.Chronology chronology80 = null;
//        java.util.Locale locale81 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket(100L, chronology80, locale81, (java.lang.Integer) 2019, 0);
//        boolean boolean86 = dateTimeParserBucket84.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone89 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket84.setZone(dateTimeZone89);
//        java.util.Locale locale91 = dateTimeParserBucket84.getLocale();
//        try {
//            java.lang.String str92 = unsupportedDateTimeField68.getAsShortText((org.joda.time.ReadablePartial) localDateTime77, 0, locale91);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(localDateTime77);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone89);
//        org.junit.Assert.assertNotNull(locale91);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
        java.lang.Object obj4 = null;
        boolean boolean5 = property1.equals(obj4);
        org.joda.time.DateTime dateTime7 = property1.addToCopy(26);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withEra((-292275035));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275035 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.minusYears(6);
        org.joda.time.DateTime dateTime7 = dateTime2.withEra((int) (short) 0);
        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-12-31", "December");
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        boolean boolean10 = mutableDateTime6.isAfter((long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology12, locale13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.era();
//        mutableDateTime6.setRounding(dateTimeField15);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime23 = property22.getMutableDateTime();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property25 = dateTime24.weekyear();
//        org.joda.time.DateTime.Property property26 = dateTime24.secondOfDay();
//        java.lang.String str27 = property26.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
//        boolean boolean29 = mutableDateTime23.isSupported(dateTimeFieldType28);
//        dateTimeParserBucket20.saveField(dateTimeFieldType28, 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType28, 22, 5, 9);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField35.getAsShortText(360000L, locale37);
//        try {
//            long long41 = offsetDateTimeField35.set((long) 26, 2922789);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for secondOfDay must be in the range [22,9]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57600" + "'", str27.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "23" + "'", str38.equals("23"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        int int6 = gJChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField7 = gJChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology4.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 6);
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
//        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendOptional(dateTimeParser14);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYear(637);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 1);
//        org.joda.time.Chronology chronology21 = null;
//        java.util.Locale locale22 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket(100L, chronology21, locale22, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology27, locale28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.minuteOfHour();
//        org.joda.time.DurationField durationField31 = gregorianChronology27.weekyears();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology27.millisOfDay();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime35 = dateTime33.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime37 = dateTime33.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime33.minus(readableDuration38);
//        int int40 = dateTime39.getDayOfWeek();
//        org.joda.time.LocalDate localDate41 = dateTime39.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale44 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology43, locale44);
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.minuteOfHour();
//        org.joda.time.DurationField durationField47 = gregorianChronology43.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology49, locale50);
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) (byte) -1);
//        long long57 = offsetDateTimeField54.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField58 = offsetDateTimeField54.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology43, (org.joda.time.DateTimeField) offsetDateTimeField54);
//        java.util.Locale locale62 = null;
//        long long63 = skipUndoDateTimeField59.set((long) 19, "10", locale62);
//        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property65 = dateTime64.weekyear();
//        org.joda.time.DateTime dateTime67 = dateTime64.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay68 = dateTime64.toYearMonthDay();
//        int[] intArray73 = new int[] { '4', 321, (short) 10 };
//        int[] intArray75 = skipUndoDateTimeField59.addWrapField((org.joda.time.ReadablePartial) yearMonthDay68, 0, intArray73, (int) (byte) 10);
//        gregorianChronology27.validate((org.joda.time.ReadablePartial) localDate41, intArray75);
//        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology27.year();
//        dateTimeParserBucket25.saveField(dateTimeField77, 55);
//        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property81 = dateTime80.weekyear();
//        org.joda.time.DateTime.Property property82 = dateTime80.secondOfDay();
//        java.lang.String str83 = property82.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property82.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField(dateTimeField77, dateTimeFieldType84, (int) ' ');
//        long long88 = remainderDateTimeField86.roundHalfFloor((long) 321);
//        int int90 = remainderDateTimeField86.get(660019L);
//        int int92 = remainderDateTimeField86.get(28800010L);
//        int int93 = remainderDateTimeField86.getMinimumValue();
//        int int94 = remainderDateTimeField86.getMaximumValue();
//        java.lang.String str95 = remainderDateTimeField86.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType96 = remainderDateTimeField86.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder99 = dateTimeFormatterBuilder17.appendFraction(dateTimeFieldType96, 31, (int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeParser14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 660019L + "'", long63 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(yearMonthDay68);
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "57600" + "'", str83.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType84);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 18 + "'", int90 == 18);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 18 + "'", int92 == 18);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 31 + "'", int94 == 31);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "secondOfDay" + "'", str95.equals("secondOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType96);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder99);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusYears(1439);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 19, locale7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
//        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.millisOfDay();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime20.minus(readableDuration25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale31 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology30, locale31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.minuteOfHour();
//        org.joda.time.DurationField durationField34 = gregorianChronology30.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale37 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology36, locale37);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) -1);
//        long long44 = offsetDateTimeField41.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField41.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, (org.joda.time.DateTimeField) offsetDateTimeField41);
//        java.util.Locale locale49 = null;
//        long long50 = skipUndoDateTimeField46.set((long) 19, "10", locale49);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property52 = dateTime51.weekyear();
//        org.joda.time.DateTime dateTime54 = dateTime51.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime51.toYearMonthDay();
//        int[] intArray60 = new int[] { '4', 321, (short) 10 };
//        int[] intArray62 = skipUndoDateTimeField46.addWrapField((org.joda.time.ReadablePartial) yearMonthDay55, 0, intArray60, (int) (byte) 10);
//        gregorianChronology14.validate((org.joda.time.ReadablePartial) localDate28, intArray62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology14.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology66, locale67);
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology66.minuteOfHour();
//        org.joda.time.DurationField durationField70 = gregorianChronology66.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale73 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology72, locale73);
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology72.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, (int) (byte) -1);
//        long long80 = offsetDateTimeField77.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField81 = offsetDateTimeField77.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField82 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology66, (org.joda.time.DateTimeField) offsetDateTimeField77);
//        java.util.Locale locale85 = null;
//        long long86 = skipUndoDateTimeField82.set((long) 19, "10", locale85);
//        org.joda.time.DateTimeFieldType dateTimeFieldType87 = skipUndoDateTimeField82.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, dateTimeFieldType87, 19);
//        mutableDateTime10.set(dateTimeFieldType87, (int) (byte) 0);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType87, (int) (short) 100, (int) (short) 100, 150);
//        int int96 = dateTime3.get(dateTimeFieldType87);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException99 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType87, (java.lang.Number) 28799, "00:00:00Z");
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 660019L + "'", long50 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 660019L + "'", long86 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType87);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 0, 150, (-292275035));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
        java.lang.Object obj4 = null;
        boolean boolean5 = property1.equals(obj4);
        org.joda.time.DateTime dateTime7 = property1.addToCopy(26);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        java.util.Date date9 = dateTime7.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.DurationField durationField12 = gregorianChronology8.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        long long22 = offsetDateTimeField19.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField23 = offsetDateTimeField19.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeField) offsetDateTimeField19);
        java.util.Locale locale27 = null;
        long long28 = skipUndoDateTimeField24.set((long) 19, "10", locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType30, 19329);
        org.joda.time.DurationField durationField33 = remainderDateTimeField32.getDurationField();
        long long35 = remainderDateTimeField32.remainder((long) 1439);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 660019L + "'", long28 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1439L + "'", long35 == 1439L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        boolean boolean3 = dateTime1.isEqual(0L);
//        org.joda.time.DateTime dateTime4 = dateTime1.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.year();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfCeiling();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            mutableDateTime5.add(durationFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, 100, (int) (short) 100, 19329, (-292275035), 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19329 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant5 = instant3.withMillis(0L);
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone4.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone4.getUncachedZone();
//        long long12 = dateTimeZone9.adjustOffset((long) 1, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder6.appendFractionOfDay(0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendHourOfDay(32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear(26005701);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendSecondOfMinute(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder18.appendFractionOfSecond(52, 16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.hourOfDay();
//        java.lang.Object obj9 = mutableDateTime6.clone();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime11 = property10.roundCeiling();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        java.lang.String str9 = cachedDateTimeZone4.toString();
//        int int11 = cachedDateTimeZone4.getStandardOffset((long) 425760);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[+00:00:02.019]" + "'", str5.equals("ISOChronology[+00:00:02.019]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "00:00:00Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfDay((int) (short) 10, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay(637);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) -1);
        long long25 = offsetDateTimeField22.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField26 = offsetDateTimeField22.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) offsetDateTimeField22);
        java.util.Locale locale30 = null;
        long long31 = skipUndoDateTimeField27.set((long) 19, "10", locale30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property33 = dateTime32.weekyear();
        org.joda.time.DateTime dateTime35 = dateTime32.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime32.toYearMonthDay();
        int[] intArray41 = new int[] { '4', 321, (short) 10 };
        int[] intArray43 = skipUndoDateTimeField27.addWrapField((org.joda.time.ReadablePartial) yearMonthDay36, 0, intArray41, (int) (byte) 10);
        int int45 = skipUndoDateTimeField27.get((-210866500800000L));
        java.lang.String str46 = skipUndoDateTimeField27.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField27.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType47, 425760, (int) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) (-1), "Jun 12, 2019 12:09:28 PM");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 660019L + "'", long31 == 660019L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str46.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant5 = instant3.withMillis(0L);
        org.joda.time.Instant instant7 = instant5.withMillis((-28804037L));
        org.joda.time.Instant instant8 = instant7.toInstant();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant8);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology2, locale3, (java.lang.Integer) 53);
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.monthOfYear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField6, 1975);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
//        long long18 = offsetDateTimeField16.roundHalfFloor((long) (byte) 0);
//        int int20 = offsetDateTimeField16.get((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName((long) 19, locale26);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone30.getName((long) 19, locale32);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
//        mutableDateTime29.setZoneRetainFields(dateTimeZone30);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime29.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale39 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology38, locale39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology38.getZone();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology38.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale46 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket47 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology45, locale46);
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.minuteOfHour();
//        org.joda.time.DurationField durationField49 = gregorianChronology45.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale52 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology51, locale52);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, (int) (byte) -1);
//        long long59 = offsetDateTimeField56.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField56.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, (org.joda.time.DateTimeField) offsetDateTimeField56);
//        java.util.Locale locale64 = null;
//        long long65 = skipUndoDateTimeField61.set((long) 19, "10", locale64);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipUndoDateTimeField61.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipUndoDateTimeField61.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dateTimeField43, dateTimeFieldType67, 19329);
//        org.joda.time.Chronology chronology72 = null;
//        java.util.Locale locale73 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket76 = new org.joda.time.format.DateTimeParserBucket(100L, chronology72, locale73, (java.lang.Integer) 2019, 0);
//        boolean boolean78 = dateTimeParserBucket76.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket76.setZone(dateTimeZone81);
//        java.util.Locale locale83 = dateTimeParserBucket76.getLocale();
//        java.lang.String str84 = remainderDateTimeField69.getAsText(31, locale83);
//        java.util.Calendar calendar85 = mutableDateTime29.toCalendar(locale83);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = dateTimeFormatter22.withLocale(locale83);
//        java.lang.String str87 = offsetDateTimeField16.getAsShortText((int) (byte) 0, locale83);
//        java.text.DateFormatSymbols dateFormatSymbols88 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale83);
//        java.lang.String str89 = skipUndoDateTimeField8.getAsShortText((long) 19329, locale83);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordinated Universal Time" + "'", str33.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 660019L + "'", long65 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone81);
//        org.junit.Assert.assertNotNull(locale83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "31" + "'", str84.equals("31"));
//        org.junit.Assert.assertNotNull(calendar85);
//        org.junit.Assert.assertNotNull(dateTimeFormatter86);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "0" + "'", str87.equals("0"));
//        org.junit.Assert.assertNotNull(dateFormatSymbols88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "Dec" + "'", str89.equals("Dec"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(0, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        org.joda.time.DurationField durationField70 = unsupportedDateTimeField68.getRangeDurationField();
//        org.joda.time.DurationField durationField71 = unsupportedDateTimeField68.getRangeDurationField();
//        java.lang.String str72 = unsupportedDateTimeField68.toString();
//        try {
//            boolean boolean74 = unsupportedDateTimeField68.isLeap((long) 86399);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertNull(durationField70);
//        org.junit.Assert.assertNull(durationField71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "UnsupportedDateTimeField" + "'", str72.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 194L + "'", long2 == 194L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.append(dateTimeFormatter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneName();
        boolean boolean21 = dateTimeFormatterBuilder19.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder19.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder23.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatterBuilder29.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendTimeZoneName();
        boolean boolean39 = dateTimeFormatterBuilder37.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder37.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder41.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = dateTimeFormatterBuilder47.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatter49.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter48, dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder34.appendOptional(dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder6.append(dateTimePrinter30, dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimePrinter48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra((int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DurationField durationField8 = gJChronology7.seconds();
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        boolean boolean6 = dateTime5.isBeforeNow();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMinutes(32);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        long long28 = offsetDateTimeField25.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField29 = offsetDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) offsetDateTimeField25);
        java.util.Locale locale33 = null;
        long long34 = skipUndoDateTimeField30.set((long) 19, "10", locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder6.appendCenturyOfEra(2019, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder6.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 660019L + "'", long34 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology2, locale3, (java.lang.Integer) 53);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.monthOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField6, 1975);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.clockhourOfDay();
        try {
            long long17 = julianChronology0.getDateTimeMillis(2000, 2922789, 52, (-6), 0, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -6 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        int int8 = property7.getMaximumValueOverall();
        boolean boolean9 = property7.isLeap();
        java.lang.String str10 = property7.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[minuteOfDay]" + "'", str10.equals("Property[minuteOfDay]"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 53, (java.lang.Number) (-2018L), (java.lang.Number) (-4200320));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        long long28 = offsetDateTimeField25.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField29 = offsetDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) offsetDateTimeField25);
        java.util.Locale locale33 = null;
        long long34 = skipUndoDateTimeField30.set((long) 19, "10", locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder6.appendHourOfHalfday(637);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 660019L + "'", long34 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField13.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField13);
        java.util.Locale locale21 = null;
        long long22 = skipUndoDateTimeField18.set((long) 19, "10", locale21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.joda.time.DateTimeField dateTimeField24 = skipDateTimeField23.getWrappedField();
        int int26 = skipDateTimeField23.getLeapAmount((long) 21);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 660019L + "'", long22 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra((int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.minusSeconds(57600000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 100);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField6.getWrappedField();
        long long16 = offsetDateTimeField6.roundHalfEven((long) 59);
        long long19 = offsetDateTimeField6.add((long) 16, 20);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1200016L + "'", long19 == 1200016L);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        org.joda.time.DurationField durationField70 = unsupportedDateTimeField68.getRangeDurationField();
//        org.joda.time.DurationField durationField71 = unsupportedDateTimeField68.getRangeDurationField();
//        java.lang.String str72 = unsupportedDateTimeField68.toString();
//        org.joda.time.DurationField durationField73 = unsupportedDateTimeField68.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertNull(durationField70);
//        org.junit.Assert.assertNull(durationField71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "UnsupportedDateTimeField" + "'", str72.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNull(durationField73);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
//        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) 19, locale8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone10);
//        mutableDateTime11.setWeekOfWeekyear((int) '4');
//        mutableDateTime11.addMillis(2000);
//        mutableDateTime11.addMonths(0);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime11.yearOfCentury();
//        int int19 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime11.hourOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(property20);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute((int) '#', 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.Chronology chronology13 = gJChronology11.withUTC();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder10, chronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        long long28 = offsetDateTimeField25.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField29 = offsetDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) offsetDateTimeField25);
        java.util.Locale locale33 = null;
        long long34 = skipUndoDateTimeField30.set((long) 19, "10", locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder6.appendCenturyOfEra(2019, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendDayOfMonth((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder39.appendDayOfYear(32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 660019L + "'", long34 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusYears(2019);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withChronology(chronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusDays(2019);
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) 19, locale16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName((long) 19, locale22);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
//        mutableDateTime19.setZoneRetainFields(dateTimeZone20);
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime19.monthOfYear();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) mutableDateTime19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordinated Universal Time" + "'", str23.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3T16:00:00-08:00" + "'", str2.equals("1970-W01-3T16:00:00-08:00"));
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
//        long long18 = offsetDateTimeField13.roundHalfFloor((long) (byte) 1);
//        java.lang.String str19 = offsetDateTimeField13.toString();
//        mutableDateTime6.setRounding((org.joda.time.DateTimeField) offsetDateTimeField13, 5);
//        long long23 = offsetDateTimeField13.roundHalfEven(122401140100L);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime28 = dateTime24.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime24.withDurationAdded(readableDuration29, (int) (short) 10);
//        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
//        int[] intArray33 = null;
//        int int34 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate32, intArray33);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str19.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 122401140000L + "'", long23 == 122401140000L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 58 + "'", int34 == 58);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        long long72 = unsupportedDateTimeField68.add((-1138000L), (long) 9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale76 = null;
//        java.lang.String str77 = dateTimeZone74.getName((long) 19, locale76);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone78 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone74);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = dateTimeFormatter73.withZone(dateTimeZone74);
//        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property81 = dateTime80.weekyear();
//        org.joda.time.DateTime dateTime83 = dateTime80.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property84 = dateTime80.year();
//        org.joda.time.DateTime dateTime85 = dateTime80.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property86 = dateTime85.era();
//        org.joda.time.LocalDateTime localDateTime87 = dateTime85.toLocalDateTime();
//        boolean boolean88 = dateTimeZone74.isLocalDateTimeGap(localDateTime87);
//        int[] intArray90 = null;
//        try {
//            int[] intArray92 = unsupportedDateTimeField68.add((org.joda.time.ReadablePartial) localDateTime87, 0, intArray90, 28799);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1137991L) + "'", long72 == (-1137991L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Coordinated Universal Time" + "'", str77.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone78);
//        org.junit.Assert.assertNotNull(dateTimeFormatter79);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(dateTime85);
//        org.junit.Assert.assertNotNull(property86);
//        org.junit.Assert.assertNotNull(localDateTime87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField6 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology9 = mutableDateTime6.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime6.copy();
//        mutableDateTime10.addMonths((int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("19311", "19313");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("19311", "19313");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("19311", "19313");
        java.lang.String str10 = illegalFieldValueException9.getFieldName();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.Number number12 = illegalFieldValueException9.getUpperBound();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19311" + "'", str10.equals("19311"));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        boolean boolean6 = gJChronology2.equals((java.lang.Object) property5);
        org.joda.time.DateTime dateTime8 = property5.addToCopy((-10L));
        org.joda.time.DateTime.Property property9 = dateTime8.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(53);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekyear((-4200320));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        try {
//            long long70 = unsupportedDateTimeField68.roundFloor((long) (-4200320));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology2, locale3, (java.lang.Integer) 53);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.monthOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField6, 1975);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(2019);
//        int int9 = dateTime6.getHourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.getMutableDateTime();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property19 = dateTime17.secondOfDay();
//        java.lang.String str20 = property19.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        boolean boolean22 = mutableDateTime16.isSupported(dateTimeFieldType21);
//        dateTimeParserBucket13.saveField(dateTimeFieldType21, 0);
//        org.joda.time.DateTime.Property property25 = dateTime6.property(dateTimeFieldType21);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, (-292275054), 0, 21);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for secondOfDay must be in the range [0,21]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "57600" + "'", str20.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property25);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime11 = dateTime7.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.withDurationAdded(readableDuration12, (int) (short) 10);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        int int16 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate15);
        long long19 = offsetDateTimeField6.getDifferenceAsLong((-2018L), (long) 26);
        java.lang.String str20 = offsetDateTimeField6.toString();
        long long23 = offsetDateTimeField6.set((long) 59, "53");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str20.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3240059L + "'", long23 == 3240059L);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra((int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getMinuteOfHour();
//        org.joda.time.DateTime dateTime10 = dateTime6.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours(0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 100.0d);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
        dateTimeParserBucket5.setZone(dateTimeZone10);
        java.util.Locale locale12 = dateTimeParserBucket5.getLocale();
        long long15 = dateTimeParserBucket5.computeMillis(false, "BuddhistChronology[America/Los_Angeles]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59900L) + "'", long15 == (-59900L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2, (java.lang.Integer) 53);
        long long7 = dateTimeParserBucket4.computeMillis(false, "America/Los_Angeles");
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology9, locale10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.minuteOfHour();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology15, locale16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) -1);
        long long23 = offsetDateTimeField20.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField20.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) offsetDateTimeField20);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology9.weekyearOfCentury();
        dateTimeParserBucket4.saveField(dateTimeField26, (int) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800010L + "'", long7 == 28800010L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
//        long long18 = offsetDateTimeField13.roundHalfFloor((long) (byte) 1);
//        java.lang.String str19 = offsetDateTimeField13.toString();
//        mutableDateTime6.setRounding((org.joda.time.DateTimeField) offsetDateTimeField13, 5);
//        org.joda.time.DateTime dateTime22 = mutableDateTime6.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra(0);
//        org.joda.time.DateTime dateTime26 = dateTime24.withYear(0);
//        org.joda.time.DateTime dateTime28 = dateTime26.plusMillis((int) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str19.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getDurationField();
//        try {
//            java.lang.String str71 = unsupportedDateTimeField68.getAsText(25980000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.minus(readableDuration6);
//        int int8 = dateTime7.getDayOfWeek();
//        org.joda.time.LocalDate localDate9 = dateTime7.toLocalDate();
//        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-365T��:��:��" + "'", str10.equals("1969-365T��:��:��"));
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusMonths((int) '#');
//        int int6 = dateTime5.getWeekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getName((long) 19, locale10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone12);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.secondOfDay();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime13.hourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology17.millisOfDay();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime27 = dateTime23.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime23.minus(readableDuration28);
//        int int30 = dateTime29.getDayOfWeek();
//        org.joda.time.LocalDate localDate31 = dateTime29.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DurationField durationField37 = gregorianChronology33.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology39, locale40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
//        long long47 = offsetDateTimeField44.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField44.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, (org.joda.time.DateTimeField) offsetDateTimeField44);
//        java.util.Locale locale52 = null;
//        long long53 = skipUndoDateTimeField49.set((long) 19, "10", locale52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.weekyear();
//        org.joda.time.DateTime dateTime57 = dateTime54.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay58 = dateTime54.toYearMonthDay();
//        int[] intArray63 = new int[] { '4', 321, (short) 10 };
//        int[] intArray65 = skipUndoDateTimeField49.addWrapField((org.joda.time.ReadablePartial) yearMonthDay58, 0, intArray63, (int) (byte) 10);
//        gregorianChronology17.validate((org.joda.time.ReadablePartial) localDate31, intArray65);
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology17.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology69, locale70);
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology69.minuteOfHour();
//        org.joda.time.DurationField durationField73 = gregorianChronology69.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale76 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology75, locale76);
//        org.joda.time.DateTimeField dateTimeField78 = gregorianChronology75.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField78, (int) (byte) -1);
//        long long83 = offsetDateTimeField80.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField84 = offsetDateTimeField80.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology69, (org.joda.time.DateTimeField) offsetDateTimeField80);
//        java.util.Locale locale88 = null;
//        long long89 = skipUndoDateTimeField85.set((long) 19, "10", locale88);
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = skipUndoDateTimeField85.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, dateTimeFieldType90, 19);
//        mutableDateTime13.set(dateTimeFieldType90, (int) (byte) 0);
//        org.joda.time.DateTime.Property property95 = dateTime5.property(dateTimeFieldType90);
//        int int96 = property95.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 49 + "'", int6 == 49);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 660019L + "'", long53 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(yearMonthDay58);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(gregorianChronology75);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 660019L + "'", long89 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//        org.junit.Assert.assertNotNull(property95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        boolean boolean8 = dateTime0.isBefore((long) (byte) 100);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(100L, chronology10, locale11, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTime.Property property17 = dateTime15.secondOfDay();
//        java.lang.String str18 = property17.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
//        java.util.Locale locale21 = null;
//        dateTimeParserBucket14.saveField(dateTimeFieldType19, "+00:00:02.019", locale21);
//        org.joda.time.DateTime.Property property23 = dateTime0.property(dateTimeFieldType19);
//        org.joda.time.DateTime dateTime24 = dateTime0.withTimeAtStartOfDay();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime0.toLocalDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "57600" + "'", str18.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime14 = property11.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int21 = fixedDateTimeZone19.getStandardOffset(1560342124707L);
        mutableDateTime14.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology23 = gregorianChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        long long25 = fixedDateTimeZone19.previousTransition((long) 10);
        long long27 = fixedDateTimeZone19.nextTransition((long) 2);
        long long29 = dateTimeZone3.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone19, (long) 1439);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:02.019" + "'", str5.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3448L + "'", long29 == 3448L);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
//        long long18 = offsetDateTimeField13.roundHalfFloor((long) (byte) 1);
//        java.lang.String str19 = offsetDateTimeField13.toString();
//        mutableDateTime6.setRounding((org.joda.time.DateTimeField) offsetDateTimeField13, 5);
//        org.joda.time.DateTime dateTime22 = mutableDateTime6.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra(0);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str19.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.getID();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime8.minus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str17 = dateTimeZone16.toString();
        org.joda.time.DateTime dateTime18 = dateTime14.withZoneRetainFields(dateTimeZone16);
        try {
            org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime18, 57600000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57600000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:02.019" + "'", str5.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTime dateTime5 = dateTime0.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime5.era();
//        org.joda.time.LocalDateTime localDateTime7 = dateTime5.toLocalDateTime();
//        int int8 = dateTime5.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, 1969);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19690L + "'", long2 == 19690L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) ' ', 1, 1, 0, (int) (byte) 0, 0, dateTimeZone7);
        int int10 = dateTime9.getYearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
        org.joda.time.DateMidnight dateMidnight12 = dateTime9.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:02.019" + "'", str8.equals("+00:00:02.019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField17.getType();
        java.lang.String str23 = skipUndoDateTimeField17.toString();
        boolean boolean24 = skipUndoDateTimeField17.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str23.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendOptional(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYear(637);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(2, 155);
        try {
            org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder22.toPrinter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        boolean boolean10 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendFractionOfDay(0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendHourOfDay(32);
        boolean boolean24 = iSOChronology4.equals((java.lang.Object) dateTimeFormatterBuilder12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder12.appendWeekyear(6, 55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder12.appendYearOfCentury(55, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[+00:00:02.019]" + "'", str5.equals("ISOChronology[+00:00:02.019]"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
//        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.millisOfDay();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime12 = dateTime8.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime8.minus(readableDuration13);
//        int int15 = dateTime14.getDayOfWeek();
//        org.joda.time.LocalDate localDate16 = dateTime14.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.minuteOfHour();
//        org.joda.time.DurationField durationField22 = gregorianChronology18.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology24, locale25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (byte) -1);
//        long long32 = offsetDateTimeField29.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField33 = offsetDateTimeField29.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology18, (org.joda.time.DateTimeField) offsetDateTimeField29);
//        java.util.Locale locale37 = null;
//        long long38 = skipUndoDateTimeField34.set((long) 19, "10", locale37);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay43 = dateTime39.toYearMonthDay();
//        int[] intArray48 = new int[] { '4', 321, (short) 10 };
//        int[] intArray50 = skipUndoDateTimeField34.addWrapField((org.joda.time.ReadablePartial) yearMonthDay43, 0, intArray48, (int) (byte) 10);
//        gregorianChronology2.validate((org.joda.time.ReadablePartial) localDate16, intArray50);
//        java.util.Locale locale52 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket(660019L, (org.joda.time.Chronology) gregorianChronology2, locale52, (java.lang.Integer) 2019);
//        org.joda.time.DurationField durationField55 = gregorianChronology2.weekyears();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 660019L + "'", long38 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(yearMonthDay43);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(durationField55);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        try {
//            long long70 = unsupportedDateTimeField68.roundHalfEven((long) (-292275035));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 100);
        int int14 = offsetDateTimeField6.getMaximumValue();
        int int16 = offsetDateTimeField6.getLeapAmount(1560342120000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 58 + "'", int14 == 58);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int11 = fixedDateTimeZone9.getStandardOffset(1560342124707L);
        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        mutableDateTime4.addHours(4);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime4.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime17 = property15.add((-1L));
        mutableDateTime17.setDate(660019L);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            mutableDateTime17.add(durationFieldType20, 1990);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationFieldType durationFieldType69 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField70 = new org.joda.time.field.DecoratedDurationField(durationField67, durationFieldType69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        try {
//            long long70 = unsupportedDateTimeField68.roundHalfEven((long) 26005753);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField13.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField13);
        java.util.Locale locale21 = null;
        long long22 = skipUndoDateTimeField18.set((long) 19, "10", locale21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField18);
        int int25 = skipUndoDateTimeField18.get(1975L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 660019L + "'", long22 == 660019L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.yearOfEra();
//        boolean boolean6 = mutableDateTime0.isBefore(2040019L);
//        mutableDateTime0.addMinutes((int) (byte) 1);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = unsupportedDateTimeField68.getType();
//        java.lang.String str71 = unsupportedDateTimeField68.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "UnsupportedDateTimeField" + "'", str71.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology3, locale4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.minuteOfHour();
//        org.joda.time.DurationField durationField7 = gregorianChronology3.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology9, locale10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) -1);
//        long long17 = offsetDateTimeField14.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField14.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) offsetDateTimeField14);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
//        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime20.toYearMonthDay();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay24, (int) (byte) 0, locale26);
//        boolean boolean28 = skipUndoDateTimeField19.isLenient();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime31 = dateTime29.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime33 = dateTime29.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime29.minus(readableDuration34);
//        int int36 = dateTime35.getDayOfWeek();
//        org.joda.time.LocalDate localDate37 = dateTime35.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology40, locale41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.minuteOfHour();
//        org.joda.time.DurationField durationField44 = gregorianChronology40.weekyears();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology40.millisOfDay();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime48 = dateTime46.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime50 = dateTime46.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime46.minus(readableDuration51);
//        int int53 = dateTime52.getDayOfWeek();
//        org.joda.time.LocalDate localDate54 = dateTime52.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology56, locale57);
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology56.minuteOfHour();
//        org.joda.time.DurationField durationField60 = gregorianChronology56.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale63 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology62, locale63);
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology62.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, (int) (byte) -1);
//        long long70 = offsetDateTimeField67.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField71 = offsetDateTimeField67.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology56, (org.joda.time.DateTimeField) offsetDateTimeField67);
//        java.util.Locale locale75 = null;
//        long long76 = skipUndoDateTimeField72.set((long) 19, "10", locale75);
//        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property78 = dateTime77.weekyear();
//        org.joda.time.DateTime dateTime80 = dateTime77.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay81 = dateTime77.toYearMonthDay();
//        int[] intArray86 = new int[] { '4', 321, (short) 10 };
//        int[] intArray88 = skipUndoDateTimeField72.addWrapField((org.joda.time.ReadablePartial) yearMonthDay81, 0, intArray86, (int) (byte) 10);
//        gregorianChronology40.validate((org.joda.time.ReadablePartial) localDate54, intArray88);
//        int[] intArray91 = skipUndoDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) localDate37, 0, intArray88, 321);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(durationField60);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 660019L + "'", long76 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(yearMonthDay81);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertNotNull(intArray88);
//        org.junit.Assert.assertNotNull(intArray91);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.util.TimeZone timeZone18 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime21 = property20.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime23 = property20.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int30 = fixedDateTimeZone28.getStandardOffset(1560342124707L);
        mutableDateTime23.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        mutableDateTime23.addHours(4);
        mutableDateTime23.setWeekOfWeekyear(4);
        try {
            org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime23, 155);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 155");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.lang.String str2 = dateTimeFormatter0.print(122401140100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Saturday, November 17, 1973" + "'", str2.equals("Saturday, November 17, 1973"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("12");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        mutableDateTime6.addMillis(2000);
//        mutableDateTime6.addMonths(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime6.add(readablePeriod13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        int int7 = mutableDateTime6.getRoundingMode();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = fixedDateTimeZone12.getName(120052L, locale14);
//        long long18 = fixedDateTimeZone12.convertLocalToUTC((long) 2000, true);
//        int int20 = fixedDateTimeZone12.getOffsetFromLocal(0L);
//        mutableDateTime6.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1990L + "'", long18 == 1990L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfSecond(55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra(20, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2, (long) 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology14, locale15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.DurationField durationField18 = gregorianChronology14.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        long long28 = offsetDateTimeField25.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField29 = offsetDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) offsetDateTimeField25);
        java.util.Locale locale33 = null;
        long long34 = skipUndoDateTimeField30.set((long) 19, "10", locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder6.appendCenturyOfEra(2019, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendTimeZoneName();
        boolean boolean49 = dateTimeFormatterBuilder47.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder47.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder51.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter58 = dateTimeFormatterBuilder57.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser60 = dateTimeFormatter59.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter58, dateTimeParser60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder44.appendOptional(dateTimeParser60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder39.append(dateTimeParser60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 660019L + "'", long34 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimePrinter58);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeParser60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.addWrapField(1969);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
//        long long5 = property1.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) 19, locale8);
//        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(53);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology11.millisOfDay();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime21 = dateTime17.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime17.minus(readableDuration22);
//        int int24 = dateTime23.getDayOfWeek();
//        org.joda.time.LocalDate localDate25 = dateTime23.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology27, locale28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.minuteOfHour();
//        org.joda.time.DurationField durationField31 = gregorianChronology27.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
//        long long41 = offsetDateTimeField38.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField42 = offsetDateTimeField38.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, (org.joda.time.DateTimeField) offsetDateTimeField38);
//        java.util.Locale locale46 = null;
//        long long47 = skipUndoDateTimeField43.set((long) 19, "10", locale46);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property49 = dateTime48.weekyear();
//        org.joda.time.DateTime dateTime51 = dateTime48.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay52 = dateTime48.toYearMonthDay();
//        int[] intArray57 = new int[] { '4', 321, (short) 10 };
//        int[] intArray59 = skipUndoDateTimeField43.addWrapField((org.joda.time.ReadablePartial) yearMonthDay52, 0, intArray57, (int) (byte) 10);
//        gregorianChronology11.validate((org.joda.time.ReadablePartial) localDate25, intArray59);
//        java.util.Locale locale61 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(660019L, (org.joda.time.Chronology) gregorianChronology11, locale61, (java.lang.Integer) 2019);
//        java.lang.String str64 = gregorianChronology11.toString();
//        org.joda.time.DateTime dateTime65 = dateTime8.withChronology((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTime.Property property66 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration67 = null;
//        org.joda.time.DateTime dateTime68 = dateTime8.plus(readableDuration67);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 660019L + "'", long47 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(yearMonthDay52);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "GregorianChronology[UTC]" + "'", str64.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTime68);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime21.toYearMonthDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay25, (int) (byte) 0, locale27);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology2.getZone();
        org.joda.time.Instant instant31 = gJChronology2.getGregorianCutover();
        org.joda.time.DurationField durationField32 = gJChronology2.months();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(durationField32);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        boolean boolean8 = dateTime0.isBefore((long) (byte) 100);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(100L, chronology10, locale11, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTime.Property property17 = dateTime15.secondOfDay();
//        java.lang.String str18 = property17.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
//        java.util.Locale locale21 = null;
//        dateTimeParserBucket14.saveField(dateTimeFieldType19, "+00:00:02.019", locale21);
//        org.joda.time.DateTime.Property property23 = dateTime0.property(dateTimeFieldType19);
//        org.joda.time.DateTime dateTime24 = dateTime0.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "57600" + "'", str18.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology19.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
        org.joda.time.DurationField durationField30 = gregorianChronology26.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (byte) -1);
        long long40 = offsetDateTimeField37.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeField) offsetDateTimeField37);
        java.util.Locale locale45 = null;
        long long46 = skipUndoDateTimeField42.set((long) 19, "10", locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField42.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField42.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField50 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType48, 19329);
        int int51 = remainderDateTimeField50.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, (org.joda.time.DateTimeField) remainderDateTimeField50);
        long long54 = remainderDateTimeField50.roundHalfCeiling((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 660019L + "'", long46 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime21.toYearMonthDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay25, (int) (byte) 0, locale27);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        java.lang.String str30 = gJChronology2.toString();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime33 = property32.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime35 = property32.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int42 = fixedDateTimeZone40.getStandardOffset(1560342124707L);
        mutableDateTime35.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.Chronology chronology44 = gJChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        try {
            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) chronology44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str30.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(chronology44);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.hourOfDay();
//        mutableDateTime0.setSecondOfDay(52);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime6.getRoundingField();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        int int10 = dateTime9.getWeekyear();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTime.Property property12 = dateTime9.minuteOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime9.minusWeeks(1);
//        mutableDateTime6.setMillis((org.joda.time.ReadableInstant) dateTime9);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime9);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.millisOfDay();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime10.minus(readableDuration15);
//        int int17 = dateTime16.getDayOfWeek();
//        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale21 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
//        org.joda.time.DurationField durationField24 = gregorianChronology20.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) -1);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField35 = offsetDateTimeField31.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, (org.joda.time.DateTimeField) offsetDateTimeField31);
//        java.util.Locale locale39 = null;
//        long long40 = skipUndoDateTimeField36.set((long) 19, "10", locale39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property42 = dateTime41.weekyear();
//        org.joda.time.DateTime dateTime44 = dateTime41.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime41.toYearMonthDay();
//        int[] intArray50 = new int[] { '4', 321, (short) 10 };
//        int[] intArray52 = skipUndoDateTimeField36.addWrapField((org.joda.time.ReadablePartial) yearMonthDay45, 0, intArray50, (int) (byte) 10);
//        gregorianChronology4.validate((org.joda.time.ReadablePartial) localDate18, intArray52);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology4.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology56, locale57);
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology56.minuteOfHour();
//        org.joda.time.DurationField durationField60 = gregorianChronology56.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale63 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology62, locale63);
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology62.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, (int) (byte) -1);
//        long long70 = offsetDateTimeField67.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField71 = offsetDateTimeField67.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology56, (org.joda.time.DateTimeField) offsetDateTimeField67);
//        java.util.Locale locale75 = null;
//        long long76 = skipUndoDateTimeField72.set((long) 19, "10", locale75);
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = skipUndoDateTimeField72.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, dateTimeFieldType77, 19);
//        org.joda.time.DateTime.Property property80 = dateTime0.property(dateTimeFieldType77);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, (java.lang.Number) (-60431501221900L), (java.lang.Number) 2019, (java.lang.Number) 2019);
//        java.lang.String str85 = illegalFieldValueException84.getFieldName();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 660019L + "'", long40 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(durationField60);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 660019L + "'", long76 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "minuteOfHour" + "'", str85.equals("minuteOfHour"));
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        boolean boolean8 = dateTime0.isBefore((long) (byte) 100);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(100L, chronology10, locale11, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTime.Property property17 = dateTime15.secondOfDay();
//        java.lang.String str18 = property17.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
//        java.util.Locale locale21 = null;
//        dateTimeParserBucket14.saveField(dateTimeFieldType19, "+00:00:02.019", locale21);
//        org.joda.time.DateTime.Property property23 = dateTime0.property(dateTimeFieldType19);
//        org.joda.time.DateTime dateTime25 = dateTime0.plusSeconds(322);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "57600" + "'", str18.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
//        int int11 = fixedDateTimeZone9.getStandardOffset(1560342124707L);
//        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        mutableDateTime4.addHours(4);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime4.yearOfEra();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime20 = dateTime18.withMillisOfSecond(0);
//        long long21 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfCentury((int) '4');
//        long long24 = property15.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 16L + "'", long24 == 16L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 1, 0L);
//        long long14 = offsetDateTimeField9.roundHalfFloor((long) (byte) 1);
//        java.lang.String str15 = offsetDateTimeField9.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) -1);
//        long long24 = offsetDateTimeField22.roundHalfFloor((long) (byte) 0);
//        int int26 = offsetDateTimeField22.get((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone30.getName((long) 19, locale32);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName((long) 19, locale38);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone36);
//        mutableDateTime35.setZoneRetainFields(dateTimeZone36);
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime35.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale45 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology44, locale45);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology44.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology44.getZone();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology44.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale52 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology51, locale52);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.minuteOfHour();
//        org.joda.time.DurationField durationField55 = gregorianChronology51.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology57, locale58);
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) (byte) -1);
//        long long65 = offsetDateTimeField62.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField66 = offsetDateTimeField62.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology51, (org.joda.time.DateTimeField) offsetDateTimeField62);
//        java.util.Locale locale70 = null;
//        long long71 = skipUndoDateTimeField67.set((long) 19, "10", locale70);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = skipUndoDateTimeField67.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField67.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField(dateTimeField49, dateTimeFieldType73, 19329);
//        org.joda.time.Chronology chronology78 = null;
//        java.util.Locale locale79 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket82 = new org.joda.time.format.DateTimeParserBucket(100L, chronology78, locale79, (java.lang.Integer) 2019, 0);
//        boolean boolean84 = dateTimeParserBucket82.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone87 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket82.setZone(dateTimeZone87);
//        java.util.Locale locale89 = dateTimeParserBucket82.getLocale();
//        java.lang.String str90 = remainderDateTimeField75.getAsText(31, locale89);
//        java.util.Calendar calendar91 = mutableDateTime35.toCalendar(locale89);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter92 = dateTimeFormatter28.withLocale(locale89);
//        java.lang.String str93 = offsetDateTimeField22.getAsShortText((int) (byte) 0, locale89);
//        int int94 = offsetDateTimeField9.getMaximumTextLength(locale89);
//        java.lang.String str95 = property2.getAsText(locale89);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str15.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordinated Universal Time" + "'", str33.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordinated Universal Time" + "'", str39.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 660019L + "'", long71 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone87);
//        org.junit.Assert.assertNotNull(locale89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "31" + "'", str90.equals("31"));
//        org.junit.Assert.assertNotNull(calendar91);
//        org.junit.Assert.assertNotNull(dateTimeFormatter92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "0" + "'", str93.equals("0"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2 + "'", int94 == 2);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "57600" + "'", str95.equals("57600"));
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(3);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMonths((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) 19, locale11);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology16, locale17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) -1);
//        long long24 = offsetDateTimeField21.getDifferenceAsLong((long) 1, 0L);
//        long long26 = offsetDateTimeField21.roundHalfFloor((long) (byte) 1);
//        java.lang.String str27 = offsetDateTimeField21.toString();
//        mutableDateTime14.setRounding((org.joda.time.DateTimeField) offsetDateTimeField21, 5);
//        int int30 = property7.compareTo((org.joda.time.ReadableInstant) mutableDateTime14);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime14.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) 19, locale36);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone38 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone34);
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName((long) 19, locale42);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone44 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        mutableDateTime39.setZoneRetainFields(dateTimeZone40);
//        org.joda.time.MutableDateTime.Property property46 = mutableDateTime39.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology48, locale49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology48.getZone();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology48.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale56 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology55, locale56);
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.minuteOfHour();
//        org.joda.time.DurationField durationField59 = gregorianChronology55.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale62 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology61, locale62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology61.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, (int) (byte) -1);
//        long long69 = offsetDateTimeField66.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField70 = offsetDateTimeField66.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology55, (org.joda.time.DateTimeField) offsetDateTimeField66);
//        java.util.Locale locale74 = null;
//        long long75 = skipUndoDateTimeField71.set((long) 19, "10", locale74);
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = skipUndoDateTimeField71.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = skipUndoDateTimeField71.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dateTimeField53, dateTimeFieldType77, 19329);
//        org.joda.time.Chronology chronology82 = null;
//        java.util.Locale locale83 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(100L, chronology82, locale83, (java.lang.Integer) 2019, 0);
//        boolean boolean88 = dateTimeParserBucket86.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone91 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket86.setZone(dateTimeZone91);
//        java.util.Locale locale93 = dateTimeParserBucket86.getLocale();
//        java.lang.String str94 = remainderDateTimeField79.getAsText(31, locale93);
//        java.util.Calendar calendar95 = mutableDateTime39.toCalendar(locale93);
//        try {
//            java.lang.String str96 = mutableDateTime14.toString("Coordinated Universal Time", locale93);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str27.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Coordinated Universal Time" + "'", str37.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Coordinated Universal Time" + "'", str43.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 660019L + "'", long75 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone91);
//        org.junit.Assert.assertNotNull(locale93);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "31" + "'", str94.equals("31"));
//        org.junit.Assert.assertNotNull(calendar95);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        int[] intArray31 = new int[] { '4', 321, (short) 10 };
        int[] intArray33 = skipUndoDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay26, 0, intArray31, (int) (byte) 10);
        boolean boolean34 = skipUndoDateTimeField17.isSupported();
        boolean boolean35 = skipUndoDateTimeField17.isSupported();
        long long37 = skipUndoDateTimeField17.remainder((long) (short) 1);
        int int38 = skipUndoDateTimeField17.getMaximumValue();
        int int39 = skipUndoDateTimeField17.getMaximumValue();
        long long41 = skipUndoDateTimeField17.remainder((long) 86399);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 58 + "'", int38 == 58);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 58 + "'", int39 == 58);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 26399L + "'", long41 == 26399L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        try {
            long long13 = gJChronology4.getDateTimeMillis((int) (short) 0, 0, 31, 55, 100, 69, 155);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        mutableDateTime6.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime6.secondOfMinute();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        mutableDateTime6.add(readablePeriod14, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
//        org.joda.time.DurationField durationField30 = gregorianChronology26.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (byte) -1);
//        long long40 = offsetDateTimeField37.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeField) offsetDateTimeField37);
//        java.util.Locale locale45 = null;
//        long long46 = skipUndoDateTimeField42.set((long) 19, "10", locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField42.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField42.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField50 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType48, 19329);
//        org.joda.time.Chronology chronology53 = null;
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(100L, chronology53, locale54, (java.lang.Integer) 2019, 0);
//        boolean boolean59 = dateTimeParserBucket57.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket57.setZone(dateTimeZone62);
//        java.util.Locale locale64 = dateTimeParserBucket57.getLocale();
//        java.lang.String str65 = remainderDateTimeField50.getAsText(31, locale64);
//        try {
//            java.lang.String str66 = mutableDateTime6.toString("1970-W01-3", locale64);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 660019L + "'", long46 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(locale64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "31" + "'", str65.equals("31"));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology22, locale23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.minuteOfHour();
        org.joda.time.DurationField durationField26 = gregorianChronology22.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology28, locale29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) -1);
        long long36 = offsetDateTimeField33.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField37 = offsetDateTimeField33.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, (org.joda.time.DateTimeField) offsetDateTimeField33);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
        org.joda.time.DateTime dateTime42 = dateTime39.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime39.toYearMonthDay();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipUndoDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay43, (int) (byte) 0, locale45);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology20, (org.joda.time.DateTimeField) skipUndoDateTimeField38);
        org.joda.time.DateTimeZone dateTimeZone48 = gJChronology20.getZone();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str51 = dateTimeZone50.getID();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property53 = dateTime52.weekyear();
        org.joda.time.DateTime dateTime55 = dateTime52.withYearOfEra((int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DurationField durationField57 = gJChronology56.seconds();
        org.joda.time.DateTimeZone dateTimeZone58 = gJChronology56.getZone();
        long long60 = dateTimeZone48.getMillisKeepLocal(dateTimeZone58, 31L);
        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance(chronology17, dateTimeZone58);
        try {
            long long67 = zonedChronology61.getDateTimeMillis((long) 'a', 1, 69, (int) '#', 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "+00:00:02.019" + "'", str51.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-28801988L) + "'", long60 == (-28801988L));
        org.junit.Assert.assertNotNull(zonedChronology61);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.hourOfDay();
//        org.joda.time.DurationField durationField9 = property8.getLeapDurationField();
//        int int10 = property8.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNull(durationField9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime21.toYearMonthDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay25, (int) (byte) 0, locale27);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        java.lang.String str30 = gJChronology2.toString();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime33 = property32.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime35 = property32.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int42 = fixedDateTimeZone40.getStandardOffset(1560342124707L);
        mutableDateTime35.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.Chronology chronology44 = gJChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.DateTimeField dateTimeField45 = gJChronology2.hourOfHalfday();
        java.lang.String str46 = gJChronology2.toString();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str30.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str46.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.Instant instant1 = dateTime0.toInstant();
        boolean boolean2 = instant1.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        long long6 = cachedDateTimeZone4.previousTransition(0L);
//        long long8 = cachedDateTimeZone4.previousTransition((long) (short) 100);
//        java.lang.String str10 = cachedDateTimeZone4.getName((-2340001L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        org.joda.time.DateTime dateTime8 = dateTime0.withMillisOfSecond((int) (short) 10);
//        int int9 = dateTime0.getEra();
//        int int10 = dateTime0.getDayOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime0.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        try {
            long long8 = gJChronology2.getDateTimeMillis(28799, 31, (-1), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        mutableDateTime6.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime6.monthOfYear();
//        try {
//            mutableDateTime6.setDateTime(0, 637, 18, 86399, (-292275054), 16, (-292275054));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
//        long long18 = offsetDateTimeField13.roundHalfFloor((long) (byte) 1);
//        java.lang.String str19 = offsetDateTimeField13.toString();
//        mutableDateTime6.setRounding((org.joda.time.DateTimeField) offsetDateTimeField13, 5);
//        org.joda.time.DateTime dateTime22 = mutableDateTime6.toDateTime();
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime6.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str19.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 19, locale4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        mutableDateTime7.setWeekOfWeekyear((int) '4');
//        org.joda.time.Chronology chronology10 = mutableDateTime7.getChronology();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 322, chronology10, locale11, (java.lang.Integer) 52);
//        long long15 = dateTimeParserBucket13.computeMillis(false);
//        java.lang.Object obj16 = dateTimeParserBucket13.saveState();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 322L + "'", long15 == 322L);
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1990);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime2 = property1.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int11 = fixedDateTimeZone9.getStandardOffset(1560342124707L);
        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        mutableDateTime4.addMillis(100);
        try {
            mutableDateTime4.setTime(55, 19329, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        boolean boolean6 = dateTime5.isBeforeNow();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours(57600000);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        boolean boolean10 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendFractionOfDay(0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendHourOfDay(32);
        boolean boolean24 = iSOChronology4.equals((java.lang.Object) dateTimeFormatterBuilder12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder12.appendWeekyear(6, 55);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property29 = dateTime28.weekyear();
        org.joda.time.DateTime dateTime31 = property29.addWrapFieldToCopy(3);
        java.lang.Object obj32 = null;
        boolean boolean33 = property29.equals(obj32);
        org.joda.time.DateTime dateTime35 = property29.addToCopy(26);
        org.joda.time.DateTime.Property property36 = dateTime35.weekyear();
        org.joda.time.DurationField durationField37 = property36.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType38, 321, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendCenturyOfEra(52, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[+00:00:02.019]" + "'", str5.equals("ISOChronology[+00:00:02.019]"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        int[] intArray31 = new int[] { '4', 321, (short) 10 };
        int[] intArray33 = skipUndoDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay26, 0, intArray31, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, (int) (byte) 1);
        long long37 = offsetDateTimeField35.roundFloor((long) 21);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField17.getType();
        java.lang.String str23 = skipUndoDateTimeField17.toString();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField17.getAsShortText(0L, locale25);
        long long28 = skipUndoDateTimeField17.roundHalfFloor((long) (-292275054));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str23.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-1" + "'", str26.equals("-1"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-292260000L) + "'", long28 == (-292260000L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfDay((int) (short) 10, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay(637);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) -1);
        long long25 = offsetDateTimeField22.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField26 = offsetDateTimeField22.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) offsetDateTimeField22);
        java.util.Locale locale30 = null;
        long long31 = skipUndoDateTimeField27.set((long) 19, "10", locale30);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property33 = dateTime32.weekyear();
        org.joda.time.DateTime dateTime35 = dateTime32.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime32.toYearMonthDay();
        int[] intArray41 = new int[] { '4', 321, (short) 10 };
        int[] intArray43 = skipUndoDateTimeField27.addWrapField((org.joda.time.ReadablePartial) yearMonthDay36, 0, intArray41, (int) (byte) 10);
        int int45 = skipUndoDateTimeField27.get((-210866500800000L));
        java.lang.String str46 = skipUndoDateTimeField27.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField27.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType47, 425760, (int) (byte) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap51 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap51);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(150);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 660019L + "'", long31 == 660019L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str46.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long8 = offsetDateTimeField6.roundHalfFloor((long) (byte) 0);
        int int10 = offsetDateTimeField6.get((long) 'a');
        int int13 = offsetDateTimeField6.getDifference(1560342114588L, 2000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 26005701 + "'", int13 == 26005701);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
//        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
//        java.util.Locale locale20 = null;
//        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField17.getType();
//        int int23 = skipUndoDateTimeField17.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField17.getType();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField17.getAsShortText(58, locale26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        int int31 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DurationField durationField37 = gregorianChronology33.weekyears();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology33.millisOfDay();
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime41 = dateTime39.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime43 = dateTime39.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime39.minus(readableDuration44);
//        int int46 = dateTime45.getDayOfWeek();
//        org.joda.time.LocalDate localDate47 = dateTime45.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology49, locale50);
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.minuteOfHour();
//        org.joda.time.DurationField durationField53 = gregorianChronology49.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale56 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology55, locale56);
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, (int) (byte) -1);
//        long long63 = offsetDateTimeField60.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField64 = offsetDateTimeField60.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology49, (org.joda.time.DateTimeField) offsetDateTimeField60);
//        java.util.Locale locale68 = null;
//        long long69 = skipUndoDateTimeField65.set((long) 19, "10", locale68);
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property71 = dateTime70.weekyear();
//        org.joda.time.DateTime dateTime73 = dateTime70.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay74 = dateTime70.toYearMonthDay();
//        int[] intArray79 = new int[] { '4', 321, (short) 10 };
//        int[] intArray81 = skipUndoDateTimeField65.addWrapField((org.joda.time.ReadablePartial) yearMonthDay74, 0, intArray79, (int) (byte) 10);
//        gregorianChronology33.validate((org.joda.time.ReadablePartial) localDate47, intArray81);
//        int[] intArray84 = gregorianChronology29.get((org.joda.time.ReadablePartial) localDate47, (long) '#');
//        java.lang.String str85 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate47);
//        int int86 = skipUndoDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate47);
//        java.lang.String str87 = skipUndoDateTimeField17.getName();
//        org.joda.time.DurationField durationField88 = skipUndoDateTimeField17.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "58" + "'", str27.equals("58"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 660019L + "'", long69 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(yearMonthDay74);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertNotNull(intArray84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "1970-W01-3" + "'", str85.equals("1970-W01-3"));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 58 + "'", int86 == 58);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "minuteOfHour" + "'", str87.equals("minuteOfHour"));
//        org.junit.Assert.assertNull(durationField88);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
//        java.lang.String str8 = property7.getAsString();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add((long) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology13, locale14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
//        long long20 = offsetDateTimeField18.roundHalfFloor((long) (byte) 0);
//        int int22 = offsetDateTimeField18.get((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getName((long) 19, locale28);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = dateTimeZone32.getName((long) 19, locale34);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        mutableDateTime31.setZoneRetainFields(dateTimeZone32);
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime31.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology40, locale41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology40.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale48 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket49 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology47, locale48);
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.minuteOfHour();
//        org.joda.time.DurationField durationField51 = gregorianChronology47.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology53, locale54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (byte) -1);
//        long long61 = offsetDateTimeField58.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField62 = offsetDateTimeField58.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, (org.joda.time.DateTimeField) offsetDateTimeField58);
//        java.util.Locale locale66 = null;
//        long long67 = skipUndoDateTimeField63.set((long) 19, "10", locale66);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = skipUndoDateTimeField63.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = skipUndoDateTimeField63.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dateTimeField45, dateTimeFieldType69, 19329);
//        org.joda.time.Chronology chronology74 = null;
//        java.util.Locale locale75 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket78 = new org.joda.time.format.DateTimeParserBucket(100L, chronology74, locale75, (java.lang.Integer) 2019, 0);
//        boolean boolean80 = dateTimeParserBucket78.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone83 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket78.setZone(dateTimeZone83);
//        java.util.Locale locale85 = dateTimeParserBucket78.getLocale();
//        java.lang.String str86 = remainderDateTimeField71.getAsText(31, locale85);
//        java.util.Calendar calendar87 = mutableDateTime31.toCalendar(locale85);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter88 = dateTimeFormatter24.withLocale(locale85);
//        java.lang.String str89 = offsetDateTimeField18.getAsShortText((int) (byte) 0, locale85);
//        org.joda.time.MutableDateTime mutableDateTime90 = property7.set("23", locale85);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "57600" + "'", str8.equals("57600"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Coordinated Universal Time" + "'", str29.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordinated Universal Time" + "'", str35.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 660019L + "'", long67 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFieldType69);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone83);
//        org.junit.Assert.assertNotNull(locale85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "31" + "'", str86.equals("31"));
//        org.junit.Assert.assertNotNull(calendar87);
//        org.junit.Assert.assertNotNull(dateTimeFormatter88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "0" + "'", str89.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime90);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(150, 69, 3, 1970, 1975, 1005108, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(53);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology11.millisOfDay();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime21 = dateTime17.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime17.minus(readableDuration22);
//        int int24 = dateTime23.getDayOfWeek();
//        org.joda.time.LocalDate localDate25 = dateTime23.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology27, locale28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.minuteOfHour();
//        org.joda.time.DurationField durationField31 = gregorianChronology27.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
//        long long41 = offsetDateTimeField38.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField42 = offsetDateTimeField38.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, (org.joda.time.DateTimeField) offsetDateTimeField38);
//        java.util.Locale locale46 = null;
//        long long47 = skipUndoDateTimeField43.set((long) 19, "10", locale46);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property49 = dateTime48.weekyear();
//        org.joda.time.DateTime dateTime51 = dateTime48.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay52 = dateTime48.toYearMonthDay();
//        int[] intArray57 = new int[] { '4', 321, (short) 10 };
//        int[] intArray59 = skipUndoDateTimeField43.addWrapField((org.joda.time.ReadablePartial) yearMonthDay52, 0, intArray57, (int) (byte) 10);
//        gregorianChronology11.validate((org.joda.time.ReadablePartial) localDate25, intArray59);
//        java.util.Locale locale61 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(660019L, (org.joda.time.Chronology) gregorianChronology11, locale61, (java.lang.Integer) 2019);
//        java.lang.String str64 = gregorianChronology11.toString();
//        org.joda.time.DateTime dateTime65 = dateTime8.withChronology((org.joda.time.Chronology) gregorianChronology11);
//        java.util.Locale locale67 = null;
//        try {
//            java.lang.String str68 = dateTime8.toString("1970-W01-3", locale67);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 660019L + "'", long47 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(yearMonthDay52);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "GregorianChronology[UTC]" + "'", str64.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime65);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long14 = offsetDateTimeField6.add((long) (short) 100, 2040019L);
        int int17 = offsetDateTimeField6.getDifference(1975L, (long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 122401140100L + "'", long14 == 122401140100L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone11);
//        mutableDateTime12.setWeekOfWeekyear((int) '4');
//        boolean boolean16 = mutableDateTime12.isAfter((long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.era();
//        mutableDateTime12.setRounding(dateTimeField21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        long long26 = dateTimeZone23.convertLocalToUTC((long) (byte) -1, true);
//        mutableDateTime12.setZoneRetainFields(dateTimeZone23);
//        try {
//            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(32, (int) (byte) 100, 1975, 26005753, 365, 2019, dateTimeZone23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26005753 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long8 = offsetDateTimeField6.roundHalfFloor((long) (byte) 0);
        int int10 = offsetDateTimeField6.get((long) 'a');
        int int12 = offsetDateTimeField6.get((long) 26);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendOptional(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYear(637);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology21, locale22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology21.getZone();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology28, locale29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.minuteOfHour();
        org.joda.time.DurationField durationField32 = gregorianChronology28.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology34, locale35);
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) -1);
        long long42 = offsetDateTimeField39.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField43 = offsetDateTimeField39.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, (org.joda.time.DateTimeField) offsetDateTimeField39);
        java.util.Locale locale47 = null;
        long long48 = skipUndoDateTimeField44.set((long) 19, "10", locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipUndoDateTimeField44.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField44.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField26, dateTimeFieldType50, 19329);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField54 = gJChronology53.hourOfHalfday();
        org.joda.time.DurationField durationField55 = gJChronology53.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField56 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType50, durationField55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder19.appendDecimal(dateTimeFieldType50, (int) (short) 100, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 660019L + "'", long48 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        mutableDateTime6.addMillis(2000);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime6.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField(321);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun 12, 2019 12:09:28 PM", (java.lang.Number) 4, number2, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("19311", "19313");
        java.lang.String str9 = illegalFieldValueException8.getFieldName();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19311" + "'", str9.equals("19311"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        boolean boolean8 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder3.appendOptional(dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("19342");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 19342");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        java.lang.String str3 = property2.getAsString();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property2.getAsText(locale4);
//        java.lang.String str6 = property2.getAsString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "57600" + "'", str3.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600" + "'", str5.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "57600" + "'", str6.equals("57600"));
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology19.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
        org.joda.time.DurationField durationField30 = gregorianChronology26.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (byte) -1);
        long long40 = offsetDateTimeField37.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeField) offsetDateTimeField37);
        java.util.Locale locale45 = null;
        long long46 = skipUndoDateTimeField42.set((long) 19, "10", locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField42.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField42.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField50 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType48, 19329);
        int int51 = remainderDateTimeField50.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, (org.joda.time.DateTimeField) remainderDateTimeField50);
        int int53 = remainderDateTimeField50.getDivisor();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 660019L + "'", long46 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 19329 + "'", int53 == 19329);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
//        long long31 = offsetDateTimeField28.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField28.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) offsetDateTimeField28);
//        java.util.Locale locale36 = null;
//        long long37 = skipUndoDateTimeField33.set((long) 19, "10", locale36);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay42 = dateTime38.toYearMonthDay();
//        int[] intArray47 = new int[] { '4', 321, (short) 10 };
//        int[] intArray49 = skipUndoDateTimeField33.addWrapField((org.joda.time.ReadablePartial) yearMonthDay42, 0, intArray47, (int) (byte) 10);
//        gregorianChronology1.validate((org.joda.time.ReadablePartial) localDate15, intArray49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology1.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology53, locale54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.minuteOfHour();
//        org.joda.time.DurationField durationField57 = gregorianChronology53.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology59, locale60);
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, (int) (byte) -1);
//        long long67 = offsetDateTimeField64.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField68 = offsetDateTimeField64.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField69 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, (org.joda.time.DateTimeField) offsetDateTimeField64);
//        java.util.Locale locale72 = null;
//        long long73 = skipUndoDateTimeField69.set((long) 19, "10", locale72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = skipUndoDateTimeField69.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, dateTimeFieldType74, 19);
//        int int78 = offsetDateTimeField76.getMinimumValue((long) 637);
//        long long80 = offsetDateTimeField76.roundCeiling(2040019L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 660019L + "'", long37 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(yearMonthDay42);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 660019L + "'", long73 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-292275035) + "'", int78 == (-292275035));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 31536000000L + "'", long80 == 31536000000L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField15.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) offsetDateTimeField15);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime24 = dateTime21.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime21.toYearMonthDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay25, (int) (byte) 0, locale27);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        java.lang.String str30 = gJChronology2.toString();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime33 = property32.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime35 = property32.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int42 = fixedDateTimeZone40.getStandardOffset(1560342124707L);
        mutableDateTime35.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.Chronology chronology44 = gJChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        long long46 = fixedDateTimeZone40.nextTransition(16L);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str30.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 16L + "'", long46 == 16L);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(2019);
//        int int9 = dateTime6.getHourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.getMutableDateTime();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property19 = dateTime17.secondOfDay();
//        java.lang.String str20 = property19.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        boolean boolean22 = mutableDateTime16.isSupported(dateTimeFieldType21);
//        dateTimeParserBucket13.saveField(dateTimeFieldType21, 0);
//        org.joda.time.DateTime.Property property25 = dateTime6.property(dateTimeFieldType21);
//        org.joda.time.DateTime dateTime26 = property25.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "57600" + "'", str20.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneName();
        boolean boolean10 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder12.appendTimeZoneOffset("19338", "19327", false, 18, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendFractionOfDay(0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendHourOfDay(32);
        boolean boolean24 = iSOChronology4.equals((java.lang.Object) dateTimeFormatterBuilder12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder12.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[+00:00:02.019]" + "'", str5.equals("ISOChronology[+00:00:02.019]"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1200016L, (long) 1005108);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1206145681728");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime6 = property5.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime8 = property5.add((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
//        int int15 = fixedDateTimeZone13.getStandardOffset(1560342124707L);
//        mutableDateTime8.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        org.joda.time.Chronology chronology17 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        long long19 = fixedDateTimeZone13.previousTransition((long) 10);
//        java.util.TimeZone timeZone20 = fixedDateTimeZone13.toTimeZone();
//        java.util.TimeZone timeZone21 = fixedDateTimeZone13.toTimeZone();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime26 = dateTime22.plusYears(2019);
//        org.joda.time.DateTime dateTime28 = dateTime22.withMonthOfYear(3);
//        org.joda.time.DateTime.Property property29 = dateTime28.secondOfMinute();
//        boolean boolean30 = fixedDateTimeZone13.equals((java.lang.Object) dateTime28);
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime28.minus(readableDuration31);
//        org.joda.time.Chronology chronology34 = null;
//        java.util.Locale locale35 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(100L, chronology34, locale35, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
//        org.joda.time.DateTime.Property property41 = dateTime39.secondOfDay();
//        java.lang.String str42 = property41.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property41.getFieldType();
//        java.util.Locale locale45 = null;
//        dateTimeParserBucket38.saveField(dateTimeFieldType43, "+00:00:02.019", locale45);
//        org.joda.time.DateTime.Property property47 = dateTime28.property(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "57600" + "'", str42.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property47);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) 19, locale11);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology16, locale17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) -1);
//        long long24 = offsetDateTimeField21.getDifferenceAsLong((long) 1, 0L);
//        long long26 = offsetDateTimeField21.roundHalfFloor((long) (byte) 1);
//        java.lang.String str27 = offsetDateTimeField21.toString();
//        mutableDateTime14.setRounding((org.joda.time.DateTimeField) offsetDateTimeField21, 5);
//        int int30 = property7.compareTo((org.joda.time.ReadableInstant) mutableDateTime14);
//        java.lang.String str31 = property7.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str27.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "960" + "'", str31.equals("960"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        try {
            mutableDateTime0.setDayOfYear(28799);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28799 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long8 = offsetDateTimeField6.roundHalfFloor((long) (byte) 0);
        int int10 = offsetDateTimeField6.get((long) 'a');
        long long13 = offsetDateTimeField6.getDifferenceAsLong((long) 59, 1200016L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-19L) + "'", long13 == (-19L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 100);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField6.getWrappedField();
        long long16 = offsetDateTimeField6.remainder(28860009L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9L + "'", long16 == 9L);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology4, locale5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DurationField durationField8 = gregorianChronology4.weekyears();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.millisOfDay();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime10.minus(readableDuration15);
//        int int17 = dateTime16.getDayOfWeek();
//        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale21 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology20, locale21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.minuteOfHour();
//        org.joda.time.DurationField durationField24 = gregorianChronology20.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) -1);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField35 = offsetDateTimeField31.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, (org.joda.time.DateTimeField) offsetDateTimeField31);
//        java.util.Locale locale39 = null;
//        long long40 = skipUndoDateTimeField36.set((long) 19, "10", locale39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property42 = dateTime41.weekyear();
//        org.joda.time.DateTime dateTime44 = dateTime41.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime41.toYearMonthDay();
//        int[] intArray50 = new int[] { '4', 321, (short) 10 };
//        int[] intArray52 = skipUndoDateTimeField36.addWrapField((org.joda.time.ReadablePartial) yearMonthDay45, 0, intArray50, (int) (byte) 10);
//        gregorianChronology4.validate((org.joda.time.ReadablePartial) localDate18, intArray52);
//        int[] intArray55 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate18, (long) '#');
//        try {
//            org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((java.lang.Object) intArray55);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: [I");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 660019L + "'", long40 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertNotNull(intArray55);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property2 = dateTime0.secondOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        mutableDateTime5.setTime((org.joda.time.ReadableInstant) dateTime7);
//        int int9 = property2.getDifference((org.joda.time.ReadableInstant) dateTime7);
//        int int10 = property2.getMaximumValue();
//        org.joda.time.DateTime dateTime11 = property2.withMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime11.withDate((int) (short) 100, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "57600" + "'", str3.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 86399 + "'", int10 == 86399);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        java.lang.String str10 = cachedDateTimeZone4.getNameKey((long) ' ');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury((int) '4', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendWeekOfWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfDay((-292275035));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        long long68 = remainderDateTimeField66.roundHalfFloor((long) 321);
//        long long71 = remainderDateTimeField66.getDifferenceAsLong(0L, 86340000L);
//        long long73 = remainderDateTimeField66.roundCeiling((long) 3);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 31536000000L + "'", long73 == 31536000000L);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology5, locale6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.minuteOfHour();
        org.joda.time.DurationField durationField9 = gregorianChronology5.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        long long19 = offsetDateTimeField16.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField16.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, (org.joda.time.DateTimeField) offsetDateTimeField16);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay26, (int) (byte) 0, locale28);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology3);
        mutableDateTime31.setWeekyear(19329);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField13.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField13);
        java.util.Locale locale21 = null;
        long long22 = skipUndoDateTimeField18.set((long) 19, "10", locale21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.joda.time.DateTimeField dateTimeField24 = skipDateTimeField23.getWrappedField();
        int int25 = skipDateTimeField23.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 660019L + "'", long22 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 32L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
//        java.lang.String str8 = property7.getAsString();
//        org.joda.time.MutableDateTime mutableDateTime10 = property7.add((long) (byte) -1);
//        mutableDateTime10.setMillisOfSecond((int) (short) 10);
//        mutableDateTime10.add(28802169L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "57600" + "'", str8.equals("57600"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        java.util.Locale locale20 = null;
        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField17.getType();
        int int23 = skipUndoDateTimeField17.getMaximumValue();
        long long25 = skipUndoDateTimeField17.roundCeiling((long) (short) 0);
        java.util.Locale locale26 = null;
        int int27 = skipUndoDateTimeField17.getMaximumTextLength(locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField17.getType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        int int7 = mutableDateTime6.getRoundingMode();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology10, locale11);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.minuteOfHour();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.millisOfDay();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime20 = dateTime16.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime16.minus(readableDuration21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.LocalDate localDate24 = dateTime22.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
//        org.joda.time.DurationField durationField30 = gregorianChronology26.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (byte) -1);
//        long long40 = offsetDateTimeField37.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeField) offsetDateTimeField37);
//        java.util.Locale locale45 = null;
//        long long46 = skipUndoDateTimeField42.set((long) 19, "10", locale45);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property48 = dateTime47.weekyear();
//        org.joda.time.DateTime dateTime50 = dateTime47.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay51 = dateTime47.toYearMonthDay();
//        int[] intArray56 = new int[] { '4', 321, (short) 10 };
//        int[] intArray58 = skipUndoDateTimeField42.addWrapField((org.joda.time.ReadablePartial) yearMonthDay51, 0, intArray56, (int) (byte) 10);
//        gregorianChronology10.validate((org.joda.time.ReadablePartial) localDate24, intArray58);
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket(660019L, (org.joda.time.Chronology) gregorianChronology10, locale60, (java.lang.Integer) 2019);
//        org.joda.time.Chronology chronology63 = gregorianChronology10.withUTC();
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology10.millisOfSecond();
//        mutableDateTime6.setRounding(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 660019L + "'", long46 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(yearMonthDay51);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(chronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
        long long5 = property1.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) '4');
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTimeISO();
        mutableDateTime8.addDays(20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone4.getUncachedZone();
//        boolean boolean10 = cachedDateTimeZone4.isStandardOffset((long) 19329);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, dateTimeZone12);
//        try {
//            long long20 = zonedChronology14.getDateTimeMillis(0L, (int) (short) 10, 4, (-292275035), (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275035 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime2 = property1.roundHalfFloorCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 19, locale7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName((long) 19, locale13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        mutableDateTime10.setZoneRetainFields(dateTimeZone11);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime10.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology19.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology26, locale27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.minuteOfHour();
//        org.joda.time.DurationField durationField30 = gregorianChronology26.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology32, locale33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (byte) -1);
//        long long40 = offsetDateTimeField37.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, (org.joda.time.DateTimeField) offsetDateTimeField37);
//        java.util.Locale locale45 = null;
//        long long46 = skipUndoDateTimeField42.set((long) 19, "10", locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipUndoDateTimeField42.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField42.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField50 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType48, 19329);
//        org.joda.time.Chronology chronology53 = null;
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(100L, chronology53, locale54, (java.lang.Integer) 2019, 0);
//        boolean boolean59 = dateTimeParserBucket57.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket57.setZone(dateTimeZone62);
//        java.util.Locale locale64 = dateTimeParserBucket57.getLocale();
//        java.lang.String str65 = remainderDateTimeField50.getAsText(31, locale64);
//        java.util.Calendar calendar66 = mutableDateTime10.toCalendar(locale64);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = dateTimeFormatter3.withLocale(locale64);
//        int int68 = property1.getMaximumTextLength(locale64);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 660019L + "'", long46 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(locale64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "31" + "'", str65.equals("31"));
//        org.junit.Assert.assertNotNull(calendar66);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 9 + "'", int68 == 9);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        int int8 = property7.getMaximumValueOverall();
//        boolean boolean9 = property7.isLeap();
//        org.joda.time.DateTimeField dateTimeField10 = property7.getField();
//        org.joda.time.DateTime dateTime11 = property7.roundHalfFloorCopy();
//        int int12 = dateTime11.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime2 = property1.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy(1990);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1990 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology5, locale6);
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.minuteOfHour();
//        org.joda.time.DurationField durationField9 = gregorianChronology5.weekyears();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.millisOfDay();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime11.minus(readableDuration16);
//        int int18 = dateTime17.getDayOfWeek();
//        org.joda.time.LocalDate localDate19 = dateTime17.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale22 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology21, locale22);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
//        org.joda.time.DurationField durationField25 = gregorianChronology21.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology27, locale28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) -1);
//        long long35 = offsetDateTimeField32.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField32.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, (org.joda.time.DateTimeField) offsetDateTimeField32);
//        java.util.Locale locale40 = null;
//        long long41 = skipUndoDateTimeField37.set((long) 19, "10", locale40);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property43 = dateTime42.weekyear();
//        org.joda.time.DateTime dateTime45 = dateTime42.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay46 = dateTime42.toYearMonthDay();
//        int[] intArray51 = new int[] { '4', 321, (short) 10 };
//        int[] intArray53 = skipUndoDateTimeField37.addWrapField((org.joda.time.ReadablePartial) yearMonthDay46, 0, intArray51, (int) (byte) 10);
//        gregorianChronology5.validate((org.joda.time.ReadablePartial) localDate19, intArray53);
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology57, locale58);
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.minuteOfHour();
//        org.joda.time.DurationField durationField61 = gregorianChronology57.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale64 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology63, locale64);
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology63.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, (int) (byte) -1);
//        long long71 = offsetDateTimeField68.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField72 = offsetDateTimeField68.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology57, (org.joda.time.DateTimeField) offsetDateTimeField68);
//        java.util.Locale locale76 = null;
//        long long77 = skipUndoDateTimeField73.set((long) 19, "10", locale76);
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = skipUndoDateTimeField73.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType78, 19);
//        org.joda.time.DateTime.Property property81 = dateTime1.property(dateTimeFieldType78);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException85 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType78, (java.lang.Number) (-60431501221900L), (java.lang.Number) 2019, (java.lang.Number) 2019);
//        java.lang.Class<?> wildcardClass86 = dateTimeFieldType78.getClass();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField87 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 660019L + "'", long41 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(yearMonthDay46);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 660019L + "'", long77 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(wildcardClass86);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfDay();
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gregorianChronology2, locale6);
//        org.joda.time.Chronology chronology9 = null;
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(100L, chronology9, locale10, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology15, locale16);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.minuteOfHour();
//        org.joda.time.DurationField durationField19 = gregorianChronology15.weekyears();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology15.millisOfDay();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime23 = dateTime21.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime25 = dateTime21.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime21.minus(readableDuration26);
//        int int28 = dateTime27.getDayOfWeek();
//        org.joda.time.LocalDate localDate29 = dateTime27.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale32 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology31, locale32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.minuteOfHour();
//        org.joda.time.DurationField durationField35 = gregorianChronology31.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale38 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology37, locale38);
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (byte) -1);
//        long long45 = offsetDateTimeField42.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField42.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology31, (org.joda.time.DateTimeField) offsetDateTimeField42);
//        java.util.Locale locale50 = null;
//        long long51 = skipUndoDateTimeField47.set((long) 19, "10", locale50);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property53 = dateTime52.weekyear();
//        org.joda.time.DateTime dateTime55 = dateTime52.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay56 = dateTime52.toYearMonthDay();
//        int[] intArray61 = new int[] { '4', 321, (short) 10 };
//        int[] intArray63 = skipUndoDateTimeField47.addWrapField((org.joda.time.ReadablePartial) yearMonthDay56, 0, intArray61, (int) (byte) 10);
//        gregorianChronology15.validate((org.joda.time.ReadablePartial) localDate29, intArray63);
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology15.year();
//        dateTimeParserBucket13.saveField(dateTimeField65, 55);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str70 = dateTimeZone69.getID();
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
//        java.lang.String str73 = dateTimeZone71.getID();
//        dateTimeParserBucket13.setZone(dateTimeZone71);
//        boolean boolean75 = gregorianChronology2.equals((java.lang.Object) dateTimeZone71);
//        org.joda.time.DateTimeField dateTimeField76 = gregorianChronology2.year();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 660019L + "'", long51 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(yearMonthDay56);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+00:00:02.019" + "'", str70.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(iSOChronology72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "+00:00:02.019" + "'", str73.equals("+00:00:02.019"));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(dateTimeField76);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
//        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        java.lang.String str6 = property5.getAsText();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property5.getAsShortText(locale7);
//        int int9 = property5.get();
//        boolean boolean10 = gJChronology0.equals((java.lang.Object) property5);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "57600" + "'", str6.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "57600" + "'", str8.equals("57600"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond((int) 'a');
        boolean boolean13 = property2.equals((java.lang.Object) dateTime10);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.ReadableInterval readableInterval15 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
        org.joda.time.ReadableInterval readableInterval16 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval14);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.DateTime dateTime18 = dateTime10.toDateTime(chronology17);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:02.019" + "'", str9.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(readableInterval15);
        org.junit.Assert.assertNotNull(readableInterval16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 100);
        org.joda.time.DateTime.Property property4 = dateTime0.year();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(53);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(32);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime15 = property12.add((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        int int22 = fixedDateTimeZone20.getStandardOffset(1560342124707L);
        mutableDateTime15.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        boolean boolean24 = dateTime8.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("19332", (int) '4');
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("19314", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        org.joda.time.DateTime dateTime8 = dateTime0.withMillisOfSecond((int) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime0.yearOfCentury();
//        java.lang.String str10 = property9.getAsShortText();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) -1);
//        long long26 = offsetDateTimeField24.roundHalfFloor((long) (byte) 0);
//        int int28 = offsetDateTimeField24.get((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = dateTimeZone32.getName((long) 19, locale34);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) 19, locale40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone42 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone38);
//        mutableDateTime37.setZoneRetainFields(dateTimeZone38);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime37.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale47 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology46, locale47);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology46.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology46.getZone();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology46.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology53, locale54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.minuteOfHour();
//        org.joda.time.DurationField durationField57 = gregorianChronology53.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology59, locale60);
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, (int) (byte) -1);
//        long long67 = offsetDateTimeField64.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField68 = offsetDateTimeField64.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField69 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, (org.joda.time.DateTimeField) offsetDateTimeField64);
//        java.util.Locale locale72 = null;
//        long long73 = skipUndoDateTimeField69.set((long) 19, "10", locale72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = skipUndoDateTimeField69.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = skipUndoDateTimeField69.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dateTimeField51, dateTimeFieldType75, 19329);
//        org.joda.time.Chronology chronology80 = null;
//        java.util.Locale locale81 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket(100L, chronology80, locale81, (java.lang.Integer) 2019, 0);
//        boolean boolean86 = dateTimeParserBucket84.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone89 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket84.setZone(dateTimeZone89);
//        java.util.Locale locale91 = dateTimeParserBucket84.getLocale();
//        java.lang.String str92 = remainderDateTimeField77.getAsText(31, locale91);
//        java.util.Calendar calendar93 = mutableDateTime37.toCalendar(locale91);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter94 = dateTimeFormatter30.withLocale(locale91);
//        java.lang.String str95 = offsetDateTimeField24.getAsShortText((int) (byte) 0, locale91);
//        java.lang.String str96 = dateTimeZone15.getShortName((long) (-6), locale91);
//        try {
//            org.joda.time.DateTime dateTime97 = property9.setCopy("", locale91);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:02.019" + "'", str14.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordinated Universal Time" + "'", str35.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 660019L + "'", long73 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(dateTimeFieldType75);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone89);
//        org.junit.Assert.assertNotNull(locale91);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "31" + "'", str92.equals("31"));
//        org.junit.Assert.assertNotNull(calendar93);
//        org.junit.Assert.assertNotNull(dateTimeFormatter94);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "0" + "'", str95.equals("0"));
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "+00:00:02.019" + "'", str96.equals("+00:00:02.019"));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime5 = property2.roundCeiling();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 100, (org.joda.time.Chronology) gregorianChronology8, locale13, (java.lang.Integer) 10);
        mutableDateTime5.setChronology((org.joda.time.Chronology) gregorianChronology8);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime6.add(readableDuration9, (int) 'a');
//        mutableDateTime6.setMonthOfYear((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        mutableDateTime6.add(readablePeriod14, 9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.minuteOfHour();
//        org.joda.time.DurationField durationField22 = gregorianChronology18.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology24, locale25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (byte) -1);
//        long long32 = offsetDateTimeField29.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField33 = offsetDateTimeField29.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology18, (org.joda.time.DateTimeField) offsetDateTimeField29);
//        java.util.Locale locale37 = null;
//        long long38 = skipUndoDateTimeField34.set((long) 19, "10", locale37);
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay43 = dateTime39.toYearMonthDay();
//        int[] intArray48 = new int[] { '4', 321, (short) 10 };
//        int[] intArray50 = skipUndoDateTimeField34.addWrapField((org.joda.time.ReadablePartial) yearMonthDay43, 0, intArray48, (int) (byte) 10);
//        int int52 = skipUndoDateTimeField34.get((-210866500800000L));
//        java.lang.String str53 = skipUndoDateTimeField34.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = skipUndoDateTimeField34.getType();
//        mutableDateTime6.set(dateTimeFieldType54, 53);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime6.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 660019L + "'", long38 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(yearMonthDay43);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str53.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(property57);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
//        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str11 = dateTimeZone10.toString();
//        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        mutableDateTime1.setZone(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName((long) 19, locale16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        int int20 = cachedDateTimeZone18.getOffset((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone21 = cachedDateTimeZone18.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone18.getUncachedZone();
//        boolean boolean23 = cachedDateTimeZone18.isFixed();
//        int int25 = cachedDateTimeZone18.getStandardOffset((long) 32);
//        try {
//            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone10, (org.joda.time.DateTimeZone) cachedDateTimeZone18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone1.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        int int7 = gJChronology5.getMinimumDaysInFirstWeek();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(1560342114588L, (org.joda.time.Chronology) gJChronology5, locale8, (java.lang.Integer) 57600000, 2000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        long long3 = dateTimeZone0.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-28800000L) + "'", long3 == (-28800000L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(2019);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra(5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra((int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.withWeekyear((int) (byte) -1);
//        int int10 = dateTime6.getMillisOfSecond();
//        org.joda.time.DateTime.Property property11 = dateTime6.millisOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology13, locale14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
//        long long21 = offsetDateTimeField18.getDifferenceAsLong((long) 1, 0L);
//        long long23 = offsetDateTimeField18.roundHalfFloor((long) (byte) 1);
//        int int24 = dateTime6.get((org.joda.time.DateTimeField) offsetDateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 51 + "'", int24 == 51);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setMinuteOfDay(53);
//        mutableDateTime6.setSecondOfMinute(31);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime6.millisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology2, locale3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 100, (org.joda.time.Chronology) gregorianChronology2, locale7, (java.lang.Integer) 10);
        org.joda.time.DurationField durationField10 = gregorianChronology2.days();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.Instant instant6 = gJChronology4.getGregorianCutover();
        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
//        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withLocale(locale4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone11);
//        mutableDateTime12.setWeekOfWeekyear((int) '4');
//        boolean boolean16 = mutableDateTime12.isAfter((long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology18, locale19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.era();
//        mutableDateTime12.setRounding(dateTimeField21);
//        java.lang.String str23 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0001-W01-1" + "'", str23.equals("0001-W01-1"));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withLocale(locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(dateTimeZone6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 19, locale9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        mutableDateTime6.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime6.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology15, locale16);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology15.getZone();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology22, locale23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.minuteOfHour();
//        org.joda.time.DurationField durationField26 = gregorianChronology22.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology28, locale29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) -1);
//        long long36 = offsetDateTimeField33.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField37 = offsetDateTimeField33.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, (org.joda.time.DateTimeField) offsetDateTimeField33);
//        java.util.Locale locale41 = null;
//        long long42 = skipUndoDateTimeField38.set((long) 19, "10", locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField38.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipUndoDateTimeField38.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField20, dateTimeFieldType44, 19329);
//        org.joda.time.Chronology chronology49 = null;
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(100L, chronology49, locale50, (java.lang.Integer) 2019, 0);
//        boolean boolean55 = dateTimeParserBucket53.restoreState((java.lang.Object) 100.0d);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
//        dateTimeParserBucket53.setZone(dateTimeZone58);
//        java.util.Locale locale60 = dateTimeParserBucket53.getLocale();
//        java.lang.String str61 = remainderDateTimeField46.getAsText(31, locale60);
//        java.util.Calendar calendar62 = mutableDateTime6.toCalendar(locale60);
//        mutableDateTime6.setWeekyear((int) (byte) 100);
//        org.joda.time.MutableDateTime.Property property65 = mutableDateTime6.secondOfMinute();
//        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime68 = dateTime66.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime70 = dateTime66.plusYears(2019);
//        org.joda.time.DateTimeZone dateTimeZone71 = dateTime70.getZone();
//        mutableDateTime6.setDate((org.joda.time.ReadableInstant) dateTime70);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 660019L + "'", long42 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(locale60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31" + "'", str61.equals("31"));
//        org.junit.Assert.assertNotNull(calendar62);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) 0);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime7 = dateTime3.plusYears(2019);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.withChronology(chronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear(53);
        org.joda.time.DateTime dateTime13 = dateTime9.plusSeconds(55);
        try {
            java.lang.String str14 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.era();
//        org.joda.time.DateTime dateTime9 = property8.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 100);
        int int15 = offsetDateTimeField6.getLeapAmount((long) 32);
        long long17 = offsetDateTimeField6.roundHalfEven((-86399980L));
        java.lang.String str18 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-86400000L) + "'", long17 == (-86400000L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str18.equals("DateTimeField[minuteOfHour]"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime6 = dateTime2.plusYears(2019);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str11 = dateTimeZone10.toString();
        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone10);
        mutableDateTime1.setZone(dateTimeZone10);
        try {
            mutableDateTime1.setMonthOfYear(57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.withChronology(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime0.plusHours((-292275035));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology6, locale7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.minuteOfHour();
        org.joda.time.DurationField durationField10 = gregorianChronology6.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology12, locale13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        long long20 = offsetDateTimeField17.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField17.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) offsetDateTimeField17);
        java.util.Locale locale25 = null;
        long long26 = skipUndoDateTimeField22.set((long) 19, "10", locale25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipUndoDateTimeField22.getType();
        int int28 = skipUndoDateTimeField22.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType29, 26, 26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 16L, (java.lang.Number) (-3178010L), (java.lang.Number) 49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 660019L + "'", long26 == 660019L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 58 + "'", int28 == 58);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone1.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
        int int7 = gJChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField8 = gJChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology5.minuteOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(360000L, (org.joda.time.Chronology) gJChronology5);
        org.joda.time.DurationField durationField11 = gJChronology5.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology5, locale6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.minuteOfHour();
        org.joda.time.DurationField durationField9 = gregorianChronology5.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology11, locale12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        long long19 = offsetDateTimeField16.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField16.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, (org.joda.time.DateTimeField) offsetDateTimeField16);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra((int) (byte) 100);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime22.toYearMonthDay();
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay26, (int) (byte) 0, locale28);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology3);
        try {
            long long39 = gJChronology3.getDateTimeMillis(31, (int) '4', 0, 0, 155, 69, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 155 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekOfWeekyear();
        java.util.Locale locale2 = null;
        int int3 = property1.getMaximumTextLength(locale2);
        org.joda.time.DateTime dateTime4 = property1.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19314", "2019", 10, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology3, locale4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.minuteOfHour();
//        org.joda.time.DurationField durationField7 = gregorianChronology3.weekyears();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.millisOfDay();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime13 = dateTime9.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.minus(readableDuration14);
//        int int16 = dateTime15.getDayOfWeek();
//        org.joda.time.LocalDate localDate17 = dateTime15.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology19, locale20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.minuteOfHour();
//        org.joda.time.DurationField durationField23 = gregorianChronology19.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology25, locale26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (byte) -1);
//        long long33 = offsetDateTimeField30.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField34 = offsetDateTimeField30.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, (org.joda.time.DateTimeField) offsetDateTimeField30);
//        java.util.Locale locale38 = null;
//        long long39 = skipUndoDateTimeField35.set((long) 19, "10", locale38);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property41 = dateTime40.weekyear();
//        org.joda.time.DateTime dateTime43 = dateTime40.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay44 = dateTime40.toYearMonthDay();
//        int[] intArray49 = new int[] { '4', 321, (short) 10 };
//        int[] intArray51 = skipUndoDateTimeField35.addWrapField((org.joda.time.ReadablePartial) yearMonthDay44, 0, intArray49, (int) (byte) 10);
//        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate17, intArray51);
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(660019L, (org.joda.time.Chronology) gregorianChronology3, locale53, (java.lang.Integer) 2019);
//        org.joda.time.Chronology chronology56 = gregorianChronology3.withUTC();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(660019L, chronology56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = null;
//        try {
//            int int59 = dateTime57.get(dateTimeFieldType58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 660019L + "'", long39 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(yearMonthDay44);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertNotNull(chronology56);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
        int int19 = offsetDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        org.joda.time.DurationField durationField69 = unsupportedDateTimeField68.getLeapDurationField();
//        try {
//            long long71 = unsupportedDateTimeField68.roundHalfEven((-28799900L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNull(durationField69);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury((int) '4', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendWeekOfWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMillisOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendLiteral("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readableDuration5);
//        boolean boolean8 = dateTime0.isBefore((long) (byte) 100);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(100L, chronology10, locale11, (java.lang.Integer) 2019, 0);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
//        org.joda.time.DateTime.Property property17 = dateTime15.secondOfDay();
//        java.lang.String str18 = property17.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
//        java.util.Locale locale21 = null;
//        dateTimeParserBucket14.saveField(dateTimeFieldType19, "+00:00:02.019", locale21);
//        org.joda.time.DateTime.Property property23 = dateTime0.property(dateTimeFieldType19);
//        org.joda.time.DateTime dateTime24 = dateTime0.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime0.withWeekyear((int) (byte) -1);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "57600" + "'", str18.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:02.019" + "'", str2.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 100.0d);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (short) 1);
        dateTimeParserBucket5.setZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        java.lang.String str14 = dateTimeZone13.getID();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        dateTimeParserBucket5.setZone(dateTimeZone13);
        long long19 = dateTimeZone13.convertLocalToUTC((long) (-292275035), true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:02.019" + "'", str14.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-292277054L) + "'", long19 == (-292277054L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.util.Locale locale5 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-4200320), "Property[weekyear]");
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 19, locale2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        long long6 = cachedDateTimeZone4.previousTransition(0L);
//        long long8 = cachedDateTimeZone4.nextTransition(32L);
//        java.lang.String str10 = cachedDateTimeZone4.getName(2000L);
//        java.lang.String str12 = cachedDateTimeZone4.getName((long) 9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        mutableDateTime6.setWeekOfWeekyear((int) '4');
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime6.add(readableDuration9, (int) 'a');
//        mutableDateTime6.setMonthOfYear((int) (short) 10);
//        long long14 = mutableDateTime6.getMillis();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
//        java.lang.String str23 = dateTimeZone22.getID();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((int) ' ', 1, 1, 0, (int) (byte) 0, 0, dateTimeZone22);
//        mutableDateTime6.setZone(dateTimeZone22);
//        mutableDateTime6.setMillisOfSecond(1);
//        mutableDateTime6.add(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25545600100L + "'", long14 == 25545600100L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:02.019" + "'", str23.equals("+00:00:02.019"));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong((long) 1, 0L);
        long long11 = offsetDateTimeField6.roundHalfFloor((long) (byte) 1);
        long long13 = offsetDateTimeField6.roundHalfFloor((long) 100);
        int int15 = offsetDateTimeField6.getLeapAmount(1560342127209L);
        int int18 = offsetDateTimeField6.getDifference((long) 19329, (long) 425760);
        long long21 = offsetDateTimeField6.getDifferenceAsLong((long) 86399, 720019L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-6) + "'", int18 == (-6));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = dateTime7.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology17, locale18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
//        org.joda.time.DurationField durationField21 = gregorianChronology17.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
//        long long31 = offsetDateTimeField28.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField32 = offsetDateTimeField28.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) offsetDateTimeField28);
//        java.util.Locale locale36 = null;
//        long long37 = skipUndoDateTimeField33.set((long) 19, "10", locale36);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property39 = dateTime38.weekyear();
//        org.joda.time.DateTime dateTime41 = dateTime38.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay42 = dateTime38.toYearMonthDay();
//        int[] intArray47 = new int[] { '4', 321, (short) 10 };
//        int[] intArray49 = skipUndoDateTimeField33.addWrapField((org.joda.time.ReadablePartial) yearMonthDay42, 0, intArray47, (int) (byte) 10);
//        gregorianChronology1.validate((org.joda.time.ReadablePartial) localDate15, intArray49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology1.year();
//        org.joda.time.Chronology chronology52 = gregorianChronology1.withUTC();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology1.clockhourOfHalfday();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 660019L + "'", long37 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(yearMonthDay42);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 19, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-28799900L), (org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology8, locale9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.year();
//        mutableDateTime6.setRounding(dateTimeField11);
//        mutableDateTime6.setMillisOfDay(2000);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime6.secondOfDay();
//        boolean boolean16 = mutableDateTime6.isBeforeNow();
//        mutableDateTime6.addYears(1005108);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        int int5 = gJChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 2019, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.millisOfDay();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.minus(readableDuration18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology23, locale24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.minuteOfHour();
//        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology29, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        long long37 = offsetDateTimeField34.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField38 = offsetDateTimeField34.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, (org.joda.time.DateTimeField) offsetDateTimeField34);
//        java.util.Locale locale42 = null;
//        long long43 = skipUndoDateTimeField39.set((long) 19, "10", locale42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property45 = dateTime44.weekyear();
//        org.joda.time.DateTime dateTime47 = dateTime44.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime44.toYearMonthDay();
//        int[] intArray53 = new int[] { '4', 321, (short) 10 };
//        int[] intArray55 = skipUndoDateTimeField39.addWrapField((org.joda.time.ReadablePartial) yearMonthDay48, 0, intArray53, (int) (byte) 10);
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) localDate21, intArray55);
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology7.year();
//        dateTimeParserBucket5.saveField(dateTimeField57, 55);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property61 = dateTime60.weekyear();
//        org.joda.time.DateTime.Property property62 = dateTime60.secondOfDay();
//        java.lang.String str63 = property62.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField57, dateTimeFieldType64, (int) ' ');
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField67);
//        try {
//            boolean boolean70 = unsupportedDateTimeField68.isLeap((long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 660019L + "'", long43 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57600" + "'", str63.equals("57600"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
//        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
//        java.util.Locale locale20 = null;
//        long long21 = skipUndoDateTimeField17.set((long) 19, "10", locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField17.getType();
//        int int23 = skipUndoDateTimeField17.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField17.getType();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField17.getAsShortText(58, locale26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        int int31 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology33, locale34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DurationField durationField37 = gregorianChronology33.weekyears();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology33.millisOfDay();
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime41 = dateTime39.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime43 = dateTime39.plusYears(2019);
//        org.joda.time.ReadableDuration readableDuration44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime39.minus(readableDuration44);
//        int int46 = dateTime45.getDayOfWeek();
//        org.joda.time.LocalDate localDate47 = dateTime45.toLocalDate();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology49, locale50);
//        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.minuteOfHour();
//        org.joda.time.DurationField durationField53 = gregorianChronology49.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale56 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology55, locale56);
//        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, (int) (byte) -1);
//        long long63 = offsetDateTimeField60.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField64 = offsetDateTimeField60.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology49, (org.joda.time.DateTimeField) offsetDateTimeField60);
//        java.util.Locale locale68 = null;
//        long long69 = skipUndoDateTimeField65.set((long) 19, "10", locale68);
//        org.joda.time.DateTime dateTime70 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property71 = dateTime70.weekyear();
//        org.joda.time.DateTime dateTime73 = dateTime70.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay74 = dateTime70.toYearMonthDay();
//        int[] intArray79 = new int[] { '4', 321, (short) 10 };
//        int[] intArray81 = skipUndoDateTimeField65.addWrapField((org.joda.time.ReadablePartial) yearMonthDay74, 0, intArray79, (int) (byte) 10);
//        gregorianChronology33.validate((org.joda.time.ReadablePartial) localDate47, intArray81);
//        int[] intArray84 = gregorianChronology29.get((org.joda.time.ReadablePartial) localDate47, (long) '#');
//        java.lang.String str85 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate47);
//        int int86 = skipUndoDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate47);
//        java.lang.String str87 = skipUndoDateTimeField17.getName();
//        long long90 = skipUndoDateTimeField17.addWrapField((long) (short) -1, 321);
//        int int92 = skipUndoDateTimeField17.getMinimumValue((long) 321);
//        boolean boolean93 = skipUndoDateTimeField17.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 660019L + "'", long21 == 660019L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "58" + "'", str27.equals("58"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 660019L + "'", long69 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(yearMonthDay74);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertNotNull(intArray84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "1970-W01-3" + "'", str85.equals("1970-W01-3"));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 58 + "'", int86 == 58);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "minuteOfHour" + "'", str87.equals("minuteOfHour"));
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-2340001L) + "'", long90 == (-2340001L));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology1, locale2);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology7, locale8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
//        long long15 = offsetDateTimeField12.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField12.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField12);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property19 = dateTime18.weekyear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime18.toYearMonthDay();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay22, (int) (byte) 0, locale24);
//        boolean boolean26 = skipUndoDateTimeField17.isLenient();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology28, locale29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.minuteOfHour();
//        org.joda.time.DurationField durationField32 = gregorianChronology28.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale35 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology34, locale35);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.minuteOfHour();
//        org.joda.time.DurationField durationField38 = gregorianChronology34.weekyears();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 52, (org.joda.time.Chronology) gregorianChronology40, locale41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
//        long long48 = offsetDateTimeField45.getDifferenceAsLong((long) 1, 0L);
//        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField45.getWrappedField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, (org.joda.time.DateTimeField) offsetDateTimeField45);
//        java.util.Locale locale53 = null;
//        long long54 = skipUndoDateTimeField50.set((long) 19, "10", locale53);
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property56 = dateTime55.weekyear();
//        org.joda.time.DateTime dateTime58 = dateTime55.withYearOfEra((int) (byte) 100);
//        org.joda.time.YearMonthDay yearMonthDay59 = dateTime55.toYearMonthDay();
//        int[] intArray64 = new int[] { '4', 321, (short) 10 };
//        int[] intArray66 = skipUndoDateTimeField50.addWrapField((org.joda.time.ReadablePartial) yearMonthDay59, 0, intArray64, (int) (byte) 10);
//        long long68 = gregorianChronology28.set((org.joda.time.ReadablePartial) yearMonthDay59, (long) 20);
//        int int69 = skipUndoDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay59);
//        org.joda.time.DurationField durationField70 = skipUndoDateTimeField17.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 660019L + "'", long54 == 660019L);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(yearMonthDay59);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-86399980L) + "'", long68 == (-86399980L));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNull(durationField70);
//    }
//}

