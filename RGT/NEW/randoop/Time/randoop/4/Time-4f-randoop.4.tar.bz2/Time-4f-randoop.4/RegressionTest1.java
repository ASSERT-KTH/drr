import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        java.lang.String str10 = partial7.toString("19");
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial13 = partial7.withPeriodAdded(readablePeriod11, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.Partial.Property property15 = partial13.property(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
        org.junit.Assert.assertNotNull(partial13);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("DateTimeField[minuteOfDay]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay((int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        int int7 = property6.getMinimumValueOverall();
        org.joda.time.LocalDate localDate8 = property6.roundHalfFloorCopy();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = localDate8.isSupported(durationFieldType9);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.clockhourOfDay();
        int int4 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology5 = gJChronology1.withUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 929, chronology5);
        org.joda.time.DateTime dateTime11 = dateTime6.withTime(0, (int) '#', (int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str5 = buddhistChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str5.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 1970, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.withYear((int) (byte) 1);
        int int9 = localDate8.getWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        int int14 = localDate13.getYear();
        org.joda.time.LocalDate localDate16 = localDate13.withWeekyear(0);
        org.joda.time.LocalDate localDate18 = localDate16.minusMonths(1970);
        boolean boolean19 = partial7.isEqual((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.Partial partial21 = partial7.plus(readablePeriod20);
        boolean boolean22 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial7);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            org.joda.time.Partial partial25 = partial7.withField(dateTimeFieldType23, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1869 + "'", int14 == 1869);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(partial21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (byte) 100);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) ' ', dateTimeZone7);
//        java.lang.String str12 = dateTimeZone7.getName(86340001L);
//        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.DateTime dateTime3 = instant1.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withFieldAdded(durationFieldType5, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        int int13 = skipDateTimeField8.getDifference(0L, 0L);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property16 = localDate15.centuryOfEra();
        int[] intArray17 = localDate15.getValues();
        int int18 = localDate15.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate20 = localDate15.minus(readablePeriod19);
        org.joda.time.Partial partial21 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate20);
        int int22 = partial21.size();
        java.lang.String str24 = partial21.toString("19");
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial27 = partial21.withPeriodAdded(readablePeriod25, 1969);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.Partial partial29 = partial27.plus(readablePeriod28);
        int int30 = partial29.size();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        java.lang.String str34 = gregorianChronology33.toString();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = gregorianChronology37.toString();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField39);
        boolean boolean41 = skipDateTimeField40.isLenient();
        long long44 = skipDateTimeField40.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property47 = localDate46.centuryOfEra();
        org.joda.time.LocalDate localDate49 = property47.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate51 = localDate49.minusMonths((int) '4');
        int int52 = localDate49.getYearOfCentury();
        org.joda.time.LocalDate.Property property53 = localDate49.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField55 = gJChronology54.era();
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField58 = gJChronology56.secondOfDay();
        org.joda.time.DateTimeField dateTimeField59 = gJChronology56.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField60 = gJChronology56.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField62 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology54, dateTimeField60, (int) (byte) 0);
        int int64 = skipDateTimeField62.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property67 = localDate66.centuryOfEra();
        int int68 = localDate66.getYear();
        int[] intArray69 = localDate66.getValues();
        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property73 = localDate72.centuryOfEra();
        int[] intArray74 = localDate72.getValues();
        int[] intArray76 = skipDateTimeField62.addWrapField((org.joda.time.ReadablePartial) localDate66, 0, intArray74, 10);
        int int77 = skipDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) localDate49, intArray76);
        int[] intArray79 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) partial29, 0, intArray76, (int) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19" + "'", str24.equals("19"));
        org.junit.Assert.assertNotNull(partial27);
        org.junit.Assert.assertNotNull(partial29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str34.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str38.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 69 + "'", int52 == 69);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1439 + "'", int64 == 1439);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1969 + "'", int68 == 1969);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate1.isSupported(dateTimeFieldType3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = localDate1.isSupported(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = dateTimeZone2.toString();
        org.joda.time.Chronology chronology5 = buddhistChronology1.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology(chronology5);
        try {
            org.joda.time.DateTime dateTime8 = dateTimeFormatter0.parseDateTime("minuteOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"minuteOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.minus((long) (byte) 0);
        org.joda.time.Chronology chronology4 = instant0.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        int int5 = delegatedDateTimeField2.getMaximumValue();
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField2.getMaximumTextLength(locale6);
        boolean boolean9 = delegatedDateTimeField2.isLeap(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9);
        org.joda.time.DurationField durationField11 = gregorianChronology3.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.LocalDate localDate19 = property17.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology20.getZone();
        org.joda.time.DateTime dateTime23 = localDate19.toDateTimeAtStartOfDay(dateTimeZone22);
        org.joda.time.Chronology chronology24 = zonedChronology14.withZone(dateTimeZone22);
        org.joda.time.Chronology chronology25 = zonedChronology14.withUTC();
        try {
            org.joda.time.Partial partial26 = new org.joda.time.Partial(dateTimeFieldType0, (int) (byte) 0, chronology25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str8.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        boolean boolean30 = dateTimeZone25.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths((int) '4');
        int int39 = localDate36.getYearOfCentury();
        boolean boolean40 = cachedDateTimeZone31.equals((java.lang.Object) localDate36);
        java.lang.String str41 = cachedDateTimeZone31.getID();
        org.joda.time.DateTimeZone dateTimeZone42 = cachedDateTimeZone31.getUncachedZone();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "America/Los_Angeles" + "'", str41.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 929);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours(1970);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekyear(1969);
        org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1", (java.lang.Number) 8, (java.lang.Number) 2922789, number3);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.era();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField12, (int) (byte) 0);
        int int16 = skipDateTimeField14.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int int20 = localDate18.getYear();
        int int21 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        int int26 = localDate24.getYear();
        int[] intArray27 = localDate24.getValues();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        java.lang.String str40 = gregorianChronology39.toString();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
        java.lang.String str44 = gregorianChronology43.toString();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology39, dateTimeField45);
        org.joda.time.DurationField durationField47 = gregorianChronology39.minutes();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48);
        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology39, dateTimeZone48);
        org.joda.time.MutableDateTime mutableDateTime51 = dateTime37.toMutableDateTime(dateTimeZone48);
        boolean boolean53 = dateTimeZone48.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone48);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property57 = localDate56.centuryOfEra();
        org.joda.time.LocalDate localDate59 = property57.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate61 = localDate59.minusMonths((int) '4');
        int int62 = localDate59.getYearOfCentury();
        boolean boolean63 = cachedDateTimeZone54.equals((java.lang.Object) localDate59);
        java.lang.String str65 = cachedDateTimeZone54.getNameKey((long) (byte) 1);
        org.joda.time.Interval interval66 = localDate18.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone54);
        long long68 = cachedDateTimeZone54.previousTransition((long) 930);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1439 + "'", int16 == 1439);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str40.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str44.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(zonedChronology50);
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 69 + "'", int62 == 69);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "PST" + "'", str65.equals("PST"));
        org.junit.Assert.assertNotNull(interval66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-5756400001L) + "'", long68 == (-5756400001L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray22 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15, dateTimeParser17, dateTimeParser19, dateTimeParser21 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(69, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendMinuteOfHour((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeParserArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        java.lang.String str6 = gregorianChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        boolean boolean9 = skipDateTimeField8.isLenient();
//        long long12 = skipDateTimeField8.set(0L, (int) (short) 1);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
//        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
//        org.joda.time.LocalDate localDate19 = localDate17.minusMonths((int) '4');
//        org.joda.time.LocalDate localDate21 = localDate17.withYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate23 = localDate21.plusWeeks((int) (short) 100);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
//        int int27 = localDate25.getYear();
//        int[] intArray28 = localDate25.getValues();
//        int int29 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray28);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology31.getZone();
//        boolean boolean35 = dateTimeZone33.isStandardOffset((long) (byte) 100);
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) ' ', dateTimeZone33);
//        java.lang.String str38 = dateTimeZone33.getName(86340001L);
//        org.joda.time.DateMidnight dateMidnight39 = localDate23.toDateMidnight(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Pacific Standard Time" + "'", str38.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateMidnight39);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-9223372036825975809L));
        boolean boolean12 = dateTime8.isAfter((long) 4);
        try {
            org.joda.time.DateTime dateTime16 = dateTime8.withDate((int) 'a', 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(69, '#', (int) (short) 1, 1439, (-1), false, 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeZoneBuilder10.toDateTimeZone("BC", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.weekyearOfCentury();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        boolean boolean7 = delegatedDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder20.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter26 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray46 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser37, dateTimeParser39, dateTimeParser41, dateTimeParser43, dateTimeParser45 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder31.append(dateTimePrinter33, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder25.append(dateTimePrinter26, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.append(dateTimePrinter23, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeParserArray46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("18", 929, 52, 24, ' ', 1, (int) ' ', 1888, true, (int) (short) 1);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder3.writeTo("7", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendDayOfWeek(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        int int17 = skipDateTimeField8.get((long) 929);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField8.getAsText((int) 'a', locale19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 960 + "'", int17 == 960);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        long long6 = dateTimeZone3.convertLocalToUTC(86340001L, false);
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtStartOfDay(dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getShortName(0L, locale12);
//        org.joda.time.DateTime dateTime14 = localDate1.toDateTimeAtMidnight(dateTimeZone10);
//        try {
//            org.joda.time.Instant instant15 = new org.joda.time.Instant((java.lang.Object) dateTimeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86339901L + "'", long6 == 86339901L);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 32L, (java.lang.Number) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendSecondOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatterBuilder20.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder8.append(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        boolean boolean30 = dateTimeZone25.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField10);
        org.joda.time.DurationField durationField12 = gregorianChronology4.minutes();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone13);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.Chronology chronology25 = zonedChronology15.withZone(dateTimeZone23);
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology15);
        int int27 = property2.compareTo((org.joda.time.ReadablePartial) localDate26);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str9.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, 1869);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition(1560637837398L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560637837398L + "'", long8 == 1560637837398L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtMidnight();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        boolean boolean11 = dateTime8.isBefore(57600035L);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readablePeriod12);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = dateTimeZone2.toString();
        org.joda.time.Chronology chronology5 = buddhistChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(34L, chronology5);
        int int7 = dateTime6.getYearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2512 + "'", int7 == 2512);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        int int7 = localDate5.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate9 = localDate5.minusMonths(12);
        try {
            int int11 = localDate5.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField2.getDurationField();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate9.withPeriodAdded(readablePeriod11, (int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate15 = localDate9.minus(readablePeriod14);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int[] intArray19 = localDate17.getValues();
        int int20 = localDate17.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.LocalDate localDate22 = localDate17.minus(readablePeriod21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate22);
        int int24 = partial23.size();
        java.lang.String str25 = partial23.toString();
        int[] intArray26 = partial23.getValues();
        int int27 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate15, intArray26);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str30 = localDate29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        java.lang.String str33 = dateTimeZone31.toString();
        org.joda.time.Interval interval34 = localDate29.toInterval(dateTimeZone31);
        org.joda.time.DateTime dateTime35 = localDate15.toDateTimeAtMidnight(dateTimeZone31);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31" + "'", str25.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969-12-31" + "'", str30.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "America/Los_Angeles" + "'", str33.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, 22, (int) (byte) 0, 2922789, 2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
//        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology10 = instant9.getChronology();
//        org.joda.time.DateTime dateTime11 = instant9.toDateTime();
//        org.joda.time.DateTime dateTime12 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology14 = instant13.getChronology();
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant13);
//        int int16 = dateTime11.compareTo((org.joda.time.ReadableInstant) instant13);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560724197720L + "'", long15 == 1560724197720L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate1.withPeriodAdded(readablePeriod3, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfWeek((int) '4');
        boolean boolean11 = dateTimeFormatterBuilder8.canBuildFormatter();
        boolean boolean12 = dateTimeFormatterBuilder8.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendSecondOfDay(1439);
        boolean boolean15 = localDate1.equals((java.lang.Object) dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate10.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"97\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 1, 1869);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (-1));
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder9.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        boolean boolean3 = buddhistChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = localDate5.isSupported(dateTimeFieldType7);
        int int9 = localDate5.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = dateTimeZone10.toString();
        org.joda.time.DateTime dateTime13 = localDate5.toDateTimeAtMidnight(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter1.withZone(dateTimeZone10);
        java.lang.Appendable appendable15 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = property18.get();
        org.joda.time.LocalDate localDate21 = property18.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property22 = localDate21.dayOfWeek();
        org.joda.time.LocalDate localDate23 = property22.roundHalfCeilingCopy();
        org.joda.time.Chronology chronology24 = localDate23.getChronology();
        org.joda.time.LocalDate.Property property25 = localDate23.dayOfWeek();
        try {
            dateTimeFormatter14.printTo(appendable15, (org.joda.time.ReadablePartial) localDate23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100, chronology1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        int int16 = property15.get();
        java.util.Locale locale18 = null;
        try {
            org.joda.time.DateTime dateTime19 = property15.setCopy("-28378000", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        long long12 = skipDateTimeField8.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate19 = localDate17.minusMonths((int) '4');
        int int20 = localDate17.getYearOfCentury();
        org.joda.time.LocalDate.Property property21 = localDate17.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.era();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology24.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology24.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField28, (int) (byte) 0);
        int int32 = skipDateTimeField30.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        int int36 = localDate34.getYear();
        int[] intArray37 = localDate34.getValues();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property41 = localDate40.centuryOfEra();
        int[] intArray42 = localDate40.getValues();
        int[] intArray44 = skipDateTimeField30.addWrapField((org.joda.time.ReadablePartial) localDate34, 0, intArray42, 10);
        int int45 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate17, intArray44);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property48 = localDate47.centuryOfEra();
        int int49 = localDate47.getYear();
        int[] intArray50 = localDate47.getValues();
        int int51 = localDate47.getWeekyear();
        org.joda.time.LocalDate localDate53 = localDate47.minusDays(3);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate47.minus(readablePeriod54);
        int[] intArray56 = null;
        int int57 = skipDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate55, intArray56);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 69 + "'", int20 == 69);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1439 + "'", int32 == 1439);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1970 + "'", int51 == 1970);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str22 = localDate21.toString();
        org.joda.time.LocalDate localDate23 = localDate17.withFields((org.joda.time.ReadablePartial) localDate21);
        boolean boolean24 = property15.equals((java.lang.Object) localDate17);
        org.joda.time.DateTimeField[] dateTimeFieldArray25 = localDate17.getFields();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31" + "'", str22.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.appendTimeZoneOffset("BC", true, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfMonth();
        org.joda.time.DurationField durationField14 = zonedChronology12.days();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        java.lang.String str11 = property2.getAsString();
        org.joda.time.LocalDate localDate12 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "19" + "'", str11.equals("19"));
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("America/Los_Angeles");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"America/Los_Angeles\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"America/Los_Angeles\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int[] intArray4 = localDate2.getValues();
        int int5 = localDate2.getWeekOfWeekyear();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) localDate2);
        try {
            long long14 = copticChronology0.getDateTimeMillis(0, 2512, 1888, (int) (byte) -1, 2512, (int) (short) 10, 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        java.lang.String str14 = gregorianChronology13.toString();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15);
        org.joda.time.DurationField durationField17 = gregorianChronology9.minutes();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, dateTimeZone18);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.Chronology chronology30 = zonedChronology20.withZone(dateTimeZone28);
        long long33 = dateTimeZone28.convertLocalToUTC((-59999L), false);
        java.lang.String str34 = dateTimeZone28.toString();
        org.joda.time.DateTime dateTime35 = localDate7.toDateTimeAtCurrentTime(dateTimeZone28);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str14.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28740001L + "'", long33 == 28740001L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "America/Los_Angeles" + "'", str34.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronolgy();
        boolean boolean7 = dateTimeFormatter5.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withPivotYear(0);
        java.lang.String str10 = localDate4.toString(dateTimeFormatter5);
        org.joda.time.LocalDate.Property property11 = localDate4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            int int13 = localDate4.get(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1869-W52" + "'", str10.equals("1869-W52"));
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) instant19);
        org.joda.time.DateTime dateTime21 = instant19.toDateTime();
        int int22 = dateTime14.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withMillis((-3155731622000L));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone29 = dateTime14.getZone();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.getMinimumValueOverall();
        java.lang.Class<?> wildcardClass4 = property2.getClass();
        org.joda.time.LocalDate localDate5 = property2.getLocalDate();
        try {
            org.joda.time.LocalDate localDate7 = localDate5.withDayOfMonth(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.clockhourOfDay();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField5 = gJChronology0.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        int int22 = localDate20.getYear();
        int[] intArray23 = localDate20.getValues();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        org.joda.time.LocalDate localDate28 = property26.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology29.getZone();
        org.joda.time.DateTime dateTime32 = localDate28.toDateTimeAtStartOfDay(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = localDate20.toDateTime((org.joda.time.ReadableInstant) dateTime32);
        java.lang.String str34 = dateTimeFormatter18.print((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime.Property property35 = dateTime32.centuryOfEra();
        int int36 = property35.getLeapAmount();
        org.joda.time.DateTime dateTime37 = property35.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime39 = property35.addWrapFieldToCopy(1969);
        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime14, (java.lang.Object) dateTime39);
        int int41 = dateTime39.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1869-12-31T00" + "'", str34.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 198769 + "'", int41 == 198769);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        boolean boolean16 = skipDateTimeField8.isSupported();
        int int18 = skipDateTimeField8.get((long) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 960 + "'", int18 == 960);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 55800837 + "'", int1 == 55800837);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.DateTime dateTime19 = dateTime14.withFieldAdded(durationFieldType17, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("1439");
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.LocalDate localDate4 = localDate1.plusWeeks(0);
        int int5 = localDate4.size();
        try {
            org.joda.time.LocalDate localDate7 = localDate4.withDayOfYear(55840263);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55840263 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendHourOfDay(2922789);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = copticChronology15.add(readablePeriod16, (long) 100, 1);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1439");
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long26 = dateTimeZone23.convertLocalToUTC(86340001L, false);
        org.joda.time.DateTime dateTime27 = dateTime21.toDateTime(dateTimeZone23);
        boolean boolean28 = copticChronology15.equals((java.lang.Object) dateTime27);
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = dateTime27.toString("(\"org.joda.time.JodaTimePermission\" \"America/Los_Angeles\")", locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86339901L + "'", long26 == 86339901L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.clockhourOfDay();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int[] intArray8 = localDate6.getValues();
        int int9 = localDate6.getWeekOfWeekyear();
        boolean boolean10 = gJChronology0.equals((java.lang.Object) int9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "960");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("DateTimeField[minuteOfDay]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYear(929, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        int int6 = localDate4.getYear();
        int[] intArray7 = localDate4.getValues();
        int int8 = localDate4.getWeekyear();
        org.joda.time.LocalDate localDate10 = localDate4.minusDays(3);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate4.minus(readablePeriod11);
        org.joda.time.Interval interval13 = localDate12.toInterval();
        int[] intArray15 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDate12, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        try {
            long long9 = copticChronology0.getDateTimeMillis((int) '#', 0, 0, 930, 0, 0, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 930 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.centuries();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) gJChronology1);
        org.joda.time.Instant instant4 = gJChronology1.getGregorianCutover();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.toString();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone5);
        int int10 = dateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.Chronology chronology11 = gJChronology1.withZone(dateTimeZone5);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate18 = localDate16.minusMonths((int) '4');
        int int19 = localDate16.getYearOfCentury();
        int int20 = localDate16.getYear();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.era();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology23.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, dateTimeField27, (int) (byte) 0);
        int int31 = skipDateTimeField29.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        int int35 = localDate33.getYear();
        int[] intArray36 = localDate33.getValues();
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property40 = localDate39.centuryOfEra();
        int[] intArray41 = localDate39.getValues();
        int[] intArray43 = skipDateTimeField29.addWrapField((org.joda.time.ReadablePartial) localDate33, 0, intArray41, 10);
        gJChronology1.validate((org.joda.time.ReadablePartial) localDate16, intArray43);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 69 + "'", int19 == 69);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1869 + "'", int20 == 1869);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1439 + "'", int31 == 1439);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1869);
        try {
            long long4 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfSecond((int) '4', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendSecondOfDay((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder20.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter26 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray46 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser37, dateTimeParser39, dateTimeParser41, dateTimeParser43, dateTimeParser45 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder31.append(dateTimePrinter33, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder25.append(dateTimePrinter26, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.append(dateTimePrinter23, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder11.appendMillisOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.appendDayOfYear(1888);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeParserArray46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant5 = instant3.minus((long) 4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 0);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("minuteOfDay", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("97", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"97\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = copticChronology15.add(readablePeriod16, (long) 100, 1);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.parse("1439");
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long26 = dateTimeZone23.convertLocalToUTC(86340001L, false);
        org.joda.time.DateTime dateTime27 = dateTime21.toDateTime(dateTimeZone23);
        boolean boolean28 = copticChronology15.equals((java.lang.Object) dateTime27);
        try {
            long long36 = copticChronology15.getDateTimeMillis(1439, 0, 0, (int) (byte) 1, 19, (-1), 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86339901L + "'", long26 == 86339901L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.lang.String str16 = property15.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = gJChronology18.centuries();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter17, (java.lang.Object) gJChronology18);
        org.joda.time.Instant instant21 = gJChronology18.getGregorianCutover();
        long long22 = property15.getDifferenceAsLong((org.joda.time.ReadableInstant) instant21);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9063561178000L + "'", long22 == 9063561178000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfHour(1888, 1888);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        int int5 = delegatedDateTimeField2.getMaximumValue();
        try {
            long long8 = delegatedDateTimeField2.set((long) (short) 0, "millisOfDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 22, (java.lang.Number) (-5756400001L), (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("1439");
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        java.util.Date date3 = localDate1.toDate();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("America/Los_Angeles");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = buddhistChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property3.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate7 = localDate5.minusMonths((int) '4');
        int int8 = localDate5.getYearOfCentury();
        int int9 = localDate5.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = localDate5.getFieldType(0);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1869 + "'", int9 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone16 = copticChronology15.getZone();
        org.joda.time.DurationField durationField17 = copticChronology15.seconds();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName(0L, locale5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone3);
//        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(instant8);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        long long19 = skipDateTimeField8.roundHalfEven((long) (byte) 100);
        long long21 = skipDateTimeField8.remainder(0L);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField8.getAsShortText((int) (short) 1, locale23);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int[] intArray28 = localDate26.getValues();
        int int29 = localDate26.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate26.minus(readablePeriod30);
        org.joda.time.Partial partial32 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate31);
        int int33 = partial32.size();
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property36 = localDate35.centuryOfEra();
        org.joda.time.LocalDate localDate38 = property36.addToCopy((int) (short) -1);
        int int39 = localDate38.getYear();
        org.joda.time.LocalDate localDate41 = localDate38.withWeekyear(0);
        org.joda.time.LocalDate localDate43 = localDate41.minusMonths(1970);
        boolean boolean44 = partial32.isEqual((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.Partial partial46 = partial32.plus(readablePeriod45);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = partial32.getFormatter();
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) partial32, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1869 + "'", int39 == 1869);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(partial46);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long11 = skipDateTimeField8.set(0L, "0");
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, durationField14, dateTimeFieldType15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        org.joda.time.LocalDate localDate21 = property19.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate23 = localDate21.minusMonths((int) '4');
        int int24 = localDate21.getYearOfCentury();
        int int25 = localDate21.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = localDate21.getFieldType(0);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 69 + "'", int24 == 69);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1869 + "'", int25 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 24);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
//        org.joda.time.LocalDate localDate6 = property4.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
//        org.joda.time.DateTime dateTime10 = localDate6.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        java.lang.String str14 = dateTimeZone13.toString();
//        org.joda.time.Interval interval15 = localDate6.toInterval(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getShortName((long) (byte) 100, locale21);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (short) 1, (int) (byte) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology27 = gregorianChronology16.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime28 = localDate1.toDateTimeAtStartOfDay(dateTimeZone19);
//        int int29 = dateTime28.getDayOfMonth();
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(interval15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        int int7 = localDate5.getYear();
        int[] intArray8 = localDate5.getValues();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime17 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = localDate5.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        try {
            org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((int) (byte) 0, 2019, 19, (org.joda.time.Chronology) gJChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtMidnight();
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 2019);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("America/Los_Angeles");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"America/Los_Angeles\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"America/Los_Angeles\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField10);
        org.joda.time.DurationField durationField12 = gregorianChronology4.minutes();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology4.getZone();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset((long) (byte) 100);
        long long20 = dateTimeZone13.getMillisKeepLocal(dateTimeZone16, 86340001L);
        boolean boolean21 = gregorianChronology1.equals((java.lang.Object) long20);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str9.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86340001L + "'", long20 == 86340001L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        boolean boolean2 = dateTimeFormatter1.isOffsetParsed();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        boolean boolean18 = zonedChronology12.equals((java.lang.Object) 1.0d);
        long long24 = zonedChronology12.getDateTimeMillis((long) 7, 8, 0, (int) ' ', 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28767990L) + "'", long24 == (-28767990L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.append(dateTimePrinter16, dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder4.appendMonthOfYear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYear(929);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday(99);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = dateTimeZone1.toString();
//        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone1);
//        java.lang.String str5 = buddhistChronology0.toString();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
//        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
//        java.lang.String str18 = dateTimeZone17.toString();
//        org.joda.time.Interval interval19 = localDate10.toInterval(dateTimeZone17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.Chronology chronology21 = buddhistChronology0.withZone(dateTimeZone17);
//        java.lang.String str23 = dateTimeZone17.getName(0L);
//        java.util.TimeZone timeZone24 = dateTimeZone17.toTimeZone();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str5.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(interval19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(timeZone24);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime14.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime18 = dateTime14.withYearOfCentury(12);
        try {
            org.joda.time.DateTime dateTime20 = dateTime14.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime18 = dateTime14.withYear(4);
        org.joda.time.Instant instant19 = dateTime14.toInstant();
        int int20 = dateTime14.getYearOfCentury();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime14.withFieldAdded(durationFieldType21, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 69 + "'", int20 == 69);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        int int7 = property2.getMinimumValue();
        org.joda.time.LocalDate localDate8 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        org.joda.time.LocalDate localDate7 = property6.roundHalfCeilingCopy();
        java.lang.String str8 = property6.getName();
        org.joda.time.DateTimeField dateTimeField9 = property6.getField();
        java.lang.String str10 = property6.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfWeek" + "'", str8.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[dayOfWeek]" + "'", str10.equals("Property[dayOfWeek]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 198769);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1439", (java.lang.Number) 1, (java.lang.Number) (byte) 1, (java.lang.Number) 11L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("");
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours(3);
        org.joda.time.DateTime dateTime21 = dateTime17.withWeekyear(937);
        org.joda.time.DateTime.Property property22 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime23 = property22.roundHalfCeilingCopy();
        boolean boolean24 = dateTime23.isEqualNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendSecondOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendClockhourOfDay(8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = gregorianChronology11.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13);
        org.joda.time.DurationField durationField15 = gregorianChronology7.minutes();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
        org.joda.time.Chronology chronology22 = zonedChronology18.withZone(dateTimeZone21);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate27 = property25.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology28.getZone();
        org.joda.time.DateTime dateTime31 = localDate27.toDateTimeAtStartOfDay(dateTimeZone30);
        org.joda.time.Instant instant32 = dateTime31.toInstant();
        org.joda.time.Chronology chronology33 = dateTime31.getChronology();
        int int34 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime31);
        try {
            org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(0, 55840263, 55800837, 55840263, 1439, 12, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55840263 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str8.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-28378000) + "'", int34 == (-28378000));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int[] intArray20 = localDate18.getValues();
        int[] intArray22 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate12, 0, intArray20, 10);
        long long24 = skipDateTimeField8.roundFloor(11L);
        long long26 = skipDateTimeField8.roundHalfEven((long) 929);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.Chronology chronology5 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(chronology5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        int int5 = localDate4.getWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1869 + "'", int5 == 1869);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.LocalDate localDate8 = property6.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate10 = localDate8.minusMonths((int) '4');
        int int11 = localDate8.getYearOfCentury();
        int int12 = localDate8.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = localDate8.getFieldType(0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField3, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1869 + "'", int12 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        boolean boolean30 = dateTimeZone25.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths((int) '4');
        int int39 = localDate36.getYearOfCentury();
        boolean boolean40 = cachedDateTimeZone31.equals((java.lang.Object) localDate36);
        int int42 = cachedDateTimeZone31.getOffset((long) 100);
        java.lang.String str44 = cachedDateTimeZone31.getNameKey((long) (byte) 1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PST" + "'", str44.equals("PST"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property18 = dateTime15.centuryOfEra();
        int int19 = property18.getLeapAmount();
        org.joda.time.DateTime dateTime20 = property18.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime22 = property18.addWrapFieldToCopy(1969);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property18.getAsText(locale23);
        org.joda.time.DurationField durationField25 = property18.getRangeDurationField();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        int int29 = localDate27.getYear();
        int[] intArray30 = localDate27.getValues();
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
        org.joda.time.LocalDate localDate35 = property33.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone38 = gJChronology36.getZone();
        org.joda.time.DateTime dateTime39 = localDate35.toDateTimeAtStartOfDay(dateTimeZone38);
        org.joda.time.DateTime dateTime40 = localDate27.toDateTime((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime42 = dateTime40.withSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology43.clockhourOfDay();
        int int46 = dateTime40.get(dateTimeField45);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property49 = localDate48.centuryOfEra();
        org.joda.time.LocalDate localDate51 = property49.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate53 = localDate51.minusMonths((int) '4');
        int int54 = localDate51.getYearOfCentury();
        int int55 = localDate51.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = localDate51.getFieldType(0);
        int int58 = dateTime40.get(dateTimeFieldType57);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField25, dateTimeFieldType57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "18" + "'", str24.equals("18"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 69 + "'", int54 == 69);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1869 + "'", int55 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1969 + "'", int58 == 1969);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        try {
            long long6 = delegatedDateTimeField2.add((-210858120000000L), (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate10 = localDate1.withYear(929);
        org.joda.time.LocalDate localDate12 = localDate10.plusDays(1888);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property3.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate7 = localDate5.minusMonths((int) '4');
        int int8 = localDate5.getYearOfCentury();
        int int9 = localDate5.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = localDate5.getFieldType(0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1869 + "'", int9 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = property2.getAsText(locale6);
        org.joda.time.LocalDate localDate8 = property2.withMinimumValue();
        org.joda.time.LocalDate localDate10 = localDate8.minusMonths(1);
        int int11 = localDate10.getYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "19" + "'", str7.equals("19"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        boolean boolean16 = skipDateTimeField8.isSupported();
        long long19 = skipDateTimeField8.addWrapField(86340001L, (-28378000));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 100);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 91140001L + "'", long19 == 91140001L);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime5 = property2.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        boolean boolean16 = skipDateTimeField8.isSupported();
        long long19 = skipDateTimeField8.addWrapField(86340001L, (-28378000));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 100);
        long long23 = offsetDateTimeField21.roundHalfFloor((long) 'a');
        org.joda.time.DurationField durationField24 = offsetDateTimeField21.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 91140001L + "'", long19 == 91140001L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 100);
        org.joda.time.DateTime dateTime4 = instant0.toDateTimeISO();
        int int5 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset((long) (byte) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) ' ', dateTimeZone3);
        org.joda.time.LocalDate localDate8 = localDate6.withDayOfWeek(4);
        org.joda.time.LocalDate localDate10 = localDate8.withYearOfCentury(52);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property8 = localDate5.dayOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = localDate5.getFields();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.LocalDate localDate4 = localDate1.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        java.lang.String str17 = dateTimeZone16.toString();
        org.joda.time.Interval interval18 = localDate9.toInterval(dateTimeZone16);
        org.joda.time.LocalDate localDate20 = localDate9.minusWeeks(10);
        int int21 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        boolean boolean16 = skipDateTimeField8.isSupported();
        long long19 = skipDateTimeField8.addWrapField(86340001L, (-28378000));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 100);
        long long24 = offsetDateTimeField21.add((long) 937, 24);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField21.getAsText((-1), locale26);
        int int30 = offsetDateTimeField21.getDifference((long) 198769, (-57600000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 91140001L + "'", long19 == 91140001L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1440937L + "'", long24 == 1440937L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 963 + "'", int30 == 963);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 100);
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = localDate1.withYearOfEra(1439);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTime dateTime18 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = localDate6.toDateTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime19.withSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.clockhourOfDay();
        int int25 = dateTime19.get(dateTimeField24);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate32 = localDate30.minusMonths((int) '4');
        int int33 = localDate30.getYearOfCentury();
        int int34 = localDate30.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = localDate30.getFieldType(0);
        int int37 = dateTime19.get(dateTimeFieldType36);
        org.joda.time.DateTime dateTime38 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 69 + "'", int33 == 69);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1869 + "'", int34 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(dateTime38);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy(1969);
//        java.lang.String str5 = dateTime4.toString();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays((int) (short) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-11-06T22:31:07.250Z" + "'", str5.equals("2019-11-06T22:31:07.250Z"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfHour();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        int int7 = localDate5.getYear();
        int[] intArray8 = localDate5.getValues();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime17 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = localDate5.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        java.lang.String str25 = gregorianChronology24.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26);
        org.joda.time.DurationField durationField28 = gregorianChronology20.minutes();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime18.toMutableDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology33 = gJChronology0.withZone(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField34 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = gJChronology0.withZone(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        try {
            int[] intArray40 = gJChronology0.get(readablePeriod37, (-5756400001L), (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str25.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(zonedChronology31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField2.getDurationField();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property10.addToCopy((int) (short) -1);
        int int13 = localDate12.getYear();
        org.joda.time.LocalDate localDate15 = localDate12.withWeekyear(0);
        org.joda.time.LocalDate localDate17 = localDate15.minusMonths(1970);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.era();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.secondOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology20.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, (int) (byte) 0);
        int int28 = skipDateTimeField26.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property31 = localDate30.centuryOfEra();
        int int32 = localDate30.getYear();
        int[] intArray33 = localDate30.getValues();
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property37 = localDate36.centuryOfEra();
        int[] intArray38 = localDate36.getValues();
        int[] intArray40 = skipDateTimeField26.addWrapField((org.joda.time.ReadablePartial) localDate30, 0, intArray38, 10);
        int int41 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate15, intArray40);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1869 + "'", int13 == 1869);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1439 + "'", int28 == 1439);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(7);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(1869, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField8.getAsText((long) 1888, locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) str16, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = null;
        java.lang.String str22 = localDate20.toString(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1869" + "'", str13.equals("1869"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "960" + "'", str16.equals("960"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0960-01-01" + "'", str22.equals("0960-01-01"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate localDate9 = localDate4.minusWeeks(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.LocalDate localDate13 = localDate9.withDayOfMonth(4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((java.lang.Integer) (-28378000));
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withLocale(locale5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str13 = localDate12.toString();
        org.joda.time.LocalDate localDate14 = localDate8.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.LocalDate localDate19 = property17.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate21 = localDate19.minusMonths((int) '4');
        int int22 = localDate19.getYearOfCentury();
        int int23 = localDate19.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = localDate19.getFieldType(0);
        org.joda.time.LocalDate.Property property26 = localDate12.property(dateTimeFieldType25);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType25, (-28800000), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31" + "'", str13.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1869 + "'", int23 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime10 = dateTime8.withDayOfYear(1);
        int int11 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime12 = dateTime10.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        org.joda.time.LocalDate localDate21 = property19.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology22.getZone();
        org.joda.time.DateTime dateTime25 = localDate21.toDateTimeAtStartOfDay(dateTimeZone24);
        org.joda.time.Instant instant26 = dateTime25.toInstant();
        org.joda.time.Chronology chronology27 = dateTime25.getChronology();
        int int28 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property29 = dateTime25.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28378000) + "'", int28 == (-28378000));
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        long long9 = dateTime8.getMillis();
        org.joda.time.DateTime dateTime10 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime8.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime13 = dateTime11.plus(36523L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3155731622000L) + "'", long9 == (-3155731622000L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        int int5 = localDate4.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = localDate4.isSupported(dateTimeFieldType6);
        try {
            int int9 = localDate4.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 97");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1869 + "'", int5 == 1869);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = property4.get();
        org.joda.time.LocalDate localDate7 = property4.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.era();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField14, (int) (byte) 0);
        int int18 = skipDateTimeField16.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        int int22 = localDate20.getYear();
        int int23 = skipDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate20);
        boolean boolean24 = localDate7.isEqual((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int int28 = localDate26.getYear();
        int[] intArray29 = localDate26.getValues();
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.LocalDate localDate34 = property32.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
        org.joda.time.DateTime dateTime38 = localDate34.toDateTimeAtStartOfDay(dateTimeZone37);
        org.joda.time.DateTime dateTime39 = localDate26.toDateTime((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        java.lang.String str42 = gregorianChronology41.toString();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        java.lang.String str46 = gregorianChronology45.toString();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology41, dateTimeField47);
        org.joda.time.DurationField durationField49 = gregorianChronology41.minutes();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone50);
        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, dateTimeZone50);
        org.joda.time.MutableDateTime mutableDateTime53 = dateTime39.toMutableDateTime(dateTimeZone50);
        boolean boolean55 = dateTimeZone50.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone50);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property59 = localDate58.centuryOfEra();
        org.joda.time.LocalDate localDate61 = property59.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate63 = localDate61.minusMonths((int) '4');
        int int64 = localDate61.getYearOfCentury();
        boolean boolean65 = cachedDateTimeZone56.equals((java.lang.Object) localDate61);
        java.lang.String str67 = cachedDateTimeZone56.getNameKey((long) (byte) 1);
        org.joda.time.Interval interval68 = localDate20.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        org.joda.time.Chronology chronology69 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        java.lang.String str70 = julianChronology0.toString();
        java.lang.String str71 = julianChronology0.toString();
        try {
            long long79 = julianChronology0.getDateTimeMillis(0, (int) 'a', (int) '4', (-28800000), (int) 'a', 5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1439 + "'", int18 == 1439);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str42.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str46.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(zonedChronology52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 69 + "'", int64 == 69);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "PST" + "'", str67.equals("PST"));
        org.junit.Assert.assertNotNull(interval68);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str70.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str71.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        boolean boolean30 = dateTimeZone25.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths((int) '4');
        int int39 = localDate36.getYearOfCentury();
        boolean boolean40 = cachedDateTimeZone31.equals((java.lang.Object) localDate36);
        int int42 = cachedDateTimeZone31.getOffset((long) 100);
        boolean boolean44 = cachedDateTimeZone31.equals((java.lang.Object) 12);
        java.lang.String str46 = cachedDateTimeZone31.getNameKey((-59999L));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "PST" + "'", str46.equals("PST"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendSecondOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYearOfEra(1969, 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Integer int13 = dateTimeFormatter12.getPivotYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.append(dateTimeFormatter12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
        boolean boolean21 = dateTimeFormatter20.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder11.append(dateTimeFormatter20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder11.appendFractionOfHour(0, 1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(int13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        int int8 = localDate4.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = localDate4.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "365");
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869 + "'", int8 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) -1, 22, (int) (short) 0, 55800837, 4, 960, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55800837 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.lang.String str16 = property15.getName();
        org.joda.time.DateTime dateTime17 = property15.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology16.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology16.weekyearOfCentury();
        org.joda.time.DateTime dateTime22 = dateTime14.toDateTime((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTime dateTime24 = dateTime14.minusWeeks(100);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((long) 'a', (int) (byte) 1, 0, (int) '#', 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, (-28800000), 3, 55800837, 1439, (int) (short) 1, 937);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55800837 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        try {
            long long6 = delegatedDateTimeField2.set((long) (-28800000), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1439");
        org.joda.time.TimeOfDay timeOfDay2 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(timeOfDay2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "DateTimeField[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone4);
        int int7 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
        org.joda.time.DateTime dateTime12 = dateTime8.minusWeeks((-1));
        java.lang.Class<?> wildcardClass13 = dateTime8.getClass();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("BuddhistChronology[America/Los_Angeles]", 0, 2019, 55840263, '#', 2512, 31, (int) (byte) 100, true, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.getMinimumValueOverall();
        int int4 = property2.getMaximumValueOverall();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTime dateTime18 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = localDate6.toDateTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime19.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.DateTime dateTime23 = property22.roundHalfFloorCopy();
        long long24 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2922789 + "'", int4 == 2922789);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        int int9 = dateTime8.getWeekyear();
        int int10 = dateTime8.getYearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1869 + "'", int9 == 1869);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1869 + "'", int10 == 1869);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        int int8 = localDate4.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = localDate4.getFieldType(0);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime27 = dateTime25.withSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.clockhourOfDay();
        int int31 = dateTime25.get(dateTimeField30);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths((int) '4');
        int int39 = localDate36.getYearOfCentury();
        int int40 = localDate36.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = localDate36.getFieldType(0);
        int int43 = dateTime25.get(dateTimeFieldType42);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property46 = localDate45.centuryOfEra();
        org.joda.time.LocalDate localDate48 = property46.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate50 = localDate48.minusMonths((int) '4');
        int int51 = localDate48.getYearOfCentury();
        int int52 = localDate48.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = localDate48.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, "365");
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property59 = localDate58.centuryOfEra();
        int int60 = localDate58.getYear();
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str63 = localDate62.toString();
        org.joda.time.LocalDate localDate64 = localDate58.withFields((org.joda.time.ReadablePartial) localDate62);
        org.joda.time.LocalDate localDate66 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property67 = localDate66.centuryOfEra();
        org.joda.time.LocalDate localDate69 = property67.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate71 = localDate69.minusMonths((int) '4');
        int int72 = localDate69.getYearOfCentury();
        int int73 = localDate69.getYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = localDate69.getFieldType(0);
        org.joda.time.LocalDate.Property property76 = localDate62.property(dateTimeFieldType75);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray77 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType10, dateTimeFieldType42, dateTimeFieldType54, dateTimeFieldType75 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList78 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean79 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList78, dateTimeFieldTypeArray77);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList78, false, true);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1869 + "'", int8 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1869 + "'", int40 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1969 + "'", int43 == 1969);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 69 + "'", int51 == 69);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1869 + "'", int52 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1969 + "'", int60 == 1969);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1969-12-31" + "'", str63.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 69 + "'", int72 == 69);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1869 + "'", int73 == 1869);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
    }
}

