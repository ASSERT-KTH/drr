import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField1, dateTimeFieldType2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray6 = new int[] { (byte) 10, (byte) 100, (short) 100, (byte) 1 };
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0f, number2, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.Appendable appendable1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) ' ', 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        try {
            org.joda.time.LocalDate localDate6 = localDate1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 0, (int) (short) -1, (int) (byte) 10, (int) (short) 10, (int) (byte) 10, (int) (short) 1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis((int) (byte) 0, (int) (byte) 1, 0, (int) (short) 10, (int) (short) 1, (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) ' ', (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', (int) (short) 10, (int) (byte) -1, (int) '4', (int) (byte) -1, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Appendable appendable1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.LocalTime localTime9 = null;
        try {
            org.joda.time.LocalDateTime localDateTime10 = localDate4.toLocalDateTime(localTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withField(dateTimeFieldType16, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) instant4);
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((int) (short) -1, (int) (byte) -1, (int) (byte) 1, (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) (byte) 100, locale4);
//        long long8 = dateTimeZone2.convertLocalToUTC((long) '#', true);
//        org.joda.time.LocalDateTime localDateTime9 = null;
//        try {
//            boolean boolean10 = dateTimeZone2.isLocalDateTimeGap(localDateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800035L + "'", long8 == 28800035L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime17 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate13, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(10L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray12 = gregorianChronology1.get(readablePeriod10, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra((int) (short) 1);
        boolean boolean12 = dateTime8.isBeforeNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate16.withPeriodAdded(readablePeriod18, (int) (byte) 1);
        int[] intArray22 = new int[] {};
        try {
            int[] intArray24 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate16, 0, intArray22, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        try {
            org.joda.time.DateTime dateTime34 = dateTime13.withMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = instant0.toDateTime();
        org.joda.time.Instant instant4 = instant0.plus((long) 100);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("19", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"19/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) (byte) 100, locale4);
//        long long8 = dateTimeZone2.convertLocalToUTC((long) '#', true);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone2, dateTimeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800035L + "'", long8 == 28800035L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType15, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) (byte) 100, locale4);
//        long long8 = dateTimeZone2.convertLocalToUTC((long) '#', true);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800035L + "'", long8 == 28800035L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        java.lang.String str3 = dateTimeZone2.toString();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        long long6 = gJChronology0.set((org.joda.time.ReadablePartial) localDate2, (long) (byte) 100);
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withEra(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        try {
            long long17 = gregorianChronology1.getDateTimeMillis(1869, (int) '#', (int) (byte) -1, 4, (int) (byte) 1, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod2, 0L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        int[] intArray12 = localDate10.getValues();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property16 = localDate15.centuryOfEra();
        int[] intArray17 = localDate15.getValues();
        try {
            int[] intArray19 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate10, 929, intArray17, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 929");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime34 = dateTime13.withEra((int) (byte) 1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        long long12 = durationField9.subtract(1L, (long) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59999L) + "'", long12 == (-59999L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.util.Locale locale17 = null;
        try {
            org.joda.time.DateTime dateTime18 = property15.setCopy("America/Los_Angeles", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        org.joda.time.LocalTime localTime14 = null;
        try {
            org.joda.time.LocalDateTime localDateTime15 = localDate4.toLocalDateTime(localTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        boolean boolean10 = dateTimeZone8.isStandardOffset((long) (byte) 100);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1439, (int) (short) -1, 1969, (int) (byte) 100, 0, 1970, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyearOfCentury();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1869, 10, 1439, 100, (int) (byte) 10, 0, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str8.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.LocalDate localDate9 = localDate6.withField(dateTimeFieldType7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        boolean boolean6 = gJChronology2.equals((java.lang.Object) property5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = skipDateTimeField8.getWrappedField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 1, 1969, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for halfdayOfDay must be in the range [1969,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1869-12-31T00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1439");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 1, (int) (short) 1, (int) ' ');
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField7, (int) (byte) 0);
//        long long11 = skipDateTimeField9.roundHalfEven(0L);
//        int int12 = instant0.get((org.joda.time.DateTimeField) skipDateTimeField9);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
//        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = skipDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 929 + "'", int12 == 929);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) -1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, 1888);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1888");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(19, (int) '4', 19, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = skipDateTimeField8.getWrappedField();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        int int13 = localDate11.getYear();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str16 = localDate15.toString();
        org.joda.time.LocalDate localDate17 = localDate11.withFields((org.joda.time.ReadablePartial) localDate15);
        int[] intArray25 = new int[] { 1969, 100, 1888, (byte) 10, '#', 1969 };
        try {
            int[] intArray27 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate15, (-1), intArray25, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-31" + "'", str16.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(929, (int) (byte) 100, 1, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        int int33 = dateTime30.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
        org.joda.time.MutableDateTime mutableDateTime19 = instant18.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property22 = localDate21.centuryOfEra();
        int int23 = localDate21.getYear();
        int[] intArray24 = localDate21.getValues();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        org.joda.time.LocalDate localDate29 = property27.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology30.getZone();
        org.joda.time.DateTime dateTime33 = localDate29.toDateTimeAtStartOfDay(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = localDate21.toDateTime((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime.Property property35 = dateTime33.millisOfDay();
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property38 = localDate37.centuryOfEra();
        int int39 = localDate37.getYear();
        int[] intArray40 = localDate37.getValues();
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property43 = localDate42.centuryOfEra();
        org.joda.time.LocalDate localDate45 = property43.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone48 = gJChronology46.getZone();
        org.joda.time.DateTime dateTime49 = localDate45.toDateTimeAtStartOfDay(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = localDate37.toDateTime((org.joda.time.ReadableInstant) dateTime49);
        boolean boolean51 = dateTime50.isEqualNow();
        boolean boolean52 = dateTime33.isEqual((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DateTime dateTime54 = dateTime33.plusYears(19);
        int int55 = dateTime54.getYear();
        boolean boolean56 = instant18.isAfter((org.joda.time.ReadableInstant) dateTime54);
        org.joda.time.DateTime dateTime57 = instant18.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1888 + "'", int55 == 1888);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTime57);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.LocalDate localDate7 = localDate4.withField(dateTimeFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.withYear((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.LocalDate localDate11 = localDate4.withField(dateTimeFieldType9, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
        org.joda.time.DateTime dateTime12 = dateTime8.withWeekyear(0);
        int int13 = dateTime8.getYearOfEra();
        int int14 = dateTime8.getMillisOfSecond();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1869 + "'", int13 == 1869);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumShortTextLength(locale16);
        try {
            org.joda.time.DateTime dateTime19 = property15.setCopy("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipDateTimeField8.getAsShortText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.centuries();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) gJChronology1);
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.centuries();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.LocalDate localDate4 = localDate1.plusWeeks(0);
        int int5 = localDate4.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        int int6 = localDate4.getYear();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str9 = localDate8.toString();
        org.joda.time.LocalDate localDate10 = localDate4.withFields((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTime dateTime11 = localDate4.toDateTimeAtStartOfDay();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType1, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (byte) 10, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology12.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
//        int int4 = localDate2.getYear();
//        int[] intArray5 = localDate2.getValues();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
//        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.secondOfDay();
//        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology17);
//        java.lang.String str21 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019-06-15T��" + "'", str21.equals("2019-06-15T��"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property4.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate8 = localDate6.minusMonths((int) '4');
        org.joda.time.LocalDate localDate10 = localDate6.withYear((int) (byte) 1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = localDate10.getFieldTypes();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-1), (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        int int12 = skipDateTimeField8.getMaximumValue((long) (short) 10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 1, 929, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for minuteOfDay must be in the range [929,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1439 + "'", int12 == 1439);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.DateTime dateTime3 = instant1.toDateTime();
        boolean boolean5 = instant1.isBefore((long) (byte) 1);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = gregorianChronology23.toString();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        java.lang.String str28 = gregorianChronology27.toString();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology23, dateTimeField29);
        org.joda.time.DurationField durationField31 = gregorianChronology23.minutes();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology23, dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime21.toMutableDateTime(dateTimeZone32);
        org.joda.time.Chronology chronology36 = iSOChronology5.withZone(dateTimeZone32);
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((int) (byte) 1, (-1), (-1), 69, 1969, chronology36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str24.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str28.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate9 = property8.roundCeilingCopy();
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) ' ');
        try {
            org.joda.time.LocalDate localDate13 = localDate11.withWeekOfWeekyear((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        long long6 = gJChronology0.set((org.joda.time.ReadablePartial) localDate2, (long) (byte) 100);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DurationField durationField3 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gJChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str2.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        int int21 = localDate19.getYear();
        int[] intArray22 = localDate19.getValues();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        org.joda.time.LocalDate localDate27 = property25.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology28.getZone();
        org.joda.time.DateTime dateTime31 = localDate27.toDateTimeAtStartOfDay(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = localDate19.toDateTime((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property33 = dateTime31.millisOfDay();
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property36 = localDate35.centuryOfEra();
        int int37 = localDate35.getYear();
        int[] intArray38 = localDate35.getValues();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property41 = localDate40.centuryOfEra();
        org.joda.time.LocalDate localDate43 = property41.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone46 = gJChronology44.getZone();
        org.joda.time.DateTime dateTime47 = localDate43.toDateTimeAtStartOfDay(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = localDate35.toDateTime((org.joda.time.ReadableInstant) dateTime47);
        boolean boolean49 = dateTime48.isEqualNow();
        boolean boolean50 = dateTime31.isEqual((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime dateTime52 = dateTime31.plus(0L);
        boolean boolean53 = dateTime14.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1969 + "'", int37 == 1969);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 86339901L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) instant8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) '4', 4, (int) '#', 10, (int) (short) 0, 1439, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser8, dateTimeParser10, dateTimeParser12, dateTimeParser14, dateTimeParser16, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder4.append(dateTimePrinter6, dateTimeParserArray19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType21, 929, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology10 = instant9.getChronology();
        org.joda.time.DateTime dateTime11 = instant9.toDateTime();
        org.joda.time.DateTime dateTime12 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime11.secondOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        int int10 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate9);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.LocalDate localDate4 = localDate1.withDayOfYear(4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.LocalDate localDate8 = localDate5.withField(dateTimeFieldType6, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        long long20 = skipDateTimeField8.getDifferenceAsLong((long) 19, (long) (byte) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property8 = localDate1.dayOfYear();
        org.joda.time.Chronology chronology9 = null;
        try {
            org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((java.lang.Object) property8, chronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
        int int11 = dateTime10.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        int int33 = dateTime30.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DurationField durationField3 = gJChronology0.weeks();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(1869, locale12);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField8, (int) ' ', (int) (short) -1, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for minuteOfDay must be in the range [-1,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1869" + "'", str13.equals("1869"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("18");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate9 = property8.roundCeilingCopy();
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        int int13 = localDate11.indexOf(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate4.withPeriodAdded(readablePeriod9, (int) (short) -1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter1.printTo(writer2, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getShortName(32L, locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        try {
            org.joda.time.DateTime dateTime34 = dateTime13.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gregorianChronology1.get(readablePeriod2, (long) 8, 86339901L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1439", (java.lang.Number) 1, (java.lang.Number) (byte) 1, (java.lang.Number) 11L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate1.withPeriodAdded(readablePeriod3, (int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate1.minus(readablePeriod6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = localDate1.isSupported(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField7, (int) (byte) 0);
//        long long11 = skipDateTimeField9.roundHalfEven(0L);
//        int int12 = instant0.get((org.joda.time.DateTimeField) skipDateTimeField9);
//        java.lang.String str13 = skipDateTimeField9.getName();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 930 + "'", int12 == 930);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "minuteOfDay" + "'", str13.equals("minuteOfDay"));
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        java.util.Locale locale20 = null;
        org.joda.time.DateTime dateTime21 = property17.setCopy("19", locale20);
        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
        long long23 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) instant22);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology6 = instant5.getChronology();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, 1888, (int) (byte) 10, (int) (short) -1, 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property18 = dateTime14.monthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("hi!");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException("hi!");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("hi!");
        illegalInstantException6.addSuppressed((java.lang.Throwable) illegalInstantException8);
        illegalInstantException3.addSuppressed((java.lang.Throwable) illegalInstantException6);
        java.lang.Throwable[] throwableArray11 = illegalInstantException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        int int5 = localDate4.getYear();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekyear(0);
        org.joda.time.LocalDate localDate9 = localDate4.plusYears((-28800000));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1869 + "'", int5 == 1869);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        long long12 = durationField9.subtract(0L, (long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-600000L) + "'", long12 == (-600000L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "AD");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            org.joda.time.Partial partial1 = new org.joda.time.Partial(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray22 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15, dateTimeParser17, dateTimeParser19, dateTimeParser21 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendHourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeParserArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        int int12 = skipDateTimeField8.getMaximumValue((long) (short) 10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField8.getAsShortText((long) (byte) 100, locale14);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1439 + "'", int12 == 1439);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "960" + "'", str15.equals("960"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        int int12 = localDate10.getYear();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str15 = localDate14.toString();
        org.joda.time.LocalDate localDate16 = localDate10.withFields((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTime dateTime17 = localDate14.toDateTimeAtMidnight();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        int[] intArray22 = localDate20.getValues();
        try {
            int[] intArray24 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate14, (-1), intArray22, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31" + "'", str15.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 100);
        org.joda.time.DateTime dateTime4 = instant0.toDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays(0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) (byte) 100, locale4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone2.getShortName((long) (short) 100, locale7);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
//        int int4 = localDate2.getYear();
//        int[] intArray5 = localDate2.getValues();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
//        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime18 = dateTime14.minusHours((int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getShortName(0L, locale23);
//        long long27 = dateTimeZone21.convertLocalToUTC(28800035L, false);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
//        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
//        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
//        long long38 = dateTimeZone21.getMillisKeepLocal(dateTimeZone35, (long) (short) 0);
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime14.toMutableDateTime(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 57600035L + "'", long27 == 57600035L);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        try {
            long long13 = gJChronology1.getDateTimeMillis(19, (-1), 0, 929, 1869, 19, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 929 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.LocalDate localDate8 = property6.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTime dateTime12 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        org.joda.time.DateTime dateTime16 = dateTime12.withWeekyear(0);
        int int17 = dateTime12.getYearOfEra();
        int int18 = property2.compareTo((org.joda.time.ReadableInstant) dateTime12);
        boolean boolean19 = dateTime12.isEqualNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1869 + "'", int17 == 1869);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate6 = localDate1.withMonthOfYear((int) (short) 10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(929, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 937 + "'", int2 == 937);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = property2.roundHalfEvenCopy();
        int int7 = property2.getMinimumValue();
        try {
            org.joda.time.LocalDate localDate9 = property2.setCopy("millisOfDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField8);
        org.joda.time.DurationField durationField10 = gregorianChronology2.minutes();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.Chronology chronology17 = zonedChronology13.withZone(dateTimeZone16);
        org.joda.time.DurationField durationField18 = zonedChronology13.centuries();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str7.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.halfdays();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100, (int) (short) 100, 937, (int) (short) 10, 1888, (int) ' ', (int) ' ', (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1888 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1888, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate9 = property8.roundCeilingCopy();
        org.joda.time.LocalDate localDate11 = localDate9.minusYears((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.LocalDate.Property property13 = localDate9.property(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant5 = instant1.withDurationAdded(10L, (-1));
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant5.withDurationAdded(readableDuration7, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        org.joda.time.LocalDate localDate5 = property3.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtStartOfDay(dateTimeZone8);
        int int10 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime9.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28378000) + "'", int10 == (-28378000));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1869 + "'", int11 == 1869);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        try {
            org.joda.time.LocalDate localDate12 = localDate6.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.millisOfDay();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        int int26 = localDate24.getYear();
        int[] intArray27 = localDate24.getValues();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
        boolean boolean38 = dateTime37.isEqualNow();
        boolean boolean39 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime41 = dateTime20.plus(0L);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime41);
        try {
            org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendTimeZoneOffset("PST", "PST", false, 2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.LocalDate localDate27 = property2.withMaximumValue();
        int int28 = property2.getLeapAmount();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = gregorianChronology18.toString();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        java.lang.String str23 = gregorianChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology18, dateTimeField24);
        org.joda.time.DurationField durationField26 = gregorianChronology18.minutes();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology18, dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime16.toMutableDateTime(dateTimeZone27);
        int int31 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        try {
            int int33 = dateTime16.get(dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str19.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str23.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property8 = localDate1.dayOfYear();
        java.lang.String str9 = property8.getAsString();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTime dateTime18 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
        long long19 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "365" + "'", str9.equals("365"));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 36523L + "'", long19 == 36523L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(obj0, chronology2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        int int7 = localDate5.getYear();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str10 = localDate9.toString();
        org.joda.time.LocalDate localDate11 = localDate5.withFields((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTime dateTime12 = localDate5.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate14 = localDate5.withYear(929);
        boolean boolean15 = localDate3.isBefore((org.joda.time.ReadablePartial) localDate5);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("hi!");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException("hi!");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("hi!");
        illegalInstantException6.addSuppressed((java.lang.Throwable) illegalInstantException8);
        illegalInstantException3.addSuppressed((java.lang.Throwable) illegalInstantException6);
        java.lang.Throwable throwable11 = null;
        try {
            illegalInstantException6.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "18");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        java.lang.String str22 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.Instant instant23 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter6);
        org.joda.time.MutableDateTime mutableDateTime24 = instant23.toMutableDateTimeISO();
        try {
            org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime24, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1869-12-31T00" + "'", str22.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.LocalDate localDate32 = localDate17.minusDays(1969);
        int[] intArray40 = new int[] { 1888, '#', 10, (byte) 0, 960, ' ' };
        try {
            int[] intArray42 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate17, (int) (byte) 0, intArray40, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "365");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(0, 2019, 19, 1970, 24, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1869-12-31T00");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfWeek();
        org.joda.time.LocalDate localDate7 = property6.roundHalfCeilingCopy();
        int int8 = localDate7.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.lang.String str16 = property15.getName();
        org.joda.time.DateTime dateTime17 = property15.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField7, (int) (byte) 0);
//        long long11 = skipDateTimeField9.roundHalfEven(0L);
//        int int12 = instant0.get((org.joda.time.DateTimeField) skipDateTimeField9);
//        java.lang.String str13 = skipDateTimeField9.toString();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 930 + "'", int12 == 930);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str13.equals("DateTimeField[minuteOfDay]"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(1869, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField8.getAsText((long) 1888, locale15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int int20 = localDate18.getYear();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str23 = localDate22.toString();
        org.joda.time.LocalDate localDate24 = localDate18.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        int int29 = localDate27.getYear();
        int[] intArray30 = localDate27.getValues();
        try {
            int[] intArray32 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate18, (int) (short) 10, intArray30, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1869" + "'", str13.equals("1869"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "960" + "'", str16.equals("960"));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969-12-31" + "'", str23.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis(1969, (int) (byte) -1, 0, 0, 69, 937, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        long long9 = dateTime8.getMillis();
        org.joda.time.DateTime dateTime10 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.minuteOfHour();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        int int18 = localDate16.getYear();
        int[] intArray19 = localDate16.getValues();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property22 = localDate21.centuryOfEra();
        org.joda.time.LocalDate localDate24 = property22.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology25.getZone();
        org.joda.time.DateTime dateTime28 = localDate24.toDateTimeAtStartOfDay(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        java.lang.String str36 = gregorianChronology35.toString();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology31, dateTimeField37);
        org.joda.time.DurationField durationField39 = gregorianChronology31.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology31, dateTimeZone40);
        org.joda.time.MutableDateTime mutableDateTime43 = dateTime29.toMutableDateTime(dateTimeZone40);
        org.joda.time.Chronology chronology44 = gJChronology11.withZone(dateTimeZone40);
        org.joda.time.DateTime dateTime45 = dateTime10.withChronology(chronology44);
        int int46 = dateTime45.getWeekyear();
        org.joda.time.DateTime dateTime48 = dateTime45.minusYears(24);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3155731622000L) + "'", long9 == (-3155731622000L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str32.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str36.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(zonedChronology42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1869 + "'", int46 == 1869);
        org.junit.Assert.assertNotNull(dateTime48);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology10 = instant9.getChronology();
        org.joda.time.DateTime dateTime11 = instant9.toDateTime();
        org.joda.time.DateTime dateTime12 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        try {
            org.joda.time.LocalDate localDate14 = localDate4.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 937);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(readableInterval7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.LocalDate localDate5 = localDate1.withPeriodAdded(readablePeriod3, (int) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.LocalDate localDate7 = localDate1.minus(readablePeriod6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getShortName((long) (byte) 100, locale12);
//        long long16 = dateTimeZone10.convertLocalToUTC((long) '#', true);
//        org.joda.time.DateTime dateTime17 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
//        try {
//            org.joda.time.LocalDate localDate19 = localDate7.withDayOfWeek((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800035L + "'", long16 == 28800035L);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsText((long) 3, locale6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AD" + "'", str7.equals("AD"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        boolean boolean3 = julianChronology0.equals((java.lang.Object) gJChronology1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        int int9 = localDate4.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 100);
        org.joda.time.DateTime dateTime4 = instant0.toDateTimeISO();
        org.joda.time.Instant instant6 = instant0.withMillis((long) 930);
        org.joda.time.DateTime dateTime7 = instant0.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.getMinimumValueOverall();
        java.lang.Class<?> wildcardClass4 = property2.getClass();
        long long5 = property2.remainder();
        org.joda.time.Interval interval6 = property2.toInterval();
        org.joda.time.ReadableInterval readableInterval7 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-86400000L) + "'", long5 == (-86400000L));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(readableInterval7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.millisOfDay();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        int int26 = localDate24.getYear();
        int[] intArray27 = localDate24.getValues();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
        boolean boolean38 = dateTime37.isEqualNow();
        boolean boolean39 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime41 = dateTime20.plus(0L);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.toDateTime(dateTimeZone43);
        try {
            org.joda.time.DateTime dateTime48 = dateTime44.withDate((int) (byte) 1, 19, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtMidnight();
        int int9 = localDate5.getCenturyOfEra();
        org.joda.time.LocalDate localDate11 = localDate5.minusYears(1969);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
        try {
            org.joda.time.LocalDate localDate20 = dateTimeFormatter1.parseLocalDate("1869");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1869\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant18);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField7, (int) (byte) 0);
//        long long11 = skipDateTimeField9.roundHalfEven(0L);
//        int int12 = instant0.get((org.joda.time.DateTimeField) skipDateTimeField9);
//        int int14 = skipDateTimeField9.getLeapAmount((long) '4');
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
//        int[] intArray18 = localDate16.getValues();
//        int int19 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate16);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 930 + "'", int12 == 930);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Partial partial11 = partial7.withFieldAddWrapped(durationFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        try {
            long long9 = copticChronology0.getDateTimeMillis((int) ' ', 0, 19, 1439, 3, (int) (short) 0, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.millisOfDay();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        int int26 = localDate24.getYear();
        int[] intArray27 = localDate24.getValues();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
        boolean boolean38 = dateTime37.isEqualNow();
        boolean boolean39 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime41 = dateTime20.plus(0L);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime41);
        java.lang.String str43 = dateTimeZone3.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "America/Los_Angeles" + "'", str43.equals("America/Los_Angeles"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.lang.String str4 = delegatedDateTimeField2.getAsShortText((long) (short) 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.era();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField13, (int) (byte) 0);
        int int17 = skipDateTimeField15.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property20 = localDate19.centuryOfEra();
        int int21 = localDate19.getYear();
        int[] intArray22 = localDate19.getValues();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        int[] intArray27 = localDate25.getValues();
        int[] intArray29 = skipDateTimeField15.addWrapField((org.joda.time.ReadablePartial) localDate19, 0, intArray27, 10);
        try {
            int[] intArray31 = delegatedDateTimeField2.addWrapPartial(readablePartial5, 0, intArray29, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AD" + "'", str4.equals("AD"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1439 + "'", int17 == 1439);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str12 = localDate11.toString();
        int[] intArray17 = new int[] { 12, 10, 3 };
        try {
            int[] intArray19 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate11, (int) (short) 100, intArray17, 1869);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray17);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560637818892L + "'", long0 == 1560637818892L);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra((int) (short) 1);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = dateTime8.toString("BuddhistChronology[America/Los_Angeles]", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: B");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField7, (int) (byte) 0);
//        long long11 = skipDateTimeField9.roundHalfEven(0L);
//        int int12 = instant0.get((org.joda.time.DateTimeField) skipDateTimeField9);
//        org.joda.time.Chronology chronology13 = instant0.getChronology();
//        long long14 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 930 + "'", int12 == 930);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560637818927L + "'", long14 == 1560637818927L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours(1970);
        int int4 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusSeconds(3);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = dateTime28.isSupported(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        org.joda.time.DurationField durationField13 = gregorianChronology5.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        try {
            long long27 = zonedChronology12.getDateTimeMillis(1, 0, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.get((-1L));
        long long7 = delegatedDateTimeField3.roundHalfFloor(100L);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField3.getDurationField();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gJChronology9.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField11 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField8, durationField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9223372036825975809L) + "'", long7 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        try {
            int int10 = partial7.getValue(929);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 929");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.io.Writer writer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime20 = dateTime16.minusYears((int) (byte) 10);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        java.lang.String str3 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.monthOfYear();
        try {
            long long18 = zonedChronology12.getDateTimeMillis((int) (byte) 10, 1969, 1888, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        org.joda.time.DurationField durationField24 = gregorianChronology16.minutes();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime14.toMutableDateTime(dateTimeZone25);
        boolean boolean30 = dateTimeZone25.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        org.joda.time.LocalDate localDate36 = property34.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate38 = localDate36.minusMonths((int) '4');
        int int39 = localDate36.getYearOfCentury();
        boolean boolean40 = cachedDateTimeZone31.equals((java.lang.Object) localDate36);
        int int42 = cachedDateTimeZone31.getOffset((long) 100);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone31, readableInstant43);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str17.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 69 + "'", int39 == 69);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology44);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(1869, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField8.getAsText((long) 1888, locale15);
        org.joda.time.DurationField durationField17 = skipDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1869" + "'", str13.equals("1869"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "960" + "'", str16.equals("960"));
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1869-W52", 6, 937, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6 for 1869-W52 must be in the range [937,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = property17.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime23 = property17.addToCopy((int) (byte) 0);
        org.joda.time.DateTime dateTime24 = dateTime23.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 3, (java.lang.Number) 86339901L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 100, 1888, 1970, (-1), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser8, dateTimeParser10, dateTimeParser12, dateTimeParser14, dateTimeParser16, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder4.append(dateTimePrinter6, dateTimeParserArray19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendTimeZoneOffset("365", true, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.monthOfYear();
        org.joda.time.DurationField durationField7 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, durationField7, dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        int int4 = localDate3.getWeekyear();
        org.joda.time.LocalDate.Property property5 = localDate3.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.LocalTime localTime4 = null;
        try {
            org.joda.time.LocalDateTime localDateTime5 = localDate3.toLocalDateTime(localTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime8.plusMinutes((-28378000));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray22 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15, dateTimeParser17, dateTimeParser19, dateTimeParser21 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray22);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeParserArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.LocalDate.Property property3 = localDate2.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        boolean boolean9 = property8.isLeap();
        int int10 = property8.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T��", (java.lang.Number) 1970, (java.lang.Number) 10L, (java.lang.Number) 28800035L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int int15 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate12);
        try {
            java.lang.String str17 = localDate12.toString("DateTimeField[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 99, 929, 69, 1439, 1888, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.LocalDate localDate27 = property2.withMaximumValue();
        java.util.Locale locale28 = null;
        int int29 = property2.getMaximumTextLength(locale28);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology1.getZone();
        java.lang.String str11 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("18", 929, 52, 24, ' ', 1, (int) ' ', 1888, true, (int) (short) 1);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("0", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) "19");
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(69);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfHour();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        int int7 = localDate5.getYear();
        int[] intArray8 = localDate5.getValues();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime17 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = localDate5.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        java.lang.String str25 = gregorianChronology24.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26);
        org.joda.time.DurationField durationField28 = gregorianChronology20.minutes();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime18.toMutableDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology33 = gJChronology0.withZone(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField34 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology0.weekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str25.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(zonedChronology31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis((int) '#', 929, 12, 6, 1970, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.LocalDate localDate8 = property6.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTime dateTime12 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        org.joda.time.DateTime dateTime16 = dateTime12.withWeekyear(0);
        int int17 = dateTime12.getYearOfEra();
        int int18 = property2.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property19 = dateTime12.hourOfDay();
        try {
            org.joda.time.DateTime dateTime21 = dateTime12.withEra((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1869 + "'", int17 == 1869);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.lang.String str4 = delegatedDateTimeField2.getAsShortText((long) (short) 0);
        boolean boolean5 = delegatedDateTimeField2.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AD" + "'", str4.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateMidnight dateMidnight5 = dateTime2.toDateMidnight();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateMidnight5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        java.lang.String str10 = skipDateTimeField8.getName();
        long long13 = skipDateTimeField8.getDifferenceAsLong(1560637821578L, 3L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "halfdayOfDay" + "'", str10.equals("halfdayOfDay"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 36125L + "'", long13 == 36125L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsText(1439, locale12);
        int int14 = skipDateTimeField8.getMaximumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField8, 0, 2, 929);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [2,929]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1439" + "'", str13.equals("1439"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1439 + "'", int14 == 1439);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate1.isSupported(dateTimeFieldType3);
        int int5 = localDate1.getEra();
        int int6 = localDate1.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '#', (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate9 = property8.roundCeilingCopy();
        int int10 = property8.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-28800000), 3, 930, 937, 2, 960, 1970, chronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 937 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property17 = localDate16.centuryOfEra();
        org.joda.time.LocalDate localDate19 = property17.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate21 = localDate19.minusMonths((int) '4');
        boolean boolean22 = localDate1.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendMonthOfYear((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimePrinter9, dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfHour();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        int int7 = localDate5.getYear();
        int[] intArray8 = localDate5.getValues();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime17 = localDate13.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = localDate5.toDateTime((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        java.lang.String str25 = gregorianChronology24.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26);
        org.joda.time.DurationField durationField28 = gregorianChronology20.minutes();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime18.toMutableDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology33 = gJChronology0.withZone(dateTimeZone29);
        org.joda.time.DurationField durationField34 = gJChronology0.weekyears();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str21.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str25.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(zonedChronology31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod3, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        org.joda.time.DurationField durationField17 = zonedChronology12.centuries();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) instant19);
        org.joda.time.Chronology chronology21 = zonedChronology12.withZone(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours(1970);
        try {
            org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) dateTime23, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        long long5 = gregorianChronology0.add((long) (byte) -1, (long) (short) 10, 1439);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 14389L + "'", long5 == 14389L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1439");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long6 = dateTimeZone3.convertLocalToUTC(86340001L, false);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime.Property property8 = dateTime1.era();
        org.joda.time.DateTime.Property property9 = dateTime1.minuteOfHour();
        org.joda.time.DateTime.Property property10 = dateTime1.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86339901L + "'", long6 == 86339901L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        int int8 = localDate6.getYear();
        int[] intArray9 = localDate6.getValues();
        int int10 = property2.compareTo((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        int int26 = property2.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.plusSeconds(3);
        boolean boolean30 = dateTime25.isAfter((long) 'a');
        int int31 = dateTime25.getMillisOfSecond();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        try {
            long long6 = gJChronology0.getDateTimeMillis(8, 937, 7, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 937 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        long long12 = skipDateTimeField8.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate19 = localDate17.minusMonths((int) '4');
        org.joda.time.LocalDate localDate21 = localDate17.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = localDate21.plusWeeks((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        int int27 = localDate25.getYear();
        int[] intArray28 = localDate25.getValues();
        int int29 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray28);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray30 = localDate23.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        int int8 = localDate7.getDayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
        org.joda.time.MutableDateTime mutableDateTime19 = instant18.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime20 = instant18.toDateTime();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        int int24 = localDate22.getYear();
        int[] intArray25 = localDate22.getValues();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology31.getZone();
        org.joda.time.DateTime dateTime34 = localDate30.toDateTimeAtStartOfDay(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = localDate22.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property36 = dateTime34.millisOfDay();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property39 = localDate38.centuryOfEra();
        int int40 = localDate38.getYear();
        int[] intArray41 = localDate38.getValues();
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property44 = localDate43.centuryOfEra();
        org.joda.time.LocalDate localDate46 = property44.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone49 = gJChronology47.getZone();
        org.joda.time.DateTime dateTime50 = localDate46.toDateTimeAtStartOfDay(dateTimeZone49);
        org.joda.time.DateTime dateTime51 = localDate38.toDateTime((org.joda.time.ReadableInstant) dateTime50);
        boolean boolean52 = dateTime51.isEqualNow();
        boolean boolean53 = dateTime34.isEqual((org.joda.time.ReadableInstant) dateTime51);
        boolean boolean54 = instant18.isEqual((org.joda.time.ReadableInstant) dateTime51);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1969 + "'", int40 == 1969);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = skipDateTimeField8.getWrappedField();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        org.joda.time.LocalDate localDate14 = property12.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate16 = localDate14.minusMonths((int) '4');
        org.joda.time.LocalDate localDate18 = localDate14.withYear((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField27);
        boolean boolean29 = skipDateTimeField28.isLenient();
        long long32 = skipDateTimeField28.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        org.joda.time.LocalDate localDate37 = property35.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate39 = localDate37.minusMonths((int) '4');
        org.joda.time.LocalDate localDate41 = localDate37.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate43 = localDate41.plusWeeks((int) (short) 100);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property46 = localDate45.centuryOfEra();
        int int47 = localDate45.getYear();
        int[] intArray48 = localDate45.getValues();
        int int49 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate43, intArray48);
        try {
            int[] intArray51 = skipDateTimeField8.add((org.joda.time.ReadablePartial) localDate18, (int) (short) 1, intArray48, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str22.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str26.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1969 + "'", int47 == 1969);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours(1970);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekyear(1969);
//        int int6 = dateTime3.getDayOfWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime14.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime18 = dateTime14.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime20 = dateTime14.withYearOfEra(937);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.plusYears(1888);
        org.joda.time.LocalTime localTime9 = null;
        try {
            org.joda.time.LocalDateTime localDateTime10 = localDate4.toLocalDateTime(localTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int[] intArray20 = localDate18.getValues();
        int[] intArray22 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate12, 0, intArray20, 10);
        long long24 = skipDateTimeField8.roundFloor(11L);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int int28 = property27.get();
        org.joda.time.LocalDate localDate30 = property27.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.era();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology33.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField37, (int) (byte) 0);
        int int41 = skipDateTimeField39.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property44 = localDate43.centuryOfEra();
        int int45 = localDate43.getYear();
        int int46 = skipDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate43);
        boolean boolean47 = localDate30.isEqual((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property51 = localDate50.centuryOfEra();
        int[] intArray52 = localDate50.getValues();
        int int53 = localDate50.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate55 = localDate50.minus(readablePeriod54);
        org.joda.time.Partial partial56 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate55);
        int int57 = partial56.size();
        java.lang.String str58 = partial56.toString();
        int[] intArray59 = partial56.getValues();
        try {
            int[] intArray61 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDate30, 1439, intArray59, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1439");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1439 + "'", int41 == 1439);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1969-12-31" + "'", str58.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        long long6 = gJChronology0.set((org.joda.time.ReadablePartial) localDate2, (long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.plusYears(1888);
        org.joda.time.Interval interval9 = localDate8.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.monthOfYear();
        java.lang.String str7 = gJChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str7.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate localDate9 = localDate4.minusWeeks(0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.LocalDate.Property property12 = localDate9.yearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendOptional(dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withPivotYear((java.lang.Integer) (-28378000));
        try {
            org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.parse("PST", dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        long long6 = gJChronology0.set((org.joda.time.ReadablePartial) localDate2, (long) (byte) 100);
        int int7 = localDate2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-9223372036825975809L));
        boolean boolean12 = dateTime8.isAfter((long) 4);
        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfHour();
        java.lang.String str14 = property13.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[minuteOfHour]" + "'", str14.equals("Property[minuteOfHour]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long5 = copticChronology0.getDateTimeMillis(1, 0, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 930);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate6 = localDate1.withYearOfEra(929);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = dateTimeZone2.toString();
        org.joda.time.Chronology chronology5 = buddhistChronology1.withZone(dateTimeZone2);
        java.lang.String str6 = buddhistChronology1.toString();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
        java.lang.String str19 = dateTimeZone18.toString();
        org.joda.time.Interval interval20 = localDate11.toInterval(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology22 = buddhistChronology1.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) -1, dateTimeZone18);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str6.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        long long12 = skipDateTimeField8.set(0L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = skipDateTimeField8.getAsShortText(readablePartial13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.String str2 = dateTimeFormatter0.print((long) 930);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T16:00:00.930" + "'", str2.equals("1969-12-31T16:00:00.930"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = property17.addWrapFieldToCopy(1969);
        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.lang.String str25 = delegatedDateTimeField23.getAsShortText((long) 3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = dateTime14.isEqualNow();
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = dateTime14.toString("minuteOfDay", locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        java.lang.String str18 = gregorianChronology17.toString();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23);
        org.joda.time.DurationField durationField25 = gregorianChronology17.minutes();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone26);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime15.toMutableDateTime(dateTimeZone26);
        boolean boolean31 = dateTimeZone26.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property35 = localDate34.centuryOfEra();
        org.joda.time.LocalDate localDate37 = property35.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate39 = localDate37.minusMonths((int) '4');
        int int40 = localDate37.getYearOfCentury();
        boolean boolean41 = cachedDateTimeZone32.equals((java.lang.Object) localDate37);
        java.lang.String str43 = cachedDateTimeZone32.getNameKey((long) (byte) 1);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(0L, (org.joda.time.DateTimeZone) cachedDateTimeZone32);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str22.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 69 + "'", int40 == 69);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PST" + "'", str43.equals("PST"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.Appendable appendable2 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        int int6 = localDate4.getYear();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str9 = localDate8.toString();
        org.joda.time.LocalDate localDate10 = localDate4.withFields((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateTime dateTime11 = localDate4.toDateTimeAtStartOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property8 = localDate5.dayOfYear();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        int int12 = property11.get();
        org.joda.time.LocalDate localDate14 = property11.addToCopy((int) (short) -1);
        org.joda.time.LocalDate.Property property15 = localDate14.dayOfWeek();
        int int16 = localDate14.getWeekOfWeekyear();
        org.joda.time.LocalDate localDate18 = localDate14.minusMonths(12);
        int int19 = property8.compareTo((org.joda.time.ReadablePartial) localDate14);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property6 = localDate5.centuryOfEra();
        org.joda.time.LocalDate localDate8 = property6.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTime dateTime12 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        org.joda.time.DateTime dateTime16 = dateTime12.withWeekyear(0);
        int int17 = dateTime12.getYearOfEra();
        int int18 = property2.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property19 = dateTime12.hourOfDay();
        boolean boolean20 = dateTime12.isAfterNow();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime12.plus(readablePeriod21);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1869 + "'", int17 == 1869);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        java.lang.String str3 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property4 = localDate3.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        java.lang.String str9 = partial7.toString();
        int[] intArray10 = partial7.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.Partial partial13 = partial7.with(dateTimeFieldType11, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DurationField durationField4 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.centuryOfEra();
        boolean boolean9 = gregorianChronology1.equals((java.lang.Object) dateTimeField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        int int19 = localDate17.getYear();
        int[] intArray20 = localDate17.getValues();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property23 = localDate22.centuryOfEra();
        org.joda.time.LocalDate localDate25 = property23.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTime dateTime29 = localDate25.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = localDate17.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        boolean boolean31 = dateTime30.isEqualNow();
        boolean boolean32 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime30);
        java.util.Locale locale34 = null;
        java.lang.String str35 = dateTime30.toString("19", locale34);
        try {
            org.joda.time.DateTime dateTime37 = dateTime30.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19" + "'", str35.equals("19"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(12, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 365");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        int int5 = localDate1.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(3);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate1.minus(readablePeriod8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = localDate1.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
        java.lang.StringBuffer stringBuffer19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        try {
            dateTimeFormatter1.printTo(stringBuffer19, readableInstant20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFixedSignedDecimal(dateTimeFieldType12, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        int int8 = delegatedDateTimeField2.getLeapAmount((-57600000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = skipDateTimeField8.getWrappedField();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property12 = localDate11.centuryOfEra();
        int int13 = localDate11.getYear();
        int[] intArray14 = localDate11.getValues();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = skipDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate11, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) (byte) -1, 24, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField2.getDurationField();
        int int8 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate15 = localDate13.minusMonths((int) '4');
        int int16 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate localDate18 = localDate13.minusWeeks(0);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = localDate18.isSupported(durationFieldType19);
        int int21 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        java.lang.String str23 = delegatedDateTimeField2.getAsText((long) 52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AD" + "'", str23.equals("AD"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder20.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter26 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray46 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser37, dateTimeParser39, dateTimeParser41, dateTimeParser43, dateTimeParser45 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder31.append(dateTimePrinter33, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder25.append(dateTimePrinter26, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.append(dateTimePrinter23, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter50.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.append(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeParserArray46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfCeiling((long) 960);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int[] intArray10 = localDate8.getValues();
        int int11 = localDate8.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate13 = localDate8.minus(readablePeriod12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.Partial partial16 = partial14.minus(readablePeriod15);
        int int17 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) partial16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(partial16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 365);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str17 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1869-12-31T00", dateTimeFormatter1);
        java.lang.Appendable appendable19 = null;
        try {
            dateTimeFormatter1.printTo(appendable19, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1869-12-31T00" + "'", str17.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendMinuteOfDay((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.LocalDate.Property property24 = localDate23.dayOfMonth();
        org.joda.time.Chronology chronology25 = localDate23.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        java.lang.String str3 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property18 = localDate17.centuryOfEra();
        org.joda.time.LocalDate localDate20 = property18.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay(dateTimeZone23);
        long long25 = dateTime24.getMillis();
        int int26 = property15.compareTo((org.joda.time.ReadableInstant) dateTime24);
        java.util.Locale locale27 = null;
        int int28 = property15.getMaximumTextLength(locale27);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-3155731622000L) + "'", long25 == (-3155731622000L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = property17.addToCopy((long) 1869);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, (-28378000), 7, 8, 1, 930);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 930 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology0.getZone();
        try {
            long long11 = gJChronology0.getDateTimeMillis(3, 929, (int) (short) -1, (int) (byte) 10, 960, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfCeiling((long) 960);
        int int8 = delegatedDateTimeField2.getMaximumValue((long) 1888);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField2.getDurationField();
        org.joda.time.DurationField durationField8 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate15 = localDate13.minusMonths((int) '4');
        int int16 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate.Property property17 = localDate13.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.era();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.secondOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology20.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField24, (int) (byte) 0);
        int int28 = skipDateTimeField26.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property31 = localDate30.centuryOfEra();
        int int32 = localDate30.getYear();
        int[] intArray33 = localDate30.getValues();
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property37 = localDate36.centuryOfEra();
        int[] intArray38 = localDate36.getValues();
        int[] intArray40 = skipDateTimeField26.addWrapField((org.joda.time.ReadablePartial) localDate30, 0, intArray38, 10);
        int int41 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray40);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1439 + "'", int28 == 1439);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        org.joda.time.LocalDate localDate6 = property4.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
        org.joda.time.DateTime dateTime10 = localDate6.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Instant instant11 = dateTime10.toInstant();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(instant11);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        org.joda.time.Instant instant2 = instant0.toInstant();
//        long long3 = instant2.getMillis();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560637837398L + "'", long3 == 1560637837398L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(36125L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology0.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = gJChronology0.get(readablePeriod11, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.centuryOfEra();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) gJChronology2);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str13 = localDate12.toString();
        org.joda.time.LocalDate localDate14 = localDate8.withFields((org.joda.time.ReadablePartial) localDate12);
        int[] intArray16 = gJChronology2.get((org.joda.time.ReadablePartial) localDate14, (long) 1869);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31" + "'", str13.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = property17.roundCeilingCopy();
        org.joda.time.DateTime dateTime21 = property17.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = property17.roundCeilingCopy();
        org.joda.time.DateTime dateTime21 = property17.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-9223372036825975809L));
        boolean boolean12 = dateTime8.isAfter((long) 4);
        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfHour();
        int int14 = dateTime8.getWeekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        java.lang.String str18 = dateTimeZone16.toString();
        org.joda.time.Chronology chronology19 = buddhistChronology15.withZone(dateTimeZone16);
        java.lang.String str20 = buddhistChronology15.toString();
        org.joda.time.DateTime dateTime21 = dateTime8.toDateTime((org.joda.time.Chronology) buddhistChronology15);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1869 + "'", int14 == 1869);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str20.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(6, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate1.isSupported(dateTimeFieldType3);
        int int5 = localDate1.getEra();
        org.joda.time.LocalDate localDate7 = localDate1.minusWeeks(365);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        java.lang.String str10 = partial7.toString("19");
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Partial partial13 = partial7.withPeriodAdded(readablePeriod11, 1969);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) instant15);
        org.joda.time.DateTime dateTime17 = instant15.toDateTime();
        org.joda.time.DateTime dateTime18 = instant15.toDateTimeISO();
        boolean boolean19 = partial7.isMatch((org.joda.time.ReadableInstant) instant15);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
        org.junit.Assert.assertNotNull(partial13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumShortTextLength(locale16);
        org.joda.time.DateTimeField dateTimeField18 = property15.getField();
        org.joda.time.DateTime dateTime20 = property15.addToCopy(28800035L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int[] intArray20 = localDate18.getValues();
        int[] intArray22 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate12, 0, intArray20, 10);
        long long24 = skipDateTimeField8.roundFloor(11L);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int int28 = property27.get();
        org.joda.time.LocalDate localDate30 = property27.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.era();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology33.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField37, (int) (byte) 0);
        int int41 = skipDateTimeField39.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property44 = localDate43.centuryOfEra();
        int int45 = localDate43.getYear();
        int int46 = skipDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate43);
        boolean boolean47 = localDate30.isEqual((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        java.lang.String str51 = gregorianChronology50.toString();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        java.lang.String str55 = gregorianChronology54.toString();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology50, dateTimeField56);
        boolean boolean58 = skipDateTimeField57.isLenient();
        long long61 = skipDateTimeField57.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property64 = localDate63.centuryOfEra();
        org.joda.time.LocalDate localDate66 = property64.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate68 = localDate66.minusMonths((int) '4');
        int int69 = localDate66.getYearOfCentury();
        org.joda.time.LocalDate.Property property70 = localDate66.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.era();
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField74 = gJChronology73.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology73.secondOfDay();
        org.joda.time.DateTimeField dateTimeField76 = gJChronology73.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField77 = gJChronology73.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField79 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField77, (int) (byte) 0);
        int int81 = skipDateTimeField79.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate83 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property84 = localDate83.centuryOfEra();
        int int85 = localDate83.getYear();
        int[] intArray86 = localDate83.getValues();
        org.joda.time.LocalDate localDate89 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property90 = localDate89.centuryOfEra();
        int[] intArray91 = localDate89.getValues();
        int[] intArray93 = skipDateTimeField79.addWrapField((org.joda.time.ReadablePartial) localDate83, 0, intArray91, 10);
        int int94 = skipDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) localDate66, intArray93);
        try {
            int[] intArray96 = skipDateTimeField8.set((org.joda.time.ReadablePartial) localDate30, (int) (short) -1, intArray93, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1439 + "'", int41 == 1439);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str51.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str55.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 69 + "'", int69 == 69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1439 + "'", int81 == 1439);
        org.junit.Assert.assertNotNull(property84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1969 + "'", int85 == 1969);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long6 = dateTimeZone3.convertLocalToUTC(86340001L, false);
        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtStartOfDay(dateTimeZone3);
        int int8 = dateTime7.getHourOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds(99);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86339901L + "'", long6 == 86339901L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        long long19 = skipDateTimeField8.roundHalfEven((long) (byte) 100);
        long long21 = skipDateTimeField8.remainder(0L);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField8.getAsShortText((int) (short) 1, locale23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = skipDateTimeField8.getAsText(readablePartial25, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 365");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-86400000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime4 = instant0.toDateTimeISO();
//        int int5 = dateTime4.getMonthOfYear();
//        int int6 = dateTime4.getMillisOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 55840263 + "'", int6 == 55840263);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime2);
//        int int5 = dateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 22 + "'", int5 == 22);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1439");
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(1970);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate1.isSupported(dateTimeFieldType3);
        int int5 = localDate1.getEra();
        int[] intArray6 = localDate1.getValues();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField8.getAsShortText((long) 'a', locale19);
        long long22 = skipDateTimeField8.roundCeiling((long) 5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        int int27 = localDate25.getYear();
        int[] intArray28 = localDate25.getValues();
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property31 = localDate30.centuryOfEra();
        org.joda.time.LocalDate localDate33 = property31.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology34.getZone();
        org.joda.time.DateTime dateTime37 = localDate33.toDateTimeAtStartOfDay(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = localDate25.toDateTime((org.joda.time.ReadableInstant) dateTime37);
        java.lang.String str39 = dateTimeFormatter23.print((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property40 = dateTime37.centuryOfEra();
        int int41 = property40.getLeapAmount();
        org.joda.time.DateTime dateTime42 = property40.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime44 = property40.addWrapFieldToCopy(1969);
        org.joda.time.DateTimeField dateTimeField45 = property40.getField();
        org.joda.time.DurationField durationField46 = property40.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, durationField46, dateTimeFieldType47, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "960" + "'", str20.equals("960"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60000L + "'", long22 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1869-12-31T00" + "'", str39.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField46);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = property17.roundCeilingCopy();
        int int21 = property17.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.centuries();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.era();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField8, (int) (byte) 0);
        long long12 = skipDateTimeField10.roundHalfEven(0L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1869, locale14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField10);
        int int18 = skipDateTimeField16.get(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1869" + "'", str15.equals("1869"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 960 + "'", int18 == 960);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField2.getDurationField();
        org.joda.time.DurationField durationField8 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DurationField durationField9 = delegatedDateTimeField2.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = property17.addWrapFieldToCopy(1969);
        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        int int24 = delegatedDateTimeField23.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922789 + "'", int24 == 2922789);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 930);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate4.plus(readablePeriod7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(1L, dateTimeZone25);
        org.joda.time.Chronology chronology27 = zonedChronology12.withZone(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DurationField durationField24 = zonedChronology12.millis();
        java.lang.String str25 = zonedChronology12.toString();
        try {
            long long30 = zonedChronology12.getDateTimeMillis((int) 'a', 52, 1970, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str25.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(100L);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        int int12 = localDate11.getYear();
        org.joda.time.LocalDate localDate14 = localDate11.withWeekyear(0);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate14, locale15);
        try {
            org.joda.time.Instant instant17 = new org.joda.time.Instant((java.lang.Object) localDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036825975809L) + "'", long6 == (-9223372036825975809L));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1869 + "'", int12 == 1869);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BC" + "'", str16.equals("BC"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property7 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate9 = property7.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        java.lang.String str16 = property15.getName();
        org.joda.time.DateTime dateTime18 = property15.addToCopy(3);
        int int19 = dateTime18.getMillisOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1560637821578L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.era();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology6.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField10, (int) (byte) 0);
        long long14 = skipDateTimeField12.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField12.getAsText(readablePartial15, (int) (byte) 0, locale17);
        long long21 = skipDateTimeField12.add((long) 1, 1439);
        long long23 = skipDateTimeField12.roundHalfEven((long) (byte) 100);
        long long25 = skipDateTimeField12.remainder(0L);
        boolean boolean26 = localDate1.equals((java.lang.Object) long25);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86340001L + "'", long21 == 86340001L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.get((-1L));
        try {
            int int7 = delegatedDateTimeField2.getDifference((-210858120000000L), 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) (byte) 1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate5.toDateTimeAtMidnight();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        boolean boolean14 = dateTimeZone12.isStandardOffset((long) (byte) 100);
        org.joda.time.DateTime dateTime15 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property5 = localDate4.centuryOfEra();
        org.joda.time.LocalDate localDate7 = property5.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtStartOfDay(dateTimeZone10);
        org.joda.time.Instant instant12 = dateTime11.toInstant();
        org.joda.time.Chronology chronology13 = dateTime11.getChronology();
        org.joda.time.DateTime dateTime15 = dateTime11.minusWeeks((-1));
        boolean boolean16 = gregorianChronology1.equals((java.lang.Object) dateTime11);
        int int17 = dateTime11.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfWeek(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1869-12-31T00");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant5 = instant1.withDurationAdded(10L, (-1));
        org.joda.time.Instant instant6 = instant1.toInstant();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            long long3 = dateTimeFormatter0.parseMillis("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology10 = instant9.getChronology();
        org.joda.time.DateTime dateTime11 = instant9.toDateTime();
        org.joda.time.DateTime dateTime12 = localDate4.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        long long13 = dateTime11.getMillis();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560637821578L + "'", long13 == 1560637821578L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        int int12 = localDate10.getYear();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str15 = localDate14.toString();
        org.joda.time.LocalDate localDate16 = localDate10.withFields((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTime dateTime17 = localDate10.toDateTimeAtStartOfDay();
        boolean boolean18 = localDate4.isEqual((org.joda.time.ReadablePartial) localDate10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31" + "'", str15.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 12, 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 408L + "'", long2 == 408L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        int int10 = skipDateTimeField8.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property13 = localDate12.centuryOfEra();
        int int14 = localDate12.getYear();
        int[] intArray15 = localDate12.getValues();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int[] intArray20 = localDate18.getValues();
        int[] intArray22 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) localDate12, 0, intArray20, 10);
        long long24 = skipDateTimeField8.roundFloor(11L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField8.getAsText(7, locale26);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1439 + "'", int10 == 1439);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "7" + "'", str27.equals("7"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray22 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15, dateTimeParser17, dateTimeParser19, dateTimeParser21 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendHourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendHourOfDay((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeParserArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology12);
        org.joda.time.DurationField durationField24 = zonedChronology12.hours();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        int int11 = localDate9.getYear();
        int[] intArray12 = localDate9.getValues();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = localDate9.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.millisOfDay();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        int int27 = localDate25.getYear();
        int[] intArray28 = localDate25.getValues();
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property31 = localDate30.centuryOfEra();
        org.joda.time.LocalDate localDate33 = property31.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology34.getZone();
        org.joda.time.DateTime dateTime37 = localDate33.toDateTimeAtStartOfDay(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = localDate25.toDateTime((org.joda.time.ReadableInstant) dateTime37);
        boolean boolean39 = dateTime38.isEqualNow();
        boolean boolean40 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime41 = localDate5.toDateTime((org.joda.time.ReadableInstant) dateTime38);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long6 = dateTimeZone3.convertLocalToUTC(86340001L, false);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86339901L + "'", long6 == 86339901L);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = localDate3.getYear();
        int[] intArray6 = localDate3.getValues();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property9.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = gregorianChronology18.toString();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        java.lang.String str23 = gregorianChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology18, dateTimeField24);
        org.joda.time.DurationField durationField26 = gregorianChronology18.minutes();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology18, dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime16.toMutableDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology31 = iSOChronology0.withZone(dateTimeZone27);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property34 = localDate33.centuryOfEra();
        int int35 = localDate33.getYear();
        int[] intArray36 = localDate33.getValues();
        int int37 = localDate33.getWeekyear();
        org.joda.time.LocalDate localDate39 = localDate33.minusDays(3);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate41 = localDate33.minus(readablePeriod40);
        boolean boolean42 = iSOChronology0.equals((java.lang.Object) readablePeriod40);
        java.lang.Class<?> wildcardClass43 = iSOChronology0.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str19.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str23.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1970 + "'", int37 == 1970);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-9223372036825975809L));
        boolean boolean12 = dateTime8.isAfter((long) 4);
        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfHour();
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property16 = localDate15.centuryOfEra();
        int int17 = localDate15.getYear();
        int[] intArray18 = localDate15.getValues();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        org.joda.time.LocalDate localDate23 = property21.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology24.getZone();
        org.joda.time.DateTime dateTime27 = localDate23.toDateTimeAtStartOfDay(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = localDate15.toDateTime((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        java.lang.String str31 = gregorianChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        java.lang.String str35 = gregorianChronology34.toString();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField36);
        org.joda.time.DurationField durationField38 = gregorianChronology30.minutes();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology30, dateTimeZone39);
        org.joda.time.MutableDateTime mutableDateTime42 = dateTime28.toMutableDateTime(dateTimeZone39);
        boolean boolean44 = dateTimeZone39.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone39);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property48 = localDate47.centuryOfEra();
        org.joda.time.LocalDate localDate50 = property48.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate52 = localDate50.minusMonths((int) '4');
        int int53 = localDate50.getYearOfCentury();
        boolean boolean54 = cachedDateTimeZone45.equals((java.lang.Object) localDate50);
        int int56 = cachedDateTimeZone45.getOffset((long) 100);
        boolean boolean58 = cachedDateTimeZone45.equals((java.lang.Object) 12);
        org.joda.time.DateTime dateTime59 = dateTime8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str31.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str35.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 69 + "'", int53 == 69);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-28800000) + "'", int56 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTime59);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        int[] intArray4 = localDate1.getValues();
        int int5 = localDate1.getWeekyear();
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(3);
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = localDate7.toString("GJChronology[America/Los_Angeles]", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(1L, dateTimeZone5);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property10 = localDate9.centuryOfEra();
        int[] intArray11 = localDate9.getValues();
        int int12 = localDate9.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate9.minus(readablePeriod13);
        org.joda.time.Partial partial15 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate14);
        int int16 = partial15.size();
        java.lang.String str17 = partial15.toString();
        int[] intArray18 = partial15.getValues();
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) localDate6, (-28378000), intArray18, "1869-W52", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1869-W52\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31" + "'", str17.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        org.joda.time.LocalDate localDate8 = localDate4.plusYears(1888);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.DurationField durationField4 = property2.getDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYear(929);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("America/Los_Angeles", "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]", true, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (short) 10);
        try {
            long long5 = dateTimeFormatter0.parseMillis("365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField8);
        org.joda.time.DurationField durationField10 = gregorianChronology2.minutes();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone11);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property16 = localDate15.centuryOfEra();
        org.joda.time.LocalDate localDate18 = property16.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
        org.joda.time.DateTime dateTime22 = localDate18.toDateTimeAtStartOfDay(dateTimeZone21);
        org.joda.time.Chronology chronology23 = zonedChronology13.withZone(dateTimeZone21);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.Chronology) zonedChronology13);
        org.joda.time.DurationField durationField25 = zonedChronology13.millis();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField25, dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str7.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long4 = dateTimeZone1.convertLocalToUTC(86340001L, false);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone1.isLocalDateTimeGap(localDateTime5);
        try {
            org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86339901L + "'", long4 == 86339901L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "DateTimeField[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 0, (-28800000), (int) ' ', 937, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = property2.getAsText(locale5);
        org.joda.time.LocalDate localDate7 = property2.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate8 = property2.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial9 = partial7.minus(readablePeriod8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate13 = localDate11.plusYears(1869);
        boolean boolean14 = partial9.isMatch((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(partial9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("69");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '69' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate6 = localDate4.minusMonths((int) '4');
        int int7 = localDate4.getYearOfCentury();
        org.joda.time.LocalDate.Property property8 = localDate4.yearOfCentury();
        java.lang.String str9 = property8.getAsShortText();
        int int10 = property8.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "69" + "'", str9.equals("69"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12-31T16:00:00.930");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.930\" is malformed at \"-31T16:00:00.930\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 1969, 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hi! must be in the range [100,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(69, '#', (int) (short) 1, 1439, (-1), false, 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(0, '#', 10, (-28378000), (-1), true, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField8.getAsText(readablePartial11, (int) (byte) 0, locale13);
        long long17 = skipDateTimeField8.add((long) 1, 1439);
        long long19 = skipDateTimeField8.roundHalfEven((long) (byte) 100);
        long long21 = skipDateTimeField8.remainder(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType22);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86340001L + "'", long17 == 86340001L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.Chronology chronology16 = zonedChronology12.withZone(dateTimeZone15);
        boolean boolean18 = zonedChronology12.equals((java.lang.Object) 1.0d);
        try {
            long long23 = zonedChronology12.getDateTimeMillis(0, 69, 937, 1869);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsText(1439, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField8.getAsText((-28378000), locale15);
        long long19 = skipDateTimeField8.set(36523L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1439" + "'", str13.equals("1439"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-28378000" + "'", str16.equals("-28378000"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-57503477L) + "'", long19 == (-57503477L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[GregorianChronol...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType3, 55840263);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property9 = localDate8.centuryOfEra();
        int int10 = localDate8.getYear();
        int[] intArray11 = localDate8.getValues();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property14 = localDate13.centuryOfEra();
        org.joda.time.LocalDate localDate16 = property14.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology17.getZone();
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.millisOfDay();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property25 = localDate24.centuryOfEra();
        int int26 = localDate24.getYear();
        int[] intArray27 = localDate24.getValues();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property30 = localDate29.centuryOfEra();
        org.joda.time.LocalDate localDate32 = property30.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology33.getZone();
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = localDate24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
        boolean boolean38 = dateTime37.isEqualNow();
        boolean boolean39 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime41 = dateTime20.plus(0L);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime44 = dateTime41.minusMinutes(6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTime44);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = localDate1.isSupported(dateTimeFieldType3);
//        int int5 = localDate1.getEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        java.lang.String str8 = dateTimeZone6.toString();
//        org.joda.time.DateTime dateTime9 = localDate1.toDateTimeAtMidnight(dateTimeZone6);
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) (byte) 100, locale15);
//        long long19 = dateTimeZone13.convertLocalToUTC((long) '#', true);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone13);
//        org.joda.time.DateTime dateTime21 = localDate1.toDateTime(localTime10, dateTimeZone13);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800035L + "'", long19 == 28800035L);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long11 = skipDateTimeField8.set(0L, "0");
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, durationField14, dateTimeFieldType15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.centuryOfEra();
        int int20 = localDate18.getYear();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str23 = localDate22.toString();
        org.joda.time.LocalDate localDate24 = localDate18.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        java.lang.String str28 = gregorianChronology27.toString();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33);
        boolean boolean35 = skipDateTimeField34.isLenient();
        long long38 = skipDateTimeField34.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property41 = localDate40.centuryOfEra();
        org.joda.time.LocalDate localDate43 = property41.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate45 = localDate43.minusMonths((int) '4');
        org.joda.time.LocalDate localDate47 = localDate43.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate49 = localDate47.plusWeeks((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property52 = localDate51.centuryOfEra();
        int int53 = localDate51.getYear();
        int[] intArray54 = localDate51.getValues();
        int int55 = skipDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDate49, intArray54);
        try {
            int[] intArray57 = delegatedDateTimeField16.addWrapField((org.joda.time.ReadablePartial) localDate22, 1869, intArray54, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1869");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969-12-31" + "'", str23.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str28.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str32.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1969 + "'", int53 == 1969);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str2 = localDate1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.Interval interval6 = localDate1.toInterval(dateTimeZone3);
        int int7 = localDate1.getYearOfEra();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31" + "'", str2.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(86340001L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        java.lang.String str4 = dateTimeZone3.toString();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        boolean boolean9 = skipDateTimeField8.isLenient();
        long long12 = skipDateTimeField8.set(0L, (int) (short) 1);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate19 = localDate17.minusMonths((int) '4');
        org.joda.time.LocalDate localDate21 = localDate17.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate23 = localDate21.plusWeeks((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
        int int27 = localDate25.getYear();
        int[] intArray28 = localDate25.getValues();
        int int29 = skipDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray28);
        int int30 = localDate23.getDayOfWeek();
        org.joda.time.LocalDate localDate32 = localDate23.withYear(930);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(localDate32);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        boolean boolean18 = iSOChronology6.equals((java.lang.Object) dateTimeFormatterBuilder10);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(55840263, 930, 1969, (int) (byte) 1, (int) '#', (int) (byte) 1, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 930 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.centuries();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) gJChronology1);
        org.joda.time.Instant instant4 = gJChronology1.getGregorianCutover();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = dateTimeZone5.toString();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone5);
        int int10 = dateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.Chronology chronology11 = gJChronology1.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField12 = gJChronology1.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property2.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.Interval interval13 = localDate4.toInterval(dateTimeZone11);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType15 = localDate4.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(interval13);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        org.joda.time.DurationField durationField9 = gregorianChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone10);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property15 = localDate14.centuryOfEra();
        org.joda.time.LocalDate localDate17 = property15.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtStartOfDay(dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology12.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.DateTime dateTime26 = dateTime23.toDateTime(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.halfdayOfDay();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.centuryOfEra();
        boolean boolean9 = gregorianChronology1.equals((java.lang.Object) dateTimeField8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray22 = new org.joda.time.format.DateTimeParser[] { dateTimeParser11, dateTimeParser13, dateTimeParser15, dateTimeParser17, dateTimeParser19, dateTimeParser21 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter2, dateTimeParserArray22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(69, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendTimeZoneName(strMap29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeParserArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(strMap29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant5 = instant1.withDurationAdded(10L, (-1));
        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear(1888);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1888 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = localDate1.getYear();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        java.lang.String str6 = localDate5.toString();
        org.joda.time.LocalDate localDate7 = localDate1.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = gregorianChronology14.toString();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16);
        org.joda.time.DurationField durationField18 = gregorianChronology10.minutes();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone19);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology22.getZone();
        org.joda.time.Chronology chronology25 = zonedChronology21.withZone(dateTimeZone24);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property28 = localDate27.centuryOfEra();
        org.joda.time.LocalDate localDate30 = property28.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology31.getZone();
        org.joda.time.DateTime dateTime34 = localDate30.toDateTimeAtStartOfDay(dateTimeZone33);
        org.joda.time.Instant instant35 = dateTime34.toInstant();
        org.joda.time.Chronology chronology36 = dateTime34.getChronology();
        int int37 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime34);
        boolean boolean38 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31" + "'", str6.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str11.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str15.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28378000) + "'", int37 == (-28378000));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsText(1439, locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField8.getMinimumValue(readablePartial14);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1439" + "'", str13.equals("1439"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        java.lang.String str9 = partial7.toString();
        org.joda.time.Chronology chronology10 = partial7.getChronology();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31" + "'", str9.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatterBuilder0.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) (byte) 100, locale4);
//        int int7 = dateTimeZone2.getOffsetFromLocal((long) 24);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder2.appendTimeZoneOffset("AD", "DateTimeField[minuteOfDay]", false, (-28378000), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property4 = localDate3.centuryOfEra();
        int int5 = property4.get();
        org.joda.time.LocalDate localDate7 = property4.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.era();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField14, (int) (byte) 0);
        int int18 = skipDateTimeField16.getMaximumValue((long) '4');
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property21 = localDate20.centuryOfEra();
        int int22 = localDate20.getYear();
        int int23 = skipDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate20);
        boolean boolean24 = localDate7.isEqual((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property27 = localDate26.centuryOfEra();
        int int28 = localDate26.getYear();
        int[] intArray29 = localDate26.getValues();
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
        org.joda.time.LocalDate localDate34 = property32.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
        org.joda.time.DateTime dateTime38 = localDate34.toDateTimeAtStartOfDay(dateTimeZone37);
        org.joda.time.DateTime dateTime39 = localDate26.toDateTime((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        java.lang.String str42 = gregorianChronology41.toString();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        java.lang.String str46 = gregorianChronology45.toString();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.halfdayOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology41, dateTimeField47);
        org.joda.time.DurationField durationField49 = gregorianChronology41.minutes();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone50);
        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, dateTimeZone50);
        org.joda.time.MutableDateTime mutableDateTime53 = dateTime39.toMutableDateTime(dateTimeZone50);
        boolean boolean55 = dateTimeZone50.isStandardOffset((long) 3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone50);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property59 = localDate58.centuryOfEra();
        org.joda.time.LocalDate localDate61 = property59.addToCopy((int) (short) -1);
        org.joda.time.LocalDate localDate63 = localDate61.minusMonths((int) '4');
        int int64 = localDate61.getYearOfCentury();
        boolean boolean65 = cachedDateTimeZone56.equals((java.lang.Object) localDate61);
        java.lang.String str67 = cachedDateTimeZone56.getNameKey((long) (byte) 1);
        org.joda.time.Interval interval68 = localDate20.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        org.joda.time.Chronology chronology69 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        boolean boolean70 = cachedDateTimeZone56.isFixed();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1439 + "'", int18 == 1439);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str42.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str46.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(zonedChronology52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 69 + "'", int64 == 69);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "PST" + "'", str67.equals("PST"));
        org.junit.Assert.assertNotNull(interval68);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(1969);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.append(dateTimePrinter8, dateTimeParser9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        long long10 = skipDateTimeField8.roundHalfEven(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField8.getAsShortText(1869, locale12);
        org.joda.time.DurationField durationField14 = skipDateTimeField8.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1869" + "'", str13.equals("1869"));
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int int3 = property2.get();
        org.joda.time.LocalDate localDate5 = property2.addToCopy((int) (short) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = property2.getAsText(locale6);
        org.joda.time.LocalDate localDate8 = property2.withMinimumValue();
        int int9 = localDate8.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "19" + "'", str7.equals("19"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 69, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int int4 = localDate2.getYear();
        int[] intArray5 = localDate2.getValues();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime21 = property17.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime23 = property17.addToCopy((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime27 = dateTime23.withDate(0, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1869-12-31T00" + "'", str16.equals("1869-12-31T00"));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int[] intArray4 = localDate2.getValues();
        int int5 = localDate2.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.minus(readablePeriod6);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        int int9 = partial8.size();
        java.lang.String str10 = partial8.toString();
        int[] intArray11 = partial8.getValues();
        try {
            org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31" + "'", str10.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.clockhourOfDay();
        int int3 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.Instant instant5 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField6 = gJChronology0.millis();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder20.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter26 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray46 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser37, dateTimeParser39, dateTimeParser41, dateTimeParser43, dateTimeParser45 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder31.append(dateTimePrinter33, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder25.append(dateTimePrinter26, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.append(dateTimePrinter23, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendYearOfCentury(2019, 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeParserArray46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        int[] intArray3 = localDate1.getValues();
        int int4 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.minus(readablePeriod5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate6);
        int int8 = partial7.size();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate13 = property11.addToCopy((int) (short) -1);
        int int14 = localDate13.getYear();
        org.joda.time.LocalDate localDate16 = localDate13.withWeekyear(0);
        org.joda.time.LocalDate localDate18 = localDate16.minusMonths(1970);
        boolean boolean19 = partial7.isEqual((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.Partial partial21 = partial7.plus(readablePeriod20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.Partial.Property property23 = partial7.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1869 + "'", int14 == 1869);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(partial21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6, (int) (byte) 0);
        java.util.Locale locale9 = null;
        int int10 = skipDateTimeField8.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.toString();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
        int[] intArray4 = localDate2.getValues();
        int int5 = localDate2.getWeekOfWeekyear();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) localDate2);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-28800000), 19, 24, 69, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.toString();
        org.joda.time.Chronology chronology10 = buddhistChronology6.withZone(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withChronology(chronology10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(960, (int) (short) 100, 0, 1439, 1, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property3 = localDate2.centuryOfEra();
//        int int4 = localDate2.getYear();
//        int[] intArray5 = localDate2.getValues();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
//        org.joda.time.LocalDate localDate10 = property8.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        java.lang.String str18 = gregorianChronology17.toString();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.halfdayOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
//        java.lang.String str22 = gregorianChronology21.toString();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.halfdayOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23);
//        org.joda.time.DurationField durationField25 = gregorianChronology17.minutes();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime15.toMutableDateTime(dateTimeZone26);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
//        org.joda.time.LocalDate localDate34 = property32.addToCopy((int) (short) -1);
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
//        org.joda.time.DateTime dateTime38 = localDate34.toDateTimeAtStartOfDay(dateTimeZone37);
//        org.joda.time.Instant instant39 = dateTime38.toInstant();
//        org.joda.time.DateTime dateTime41 = dateTime38.withCenturyOfEra((int) (short) 1);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology42.getZone();
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = dateTimeZone44.getShortName((long) (byte) 100, locale46);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (long) (short) 1, (int) (byte) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTime dateTime52 = dateTime38.toDateTime(dateTimeZone44);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str22.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(instant39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PST" + "'", str47.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(dateTime52);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long6 = dateTimeZone3.convertLocalToUTC(86340001L, false);
        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtStartOfDay(dateTimeZone3);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86339901L + "'", long6 == 86339901L);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[America/Los_Angeles]", 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("18", 929, 52, 24, ' ', 1, (int) ' ', 1888, true, (int) (short) 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (short) 10, ' ', (-1), (-28378000), (-28800000), false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(1869);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendSecondOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }
}

