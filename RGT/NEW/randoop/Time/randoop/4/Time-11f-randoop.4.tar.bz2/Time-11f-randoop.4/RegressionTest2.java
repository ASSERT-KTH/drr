import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
        int int19 = period18.getMonths();
        org.joda.time.Period period20 = period18.normalizedStandard();
        int int21 = period18.getSeconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-35) + "'", int21 == (-35));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        boolean boolean5 = periodType0.equals((java.lang.Object) durationField4);
        int int6 = periodType0.size();
        try {
            org.joda.time.DurationFieldType durationFieldType8 = periodType0.getFieldType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        try {
//            long long46 = unsupportedDateTimeField39.roundHalfCeiling((long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        try {
//            int int43 = unsupportedDateTimeField39.getMaximumValue((-210858120000000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        boolean boolean12 = unsupportedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.Period period1 = org.joda.time.Period.millis(36);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT-10S", 4, 7);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, (int) (short) 10);
        long long12 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone10, (long) 52);
        long long15 = dateTimeZone10.convertLocalToUTC((-210866760000000L), true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4199944L) + "'", long12 == (-4199944L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-210866764200000L) + "'", long15 == (-210866764200000L));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test008");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        long long7 = iSOChronology0.getDateTimeMillis((long) (short) 100, 0, 4, 0, (int) '4');
//        org.joda.time.DurationField durationField8 = iSOChronology0.halfdays();
//        org.joda.time.DurationField durationField9 = iSOChronology0.eras();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 240048L + "'", long7 == 240048L);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        try {
//            long long43 = unsupportedDateTimeField39.set((long) 9700, "97");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
        org.joda.time.Period period10 = period8.plusWeeks((int) '4');
        org.joda.time.Period period12 = period10.withWeeks((int) (short) 1);
        org.joda.time.Period period14 = period10.plusDays((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, chronology17);
        org.joda.time.Period period20 = period18.withSeconds((int) (short) 0);
        int[] intArray23 = iSOChronology15.get((org.joda.time.ReadablePeriod) period18, (long) (short) 1, (long) 10);
        org.joda.time.Period period25 = period18.minusSeconds((int) '#');
        org.joda.time.Period period26 = period10.plus((org.joda.time.ReadablePeriod) period25);
        java.lang.String str27 = period10.toString();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "P-10M1052W10DT32H1000M35.001S" + "'", str27.equals("P-10M1052W10DT32H1000M35.001S"));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        int int14 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.roundHalfEven((-456073090078000L));
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField9.getAsText((int) ' ', locale18);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-453473424000004L) + "'", long16 == (-453473424000004L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        int int16 = offsetDateTimeField9.getOffset();
//        try {
//            long long19 = offsetDateTimeField9.addWrapField((-9223372036853399000L), 7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275755 for year must be in the range [-292275054,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = org.joda.time.Period.hours(0);
        org.joda.time.Period period4 = period2.plusWeeks((int) '4');
        org.joda.time.Period period6 = period4.withYears(1);
        org.joda.time.Period period7 = period0.withFields((org.joda.time.ReadablePeriod) period4);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "P52W" + "'", str9.equals("P52W"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, chronology10);
        org.joda.time.Period period13 = period11.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        int int15 = periodType14.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) period13, periodType14, (org.joda.time.Chronology) gregorianChronology16);
        boolean boolean19 = iSOChronology0.equals((java.lang.Object) period13);
        org.joda.time.Period period21 = period13.minusWeeks((int) (short) 10);
        org.joda.time.Period period23 = period21.plusMillis((-1));
        org.joda.time.Period period25 = period23.plusDays((int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology6.monthOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset((long) 4);
        long long11 = cachedDateTimeZone7.nextTransition(88L);
        java.util.TimeZone timeZone12 = cachedDateTimeZone7.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 88L + "'", long11 == 88L);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        java.lang.String str9 = zonedChronology6.toString();
//        org.joda.time.DurationField durationField10 = zonedChronology6.eras();
//        try {
//            long long18 = zonedChronology6.getDateTimeMillis(0, 100, (-10), (-35), (int) (short) 1, 98, 6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType9, "ISOChronology[UTC]");
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.Chronology chronology8 = zonedChronology6.withZone(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.getMinimumValue(0L);
//        int int13 = offsetDateTimeField9.get((-374264841599948L));
//        long long16 = offsetDateTimeField9.add((long) (byte) 100, (long) 9700);
//        java.lang.Class<?> wildcardClass17 = offsetDateTimeField9.getClass();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 99 + "'", int13 == 99);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 30610243440000100L + "'", long16 == 30610243440000100L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        java.lang.String str12 = unsupportedDurationField10.getName();
        java.lang.String str13 = unsupportedDurationField10.toString();
        java.lang.String str14 = unsupportedDurationField10.getName();
        boolean boolean15 = unsupportedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnsupportedDurationField[years]" + "'", str13.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        java.lang.String str14 = offsetDateTimeField9.getName();
//        long long16 = offsetDateTimeField9.roundHalfEven((long) 1000);
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField9.getMaximumShortTextLength(locale17);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField9.getAsText(readablePartial19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "centuryOfEra" + "'", str14.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 946684799996L + "'", long16 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(52);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        java.lang.String str13 = jodaTimePermission3.getActions();
//        java.lang.String str14 = jodaTimePermission3.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")" + "'", str14.equals("(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")"));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.years();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration4, readableInstant5, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType6.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.minutes();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.halfdayOfDay();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, (long) '#', periodType9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = periodType9.withDaysRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((long) 4, 252455616000051L, periodType14);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = periodType4.indexOf(durationFieldType6);
        java.lang.String str8 = periodType4.getName();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period10 = new org.joda.time.Period(252455616000051L, 8L, periodType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, chronology14);
        org.joda.time.Period period17 = period15.withSeconds((int) (short) 0);
        org.joda.time.Period period19 = period17.minusMillis((int) ' ');
        int[] intArray22 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period17, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology11.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology11.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean30 = fixedDateTimeZone29.isFixed();
        long long32 = fixedDateTimeZone29.previousTransition((-210858379200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.DurationField durationField34 = gregorianChronology11.years();
        org.joda.time.Period period35 = new org.joda.time.Period(1L, 92172140714106995L, periodType4, (org.joda.time.Chronology) gregorianChronology11);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YearWeekDayTime" + "'", str8.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-210858379200000L) + "'", long32 == (-210858379200000L));
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType2.indexOf(durationFieldType4);
        java.lang.String str6 = periodType2.getName();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType8 = periodType2.withHoursRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(100L, (long) 1000, periodType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType13.indexOf(durationFieldType15);
        org.joda.time.PeriodType periodType17 = periodType13.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        org.joda.time.DurationFieldType durationFieldType21 = unsupportedDurationField20.getType();
        boolean boolean22 = periodType8.isSupported(durationFieldType21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(durationFieldType21, (java.lang.Number) 2440588L, (java.lang.Number) 25, (java.lang.Number) (-61850995199948L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "YearWeekDayTime" + "'", str6.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 20, true, (-6052260001L));
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        long long14 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone11, 36L);
        boolean boolean15 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31L) + "'", long8 == (-31L));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 87L + "'", long14 == 87L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset((long) 4);
        long long11 = cachedDateTimeZone7.nextTransition(88L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        boolean boolean16 = cachedDateTimeZone7.equals((java.lang.Object) dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 88L + "'", long11 == 88L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.years();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration4, readableInstant5, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType6);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeAdd(9223372036854775807L, 15778540800036L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 9223372036854775807 + 15778540800036");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 0);
        org.joda.time.Period period6 = period4.minusMillis((int) ' ');
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) 0, chronology10);
        org.joda.time.Period period13 = period11.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        int int15 = periodType14.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) period13, periodType14, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.time();
        boolean boolean20 = gregorianChronology16.equals((java.lang.Object) periodType19);
        org.joda.time.Period period21 = period4.withPeriodType(periodType19);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period21);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.millisOfDay();
//        try {
//            long long12 = zonedChronology6.getDateTimeMillis(0, 36, 5, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance(chronology17);
//        org.joda.time.Chronology chronology20 = lenientChronology19.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.minutes();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.hourOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.era();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str32 = dateTimeZone30.getShortName((long) (short) -1);
//        long long35 = dateTimeZone30.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology25, dateTimeZone30);
//        org.joda.time.Chronology chronology37 = gregorianChronology21.withZone(dateTimeZone30);
//        org.joda.time.Chronology chronology38 = lenientChronology19.withZone(dateTimeZone30);
//        long long40 = dateTimeZone30.convertUTCToLocal((-66574860011000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.010" + "'", str32.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3L + "'", long35 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-66574860011010L) + "'", long40 == (-66574860011010L));
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test038");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology6);
//        boolean boolean12 = zonedChronology6.equals((java.lang.Object) '4');
//        long long17 = zonedChronology6.getDateTimeMillis(0, (int) (short) 1, 1, 0);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology6.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62167219200000L) + "'", long17 == (-62167219200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-3060893222000L), (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -3060893222000 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test041");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        long long20 = offsetDateTimeField9.set((long) 1000, 128);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 340815081601000L + "'", long20 == 340815081601000L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-3060893222000L), true);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
        int int12 = fixedDateTimeZone4.getOffset(946684799949L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3060893222000L) + "'", long8 == (-3060893222000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 51 + "'", int12 == 51);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test043");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[YearWeekDayTimeNoHours]");
//        java.lang.String str2 = jodaTimePermission1.toString();
//        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) (-1), locale9);
//        int int12 = dateTimeZone7.getOffsetFromLocal((long) (short) 10);
//        boolean boolean13 = jodaTimePermission6.equals((java.lang.Object) int12);
//        java.lang.String str14 = jodaTimePermission6.getActions();
//        boolean boolean15 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission6);
//        java.lang.String str16 = jodaTimePermission6.getName();
//        boolean boolean17 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
//        java.lang.String str18 = jodaTimePermission6.getName();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PeriodType[YearWeekDayTimeNoHours]\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"PeriodType[YearWeekDayTimeNoHours]\")"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "YearWeekDayTime" + "'", str16.equals("YearWeekDayTime"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "YearWeekDayTime" + "'", str18.equals("YearWeekDayTime"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.halfdays();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, chronology5);
        org.joda.time.Period period8 = period6.minusMinutes((int) (short) 100);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        long long13 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, 1L, 11);
        int int14 = period8.size();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-100M" + "'", str10.equals("PT-100M"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-65999999L) + "'", long13 == (-65999999L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        java.lang.String str2 = periodType1.toString();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str2.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 100, 0, 10, 21, 2, 0, 52, (-35));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2922770", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2922770/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        boolean boolean41 = unsupportedDateTimeField39.isLenient();
//        java.util.Locale locale42 = null;
//        try {
//            int int43 = unsupportedDateTimeField39.getMaximumShortTextLength(locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-10), locale21);
//        long long24 = offsetDateTimeField9.roundCeiling((long) 8);
//        int int25 = offsetDateTimeField9.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 946684799996L + "'", long24 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2922790 + "'", int25 == 2922790);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType4);
        org.joda.time.PeriodType periodType6 = periodType4.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType4.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.halfdayOfDay();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) '#', periodType7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.PeriodType periodType12 = periodType7.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 20, true, (-6052260001L));
        boolean boolean10 = fixedDateTimeZone4.isStandardOffset(370191460112688L);
        java.lang.String str12 = fixedDateTimeZone4.getNameKey((-61850995199946L));
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31L) + "'", long8 == (-31L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNotNull(iSOChronology13);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology6.getZone();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(9223372036854775756L, locale12);
//        boolean boolean15 = dateTimeZone10.isStandardOffset(370191460112688L);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, 36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 36");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        int int16 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int int18 = offsetDateTimeField9.getMaximumValue(readablePartial17);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField9.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//        org.junit.Assert.assertNull(durationField19);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        long long16 = offsetDateTimeField9.add((long) 97, (int) (byte) 10);
//        int int18 = offsetDateTimeField9.getMaximumValue((-210866759999949L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200097L + "'", long16 == 31556995200097L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone0.getName((long) 7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (short) -1);
//        long long10 = dateTimeZone5.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
//        org.joda.time.DurationField durationField12 = iSOChronology0.months();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.Period period25 = period19.normalizedStandard();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.Period period27 = period25.plus(readablePeriod26);
//        org.joda.time.Period period29 = period25.plusDays((int) (byte) 10);
//        int[] intArray32 = iSOChronology0.get((org.joda.time.ReadablePeriod) period25, (long) 10, (-66574860011L));
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology34.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) (-1), locale40);
//        int int43 = dateTimeZone38.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology34, dateTimeZone38);
//        java.lang.String str45 = zonedChronology44.toString();
//        org.joda.time.Period period50 = new org.joda.time.Period(4, 10, 1, (int) (byte) 0);
//        int[] intArray52 = zonedChronology44.get((org.joda.time.ReadablePeriod) period50, (-57359948L));
//        try {
//            iSOChronology0.validate(readablePartial33, intArray52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.010" + "'", str7.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str45.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(intArray52);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test059");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.remainder(54621940112688L);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField9.getAsText(readablePartial15, 6000, locale17);
//        long long20 = offsetDateTimeField9.roundHalfCeiling(0L);
//        long long22 = offsetDateTimeField9.roundHalfCeiling((-57359948L));
//        try {
//            long long25 = offsetDateTimeField9.set((long) (short) -1, "Coordinated Universal Time");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for centuryOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2180616687308L) + "'", long14 == (-2180616687308L));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6000" + "'", str18.equals("6000"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 946684799996L + "'", long20 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 946684799996L + "'", long22 == 946684799996L);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        int int6 = periodType3.indexOf(durationFieldType5);
//        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
//        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        boolean boolean19 = jodaTimePermission12.equals((java.lang.Object) int18);
//        java.lang.String str20 = jodaTimePermission12.getActions();
//        java.security.PermissionCollection permissionCollection21 = jodaTimePermission12.newPermissionCollection();
//        boolean boolean22 = unsupportedDurationField10.equals((java.lang.Object) jodaTimePermission12);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        boolean boolean28 = fixedDateTimeZone27.isFixed();
//        java.util.TimeZone timeZone29 = fixedDateTimeZone27.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
//        int int32 = cachedDateTimeZone30.getOffset((long) 4);
//        long long34 = cachedDateTimeZone30.nextTransition(88L);
//        org.joda.time.DateTimeZone dateTimeZone35 = cachedDateTimeZone30.getUncachedZone();
//        boolean boolean36 = unsupportedDurationField10.equals((java.lang.Object) dateTimeZone35);
//        long long37 = unsupportedDurationField10.getUnitMillis();
//        java.lang.String str38 = unsupportedDurationField10.getName();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(durationFieldType9);
//        org.junit.Assert.assertNotNull(unsupportedDurationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//        org.junit.Assert.assertNotNull(permissionCollection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 51 + "'", int32 == 51);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 88L + "'", long34 == 88L);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "years" + "'", str38.equals("years"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        java.lang.String str6 = periodType5.toString();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType5);
        int[] intArray8 = period7.getValues();
        org.joda.time.Minutes minutes9 = period7.toStandardMinutes();
        int[] intArray12 = gregorianChronology0.get((org.joda.time.ReadablePeriod) minutes9, 32503679999949L, 9700L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str6.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
        org.joda.time.Period period10 = period8.plusWeeks((int) '4');
        org.joda.time.Period period12 = period10.withWeeks((int) (short) 1);
        org.joda.time.Period period14 = period10.plusDays((int) ' ');
        org.joda.time.Period period16 = period10.withHours((int) '4');
        try {
            org.joda.time.DurationFieldType durationFieldType18 = period10.getFieldType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("P-10M1052W10DT32H1000M35.001S", 2922797, (int) '4', 194);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922797 for P-10M1052W10DT32H1000M35.001S must be in the range [52,194]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = org.joda.time.Period.hours(0);
        org.joda.time.Period period4 = period2.plusWeeks((int) '4');
        org.joda.time.Period period6 = period4.withYears(1);
        org.joda.time.Period period7 = period0.withFields((org.joda.time.ReadablePeriod) period4);
        org.joda.time.Period period9 = period7.withYears((int) '#');
        org.joda.time.Period period10 = period9.toPeriod();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("UnsupportedDurationField[years]");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusHours(11);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationFrom(readableInstant5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test068");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (-1), locale4);
//        java.lang.String str6 = dateTimeZone2.getID();
//        int int8 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        try {
//            long long12 = zonedChronology9.set(readablePartial10, 92172140714106995L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period20 = period18.withHours(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 0);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) -1);
        org.joda.time.Period period8 = period4.withMinutes((int) '4');
        org.joda.time.Period period10 = period8.plusHours((int) '#');
        int int11 = period8.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundHalfEven((-210866673600000L));
//        java.lang.String str14 = offsetDateTimeField9.getName();
//        long long16 = offsetDateTimeField9.roundHalfFloor((-57359947L));
//        java.lang.String str17 = offsetDateTimeField9.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-210484828800004L) + "'", long13 == (-210484828800004L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "centuryOfEra" + "'", str14.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 946684799996L + "'", long16 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "centuryOfEra" + "'", str17.equals("centuryOfEra"));
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        try {
//            int int42 = unsupportedDateTimeField39.get(54L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-66574860011010L), "GregorianChronology[UTC]");
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test076");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-210484828800051L), 100);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 105084691199949L + "'", long12 == 105084691199949L);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-3060893222000L), true);
        int int10 = fixedDateTimeZone4.getStandardOffset(31556995200097L);
        java.lang.String str11 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3060893222000L) + "'", long8 == (-3060893222000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        int int8 = periodType7.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        int int18 = periodType17.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.time();
        boolean boolean23 = gregorianChronology19.equals((java.lang.Object) periodType22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 1, periodType7, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.secondOfDay();
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.Period period30 = new org.joda.time.Period(0L, periodType7, (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationFrom(readableInstant31);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration32, readableInstant33);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(duration32);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        boolean boolean41 = unsupportedDateTimeField39.isLenient();
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        java.util.Locale locale43 = null;
//        try {
//            java.lang.String str44 = unsupportedDateTimeField39.getAsShortText(readablePartial42, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        long long16 = offsetDateTimeField9.add((long) 97, (int) (byte) 10);
//        long long18 = offsetDateTimeField9.roundHalfCeiling((long) (short) 0);
//        java.lang.String str19 = offsetDateTimeField9.getName();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200097L + "'", long16 == 31556995200097L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 946684799996L + "'", long18 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "centuryOfEra" + "'", str19.equals("centuryOfEra"));
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.DurationField durationField8 = iSOChronology0.months();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        java.lang.String str18 = offsetDateTimeField9.toString();
//        org.joda.time.DurationField durationField19 = offsetDateTimeField9.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str18.equals("DateTimeField[centuryOfEra]"));
//        org.junit.Assert.assertNull(durationField19);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) '4');
        org.joda.time.Period period5 = period1.plusHours(100);
        org.joda.time.Period period6 = period1.negated();
        org.joda.time.Period period8 = period6.minusMinutes(11);
        org.joda.time.Period period10 = period6.multipliedBy((int) (short) 0);
        org.joda.time.Duration duration11 = period6.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration11);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-10), locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField9.getAsShortText(readablePartial23, 100, locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField9.getAsShortText(6000, locale28);
//        long long32 = offsetDateTimeField9.add((long) 7, (int) (short) 0);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField38 = iSOChronology37.weekyears();
//        org.joda.time.DurationField durationField39 = iSOChronology37.halfdays();
//        org.joda.time.Period period40 = new org.joda.time.Period((-450317664000051L), (-210484828800051L), (org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.Period period49 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
//        org.joda.time.Period period51 = period49.plusWeeks((int) '4');
//        int int52 = period49.getMonths();
//        int[] intArray54 = iSOChronology37.get((org.joda.time.ReadablePeriod) period49, (long) (byte) 100);
//        try {
//            int[] intArray56 = offsetDateTimeField9.add(readablePartial33, 36, intArray54, 2922790);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "6000" + "'", str29.equals("6000"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 7L + "'", long32 == 7L);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-10) + "'", int52 == (-10));
//        org.junit.Assert.assertNotNull(intArray54);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        long long20 = offsetDateTimeField9.add((-377420515199948L), (int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField9.getType();
//        long long23 = offsetDateTimeField9.roundHalfEven(604800000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-374264841599948L) + "'", long20 == (-374264841599948L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684799996L + "'", long23 == 946684799996L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DurationField durationField9 = zonedChronology6.days();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology6.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology6.millisOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getLeapDurationField();
//        java.lang.String str43 = unsupportedDateTimeField39.getName();
//        try {
//            boolean boolean45 = unsupportedDateTimeField39.isLeap(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "centuryOfEra" + "'", str43.equals("centuryOfEra"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
        org.joda.time.Period period10 = period8.plusWeeks((int) '4');
        int int11 = period8.getMonths();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = periodType15.indexOf(durationFieldType17);
        org.joda.time.PeriodType periodType19 = periodType15.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (byte) 0);
        java.lang.Number number24 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(durationFieldType21, (java.lang.Number) 9223372036854775756L, (java.lang.Number) (-377420515199948L), number24);
        org.joda.time.Period period27 = period8.withFieldAdded(durationFieldType21, 21);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) 0, chronology29);
        org.joda.time.Period period32 = period30.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearWeekDayTime();
        int int34 = periodType33.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int36 = gregorianChronology35.getMinimumDaysInFirstWeek();
        org.joda.time.Period period37 = new org.joda.time.Period((java.lang.Object) period32, periodType33, (org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.Period period38 = period8.withFields((org.joda.time.ReadablePeriod) period37);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-10) + "'", int11 == (-10));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(period38);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        long long20 = offsetDateTimeField9.add((-377420515199948L), (int) (byte) 1);
//        java.util.Locale locale21 = null;
//        int int22 = offsetDateTimeField9.getMaximumShortTextLength(locale21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-374264841599948L) + "'", long20 == (-374264841599948L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        try {
//            int int41 = unsupportedDateTimeField39.getMaximumValue((-9223372036853399000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value -1 for 100 must be in the range [2440587,0]", (java.lang.Number) (-61850995199948L), (java.lang.Number) 9223372036854775756L, (java.lang.Number) (-6657486001100001L));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology10.getZone();
//        org.joda.time.DurationField durationField13 = zonedChronology10.minutes();
//        org.joda.time.DateTimeField dateTimeField14 = zonedChronology10.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        java.lang.String str8 = zonedChronology6.toString();
//        org.joda.time.DurationField durationField9 = zonedChronology6.weekyears();
//        org.joda.time.Chronology chronology10 = zonedChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology6.halfdayOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str8.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusHours(11);
        org.joda.time.Period period6 = period4.minusMonths(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField39.getType();
//        try {
//            long long45 = unsupportedDateTimeField39.set((long) 2922770, "52");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-3060893222000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2405160.4951157407d + "'", double1 == 2405160.4951157407d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        boolean boolean5 = fixedDateTimeZone4.isFixed();
//        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.lang.String str9 = cachedDateTimeZone7.getNameKey(8L);
//        long long11 = cachedDateTimeZone7.previousTransition(604800000L);
//        long long13 = cachedDateTimeZone7.previousTransition(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName((long) (byte) 0, locale18);
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone16);
//        org.joda.time.Chronology chronology21 = zonedChronology20.withUTC();
//        org.joda.time.DurationField durationField22 = zonedChronology20.hours();
//        org.joda.time.DateTimeField dateTimeField23 = zonedChronology20.year();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getName((long) (byte) 0, locale28);
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, dateTimeZone26);
//        org.joda.time.Chronology chronology31 = zonedChronology30.withUTC();
//        boolean boolean32 = zonedChronology20.equals((java.lang.Object) chronology31);
//        org.joda.time.chrono.LenientChronology lenientChronology33 = org.joda.time.chrono.LenientChronology.getInstance(chronology31);
//        org.joda.time.Chronology chronology34 = lenientChronology33.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField36 = gregorianChronology35.minutes();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.hourOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.era();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str46 = dateTimeZone44.getShortName((long) (short) -1);
//        long long49 = dateTimeZone44.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology39, dateTimeZone44);
//        org.joda.time.Chronology chronology51 = gregorianChronology35.withZone(dateTimeZone44);
//        org.joda.time.Chronology chronology52 = lenientChronology33.withZone(dateTimeZone44);
//        boolean boolean53 = cachedDateTimeZone7.equals((java.lang.Object) chronology52);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 604800000L + "'", long11 == 604800000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Coordinated Universal Time" + "'", str29.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(lenientChronology33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-00:00:00.010" + "'", str46.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 3L + "'", long49 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology0.minutes();
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            int[] intArray16 = gregorianChronology0.get(readablePartial14, (long) 128);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology6.secondOfMinute();
//        java.lang.String str20 = zonedChronology6.toString();
//        org.joda.time.DurationField durationField21 = zonedChronology6.minutes();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str20.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT-10S", 4, 7);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.DurationField durationField19 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology6.monthOfYear();
//        org.joda.time.DurationField durationField21 = zonedChronology6.millis();
//        long long24 = durationField21.subtract((-377420515199948L), (long) 5);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-377420515199953L) + "'", long24 == (-377420515199953L));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("P52W", "PeriodType[Minutes]");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(51);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Period period5 = period1.plusSeconds((int) (byte) 0);
        org.joda.time.Period period7 = period5.minusMonths((int) (short) 10);
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (short) 1);
        org.joda.time.Period period10 = period7.minus((org.joda.time.ReadablePeriod) period9);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0S", 2, 51);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.adjustOffset((-61850995199948L), false);
        long long12 = fixedDateTimeZone4.adjustOffset((-31L), false);
        java.lang.String str14 = fixedDateTimeZone4.getShortName((-210858379200000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61850995199948L) + "'", long9 == (-61850995199948L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31L) + "'", long12 == (-31L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.051" + "'", str14.equals("+00:00:00.051"));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField9, (-1), (int) (short) 10, 9700);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [10,9700]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        boolean boolean41 = unsupportedDateTimeField39.isLenient();
//        java.util.Locale locale43 = null;
//        try {
//            java.lang.String str44 = unsupportedDateTimeField39.getAsShortText(8, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int int15 = offsetDateTimeField9.getMinimumValue(readablePartial14);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField9.getWrappedField();
//        int int18 = offsetDateTimeField9.getMaximumValue((long) 6);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-100), locale21);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (byte) 0, locale27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology23, dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology23.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 1);
//        int int34 = offsetDateTimeField32.get((long) (-10));
//        int int36 = offsetDateTimeField32.get(0L);
//        long long39 = offsetDateTimeField32.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField40 = offsetDateTimeField32.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField32.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField32.getType();
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-100" + "'", str22.equals("-100"));
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31556995200097L + "'", long39 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "PeriodType[YearWeekDayTimeNoHours]");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        int int5 = period4.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField14 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Minutes]", (java.lang.Number) (byte) 100, number2, (java.lang.Number) (short) 1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PeriodType[Minutes]" + "'", str7.equals("PeriodType[Minutes]"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField39.getType();
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = unsupportedDateTimeField39.getAsText(0L, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test119");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        java.util.Locale locale42 = null;
//        try {
//            int int43 = unsupportedDateTimeField39.getMaximumShortTextLength(locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.years();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration4, readableInstant5, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType6);
        java.lang.String str11 = periodType6.getName();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Years" + "'", str11.equals("Years"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        int int12 = periodType11.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(1L, periodType3, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 0, chronology23);
        org.joda.time.Period period26 = period24.withSeconds((int) (short) 0);
        org.joda.time.Period period28 = period26.minusMillis((int) ' ');
        int[] intArray31 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period26, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology20.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology20.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean39 = fixedDateTimeZone38.isFixed();
        long long41 = fixedDateTimeZone38.previousTransition((-210858379200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, (org.joda.time.DateTimeZone) fixedDateTimeZone38);
        long long44 = fixedDateTimeZone38.previousTransition((long) (short) 100);
        org.joda.time.Chronology chronology45 = gregorianChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology13.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean52 = fixedDateTimeZone51.isFixed();
        java.util.TimeZone timeZone53 = fixedDateTimeZone51.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        java.lang.String str56 = cachedDateTimeZone54.getNameKey(8L);
        int int58 = cachedDateTimeZone54.getStandardOffset((long) '#');
        boolean boolean59 = gregorianChronology13.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-210858379200000L) + "'", long41 == (-210858379200000L));
        org.junit.Assert.assertNotNull(zonedChronology42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Coordinated Universal Time" + "'", str56.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 100 + "'", int58 == 100);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean19 = fixedDateTimeZone18.isFixed();
        long long21 = fixedDateTimeZone18.previousTransition((-210858379200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        java.util.TimeZone timeZone23 = fixedDateTimeZone18.toTimeZone();
        long long25 = fixedDateTimeZone18.nextTransition((long) 'a');
        long long27 = fixedDateTimeZone18.previousTransition((-4199944L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-210858379200000L) + "'", long21 == (-210858379200000L));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-4199944L) + "'", long27 == (-4199944L));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        try {
//            long long42 = unsupportedDateTimeField39.remainder((long) (-35));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("-10", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyear();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.millisOfDay();
        org.joda.time.DurationField durationField17 = iSOChronology12.millis();
        long long20 = durationField17.subtract(240048L, (long) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 240047L + "'", long20 == 240047L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType5);
        org.joda.time.Weeks weeks7 = period6.toStandardWeeks();
        int int8 = period6.getMinutes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(weeks7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(8L);
        long long11 = cachedDateTimeZone7.previousTransition(604800000L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long14 = cachedDateTimeZone7.previousTransition(8L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 604800000L + "'", long11 == 604800000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 8L + "'", long14 == 8L);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test128");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology10.getZone();
//        org.joda.time.DurationField durationField13 = zonedChronology10.minutes();
//        java.lang.String str14 = zonedChronology10.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(128);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        int int12 = periodType11.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(1L, periodType3, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.clockhourOfDay();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDayTime();
        int int7 = periodType6.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period5, periodType6, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 0, chronology12);
        org.joda.time.Period period15 = period13.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        int int17 = periodType16.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period15, periodType16, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.time();
        boolean boolean22 = gregorianChronology18.equals((java.lang.Object) periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 1, periodType6, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology18.hourOfDay();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10.0d, number2, (java.lang.Number) (-210858379199900L));
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusSeconds(10);
        org.joda.time.Period period6 = period2.minusMonths((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Period period8 = period6.plus(readablePeriod7);
        org.joda.time.Period period10 = period8.plusMonths(2);
        org.joda.time.Period period12 = period10.plusHours(10);
        try {
            org.joda.time.Hours hours13 = period12.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("128", "YearWeekDayTimeNoHours");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        java.lang.String str11 = cachedDateTimeZone7.getNameKey((long) (short) -1);
        int int13 = cachedDateTimeZone7.getStandardOffset(0L);
        java.lang.String str15 = cachedDateTimeZone7.getNameKey(2440588L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getShortName((long) 1000);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.051" + "'", str7.equals("+00:00:00.051"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusSeconds(10);
        org.joda.time.Period period6 = period2.minusMonths((int) '4');
        org.joda.time.Period period8 = period2.withMillis(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance(chronology17);
//        org.joda.time.DurationField durationField20 = lenientChronology19.millis();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        java.lang.String str4 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        long long47 = unsupportedDateTimeField39.getDifferenceAsLong((-456073090078000L), (-3060893222000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-453012196856000L) + "'", long47 == (-453012196856000L));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        java.lang.String str3 = periodType2.toString();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType2, chronology4);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str3.equals("PeriodType[YearWeekDayTimeNoHours]"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 106754431755L, (java.lang.Number) 149L, (java.lang.Number) (-61850995199946L));
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) (byte) 0, locale5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone3);
//        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
//        org.joda.time.DurationField durationField9 = zonedChronology7.hours();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.year();
//        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology7.getZone();
//        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period14 = period12.multipliedBy(0);
//        org.joda.time.Period period16 = period14.withMonths((-149));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-3060893222000L), true);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(105084691199949L);
        int int14 = fixedDateTimeZone4.getOffset((-210866760000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3060893222000L) + "'", long8 == (-3060893222000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 51 + "'", int12 == 51);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 51 + "'", int14 == 51);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = unsupportedDateTimeField39.getAsText(readablePartial42, 194, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        java.util.Locale locale46 = null;
//        try {
//            java.lang.String str47 = unsupportedDateTimeField39.getAsText(readablePartial45, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.secondOfDay();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration7, readableInstant8, periodType9);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.joda.time.Period period13 = period10.plusDays(0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period10.getFieldTypes();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.forFields(durationFieldTypeArray14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.forFields(durationFieldTypeArray14);
        boolean boolean17 = iSOChronology2.equals((java.lang.Object) periodType16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.secondOfDay();
        org.joda.time.Chronology chronology22 = iSOChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.secondOfDay();
        org.joda.time.Period period24 = new org.joda.time.Period(34712668800083L, 612204912000052L, periodType16, (org.joda.time.Chronology) iSOChronology18);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(mutablePeriod11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        int int21 = offsetDateTimeField9.getDifference(0L, (-9223372036853399000L));
//        long long23 = offsetDateTimeField9.roundHalfFloor((-9223372036853399000L));
//        java.lang.String str24 = offsetDateTimeField9.getName();
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField9.getMaximumTextLength(locale25);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2922770 + "'", int21 == 2922770);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-9223370312976000004L) + "'", long23 == (-9223370312976000004L));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "centuryOfEra" + "'", str24.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC(9223372036854775807L, false, (-3060893222000L));
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        long long12 = fixedDateTimeZone4.nextTransition(32503679999949L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775756L + "'", long8 == 9223372036854775756L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32503679999949L + "'", long12 == 32503679999949L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDayTime();
        int int7 = periodType6.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period5, periodType6, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) 0, chronology12);
        org.joda.time.Period period15 = period13.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDayTime();
        int int17 = periodType16.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) period15, periodType16, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.time();
        boolean boolean22 = gregorianChronology18.equals((java.lang.Object) periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 1, periodType6, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Period period25 = org.joda.time.Period.hours(0);
        org.joda.time.Period period27 = period25.plusWeeks((int) '4');
        org.joda.time.Period period29 = period25.plusHours(100);
        org.joda.time.Period period31 = period25.minusWeeks(100);
        org.joda.time.Period period32 = period23.withFields((org.joda.time.ReadablePeriod) period31);
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType36 = periodType35.withHoursRemoved();
        java.lang.String str37 = periodType36.toString();
        org.joda.time.Period period38 = new org.joda.time.Period(readableDuration33, readableInstant34, periodType36);
        org.joda.time.PeriodType periodType39 = periodType36.withMinutesRemoved();
        org.joda.time.Period period40 = period31.withPeriodType(periodType39);
        org.joda.time.PeriodType periodType41 = periodType39.withDaysRemoved();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 7 + "'", int17 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str37.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType41);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test153");
//        java.lang.Number number2 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10.0d, number2, (java.lang.Number) (-210858379199900L));
//        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
//        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
//        org.joda.time.Period period7 = new org.joda.time.Period();
//        org.joda.time.Period period9 = org.joda.time.Period.hours(0);
//        org.joda.time.Period period11 = period9.plusWeeks((int) '4');
//        org.joda.time.Period period13 = period11.withYears(1);
//        org.joda.time.Period period14 = period7.withFields((org.joda.time.ReadablePeriod) period11);
//        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName((long) (-1), locale22);
//        int int25 = dateTimeZone20.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology16, dateTimeZone20);
//        try {
//            org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) illegalFieldValueException4, periodType15, (org.joda.time.Chronology) zonedChronology26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.IllegalFieldValueException");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-210858379199900L) + "'", number6.equals((-210858379199900L)));
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordinated Universal Time" + "'", str23.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset((int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder2.addRecurringSavings("", (int) (byte) 100, 2922770, (int) 'a', '4', (int) '4', 6, 36, false, 100);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test155");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 0, chronology14);
//        org.joda.time.Period period17 = period15.minusMinutes((int) (short) 100);
//        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int19 = periodType18.size();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
//        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period17, periodType18, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 0, chronology24);
//        org.joda.time.Period period27 = period25.minusMinutes((int) (short) 100);
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int29 = periodType28.size();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int31 = gregorianChronology30.getMinimumDaysInFirstWeek();
//        org.joda.time.Period period32 = new org.joda.time.Period((java.lang.Object) period27, periodType28, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.time();
//        boolean boolean34 = gregorianChronology30.equals((java.lang.Object) periodType33);
//        org.joda.time.Period period35 = new org.joda.time.Period((long) (byte) 1, periodType18, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.secondOfDay();
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology36);
//        org.joda.time.Period period41 = new org.joda.time.Period(0L, periodType18, (org.joda.time.Chronology) iSOChronology36);
//        boolean boolean42 = zonedChronology10.equals((java.lang.Object) period41);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(periodType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test156");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "20");
//        illegalFieldValueException41.prependMessage("");
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.joda.time.DurationField durationField4 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        int int8 = periodType7.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        int int18 = periodType17.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.time();
        boolean boolean23 = gregorianChronology19.equals((java.lang.Object) periodType22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 1, periodType7, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.secondOfDay();
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.Period period30 = new org.joda.time.Period(0L, periodType7, (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationFrom(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Minutes]", (java.lang.Number) (-57359947L), number2, (java.lang.Number) (short) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PeriodType[Minutes]" + "'", str7.equals("PeriodType[Minutes]"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(8L);
        int int11 = cachedDateTimeZone7.getStandardOffset(83L);
        boolean boolean12 = cachedDateTimeZone7.isFixed();
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = cachedDateTimeZone7.isLocalDateTimeGap(localDateTime14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.Period period1 = org.joda.time.Period.hours(194);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        long long12 = unsupportedDurationField10.getUnitMillis();
        boolean boolean13 = unsupportedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.joda.time.ReadableDuration readableDuration0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
//        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((long) (byte) 0, locale8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 1);
//        long long16 = offsetDateTimeField13.add((-61850995199948L), (-100));
//        long long19 = offsetDateTimeField13.set((long) 51, (int) (byte) 100);
//        long long21 = offsetDateTimeField13.roundCeiling((long) 1);
//        java.lang.String str23 = offsetDateTimeField13.getAsText(54L);
//        boolean boolean24 = periodType2.equals((java.lang.Object) 54L);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-377420515199948L) + "'", long16 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 252455616000051L + "'", long19 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 946684799996L + "'", long21 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Minutes]", (java.lang.Number) (-57359947L), number2, (java.lang.Number) (short) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-57359947" + "'", str6.equals("-57359947"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -57359947 for PeriodType[Minutes] must not be larger than -1" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value -57359947 for PeriodType[Minutes] must not be larger than -1"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        boolean boolean8 = fixedDateTimeZone4.isStandardOffset((long) (short) 1);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 1000);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 100);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.joda.time.Period period4 = period1.plusWeeks(8);
        org.joda.time.Period period6 = period1.plusMinutes(6);
        org.junit.Assert.assertNotNull(seconds2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = gregorianChronology0.equals(obj3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.withSeconds((int) (short) 0);
        int[] intArray13 = iSOChronology5.get((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (long) 10);
        org.joda.time.Period period15 = period8.minusSeconds((int) '#');
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.Period period19 = period15.withDays((int) '#');
        int[] intArray22 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period15, (long) 1, (long) ' ');
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology0.dayOfWeek();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField9.getAsText((long) (-100), locale15);
//        long long18 = offsetDateTimeField9.roundHalfEven(105084691199949L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "20" + "'", str16.equals("20"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 105084691199996L + "'", long18 == 105084691199996L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField39, dateTimeFieldType42, 2922790, 52, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusWeeks(7);
        org.joda.time.Period period3 = new org.joda.time.Period();
        org.joda.time.Period period5 = org.joda.time.Period.hours(0);
        org.joda.time.Period period7 = period5.plusWeeks((int) '4');
        org.joda.time.Period period9 = period7.withYears(1);
        org.joda.time.Period period10 = period3.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period12 = period7.minusMinutes((int) (byte) 0);
        org.joda.time.Period period13 = period2.minus((org.joda.time.ReadablePeriod) period7);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test171");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        java.lang.String str8 = zonedChronology6.toString();
//        org.joda.time.DurationField durationField9 = zonedChronology6.weekyears();
//        org.joda.time.Chronology chronology10 = zonedChronology6.withUTC();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        boolean boolean16 = fixedDateTimeZone15.isFixed();
//        java.util.TimeZone timeZone17 = fixedDateTimeZone15.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int20 = cachedDateTimeZone18.getOffset((long) 4);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology6, (org.joda.time.DateTimeZone) cachedDateTimeZone18);
//        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str8.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 51 + "'", int20 == 51);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(lenientChronology22);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test172");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        boolean boolean18 = offsetDateTimeField9.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test173");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "org.joda.time.IllegalFieldValueException: Value -57359947 for PeriodType[Minutes] must not be larger than -1");
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test174");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        long long23 = zonedChronology6.getDateTimeMillis((int) (byte) 10, 1, 8, (int) '4');
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType27 = periodType26.withHoursRemoved();
//        java.lang.String str28 = periodType27.toString();
//        org.joda.time.PeriodType periodType29 = org.joda.time.DateTimeUtils.getPeriodType(periodType27);
//        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration24, readableInstant25, periodType29);
//        org.joda.time.Weeks weeks31 = period30.toStandardWeeks();
//        boolean boolean32 = zonedChronology6.equals((java.lang.Object) period30);
//        org.joda.time.Period period34 = org.joda.time.Period.weeks((int) (short) 0);
//        org.joda.time.Period period35 = period30.minus((org.joda.time.ReadablePeriod) period34);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61850995199948L) + "'", long23 == (-61850995199948L));
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str28.equals("PeriodType[YearWeekDayTimeNoHours]"));
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(weeks31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period35);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType5);
        int int7 = period6.getMinutes();
        org.joda.time.Period period9 = period6.minusYears((int) (short) -1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test177");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        int int6 = periodType3.indexOf(durationFieldType5);
//        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
//        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        boolean boolean19 = jodaTimePermission12.equals((java.lang.Object) int18);
//        java.lang.String str20 = jodaTimePermission12.getActions();
//        java.security.PermissionCollection permissionCollection21 = jodaTimePermission12.newPermissionCollection();
//        boolean boolean22 = unsupportedDurationField10.equals((java.lang.Object) jodaTimePermission12);
//        try {
//            long long25 = unsupportedDurationField10.getValueAsLong((-377420515199953L), 2440587L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(durationFieldType9);
//        org.junit.Assert.assertNotNull(unsupportedDurationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//        org.junit.Assert.assertNotNull(permissionCollection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.years();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration4, readableInstant5, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType6);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test179");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        java.util.Locale locale43 = null;
//        try {
//            java.lang.String str44 = unsupportedDateTimeField39.getAsShortText(20, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType2.indexOf(durationFieldType4);
        java.lang.String str6 = periodType2.getName();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.Period period8 = new org.joda.time.Period(252455616000051L, 8L, periodType2);
        org.joda.time.PeriodType periodType9 = periodType2.withWeeksRemoved();
        int int10 = periodType2.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "YearWeekDayTime" + "'", str6.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getLeapDurationField();
//        boolean boolean43 = unsupportedDateTimeField39.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test182");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-10), locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField9.getAsShortText(readablePartial23, 100, locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField9.getAsShortText(6000, locale28);
//        java.util.Locale locale30 = null;
//        int int31 = offsetDateTimeField9.getMaximumShortTextLength(locale30);
//        java.util.Locale locale32 = null;
//        int int33 = offsetDateTimeField9.getMaximumShortTextLength(locale32);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "6000" + "'", str29.equals("6000"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test183");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        int int16 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int int18 = offsetDateTimeField9.getMaximumValue(readablePartial17);
//        int int19 = offsetDateTimeField9.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test184");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-10), locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField9.getAsShortText(readablePartial23, 100, locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField9.getAsShortText(6000, locale28);
//        long long31 = offsetDateTimeField9.roundHalfFloor((long) 97);
//        int int32 = offsetDateTimeField9.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "6000" + "'", str29.equals("6000"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 946684799996L + "'", long31 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922790 + "'", int32 == 2922790);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withSecondsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType7 = periodType2.getFieldType(6000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("138", (java.lang.Number) 2440588L, (java.lang.Number) 2922770, number3);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test188");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
//        org.joda.time.Period period4 = period2.withSeconds((int) (short) 0);
//        org.joda.time.Period period6 = period4.minusMillis((int) ' ');
//        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 10);
//        org.joda.time.Days days9 = period4.toStandardDays();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone17 = zonedChronology16.getZone();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType21 = periodType20.withHoursRemoved();
//        java.lang.String str22 = periodType21.toString();
//        org.joda.time.Period period23 = new org.joda.time.Period(readableDuration18, readableInstant19, periodType21);
//        int int24 = period23.getDays();
//        int[] intArray27 = zonedChronology16.get((org.joda.time.ReadablePeriod) period23, 473473978L, (-2180616687261L));
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType31 = periodType30.withHoursRemoved();
//        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant28, readableDuration29, periodType31);
//        org.joda.time.DurationFieldType durationFieldType33 = null;
//        int int34 = periodType31.indexOf(durationFieldType33);
//        org.joda.time.PeriodType periodType35 = periodType31.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType37 = periodType35.getFieldType((int) (byte) 0);
//        java.lang.Number number40 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(durationFieldType37, (java.lang.Number) 9223372036854775756L, (java.lang.Number) (-377420515199948L), number40);
//        int int42 = period23.indexOf(durationFieldType37);
//        int int43 = period4.indexOf(durationFieldType37);
//        org.joda.time.Period period45 = period4.withWeeks((int) (short) 100);
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(days9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str22.equals("PeriodType[YearWeekDayTimeNoHours]"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(periodType35);
//        org.junit.Assert.assertNotNull(durationFieldType37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(period45);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType2.indexOf(durationFieldType4);
        java.lang.String str6 = periodType2.getName();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType7);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "YearWeekDayTime" + "'", str6.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT-10S", 4, 7);
        long long6 = fixedDateTimeZone4.previousTransition((-194L));
        long long8 = fixedDateTimeZone4.nextTransition((-98L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-194L) + "'", long6 == (-194L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-98L) + "'", long8 == (-98L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.secondOfDay();
        org.joda.time.Chronology chronology10 = iSOChronology6.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology6.getZone();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test192");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        try {
//            int int42 = unsupportedDateTimeField39.get((-6657486001100001L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        int int12 = periodType11.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(1L, periodType3, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology13.yearOfCentury();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset((long) 4);
        long long11 = cachedDateTimeZone7.nextTransition(88L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone7.getUncachedZone();
        long long14 = cachedDateTimeZone7.previousTransition((long) 52);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = cachedDateTimeZone7.isLocalDateTimeGap(localDateTime15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 88L + "'", long11 == 88L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test195");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        try {
//            long long42 = unsupportedDateTimeField39.roundFloor((long) 1000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test196");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNull(durationField18);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        long long7 = iSOChronology0.add((long) '#', (long) (byte) -1, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 0, chronology11);
        org.joda.time.Period period14 = period12.withSeconds((int) (short) 0);
        org.joda.time.Period period16 = period14.minusMillis((int) ' ');
        int[] intArray19 = gregorianChronology8.get((org.joda.time.ReadablePeriod) period14, (long) 100, (long) 7);
        org.joda.time.Period period20 = period14.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.years();
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType23);
        org.joda.time.Period period26 = period24.minusYears(100);
        org.joda.time.Period period28 = period26.withYears((int) (short) 100);
        org.joda.time.Period period29 = period26.negated();
        org.joda.time.Period period31 = period26.plusMonths(0);
        org.joda.time.Period period32 = period14.plus((org.joda.time.ReadablePeriod) period31);
        int[] intArray34 = iSOChronology0.get((org.joda.time.ReadablePeriod) period14, (-66574860011010L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36L + "'", long7 == 36L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        java.lang.String str8 = zonedChronology6.toString();
//        org.joda.time.DurationField durationField9 = zonedChronology6.hours();
//        java.lang.String str10 = zonedChronology6.toString();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology6.hourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str8.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test200");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(1560626860360L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField9.getAsShortText(readablePartial14, 52, locale16);
//        int int19 = offsetDateTimeField9.getMaximumValue((long) (byte) 1);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) 0, chronology22);
//        org.joda.time.Period period25 = period23.minusMinutes((int) (short) 100);
//        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.yearWeekDayTime();
//        int int27 = periodType26.size();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int29 = gregorianChronology28.getMinimumDaysInFirstWeek();
//        org.joda.time.Period period30 = new org.joda.time.Period((java.lang.Object) period25, periodType26, (org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.year();
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.years();
//        org.joda.time.Period period35 = new org.joda.time.Period(readableDuration32, readableInstant33, periodType34);
//        org.joda.time.Period period37 = period35.minusYears(100);
//        org.joda.time.Period period39 = period37.withYears((int) (short) 100);
//        int[] intArray41 = gregorianChronology28.get((org.joda.time.ReadablePeriod) period37, (long) (-1));
//        int int42 = offsetDateTimeField9.getMaximumValue(readablePartial20, intArray41);
//        boolean boolean43 = offsetDateTimeField9.isSupported();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52" + "'", str17.equals("52"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2922790 + "'", int19 == 2922790);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(periodType34);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertNotNull(period39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2922790 + "'", int42 == 2922790);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT-100M" + "'", str6.equals("PT-100M"));
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        java.lang.String str2 = periodType1.toString();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str2.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
        int int19 = period18.getMonths();
        java.lang.String str20 = period18.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT-35S" + "'", str20.equals("PT-35S"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.minusDays((-100));
        org.joda.time.PeriodType periodType3 = period2.getPeriodType();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDayTime();
        int int6 = periodType5.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period4, periodType5, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.year();
        org.joda.time.DurationField durationField11 = gregorianChronology7.eras();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.secondOfDay();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = periodType4.indexOf(durationFieldType6);
        java.lang.String str8 = periodType4.getName();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period10 = new org.joda.time.Period(604800000L, 1000L, periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period((-210865896000000L), 0L, periodType9);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YearWeekDayTime" + "'", str8.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType9);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test208");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        try {
//            long long43 = unsupportedDateTimeField39.roundHalfCeiling((-149L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test209");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getLeapDurationField();
//        java.lang.String str43 = unsupportedDateTimeField39.getName();
//        boolean boolean44 = unsupportedDateTimeField39.isLenient();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "centuryOfEra" + "'", str43.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.previousTransition((-3060893222000L));
        java.lang.String str9 = fixedDateTimeZone4.toString();
        java.lang.String str10 = fixedDateTimeZone4.getID();
        long long12 = fixedDateTimeZone4.nextTransition((long) 7);
        java.lang.String str14 = fixedDateTimeZone4.getNameKey((-149L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3060893222000L) + "'", long8 == (-3060893222000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0S" + "'", str9.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0S" + "'", str10.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDayTime();
        int int6 = periodType5.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period4, periodType5, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.weekyear();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test212");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        long long15 = offsetDateTimeField9.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField9.getWrappedField();
//        long long18 = offsetDateTimeField9.roundHalfCeiling((long) 98);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName((long) (byte) 0, locale23);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology19.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 1);
//        long long31 = offsetDateTimeField28.add((-61850995199948L), (-100));
//        int int32 = offsetDateTimeField28.getMinimumValue();
//        boolean boolean33 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 98, (java.lang.Object) offsetDateTimeField28);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        int int35 = offsetDateTimeField28.getMaximumValue(readablePartial34);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 946684799996L + "'", long15 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 946684799996L + "'", long18 == 946684799996L);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordinated Universal Time" + "'", str24.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-377420515199948L) + "'", long31 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2922790 + "'", int35 == 2922790);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test214");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.remainder(54621940112688L);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField9.getAsText(readablePartial15, 6000, locale17);
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField9.getWrappedField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2180616687308L) + "'", long14 == (-2180616687308L));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6000" + "'", str18.equals("6000"));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test215");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology6.secondOfMinute();
//        try {
//            long long24 = zonedChronology6.getDateTimeMillis(36, (-59), 100, (-59));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -59 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(6000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value 10.0 for hi! must not be larger than -210858379199900", (int) (short) -1, (int) ' ', 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for org.joda.time.IllegalFieldValueException: Value 10.0 for hi! must not be larger than -210858379199900 must be in the range [32,20]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test218");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        java.lang.String str18 = offsetDateTimeField9.toString();
//        long long20 = offsetDateTimeField9.roundHalfFloor(105084691199996L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str18.equals("DateTimeField[centuryOfEra]"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 105084691199996L + "'", long20 == 105084691199996L);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = org.joda.time.Period.hours(0);
        org.joda.time.Period period4 = period2.plusWeeks((int) '4');
        org.joda.time.Period period6 = period4.withYears(1);
        org.joda.time.Period period7 = period0.withFields((org.joda.time.ReadablePeriod) period4);
        org.joda.time.Period period9 = period4.minusMinutes((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType13.indexOf(durationFieldType15);
        org.joda.time.PeriodType periodType17 = periodType13.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        int int21 = period9.get(durationFieldType19);
        org.joda.time.Hours hours22 = period9.toStandardHours();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(hours22);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test220");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.yearOfCentury();
//        org.joda.time.DurationField durationField26 = gregorianChronology13.weekyears();
//        boolean boolean27 = jodaTimePermission3.equals((java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology13.dayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str35 = dateTimeZone33.getShortName((long) (short) -1);
//        long long38 = dateTimeZone33.adjustOffset(3L, false);
//        long long41 = dateTimeZone33.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology42 = gregorianChronology29.withZone(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology29.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, 36, 51, 0);
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField67);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType62, 11, 0, (int) '4');
//        try {
//            long long75 = offsetDateTimeField72.set(1560626860360L, 1000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for centuryOfEra must be in the range [12,18]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-00:00:00.010" + "'", str35.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3L + "'", long38 == 3L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean19 = fixedDateTimeZone18.isFixed();
        long long21 = fixedDateTimeZone18.previousTransition((-210858379200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DurationField durationField23 = gregorianChronology0.years();
        long long26 = durationField23.subtract(0L, 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-210858379200000L) + "'", long21 == (-210858379200000L));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-252460800000L) + "'", long26 == (-252460800000L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test223");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int int15 = offsetDateTimeField9.getMinimumValue(readablePartial14);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField9.getWrappedField();
//        int int18 = offsetDateTimeField9.getMaximumValue((long) 6);
//        boolean boolean20 = offsetDateTimeField9.isLeap(3L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Years]");
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test225");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.secondOfMinute();
//        org.joda.time.DurationField durationField10 = zonedChronology6.centuries();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 0);
        org.joda.time.Period period6 = period2.plusYears(97);
        org.joda.time.Period period8 = period2.withMonths((-59));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        java.lang.String str45 = unsupportedDateTimeField39.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT-35S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT-35S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        java.lang.String str11 = cachedDateTimeZone7.getNameKey((long) (short) -1);
        int int13 = cachedDateTimeZone7.getStandardOffset(0L);
        int int15 = cachedDateTimeZone7.getOffset(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 51 + "'", int15 == 51);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test230");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        int int42 = unsupportedDateTimeField39.getDifference((long) (byte) 1, 0L);
//        int int45 = unsupportedDateTimeField39.getDifference((-57359948L), 36L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-57359984) + "'", int45 == (-57359984));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(30610243440000100L, 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30610243442440688L + "'", long2 == 30610243442440688L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = period3.plusDays(0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period3.getFieldTypes();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.forFields(durationFieldTypeArray7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.forFields(durationFieldTypeArray7);
        java.lang.String str10 = periodType9.getName();
        try {
            org.joda.time.DurationFieldType durationFieldType12 = periodType9.getFieldType(20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Years" + "'", str10.equals("Years"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfMonth();
        org.joda.time.DurationField durationField6 = iSOChronology3.weeks();
        boolean boolean7 = periodType2.equals((java.lang.Object) durationField6);
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 100, 31556995200097L, periodType2, chronology12);
        java.lang.String str14 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(readableInterval9);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Years" + "'", str14.equals("Years"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusWeeks(7);
        org.joda.time.Period period3 = period0.negated();
        org.joda.time.Period period5 = period0.minusWeeks((-97));
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(8L);
        int int11 = cachedDateTimeZone7.getStandardOffset(83L);
        boolean boolean12 = cachedDateTimeZone7.isFixed();
        boolean boolean14 = cachedDateTimeZone7.isStandardOffset(36L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test236");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField39.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "UTC");
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = illegalFieldValueException44.getDateTimeFieldType();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        java.lang.String str12 = unsupportedDurationField10.getName();
        java.lang.String str13 = unsupportedDurationField10.toString();
        java.lang.String str14 = unsupportedDurationField10.getName();
        try {
            long long17 = unsupportedDurationField10.add((-6657486001100001L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnsupportedDurationField[years]" + "'", str13.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(51);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Period period5 = period1.plusSeconds((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period1.toDurationTo(readableInstant6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-61850995199948L), (java.lang.Number) (-35), (java.lang.Number) 240001L);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test240");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField9.getType();
//        long long21 = offsetDateTimeField9.roundHalfFloor((long) 25);
//        int int22 = offsetDateTimeField9.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 946684799996L + "'", long21 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.minusHours(11);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.Period period14 = new org.joda.time.Period((-149), (-100), (-1), 2922770, (-57359984), 2, (-149), (int) '#', periodType13);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test242");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (-1), locale4);
//        int int7 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
//        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) int7);
//        java.security.PermissionCollection permissionCollection9 = jodaTimePermission1.newPermissionCollection();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(permissionCollection9);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period(2440588L, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.weekyear();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology3.set(readablePartial6, (long) 25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.Period period3 = period1.plusWeeks(7);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType14 = periodType13.withHoursRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType14);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        int int17 = periodType14.indexOf(durationFieldType16);
        org.joda.time.PeriodType periodType18 = periodType14.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType22, "ZonedChronology[ISOChronology[UTC], UTC]");
        boolean boolean25 = period10.isSupported(durationFieldType22);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        int int12 = periodType11.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(1L, periodType3, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType19 = periodType3.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add(0L, (long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField7 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField8 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test247");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
//        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
//        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
//        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
//        org.joda.time.Period period12 = period10.plusDays(0);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
//        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
//        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName((long) (-1), locale25);
//        int int28 = dateTimeZone23.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone23);
//        java.lang.String str30 = zonedChronology29.toString();
//        boolean boolean31 = period18.equals((java.lang.Object) str30);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(period5);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordinated Universal Time" + "'", str26.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str30.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = periodType0.getFieldType(6);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(durationFieldType3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.multipliedBy(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusWeeks(7);
        org.joda.time.Period period3 = period0.negated();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant4, readableDuration5, periodType7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType7.indexOf(durationFieldType9);
        org.joda.time.PeriodType periodType11 = periodType7.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType13 = periodType11.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField14 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType15 = unsupportedDurationField14.getType();
        org.joda.time.Period period17 = period0.withField(durationFieldType15, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType15);
        try {
            int int20 = unsupportedDurationField18.getValue(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField14);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test251");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(1560626860360L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField9.getAsShortText(readablePartial14, 52, locale16);
//        long long19 = offsetDateTimeField9.remainder((long) 97);
//        int int21 = offsetDateTimeField9.getLeapAmount((long) (-35));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52" + "'", str17.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 101L + "'", long19 == 101L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test252");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField9.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "ZonedChronology[ISOChronology[UTC], UTC]");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 194, "(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")");
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) '4');
        org.joda.time.Period period5 = period1.plusHours(100);
        org.joda.time.Period period6 = period1.negated();
        org.joda.time.Period period8 = period6.minusWeeks((-1));
        org.joda.time.Duration duration9 = period8.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset((long) 4);
        long long11 = cachedDateTimeZone7.nextTransition(88L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone7.getUncachedZone();
        long long14 = cachedDateTimeZone7.previousTransition((long) 52);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.dayOfMonth();
        org.joda.time.DurationField durationField18 = iSOChronology15.weeks();
        org.joda.time.Chronology chronology19 = iSOChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology15.era();
        org.joda.time.chrono.LenientChronology lenientChronology21 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology22 = lenientChronology21.withUTC();
        boolean boolean23 = cachedDateTimeZone7.equals((java.lang.Object) lenientChronology21);
        long long25 = cachedDateTimeZone7.convertUTCToLocal((-4199944L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 88L + "'", long11 == 88L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(lenientChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-4199893L) + "'", long25 == (-4199893L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = gregorianChronology0.equals(obj3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.withSeconds((int) (short) 0);
        int[] intArray13 = iSOChronology5.get((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (long) 10);
        org.joda.time.Period period15 = period8.minusSeconds((int) '#');
        org.joda.time.Period period17 = period15.plusDays(0);
        org.joda.time.Period period19 = period15.withDays((int) '#');
        int[] intArray22 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period15, (long) 1, (long) ' ');
        org.joda.time.Period period23 = period15.negated();
        org.joda.time.Period period25 = period15.withYears(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType5);
        int int7 = period6.getDays();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 'a');
        int int10 = period9.getMinutes();
        org.joda.time.Period period12 = period9.withMonths(0);
        int int13 = period12.getMillis();
        org.joda.time.Period period15 = period12.withWeeks(2922770);
        org.joda.time.Period period16 = period6.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Duration duration17 = period15.toStandardDuration();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test260");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (-1), locale4);
//        int int7 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
//        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) int7);
//        java.lang.String str9 = jodaTimePermission1.toString();
//        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission11);
//        java.lang.String str13 = jodaTimePermission1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")" + "'", str13.equals("(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")"));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test261");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(1560626860360L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField9.getAsShortText(readablePartial14, 52, locale16);
//        int int19 = offsetDateTimeField9.getMaximumValue((long) (byte) 1);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        java.util.Locale locale21 = null;
//        try {
//            java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial20, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52" + "'", str17.equals("52"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2922790 + "'", int19 == 2922790);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test262");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.roundHalfCeiling((-210866760000000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210484828800004L) + "'", long14 == (-210484828800004L));
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test263");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance(chronology17);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        long long25 = dateTimeZone20.convertLocalToUTC((long) (short) 10, false, (-660001L));
//        java.lang.String str27 = dateTimeZone20.getName((long) 4);
//        org.joda.time.Chronology chronology28 = lenientChronology19.withZone(dateTimeZone20);
//        long long34 = lenientChronology19.getDateTimeMillis((long) 25, 6000, 1000, 1000, (int) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordinated Universal Time" + "'", str27.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 21661000001L + "'", long34 == 21661000001L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        int int5 = periodType3.size();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 0, chronology7);
        org.joda.time.Period period10 = period8.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDayTime();
        int int12 = periodType11.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        boolean boolean17 = gregorianChronology13.equals((java.lang.Object) periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(1L, periodType3, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology13.weekyearOfCentury();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Minutes]", (java.lang.Number) (-57359947L), number2, (java.lang.Number) (short) -1);
        illegalFieldValueException4.prependMessage("UTC");
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: UTC: Value -57359947 for PeriodType[Minutes] must not be larger than -1" + "'", str7.equals("org.joda.time.IllegalFieldValueException: UTC: Value -57359947 for PeriodType[Minutes] must not be larger than -1"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = period3.plusDays(0);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.joda.time.Period period8 = period6.toPeriod();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test267");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.yearOfCentury();
//        org.joda.time.DurationField durationField26 = gregorianChronology13.weekyears();
//        boolean boolean27 = jodaTimePermission3.equals((java.lang.Object) gregorianChronology13);
//        boolean boolean29 = jodaTimePermission3.equals((java.lang.Object) "(\"org.joda.time.JodaTimePermission\" \"YearWeekDayTime\")");
//        java.lang.String str30 = jodaTimePermission3.getActions();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = jodaTimePermission3.equals(obj31);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test268");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) (-1), locale3);
//        int int6 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
//        try {
//            org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT-10S", 4, 7);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, (int) (short) 10);
        long long12 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone10, (long) 52);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4199944L) + "'", long12 == (-4199944L));
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test270");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        long long42 = unsupportedDateTimeField39.add(0L, (long) 100);
//        long long45 = unsupportedDateTimeField39.add((-6052260001L), 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-6052260001L) + "'", long45 == (-6052260001L));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Period period3 = period1.plusWeeks((int) '4');
        org.joda.time.Period period5 = period3.withYears(1);
        org.joda.time.PeriodType periodType6 = period3.getPeriodType();
        int int7 = period3.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test272");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField9.getType();
//        long long22 = offsetDateTimeField9.addWrapField((-1609372799964L), 52);
//        int int24 = offsetDateTimeField9.getLeapAmount((long) '#');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 162486777600036L + "'", long22 == 162486777600036L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test273");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        java.util.Locale locale45 = null;
//        try {
//            java.lang.String str46 = unsupportedDateTimeField39.getAsShortText(readablePartial43, 4, locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNull(durationField42);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test274");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(1560626860360L);
//        long long15 = offsetDateTimeField9.roundHalfEven((long) (byte) 0);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField9.getAsShortText((long) 6, locale17);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField9.getLeapDurationField();
//        long long22 = offsetDateTimeField9.add((long) 1, 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 946684799996L + "'", long15 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20" + "'", str18.equals("20"));
//        org.junit.Assert.assertNull(durationField19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 315569520000001L + "'", long22 == 315569520000001L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        org.joda.time.Period period12 = new org.joda.time.Period();
        org.joda.time.Period period14 = org.joda.time.Period.hours(0);
        org.joda.time.Period period16 = period14.plusWeeks((int) '4');
        org.joda.time.Period period18 = period16.withYears(1);
        org.joda.time.Period period19 = period12.withFields((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period21 = period16.minusMinutes((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType25 = periodType24.withHoursRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant22, readableDuration23, periodType25);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        int int28 = periodType25.indexOf(durationFieldType27);
        org.joda.time.PeriodType periodType29 = periodType25.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType31 = periodType29.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType31);
        int int33 = period21.get(durationFieldType31);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) unsupportedDurationField10, durationFieldType31, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        java.lang.String str2 = periodType1.toString();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType6 = periodType3.withHoursRemoved();
        int int7 = periodType6.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str2.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT51M-0.036S");
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test278");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        java.util.Locale locale41 = null;
//        try {
//            java.lang.String str42 = unsupportedDateTimeField39.getAsText(97, locale41);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableDuration6);
        org.joda.time.Period period9 = period7.minusHours(11);
        org.joda.time.Period period10 = period4.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period12 = org.joda.time.Period.weeks(1);
        org.joda.time.Period period13 = period4.plus((org.joda.time.ReadablePeriod) period12);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test280");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance(chronology17);
//        org.joda.time.Chronology chronology20 = lenientChronology19.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.minutes();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.hourOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.era();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str32 = dateTimeZone30.getShortName((long) (short) -1);
//        long long35 = dateTimeZone30.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology25, dateTimeZone30);
//        org.joda.time.Chronology chronology37 = gregorianChronology21.withZone(dateTimeZone30);
//        org.joda.time.Chronology chronology38 = lenientChronology19.withZone(dateTimeZone30);
//        java.lang.String str39 = lenientChronology19.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.010" + "'", str32.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3L + "'", long35 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str39.equals("LenientChronology[ISOChronology[UTC]]"));
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test281");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        int int16 = offsetDateTimeField9.getOffset();
//        java.lang.String str17 = offsetDateTimeField9.getName();
//        int int18 = offsetDateTimeField9.getOffset();
//        int int21 = offsetDateTimeField9.getDifference((-2208988800004L), 30610243440000100L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "centuryOfEra" + "'", str17.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-9700) + "'", int21 == (-9700));
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        java.lang.Class<?> wildcardClass13 = period10.getClass();
        int int14 = period10.getYears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test283");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField39.getType();
//        long long45 = unsupportedDateTimeField39.add((-57359947L), (int) '#');
//        java.util.Locale locale48 = null;
//        try {
//            long long49 = unsupportedDateTimeField39.set(210866760000001L, "-00:00:00.010", locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-57359912L) + "'", long45 == (-57359912L));
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (int) (short) 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test285");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        long long16 = offsetDateTimeField9.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField9.getType();
//        long long21 = offsetDateTimeField9.addWrapField(106754431755L, 51);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200097L + "'", long16 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 161047231231755L + "'", long21 == 161047231231755L);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test286");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology9, dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.yearOfEra();
//        boolean boolean21 = zonedChronology6.equals((java.lang.Object) dateTimeField20);
//        org.joda.time.DateTimeField dateTimeField22 = zonedChronology6.weekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test287");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = dateTimeZone45.getName((long) (byte) 0, locale47);
//        org.joda.time.chrono.ZonedChronology zonedChronology49 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology43, dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology43.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) (byte) 1);
//        int int54 = offsetDateTimeField52.get((long) (-10));
//        int int56 = offsetDateTimeField52.get(0L);
//        long long59 = offsetDateTimeField52.add(52L, 194);
//        org.joda.time.ReadablePartial readablePartial60 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField62 = iSOChronology61.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField63 = iSOChronology61.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology61.era();
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str68 = dateTimeZone66.getShortName((long) (short) -1);
//        long long71 = dateTimeZone66.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology61, dateTimeZone66);
//        org.joda.time.DurationField durationField73 = iSOChronology61.months();
//        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int75 = gregorianChronology74.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology77 = null;
//        org.joda.time.Period period78 = new org.joda.time.Period((long) (short) 0, chronology77);
//        org.joda.time.Period period80 = period78.withSeconds((int) (short) 0);
//        org.joda.time.Period period82 = period80.minusMillis((int) ' ');
//        int[] intArray85 = gregorianChronology74.get((org.joda.time.ReadablePeriod) period80, (long) 100, (long) 7);
//        org.joda.time.Period period86 = period80.normalizedStandard();
//        org.joda.time.ReadablePeriod readablePeriod87 = null;
//        org.joda.time.Period period88 = period86.plus(readablePeriod87);
//        org.joda.time.Period period90 = period86.plusDays((int) (byte) 10);
//        int[] intArray93 = iSOChronology61.get((org.joda.time.ReadablePeriod) period86, (long) 10, (-66574860011L));
//        int int94 = offsetDateTimeField52.getMaximumValue(readablePartial60, intArray93);
//        try {
//            int int95 = unsupportedDateTimeField39.getMinimumValue(readablePartial42, intArray93);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Coordinated Universal Time" + "'", str48.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 20 + "'", int54 == 20);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 20 + "'", int56 == 20);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 612204912000052L + "'", long59 == 612204912000052L);
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "-00:00:00.010" + "'", str68.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 3L + "'", long71 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(gregorianChronology74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
//        org.junit.Assert.assertNotNull(period80);
//        org.junit.Assert.assertNotNull(period82);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(period86);
//        org.junit.Assert.assertNotNull(period88);
//        org.junit.Assert.assertNotNull(period90);
//        org.junit.Assert.assertNotNull(intArray93);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2922790 + "'", int94 == 2922790);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyear();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.millisOfDay();
        try {
            long long21 = iSOChronology12.getDateTimeMillis(36, 0, 2922790, 194);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test289");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (-1), locale4);
//        java.lang.String str6 = dateTimeZone2.getID();
//        int int8 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "-00:00:00.010", 10, 0);
//        org.joda.time.Chronology chronology15 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = cachedDateTimeZone7.getOffset((long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        boolean boolean12 = cachedDateTimeZone7.equals((java.lang.Object) gregorianChronology10);
        boolean boolean13 = cachedDateTimeZone7.isFixed();
        long long15 = cachedDateTimeZone7.nextTransition((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 51 + "'", int9 == 51);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test292");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField9.getType();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText((int) (byte) 10, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.era();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str32 = dateTimeZone30.getShortName((long) (short) -1);
//        long long35 = dateTimeZone30.adjustOffset(3L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology25, dateTimeZone30);
//        org.joda.time.DurationField durationField37 = iSOChronology25.months();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int39 = gregorianChronology38.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.Period period42 = new org.joda.time.Period((long) (short) 0, chronology41);
//        org.joda.time.Period period44 = period42.withSeconds((int) (short) 0);
//        org.joda.time.Period period46 = period44.minusMillis((int) ' ');
//        int[] intArray49 = gregorianChronology38.get((org.joda.time.ReadablePeriod) period44, (long) 100, (long) 7);
//        org.joda.time.Period period50 = period44.normalizedStandard();
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.Period period52 = period50.plus(readablePeriod51);
//        org.joda.time.Period period54 = period50.plusDays((int) (byte) 10);
//        int[] intArray57 = iSOChronology25.get((org.joda.time.ReadablePeriod) period50, (long) 10, (-66574860011L));
//        int[] intArray59 = offsetDateTimeField9.addWrapPartial(readablePartial23, (int) (short) 100, intArray57, 0);
//        int int60 = offsetDateTimeField9.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10" + "'", str22.equals("10"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.010" + "'", str32.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3L + "'", long35 == 3L);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(intArray49);
//        org.junit.Assert.assertNotNull(period50);
//        org.junit.Assert.assertNotNull(period52);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2922790 + "'", int60 == 2922790);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test293");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int int15 = offsetDateTimeField9.getMinimumValue(readablePartial14);
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField9.getWrappedField();
//        boolean boolean17 = offsetDateTimeField9.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        long long12 = unsupportedDurationField10.getUnitMillis();
        java.lang.String str13 = unsupportedDurationField10.getName();
        try {
            long long16 = unsupportedDurationField10.add(52L, 3155760000097L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test295");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField39.getType();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getLeapDurationField();
//        long long45 = unsupportedDateTimeField39.add((long) 9700, 1000);
//        java.lang.String str46 = unsupportedDateTimeField39.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10700L + "'", long45 == 10700L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "centuryOfEra" + "'", str46.equals("centuryOfEra"));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType2.indexOf(durationFieldType4);
        java.lang.String str6 = periodType2.getName();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType7);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.Period period11 = period8.minusYears((int) '4');
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "YearWeekDayTime" + "'", str6.equals("YearWeekDayTime"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        long long8 = fixedDateTimeZone4.previousTransition((-3060893222000L));
        java.lang.String str9 = fixedDateTimeZone4.toString();
        java.lang.String str10 = fixedDateTimeZone4.getID();
        long long12 = fixedDateTimeZone4.nextTransition((long) 7);
        int int14 = fixedDateTimeZone4.getStandardOffset((-3060893222000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3060893222000L) + "'", long8 == (-3060893222000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0S" + "'", str9.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0S" + "'", str10.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDayTime();
        int int6 = periodType5.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period4, periodType5, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.dayOfYear();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(durationFieldType11, "ZonedChronology[ISOChronology[UTC], UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType11, "");
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("(\"org.joda.time.JodaTimePermission\" \"PeriodType[YearWeekDayTimeNoHours]\")", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.PeriodType periodType19 = period17.getPeriodType();
        org.joda.time.Duration duration20 = period17.toStandardDuration();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(duration20);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test302");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str7 = dateTimeZone5.getShortName((long) (short) -1);
//        long long10 = dateTimeZone5.adjustOffset(3L, false);
//        long long13 = dateTimeZone5.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology14 = gregorianChronology1.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology1.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) (byte) 0, locale20);
//        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology16, dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology16.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) 1);
//        int int27 = offsetDateTimeField25.get((long) (-10));
//        int int29 = offsetDateTimeField25.get(0L);
//        long long32 = offsetDateTimeField25.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField33 = offsetDateTimeField25.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField25.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType34, 36, 51, 0);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.010" + "'", str7.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 20 + "'", int27 == 20);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31556995200097L + "'", long32 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Minutes]", (java.lang.Number) (-57359947L), number2, (java.lang.Number) (short) -1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test305");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        int int16 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int int18 = offsetDateTimeField9.getMaximumValue(readablePartial17);
//        long long20 = offsetDateTimeField9.roundFloor((long) (-1));
//        long long22 = offsetDateTimeField9.roundHalfEven(83L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208988800004L) + "'", long20 == (-2208988800004L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 946684799996L + "'", long22 == 946684799996L);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test306");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = dateTimeZone48.getName((long) (byte) 0, locale50);
//        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology46, dateTimeZone48);
//        org.joda.time.Chronology chronology53 = zonedChronology52.withUTC();
//        org.joda.time.DurationField durationField54 = zonedChronology52.hours();
//        long long60 = zonedChronology52.getDateTimeMillis(9223372036854775756L, 7, (int) '#', 1, 0);
//        org.joda.time.ReadableDuration readableDuration61 = null;
//        org.joda.time.ReadableInstant readableInstant62 = null;
//        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.years();
//        org.joda.time.Period period64 = new org.joda.time.Period(readableDuration61, readableInstant62, periodType63);
//        org.joda.time.Period period66 = period64.minusYears(100);
//        org.joda.time.Period period68 = period66.withYears((int) (short) 100);
//        org.joda.time.Period period69 = period66.negated();
//        int[] intArray71 = zonedChronology52.get((org.joda.time.ReadablePeriod) period66, (-210484828800004L));
//        try {
//            int int72 = unsupportedDateTimeField39.getMaximumValue(readablePartial45, intArray71);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Coordinated Universal Time" + "'", str51.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-9223372036853399000L) + "'", long60 == (-9223372036853399000L));
//        org.junit.Assert.assertNotNull(periodType63);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(period68);
//        org.junit.Assert.assertNotNull(period69);
//        org.junit.Assert.assertNotNull(intArray71);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test307");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        int int15 = offsetDateTimeField9.getMinimumValue(readablePartial14);
//        org.joda.time.DurationField durationField16 = offsetDateTimeField9.getLeapDurationField();
//        try {
//            long long19 = offsetDateTimeField9.add((-4199944L), 15778540800036L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1577854080003600");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNull(durationField16);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        int int7 = periodType5.size();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, chronology9);
        org.joda.time.Period period12 = period10.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDayTime();
        int int14 = periodType13.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period12, periodType13, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.time();
        boolean boolean19 = gregorianChronology15.equals((java.lang.Object) periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period(1L, periodType5, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology15.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.weekyear();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 0, chronology25);
        org.joda.time.Period period28 = period26.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.yearWeekDayTime();
        int int30 = periodType29.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int32 = gregorianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.Period period33 = new org.joda.time.Period((java.lang.Object) period28, periodType29, (org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) (short) 0, chronology35);
        org.joda.time.Period period38 = period36.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearWeekDayTime();
        int int40 = periodType39.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int42 = gregorianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) period38, periodType39, (org.joda.time.Chronology) gregorianChronology41);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.time();
        boolean boolean45 = gregorianChronology41.equals((java.lang.Object) periodType44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) (byte) 1, periodType29, (org.joda.time.Chronology) gregorianChronology41);
        boolean boolean47 = gregorianChronology15.equals((java.lang.Object) gregorianChronology41);
        org.joda.time.Period period48 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology41);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 5);
        org.joda.time.Chronology chronology52 = gregorianChronology41.withZone(dateTimeZone51);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 7 + "'", int40 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(chronology52);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test309");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (-1), locale4);
//        int int7 = dateTimeZone2.getOffsetFromLocal((long) (short) 10);
//        boolean boolean8 = jodaTimePermission1.equals((java.lang.Object) int7);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        long long17 = fixedDateTimeZone13.convertLocalToUTC((long) 20, true, (-6052260001L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology18.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        long long23 = fixedDateTimeZone13.getMillisKeepLocal(dateTimeZone20, 36L);
//        java.util.TimeZone timeZone24 = fixedDateTimeZone13.toTimeZone();
//        boolean boolean25 = jodaTimePermission1.equals((java.lang.Object) timeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31L) + "'", long17 == (-31L));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 87L + "'", long23 == 87L);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = org.joda.time.Period.hours(0);
        org.joda.time.Period period4 = period2.plusWeeks((int) '4');
        org.joda.time.Period period6 = period4.withYears(1);
        org.joda.time.Period period7 = period0.withFields((org.joda.time.ReadablePeriod) period4);
        org.joda.time.Period period9 = period4.minusMinutes((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType13.indexOf(durationFieldType15);
        org.joda.time.PeriodType periodType17 = periodType13.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        int int21 = period9.get(durationFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType19, "P52W");
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test311");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
//        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.era();
//        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) (byte) 0, locale11);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone9);
//        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
//        org.joda.time.DurationField durationField15 = zonedChronology13.hours();
//        org.joda.time.DateTimeField dateTimeField16 = zonedChronology13.year();
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology13);
//        boolean boolean19 = zonedChronology13.equals((java.lang.Object) '4');
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology13);
//        boolean boolean21 = lenientChronology6.equals((java.lang.Object) chronology20);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(lenientChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test312");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) 1000, (-9700));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-8700L) + "'", long44 == (-8700L));
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test313");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial19, (-10), locale21);
//        long long24 = offsetDateTimeField9.roundCeiling((long) 8);
//        int int25 = offsetDateTimeField9.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-10" + "'", str22.equals("-10"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 946684799996L + "'", long24 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test315");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        try {
//            long long43 = unsupportedDateTimeField39.roundFloor((long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 100);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.joda.time.Period period4 = period1.plusWeeks(8);
        org.joda.time.Period period6 = period1.minusYears(8);
        org.joda.time.Period period8 = org.joda.time.Period.hours(0);
        org.joda.time.Period period10 = period8.plusWeeks((int) '4');
        org.joda.time.Period period12 = period8.withMonths(4);
        org.joda.time.Period period14 = period8.minusMonths((-59));
        org.joda.time.Period period15 = period6.minus((org.joda.time.ReadablePeriod) period14);
        org.junit.Assert.assertNotNull(seconds2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test317");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.remainder(54621940112688L);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType33, 51);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) (byte) 0, locale40);
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology36, dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField43 = zonedChronology42.millisOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, (int) 'a', 6000, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType62, (int) '#');
//        long long71 = dividedDateTimeField68.add(105084691199949L, (long) 10);
//        int int72 = dividedDateTimeField68.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2180616687308L) + "'", long14 == (-2180616687308L));
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1209577967999949L + "'", long71 == 1209577967999949L);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(6, (int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(51);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, chronology6);
        org.joda.time.Period period9 = period7.withSeconds((int) (short) 0);
        int[] intArray12 = iSOChronology4.get((org.joda.time.ReadablePeriod) period7, (long) (short) 1, (long) 10);
        org.joda.time.Period period14 = period7.minusSeconds((int) '#');
        boolean boolean15 = period1.equals((java.lang.Object) period14);
        org.joda.time.Period period17 = period14.withMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("194");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"194/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusHours(11);
        org.joda.time.Period period5 = period4.negated();
        int int6 = period4.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test322");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) (byte) 0, locale5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone3);
//        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
//        org.joda.time.DurationField durationField9 = zonedChronology7.hours();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.year();
//        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology7.getZone();
//        org.joda.time.Period period12 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.Period period14 = period12.multipliedBy(0);
//        org.joda.time.Period period16 = period14.minusWeeks(2922790);
//        org.joda.time.Period period18 = new org.joda.time.Period(0L);
//        org.joda.time.Period period19 = period16.withFields((org.joda.time.ReadablePeriod) period18);
//        org.joda.time.Period period21 = period19.plusMillis((int) '#');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("centuryOfEra", (-35), 5, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for centuryOfEra must be in the range [5,-10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        boolean boolean41 = unsupportedDateTimeField39.isSupported();
//        long long44 = unsupportedDateTimeField39.add((long) (short) 0, (-149));
//        long long47 = unsupportedDateTimeField39.getDifferenceAsLong((long) (byte) 1, (-210866760000000L));
//        boolean boolean48 = unsupportedDateTimeField39.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-149L) + "'", long44 == (-149L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 210866760000001L + "'", long47 == 210866760000001L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10.0d, number2, (java.lang.Number) (-210858379199900L));
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-210858379199900L) + "'", number6.equals((-210858379199900L)));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = periodType8.isSupported(durationFieldType9);
        try {
            org.joda.time.Period period11 = new org.joda.time.Period(99, (int) (byte) 100, 0, (-149), 0, 2922790, 0, (-10), periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-9223370312976000051L), "194");
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test328");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.yearOfCentury();
//        org.joda.time.DurationField durationField26 = gregorianChronology13.weekyears();
//        boolean boolean27 = jodaTimePermission3.equals((java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology13.dayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str35 = dateTimeZone33.getShortName((long) (short) -1);
//        long long38 = dateTimeZone33.adjustOffset(3L, false);
//        long long41 = dateTimeZone33.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology42 = gregorianChronology29.withZone(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology29.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, 36, 51, 0);
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField67);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType62, 11, 0, (int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology73.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.hourOfHalfday();
//        org.joda.time.Chronology chronology76 = gregorianChronology73.withUTC();
//        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology73.clockhourOfHalfday();
//        org.joda.time.DurationField durationField78 = gregorianChronology73.days();
//        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int80 = gregorianChronology79.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField81 = gregorianChronology79.halfdays();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField82 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType62, durationField78, durationField81);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-00:00:00.010" + "'", str35.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3L + "'", long38 == 3L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertNotNull(gregorianChronology73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(chronology76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(gregorianChronology79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
//        org.junit.Assert.assertNotNull(durationField81);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.Period period3 = period1.plusWeeks(7);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        java.lang.String str14 = periodType13.toString();
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType13);
        org.joda.time.PeriodType periodType16 = periodType13.withMillisRemoved();
        org.joda.time.PeriodType periodType17 = periodType13.withMinutesRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType13);
        org.joda.time.DurationFieldType[] durationFieldTypeArray19 = period18.getFieldTypes();
        int[] intArray20 = period18.getValues();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str14.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldTypeArray19);
        org.junit.Assert.assertNotNull(intArray20);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test330");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (byte) 0, locale17);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, dateTimeZone15);
//        long long21 = dateTimeZone15.convertUTCToLocal(32L);
//        boolean boolean22 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 32L + "'", long21 == 32L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
        boolean boolean19 = fixedDateTimeZone18.isFixed();
        long long21 = fixedDateTimeZone18.previousTransition((-210858379200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long24 = fixedDateTimeZone18.previousTransition((long) (short) 100);
        java.lang.String str26 = fixedDateTimeZone18.getShortName(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-210858379200000L) + "'", long21 == (-210858379200000L));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.051" + "'", str26.equals("+00:00:00.051"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        java.lang.String str12 = unsupportedDurationField10.getName();
        java.lang.String str13 = unsupportedDurationField10.toString();
        try {
            long long15 = unsupportedDurationField10.getMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnsupportedDurationField[years]" + "'", str13.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = null;
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File[] fileArray5 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = zoneInfoCompiler0.compile(file4, fileArray5);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray5);
        org.junit.Assert.assertNotNull(strMap6);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test334");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        long long16 = offsetDateTimeField9.add(54621940112688L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
//        int int20 = offsetDateTimeField9.getDifference((long) (-1), 10L);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        int int22 = offsetDateTimeField9.getMaximumValue(readablePartial21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 370191460112688L + "'", long16 == 370191460112688L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2922790 + "'", int22 == 2922790);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusMillis((int) ' ');
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period6, (long) 100, (long) 7);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, periodType1);
        int int3 = period2.getDays();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        org.joda.time.Period period3 = period1.plusWeeks(7);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        java.lang.String str14 = periodType13.toString();
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType13);
        org.joda.time.PeriodType periodType16 = periodType13.withMillisRemoved();
        org.joda.time.PeriodType periodType17 = periodType13.withMinutesRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType13);
        org.joda.time.Period period19 = period18.negated();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 0, chronology23);
        org.joda.time.Period period26 = period24.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearWeekDayTime();
        int int28 = periodType27.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.Period period31 = new org.joda.time.Period((java.lang.Object) period26, periodType27, (org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) 0, chronology33);
        org.joda.time.Period period36 = period34.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.yearWeekDayTime();
        int int38 = periodType37.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int40 = gregorianChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) period36, periodType37, (org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.time();
        boolean boolean43 = gregorianChronology39.equals((java.lang.Object) periodType42);
        org.joda.time.Period period44 = new org.joda.time.Period((long) (byte) 1, periodType27, (org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.secondOfDay();
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology45);
        org.joda.time.Period period50 = new org.joda.time.Period(0L, periodType27, (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.PeriodType periodType51 = periodType27.withSecondsRemoved();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) 0, chronology53);
        org.joda.time.Period period56 = period54.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType57 = org.joda.time.PeriodType.yearWeekDayTime();
        int int58 = periodType57.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int60 = gregorianChronology59.getMinimumDaysInFirstWeek();
        org.joda.time.Period period61 = new org.joda.time.Period((java.lang.Object) period56, periodType57, (org.joda.time.Chronology) gregorianChronology59);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology59.year();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.PeriodType periodType65 = org.joda.time.PeriodType.years();
        org.joda.time.Period period66 = new org.joda.time.Period(readableDuration63, readableInstant64, periodType65);
        org.joda.time.Period period68 = period66.minusYears(100);
        org.joda.time.Period period70 = period68.withYears((int) (short) 100);
        int[] intArray72 = gregorianChronology59.get((org.joda.time.ReadablePeriod) period68, (long) (-1));
        long long76 = gregorianChronology59.add((long) (-1), (-66574860011000L), 100);
        org.joda.time.Period period77 = new org.joda.time.Period((java.lang.Object) period18, periodType27, (org.joda.time.Chronology) gregorianChronology59);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str14.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 7 + "'", int58 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-6657486001100001L) + "'", long76 == (-6657486001100001L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 0);
        org.joda.time.Period period10 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
        org.joda.time.Period period12 = period10.plusWeeks((int) '4');
        org.joda.time.Period period14 = period12.withWeeks((int) (short) 1);
        org.joda.time.Period period16 = period12.plusDays((int) ' ');
        int int17 = period12.getDays();
        org.joda.time.Period period18 = new org.joda.time.Period();
        org.joda.time.Period period20 = org.joda.time.Period.hours(0);
        org.joda.time.Period period22 = period20.plusWeeks((int) '4');
        org.joda.time.Period period24 = period22.withYears(1);
        org.joda.time.Period period25 = period18.withFields((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period27 = period22.minusMinutes((int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType31 = periodType30.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant28, readableDuration29, periodType31);
        org.joda.time.DurationFieldType durationFieldType33 = null;
        int int34 = periodType31.indexOf(durationFieldType33);
        org.joda.time.PeriodType periodType35 = periodType31.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType37 = periodType35.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        int int39 = period27.get(durationFieldType37);
        int int40 = period12.indexOf(durationFieldType37);
        org.joda.time.Period period42 = period1.withFieldAdded(durationFieldType37, 4);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test339");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        int int6 = periodType3.indexOf(durationFieldType5);
//        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
//        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
//        long long12 = unsupportedDurationField10.getUnitMillis();
//        java.lang.String str13 = unsupportedDurationField10.getName();
//        boolean boolean14 = unsupportedDurationField10.isSupported();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) (-1), locale21);
//        int int24 = dateTimeZone19.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology25.getZone();
//        org.joda.time.DurationField durationField28 = zonedChronology25.minutes();
//        int int29 = unsupportedDurationField10.compareTo(durationField28);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(durationFieldType9);
//        org.junit.Assert.assertNotNull(unsupportedDurationField10);
//        org.junit.Assert.assertNotNull(durationFieldType11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordinated Universal Time" + "'", str22.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test340");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.yearOfCentury();
//        org.joda.time.DurationField durationField26 = gregorianChronology13.weekyears();
//        boolean boolean27 = jodaTimePermission3.equals((java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology13.dayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str35 = dateTimeZone33.getShortName((long) (short) -1);
//        long long38 = dateTimeZone33.adjustOffset(3L, false);
//        long long41 = dateTimeZone33.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology42 = gregorianChronology29.withZone(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology29.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, 36, 51, 0);
//        org.joda.time.DurationField durationField67 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField67);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType62, 11, 0, (int) '4');
//        java.util.Locale locale74 = null;
//        java.lang.String str75 = offsetDateTimeField72.getAsText((-6657486001100001L), locale74);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-00:00:00.010" + "'", str35.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 3L + "'", long38 == 3L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "14" + "'", str75.equals("14"));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, chronology2);
        org.joda.time.Period period5 = period3.withSeconds((int) (short) 0);
        int[] intArray8 = iSOChronology0.get((org.joda.time.ReadablePeriod) period3, (long) (short) 1, (long) 10);
        org.joda.time.Period period10 = period3.minusSeconds((int) '#');
        org.joda.time.Period period12 = period10.plusDays(0);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        org.joda.time.Period period18 = period12.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period20 = period18.withDays((-10));
        org.joda.time.Period period21 = period20.toPeriod();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test342");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        int int6 = periodType3.indexOf(durationFieldType5);
//        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
//        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        boolean boolean19 = jodaTimePermission12.equals((java.lang.Object) int18);
//        java.lang.String str20 = jodaTimePermission12.getActions();
//        java.security.PermissionCollection permissionCollection21 = jodaTimePermission12.newPermissionCollection();
//        boolean boolean22 = unsupportedDurationField10.equals((java.lang.Object) jodaTimePermission12);
//        boolean boolean23 = unsupportedDurationField10.isPrecise();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(durationFieldType9);
//        org.junit.Assert.assertNotNull(unsupportedDurationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//        org.junit.Assert.assertNotNull(permissionCollection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test343");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        long long15 = offsetDateTimeField9.set((long) 51, (int) (byte) 100);
//        long long17 = offsetDateTimeField9.roundCeiling((long) 1);
//        int int18 = offsetDateTimeField9.getOffset();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField9.getType();
//        long long21 = offsetDateTimeField9.roundHalfFloor((long) 25);
//        long long23 = offsetDateTimeField9.roundCeiling((long) 51);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 252455616000051L + "'", long15 == 252455616000051L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 946684799996L + "'", long17 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 946684799996L + "'", long21 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 946684799996L + "'", long23 == 946684799996L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusHours(11);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Period period6 = period2.plus(readablePeriod5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.minusSeconds(10);
        org.joda.time.Period period6 = period2.minusMonths((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Period period8 = period6.plus(readablePeriod7);
        org.joda.time.Period period9 = period6.normalizedStandard();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test347");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.remainder(54621940112688L);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType33, 51);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) (byte) 0, locale40);
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology36, dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField43 = zonedChronology42.millisOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, (int) 'a', 6000, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType62, (int) '#');
//        long long71 = dividedDateTimeField68.add(105084691199949L, (long) 10);
//        try {
//            long long73 = dividedDateTimeField68.roundFloor(20L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,2922790]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2180616687308L) + "'", long14 == (-2180616687308L));
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1209577967999949L + "'", long71 == 1209577967999949L);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        try {
            int int14 = unsupportedDurationField10.getValue(34712668800083L, 34712668800083L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test349");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.year();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone12.getName((long) (byte) 0, locale14);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology10, dateTimeZone12);
//        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
//        boolean boolean18 = zonedChronology6.equals((java.lang.Object) chronology17);
//        org.joda.time.chrono.LenientChronology lenientChronology19 = org.joda.time.chrono.LenientChronology.getInstance(chronology17);
//        org.joda.time.Chronology chronology20 = lenientChronology19.withUTC();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = lenientChronology19.equals(obj21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(lenientChronology19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 0);
        org.joda.time.Period period6 = period4.plusWeeks((int) (byte) -1);
        org.joda.time.Period period8 = period4.minusMinutes(0);
        org.joda.time.Period period10 = period4.minusSeconds((int) '4');
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10.0d, number2, (java.lang.Number) (-210858379199900L));
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.joda.time.Period period2 = new org.joda.time.Period(8L, (long) 6000);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test353");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.010");
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        boolean boolean10 = jodaTimePermission3.equals((java.lang.Object) int9);
//        java.lang.String str11 = jodaTimePermission3.getActions();
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
//        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
//        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
//        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.yearOfCentury();
//        org.joda.time.DurationField durationField26 = gregorianChronology13.weekyears();
//        boolean boolean27 = jodaTimePermission3.equals((java.lang.Object) gregorianChronology13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int29 = gregorianChronology28.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.Period period32 = new org.joda.time.Period((long) (short) 0, chronology31);
//        org.joda.time.Period period34 = period32.withSeconds((int) (short) 0);
//        org.joda.time.Period period36 = period34.minusMillis((int) ' ');
//        int[] intArray39 = gregorianChronology28.get((org.joda.time.ReadablePeriod) period34, (long) 100, (long) 7);
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology28.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology28.millisOfSecond();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone46 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        boolean boolean47 = fixedDateTimeZone46.isFixed();
//        long long49 = fixedDateTimeZone46.previousTransition((-210858379200000L));
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology28, (org.joda.time.DateTimeZone) fixedDateTimeZone46);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = fixedDateTimeZone46.getName((long) (byte) 100, locale52);
//        java.util.TimeZone timeZone54 = fixedDateTimeZone46.toTimeZone();
//        org.joda.time.Chronology chronology55 = gregorianChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-210858379200000L) + "'", long49 == (-210858379200000L));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00:00.051" + "'", str53.equals("+00:00:00.051"));
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(chronology55);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test354");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException((long) (short) 1, "YearWeekDayTime");
//        boolean boolean11 = iSOChronology0.equals((java.lang.Object) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test355");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long11 = offsetDateTimeField9.roundHalfCeiling(3L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField9.getType();
//        long long14 = offsetDateTimeField9.remainder(54621940112688L);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType33, 51);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName((long) (byte) 0, locale40);
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology36, dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField43 = zonedChronology42.millisOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (byte) 0, locale48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology44, dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology44.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 1);
//        int int55 = offsetDateTimeField53.get((long) (-10));
//        int int57 = offsetDateTimeField53.get(0L);
//        long long60 = offsetDateTimeField53.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = offsetDateTimeField53.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType62, (int) 'a', 6000, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType62, (int) '#');
//        long long71 = dividedDateTimeField68.add(105084691199949L, (long) 10);
//        long long74 = dividedDateTimeField68.set(0L, 0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 946684799996L + "'", long11 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2180616687308L) + "'", long14 == (-2180616687308L));
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 20 + "'", int55 == 20);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31556995200097L + "'", long60 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1209577967999949L + "'", long71 == 1209577967999949L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        java.lang.String str12 = unsupportedDurationField10.getName();
        java.lang.String str13 = unsupportedDurationField10.toString();
        try {
            long long16 = unsupportedDurationField10.getDifferenceAsLong((-2208988800004L), 92172140714106995L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnsupportedDurationField[years]" + "'", str13.equals("UnsupportedDurationField[years]"));
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test357");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology6.weekyear();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology6.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology6.minuteOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        java.lang.String str4 = periodType3.toString();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType7 = periodType3.withMinutesRemoved();
        java.lang.String str8 = periodType7.toString();
        org.joda.time.Period period17 = new org.joda.time.Period(0, (-10), 1000, 10, (int) ' ', 1000, (int) '#', (int) (byte) 1);
        int int18 = period17.getYears();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType22 = periodType21.withHoursRemoved();
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant19, readableDuration20, periodType22);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        int int25 = periodType22.indexOf(durationFieldType24);
        org.joda.time.PeriodType periodType26 = periodType22.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType28 = periodType26.getFieldType((int) (byte) 0);
        java.lang.Number number31 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType28, (java.lang.Number) 9223372036854775756L, (java.lang.Number) (-377420515199948L), number31);
        org.joda.time.Period period34 = period17.withField(durationFieldType28, (int) (short) 10);
        boolean boolean35 = periodType7.isSupported(durationFieldType28);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoHours]"));
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[YearWeekDayTimeNoHoursNoMinutes]" + "'", str8.equals("PeriodType[YearWeekDayTimeNoHoursNoMinutes]"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test359");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        int int13 = offsetDateTimeField9.get(0L);
//        long long16 = offsetDateTimeField9.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getRangeDurationField();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField9.getAsText(readablePartial19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31556995200097L + "'", long16 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNull(durationField18);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
        java.lang.String str3 = dateTimeZone1.getShortName((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.010" + "'", str3.equals("-00:00:00.010"));
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test361");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfWeek();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        boolean boolean41 = unsupportedDateTimeField39.isLenient();
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField39.getRangeDurationField();
//        long long45 = unsupportedDateTimeField39.add((-210858379199900L), 8);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-210858379199892L) + "'", long45 == (-210858379199892L));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone1.getShortName((-194L), locale4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test364");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (-4199944L), "P-10M1052W42DT32H1000M35.001S");
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        int int5 = periodType3.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test366");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        org.joda.time.DurationField durationField41 = unsupportedDateTimeField39.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField39.getType();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField39.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNull(durationField43);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test367");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology6.getZone();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType11 = periodType10.withHoursRemoved();
//        java.lang.String str12 = periodType11.toString();
//        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration8, readableInstant9, periodType11);
//        int int14 = period13.getDays();
//        int[] intArray17 = zonedChronology6.get((org.joda.time.ReadablePeriod) period13, 473473978L, (-2180616687261L));
//        org.joda.time.DurationField durationField18 = zonedChronology6.centuries();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[YearWeekDayTimeNoHours]" + "'", str12.equals("PeriodType[YearWeekDayTimeNoHours]"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType3.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
        try {
            long long12 = unsupportedDurationField10.getMillis((long) (-9700));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("100");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"100/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test370");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology7 = zonedChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = zonedChronology6.hours();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology9, dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.yearOfEra();
//        boolean boolean21 = zonedChronology6.equals((java.lang.Object) dateTimeField20);
//        org.joda.time.DurationField durationField22 = zonedChronology6.halfdays();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 100);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.joda.time.Period period4 = period1.plusWeeks(8);
        org.joda.time.Period period6 = period1.minusYears(8);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.junit.Assert.assertNotNull(seconds2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
        java.lang.String str7 = dateTimeZone5.getShortName((long) (short) -1);
        long long10 = dateTimeZone5.adjustOffset(3L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone5);
        org.joda.time.DurationField durationField12 = iSOChronology0.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) 0, chronology16);
        org.joda.time.Period period19 = period17.withSeconds((int) (short) 0);
        org.joda.time.Period period21 = period19.minusMillis((int) ' ');
        int[] intArray24 = gregorianChronology13.get((org.joda.time.ReadablePeriod) period19, (long) 100, (long) 7);
        org.joda.time.Period period25 = period19.normalizedStandard();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.Period period27 = period25.plus(readablePeriod26);
        org.joda.time.Period period29 = period25.plusDays((int) (byte) 10);
        int[] intArray32 = iSOChronology0.get((org.joda.time.ReadablePeriod) period25, (long) 10, (-66574860011L));
        org.joda.time.Period period34 = period25.minusMillis(52);
        org.joda.time.PeriodType periodType35 = period34.getPeriodType();
        org.joda.time.Period period37 = period34.minusHours(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.010" + "'", str7.equals("-00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period37);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test373");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        int int11 = offsetDateTimeField9.get((long) (-10));
//        long long13 = offsetDateTimeField9.roundCeiling(32L);
//        long long15 = offsetDateTimeField9.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = offsetDateTimeField9.getAsShortText(readablePartial17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 946684799996L + "'", long13 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 946684799996L + "'", long15 == 946684799996L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test375");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) (-1), locale6);
//        int int9 = dateTimeZone4.getOffsetFromLocal((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfYear();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
//        org.joda.time.Period period16 = period14.withSeconds((int) (short) 0);
//        org.joda.time.Period period18 = period16.plusWeeks((int) (byte) -1);
//        org.joda.time.Period period20 = period16.minusMinutes(0);
//        org.joda.time.Period period22 = period20.minusYears(97);
//        org.joda.time.Period period24 = new org.joda.time.Period((long) 'a');
//        int int25 = period24.getMinutes();
//        org.joda.time.Period period27 = period24.withMonths(0);
//        org.joda.time.Period period29 = period24.plusHours((int) (short) 0);
//        org.joda.time.Period period30 = period22.minus((org.joda.time.ReadablePeriod) period24);
//        int[] intArray32 = zonedChronology10.get((org.joda.time.ReadablePeriod) period30, (long) 194);
//        java.lang.String str33 = zonedChronology10.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(period20);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str33.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test376");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        int int6 = periodType3.indexOf(durationFieldType5);
//        org.joda.time.PeriodType periodType7 = periodType3.withMonthsRemoved();
//        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
//        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType9);
//        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("YearWeekDayTime");
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) (-1), locale15);
//        int int18 = dateTimeZone13.getOffsetFromLocal((long) (short) 10);
//        boolean boolean19 = jodaTimePermission12.equals((java.lang.Object) int18);
//        java.lang.String str20 = jodaTimePermission12.getActions();
//        java.security.PermissionCollection permissionCollection21 = jodaTimePermission12.newPermissionCollection();
//        boolean boolean22 = unsupportedDurationField10.equals((java.lang.Object) jodaTimePermission12);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "Coordinated Universal Time", 51, 100);
//        boolean boolean28 = fixedDateTimeZone27.isFixed();
//        java.util.TimeZone timeZone29 = fixedDateTimeZone27.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
//        int int32 = cachedDateTimeZone30.getOffset((long) 4);
//        long long34 = cachedDateTimeZone30.nextTransition(88L);
//        org.joda.time.DateTimeZone dateTimeZone35 = cachedDateTimeZone30.getUncachedZone();
//        boolean boolean36 = unsupportedDurationField10.equals((java.lang.Object) dateTimeZone35);
//        java.lang.String str37 = unsupportedDurationField10.toString();
//        java.lang.String str38 = unsupportedDurationField10.getName();
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(periodType7);
//        org.junit.Assert.assertNotNull(durationFieldType9);
//        org.junit.Assert.assertNotNull(unsupportedDurationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//        org.junit.Assert.assertNotNull(permissionCollection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 51 + "'", int32 == 51);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 88L + "'", long34 == 88L);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDurationField[years]" + "'", str37.equals("UnsupportedDurationField[years]"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "years" + "'", str38.equals("years"));
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyearOfCentury();
        java.lang.String str7 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[]" + "'", str7.equals("ISOChronology[]"));
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test378");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 0, locale4);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((-61850995199948L), (-100));
//        int int13 = offsetDateTimeField9.getMinimumValue();
//        java.lang.String str14 = offsetDateTimeField9.getName();
//        long long16 = offsetDateTimeField9.roundHalfEven((long) 1000);
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField9.getMaximumShortTextLength(locale17);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.Period period22 = org.joda.time.Period.years((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.hourOfHalfday();
//        long long30 = iSOChronology23.getDateTimeMillis((long) (short) 100, 0, 4, 0, (int) '4');
//        org.joda.time.Period period32 = org.joda.time.Period.hours(0);
//        org.joda.time.DurationFieldType durationFieldType33 = null;
//        int int34 = period32.indexOf(durationFieldType33);
//        int[] intArray36 = iSOChronology23.get((org.joda.time.ReadablePeriod) period32, 149L);
//        boolean boolean37 = period22.equals((java.lang.Object) intArray36);
//        try {
//            int[] intArray39 = offsetDateTimeField9.set(readablePartial19, 6, intArray36, 21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-377420515199948L) + "'", long12 == (-377420515199948L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "centuryOfEra" + "'", str14.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 946684799996L + "'", long16 == 946684799996L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 240048L + "'", long30 == 240048L);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test379");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-10));
//        java.lang.String str6 = dateTimeZone4.getShortName((long) (short) -1);
//        long long9 = dateTimeZone4.adjustOffset(3L, false);
//        long long12 = dateTimeZone4.adjustOffset((long) ' ', false);
//        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName((long) (byte) 0, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology15.centuryOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 1);
//        int int26 = offsetDateTimeField24.get((long) (-10));
//        int int28 = offsetDateTimeField24.get(0L);
//        long long31 = offsetDateTimeField24.add((long) 97, (int) (byte) 10);
//        org.joda.time.DurationField durationField32 = offsetDateTimeField24.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType33, 36, 51, 0);
//        org.joda.time.DurationField durationField38 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField38);
//        boolean boolean40 = unsupportedDateTimeField39.isSupported();
//        boolean boolean41 = unsupportedDateTimeField39.isLenient();
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        org.joda.time.Period period44 = org.joda.time.Period.years((int) (short) 1);
//        int[] intArray45 = period44.getValues();
//        try {
//            int int46 = unsupportedDateTimeField39.getMaximumValue(readablePartial42, intArray45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.010" + "'", str6.equals("-00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31556995200097L + "'", long31 == 31556995200097L);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 0, chronology3);
        org.joda.time.Period period6 = period4.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        int int8 = periodType7.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 0, chronology13);
        org.joda.time.Period period16 = period14.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearWeekDayTime();
        int int18 = periodType17.size();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.time();
        boolean boolean23 = gregorianChronology19.equals((java.lang.Object) periodType22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 1, periodType7, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.secondOfDay();
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.Period period30 = new org.joda.time.Period(0L, periodType7, (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.Chronology chronology31 = iSOChronology25.withUTC();
        org.joda.time.DurationField durationField32 = iSOChronology25.years();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(durationField32);
    }
}

