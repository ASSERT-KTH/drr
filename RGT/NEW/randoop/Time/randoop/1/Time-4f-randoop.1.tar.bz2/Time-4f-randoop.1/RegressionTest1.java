import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        int[] intArray3 = localDate2.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str5 = localDate2.toString(dateTimeFormatter4);
//        int int6 = localDate2.getYearOfCentury();
//        org.joda.time.LocalDate localDate8 = localDate2.plusYears(366);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.DateMidnight dateMidnight13 = localDate8.toDateMidnight(dateTimeZone10);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateMidnight13, 923);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 923");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "��:��:��" + "'", str5.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 70 + "'", int6 == 70);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial59 = null;
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate();
//        int[] intArray61 = localDate60.getValues();
//        int int62 = remainderDateTimeField58.getMaximumValue(readablePartial59, intArray61);
//        int int64 = remainderDateTimeField58.get(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 99 + "'", int62 == 99);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(0L, 432000045);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        long long64 = remainderDateTimeField58.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int66 = remainderDateTimeField58.getMinimumValue((long) (short) 10);
//        long long68 = remainderDateTimeField58.roundCeiling((long) 180254);
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = remainderDateTimeField58.getAsText(10, locale70);
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate();
//        int[] intArray73 = localDate72.getValues();
//        org.joda.time.LocalDate localDate75 = localDate72.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate77 = localDate72.withCenturyOfEra(0);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = remainderDateTimeField58.getAsShortText((org.joda.time.ReadablePartial) localDate72, 2514, locale79);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10" + "'", str71.equals("10"));
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2514" + "'", str80.equals("2514"));
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.getMinimumValue((long) 577);
//        int int26 = skipDateTimeField18.getLeapAmount((long) (short) 1);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipDateTimeField18.getAsShortText(28800035L, locale28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        int[] intArray32 = localDate31.getValues();
//        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate31);
//        java.lang.String str34 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.LocalDate localDate36 = localDate31.plus(readablePeriod35);
//        org.joda.time.LocalDate.Property property37 = localDate36.dayOfYear();
//        org.joda.time.LocalDate localDate39 = localDate36.withYear(586);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatterBuilder43.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.weekOfWeekyear();
//        org.joda.time.DurationField durationField50 = buddhistChronology48.eras();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(chronology51);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone55);
//        org.joda.time.DurationField durationField57 = buddhistChronology56.eras();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology56);
//        int int59 = dateTime58.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone54, (org.joda.time.ReadableInstant) dateTime58, 1);
//        int int62 = dateTime58.getYearOfCentury();
//        long long63 = property53.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeField dateTimeField64 = property53.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField64);
//        long long67 = skipDateTimeField65.roundCeiling((long) 62);
//        int int69 = skipDateTimeField65.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = skipDateTimeField65.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder43.appendText(dateTimeFieldType70);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType70);
//        org.joda.time.LocalDate.Property property75 = localDate36.property(dateTimeFieldType70);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType70, 166, (int) 'a', 99);
//        org.joda.time.DurationField durationField80 = offsetDateTimeField79.getLeapDurationField();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "��:��:��.000" + "'", str34.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 13 + "'", int62 == 13);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 86400000L + "'", long67 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNull(durationField80);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(365, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-28797488L));
        int int2 = dateTime1.getEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        java.lang.String str8 = gJChronology7.toString();
//        org.joda.time.Instant instant9 = gJChronology7.getGregorianCutover();
//        org.joda.time.Instant instant11 = instant9.minus((-78689117644000L));
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str8.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(instant11);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int22 = skipDateTimeField18.get((long) (short) 0);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        int[] intArray24 = localDate23.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str26 = localDate23.toString(dateTimeFormatter25);
//        int int27 = localDate23.getYearOfCentury();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate();
//        int[] intArray29 = localDate28.getValues();
//        int int30 = skipDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate23, intArray29);
//        boolean boolean31 = skipDateTimeField18.isSupported();
//        long long34 = skipDateTimeField18.addWrapField(0L, 2019);
//        java.lang.String str36 = skipDateTimeField18.getAsText((long) 23);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "��:��:��" + "'", str26.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 70 + "'", int27 == 70);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 365 + "'", int30 == 365);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 16761600000L + "'", long34 == 16761600000L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        int int11 = dateTime7.getYearOfCentury();
//        long long12 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime14 = dateTime7.plusMonths(4);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.minus(readableDuration15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 10 for hi! must be in the range [10.0,1]", "1969-12-31T16:00:00.100-08:00");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
//        long long4 = dateTimeZone1.adjustOffset((long) '4', true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        long long7 = instant6.getMillis();
//        int int8 = cachedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant6);
//        boolean boolean9 = cachedDateTimeZone5.isFixed();
//        long long11 = cachedDateTimeZone5.previousTransition(35L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800035L + "'", long7 == 28800035L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendEraText();
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.DateTime dateTime9 = localDate3.toDateTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = buddhistChronology11.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime7.toDateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime7.minus(readablePeriod15);
//        java.lang.String str17 = dateTime16.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter18.withChronology((org.joda.time.Chronology) julianChronology19);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.weekOfWeekyear();
//        org.joda.time.DurationField durationField25 = buddhistChronology23.eras();
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(chronology26);
//        org.joda.time.LocalDate.Property property28 = localDate27.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DurationField durationField32 = buddhistChronology31.eras();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology31);
//        int int34 = dateTime33.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime33, 1);
//        int int37 = dateTime33.getYearOfCentury();
//        long long38 = property28.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTimeField dateTimeField39 = property28.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, dateTimeField39);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology19, dateTimeField39, (int) 'a');
//        int int43 = skipUndoDateTimeField42.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatterBuilder44.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.weekOfWeekyear();
//        org.joda.time.DurationField durationField51 = buddhistChronology49.eras();
//        org.joda.time.Chronology chronology52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(chronology52);
//        org.joda.time.LocalDate.Property property54 = localDate53.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone56);
//        org.joda.time.DurationField durationField58 = buddhistChronology57.eras();
//        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology57);
//        int int60 = dateTime59.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55, (org.joda.time.ReadableInstant) dateTime59, 1);
//        int int63 = dateTime59.getYearOfCentury();
//        long long64 = property54.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTimeField dateTimeField65 = property54.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology49, dateTimeField65);
//        long long68 = skipDateTimeField66.roundCeiling((long) 62);
//        int int70 = skipDateTimeField66.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = skipDateTimeField66.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType71, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder44.appendText(dateTimeFieldType71);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType71, (int) (byte) 100);
//        org.joda.time.DateTime.Property property77 = dateTime16.property(dateTimeFieldType71);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType71, (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -28800000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2513-01-01T00:00:00.035-08:00" + "'", str17.equals("2513-01-01T00:00:00.035-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 13 + "'", int37 == 13);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(buddhistChronology57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(gJChronology62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 13 + "'", int63 == 13);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(property77);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.eras();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        int int7 = dateTime6.getHourOfDay();
//        org.joda.time.DateTime dateTime8 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = buddhistChronology10.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime6.toDateTime(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = dateTime6.toLocalDate();
//        boolean boolean15 = copticChronology1.equals((java.lang.Object) localDate14);
//        java.lang.String str16 = copticChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology1.getZone();
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str16.equals("CopticChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("GJChronology[America/Los_Angeles,cutover=1970-01-01T00:00:00.035Z,mdfw=1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        int[] intArray1 = localDate0.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
//        org.joda.time.Interval interval4 = localDate0.toInterval();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate0.getFieldTypes();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekOfWeekyear();
//        org.joda.time.DurationField durationField10 = buddhistChronology8.eras();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(chronology11);
//        org.joda.time.LocalDate.Property property13 = localDate12.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField17 = buddhistChronology16.eras();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology16);
//        int int19 = dateTime18.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime18, 1);
//        int int22 = dateTime18.getYearOfCentury();
//        long long23 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeField dateTimeField24 = property13.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField24);
//        long long27 = skipDateTimeField25.roundCeiling((long) 62);
//        long long29 = skipDateTimeField25.roundHalfFloor((long) 1);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = skipDateTimeField25.getAsShortText((int) (short) 0, locale31);
//        long long34 = skipDateTimeField25.remainder((long) 923);
//        int int35 = dateTime6.get((org.joda.time.DateTimeField) skipDateTimeField25);
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(interval4);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 923L + "'", long34 == 923L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("June", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        int[] intArray1 = localDate0.getValues();
//        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate5 = localDate0.withCenturyOfEra(0);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder9.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = buddhistChronology14.eras();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = buddhistChronology22.eras();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        int int25 = dateTime24.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24, 1);
//        int int28 = dateTime24.getYearOfCentury();
//        long long29 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField dateTimeField30 = property19.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField30);
//        long long33 = skipDateTimeField31.roundCeiling((long) 62);
//        int int35 = skipDateTimeField31.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField31.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder9.appendText(dateTimeFieldType36);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType36);
//        int int41 = localDate5.get(dateTimeFieldType36);
//        int int42 = localDate5.getMonthOfYear();
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 86400000L + "'", long33 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str6 = dateTimeFormatter0.print((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DurationField durationField9 = buddhistChronology8.eras();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        boolean boolean13 = dateTime10.isSupported(dateTimeFieldType12);
//        org.joda.time.LocalDate localDate14 = dateTime10.toLocalDate();
//        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "16:00:00.100" + "'", str6.equals("16:00:00.100"));
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "00:00:00.035" + "'", str11.equals("00:00:00.035"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.lang.String str63 = remainderDateTimeField58.getAsShortText(14L);
//        int int64 = remainderDateTimeField58.getDivisor();
//        boolean boolean66 = remainderDateTimeField58.isLeap((long) 2019);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
//        int int12 = dateTime9.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        long long64 = remainderDateTimeField58.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int66 = remainderDateTimeField58.getMinimumValue((long) (short) 10);
//        long long69 = remainderDateTimeField58.add(28800003L, 69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 5990400003L + "'", long69 == 5990400003L);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        int int9 = localDate7.getValue(0);
//        org.joda.time.LocalDate localDate11 = localDate7.minusWeeks((-35));
//        org.joda.time.Chronology chronology12 = localDate11.getChronology();
//        java.lang.Object obj13 = null;
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate11, obj13);
//        org.joda.time.DateTime dateTime15 = dateTime6.withFields((org.joda.time.ReadablePartial) localDate11);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter2.parseLocalDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        int int11 = dateTime7.getYearOfCentury();
//        long long12 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeField dateTimeField13 = property2.getField();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = buddhistChronology15.eras();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology15);
//        int int18 = dateTime17.getHourOfDay();
//        int int19 = dateTime17.getWeekyear();
//        long long20 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        int int21 = property2.getMinimumValueOverall();
//        org.joda.time.LocalDate localDate22 = property2.withMaximumValue();
//        org.joda.time.LocalDate.Property property23 = localDate22.weekOfWeekyear();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsShortText(locale24);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2513 + "'", int19 == 2513);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "53" + "'", str25.equals("53"));
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int22 = skipDateTimeField18.get((long) (short) 0);
//        boolean boolean24 = skipDateTimeField18.isLeap((long) (short) 10);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField18.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.weekOfWeekyear();
//        org.joda.time.DurationField durationField26 = buddhistChronology24.eras();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(chronology27);
//        org.joda.time.LocalDate.Property property29 = localDate28.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone31);
//        org.joda.time.DurationField durationField33 = buddhistChronology32.eras();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology32);
//        int int35 = dateTime34.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime34, 1);
//        int int38 = dateTime34.getYearOfCentury();
//        long long39 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField dateTimeField40 = property29.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology24, dateTimeField40);
//        long long43 = skipDateTimeField41.roundCeiling((long) 62);
//        int int45 = skipDateTimeField41.get((long) (short) 0);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate();
//        int[] intArray47 = localDate46.getValues();
//        int int48 = skipDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) localDate46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate46, locale49);
//        long long52 = skipDateTimeField18.roundHalfCeiling((long) (short) 100);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 86400000L + "'", long43 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("��:��:��", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"��:��:��/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 62, 2000, 2562, 1970, 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2562 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.DateTime dateTime4 = dateTime1.withZoneRetainFields(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime9.withWeekOfWeekyear(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for weekOfWeekyear must be in the range [1,53]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
        org.joda.time.Interval interval4 = localDate0.toInterval();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate0.getFieldTypes();
        org.joda.time.LocalDate.Property property6 = localDate0.monthOfYear();
        int int7 = property6.getMaximumValueOverall();
        org.joda.time.Interval interval8 = property6.toInterval();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 586, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.year();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = skipDateTimeField18.getAsShortText((int) (short) 0, locale24);
//        long long28 = skipDateTimeField18.addWrapField((long) 3, (int) (byte) 0);
//        boolean boolean30 = skipDateTimeField18.isLeap((-3024000000L));
//        boolean boolean32 = skipDateTimeField18.isLeap(316800052L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3L + "'", long28 == 3L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        int[] intArray2 = localDate1.getValues();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury(4);
        org.joda.time.DateMidnight dateMidnight9 = localDate8.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', 2512);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendCenturyOfEra(19, 586);
        java.lang.Class<?> wildcardClass8 = dateTimeFormatterBuilder7.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.MutableDateTime mutableDateTime2 = dateTime1.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime3 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = buddhistChronology5.getZone();
//        boolean boolean8 = dateTimeZone6.isStandardOffset(10L);
//        java.lang.String str10 = dateTimeZone6.getName((long) (short) -1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime1.toMutableDateTime(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusDays(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(15);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfWeek(4);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime11.withTime((int) 'a', 4, (-35), 2513);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime((org.joda.time.Chronology) gJChronology8);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = buddhistChronology8.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime4.minus(readablePeriod12);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime13.withFieldAdded(durationFieldType15, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        int[] intArray2 = localDate1.getValues();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury(4);
        try {
            org.joda.time.LocalDate localDate10 = localDate6.withWeekOfWeekyear(62);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 62 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 366);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.lang.String str63 = remainderDateTimeField58.getAsShortText(14L);
//        int int64 = remainderDateTimeField58.getDivisor();
//        int int67 = remainderDateTimeField58.getDifference(0L, (-15573948208434L));
//        long long69 = remainderDateTimeField58.roundHalfEven(1560637430165L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 180254 + "'", int67 == 180254);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560643200000L + "'", long69 == 1560643200000L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        int int4 = julianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate.Property property4 = localDate0.year();
        org.joda.time.DateTime dateTime5 = localDate0.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate.Property property4 = localDate0.year();
        org.joda.time.LocalDate localDate5 = property4.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate7 = property4.addToCopy(23);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusDays(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(15);
//        int int10 = dateTime9.getEra();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("GJChronology[America/Los_Angeles,cutover=2019-06-15T22:23:28.217Z,mdfw=1]");
        illegalFieldValueException4.prependMessage("org.joda.time.IllegalFieldValueException: Value 10 for hi! must be in the range [10.0,1]");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfEra((int) (short) 1);
//        int int8 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime3.minusSeconds(166);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = buddhistChronology3.eras();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
//        int int6 = dateTime5.getHourOfDay();
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime11 = dateTime5.plusMonths(16);
//        org.joda.time.DateTime dateTime13 = dateTime5.minusMonths(4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2513-W01-4T00:00:00.035-08:00" + "'", str9.equals("2513-W01-4T00:00:00.035-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.getMinimumValue((long) 577);
//        int int26 = skipDateTimeField18.getLeapAmount((long) (short) 1);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipDateTimeField18.getAsShortText(28800035L, locale28);
//        java.lang.String str30 = skipDateTimeField18.toString();
//        int int32 = skipDateTimeField18.get((long) (byte) 100);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DateTimeField[dayOfYear]" + "'", str30.equals("DateTimeField[dayOfYear]"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(62, 577);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimeFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = buddhistChronology3.eras();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
//        int int6 = dateTime5.getHourOfDay();
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime11 = dateTime5.withDayOfWeek(1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2513-W01-4T00:00:00.035-08:00" + "'", str9.equals("2513-W01-4T00:00:00.035-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        int int11 = dateTime7.getYearOfCentury();
//        long long12 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeField dateTimeField13 = property2.getField();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = buddhistChronology15.eras();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology15);
//        int int18 = dateTime17.getHourOfDay();
//        int int19 = dateTime17.getWeekyear();
//        long long20 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime17.plus(readableDuration21);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2513 + "'", int19 == 2513);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.months();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        java.lang.String str8 = dateTime4.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513-01-01T00:00:00.035-08:00" + "'", str8.equals("2513-01-01T00:00:00.035-08:00"));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        java.lang.String str59 = remainderDateTimeField58.toString();
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField58.getAsShortText((long) 26, locale61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "DateTimeField[dayOfYear]" + "'", str59.equals("DateTimeField[dayOfYear]"));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2" + "'", str62.equals("2"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 2019);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
        java.lang.Appendable appendable4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
        int[] intArray6 = localDate5.getValues();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate5);
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate5);
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        int int3 = partial0.size();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial0.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        java.lang.String str10 = partial8.toString("1");
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField18.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.weekOfWeekyear();
//        org.joda.time.DurationField durationField26 = buddhistChronology24.eras();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(chronology27);
//        org.joda.time.LocalDate.Property property29 = localDate28.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone31);
//        org.joda.time.DurationField durationField33 = buddhistChronology32.eras();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology32);
//        int int35 = dateTime34.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime34, 1);
//        int int38 = dateTime34.getYearOfCentury();
//        long long39 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField dateTimeField40 = property29.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology24, dateTimeField40);
//        long long43 = skipDateTimeField41.roundCeiling((long) 62);
//        int int45 = skipDateTimeField41.get((long) (short) 0);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate();
//        int[] intArray47 = localDate46.getValues();
//        int int48 = skipDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) localDate46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate46, locale49);
//        org.joda.time.LocalDate localDate52 = localDate46.minusMonths(0);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        try {
//            org.joda.time.LocalDate localDate55 = localDate52.withMonthOfYear((-35));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 86400000L + "'", long43 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(property53);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.secondOfDay();
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 0);
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013" + "'", str2.equals("1970W013"));
        org.junit.Assert.assertNull(int3);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(62, 577);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(0);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        int[] intArray8 = localDate7.getValues();
//        org.joda.time.LocalDate localDate10 = localDate7.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate12 = localDate7.withCenturyOfEra(0);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatterBuilder16.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.weekOfWeekyear();
//        org.joda.time.DurationField durationField23 = buddhistChronology21.eras();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(chronology24);
//        org.joda.time.LocalDate.Property property26 = localDate25.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
//        org.joda.time.DurationField durationField30 = buddhistChronology29.eras();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology29);
//        int int32 = dateTime31.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime31, 1);
//        int int35 = dateTime31.getYearOfCentury();
//        long long36 = property26.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTimeField dateTimeField37 = property26.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology21, dateTimeField37);
//        long long40 = skipDateTimeField38.roundCeiling((long) 62);
//        int int42 = skipDateTimeField38.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipDateTimeField38.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType43);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType43);
//        int int48 = localDate12.get(dateTimeFieldType43);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType43, 26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 13 + "'", int35 == 13);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 86400000L + "'", long40 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField18.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.weekOfWeekyear();
//        org.joda.time.DurationField durationField26 = buddhistChronology24.eras();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(chronology27);
//        org.joda.time.LocalDate.Property property29 = localDate28.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone31);
//        org.joda.time.DurationField durationField33 = buddhistChronology32.eras();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology32);
//        int int35 = dateTime34.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime34, 1);
//        int int38 = dateTime34.getYearOfCentury();
//        long long39 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField dateTimeField40 = property29.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology24, dateTimeField40);
//        long long43 = skipDateTimeField41.roundCeiling((long) 62);
//        int int45 = skipDateTimeField41.get((long) (short) 0);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate();
//        int[] intArray47 = localDate46.getValues();
//        int int48 = skipDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) localDate46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate46, locale49);
//        org.joda.time.LocalDate localDate52 = localDate46.minusMonths(0);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        try {
//            org.joda.time.DateTimeField dateTimeField55 = localDate52.getField(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 86400000L + "'", long43 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(property53);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra(81);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime4.plus(readableDuration10);
//        org.joda.time.DateTime.Property property12 = dateTime4.millisOfSecond();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder3.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekOfWeekyear();
//        org.joda.time.DurationField durationField10 = buddhistChronology8.eras();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(chronology11);
//        org.joda.time.LocalDate.Property property13 = localDate12.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField17 = buddhistChronology16.eras();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology16);
//        int int19 = dateTime18.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime18, 1);
//        int int22 = dateTime18.getYearOfCentury();
//        long long23 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeField dateTimeField24 = property13.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField24);
//        long long27 = skipDateTimeField25.roundCeiling((long) 62);
//        int int29 = skipDateTimeField25.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField25.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType30);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType30);
//        int int37 = delegatedDateTimeField34.getDifference(3L, (long) (byte) 100);
//        long long40 = delegatedDateTimeField34.getDifferenceAsLong((long) ' ', (long) 2000);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.eras();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        int int7 = dateTime6.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime6, 1);
//        org.joda.time.DateTime dateTime11 = dateTime6.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfMonth();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        boolean boolean14 = dateTimeZone1.isLocalDateTimeGap(localDateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        int[] intArray2 = localDate1.getValues();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
        org.joda.time.Chronology chronology7 = localDate1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean2 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.getMinimumValue((long) 577);
//        int int26 = skipDateTimeField18.getLeapAmount((long) (short) 1);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipDateTimeField18.getAsShortText(28800035L, locale28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        int[] intArray32 = localDate31.getValues();
//        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate31);
//        java.lang.String str34 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.LocalDate localDate36 = localDate31.plus(readablePeriod35);
//        org.joda.time.LocalDate.Property property37 = localDate36.dayOfYear();
//        org.joda.time.LocalDate localDate39 = localDate36.withYear(586);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatterBuilder43.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.weekOfWeekyear();
//        org.joda.time.DurationField durationField50 = buddhistChronology48.eras();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(chronology51);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone55);
//        org.joda.time.DurationField durationField57 = buddhistChronology56.eras();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology56);
//        int int59 = dateTime58.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone54, (org.joda.time.ReadableInstant) dateTime58, 1);
//        int int62 = dateTime58.getYearOfCentury();
//        long long63 = property53.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeField dateTimeField64 = property53.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField64);
//        long long67 = skipDateTimeField65.roundCeiling((long) 62);
//        int int69 = skipDateTimeField65.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = skipDateTimeField65.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder43.appendText(dateTimeFieldType70);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType70);
//        org.joda.time.LocalDate.Property property75 = localDate36.property(dateTimeFieldType70);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType70, 166, (int) 'a', 99);
//        long long81 = offsetDateTimeField79.roundCeiling(10L);
//        try {
//            long long84 = offsetDateTimeField79.addWrapField(10L, 15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "��:��:��.000" + "'", str34.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 13 + "'", int62 == 13);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 86400000L + "'", long67 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 86400000L + "'", long81 == 86400000L);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusDays(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(15);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfWeek(4);
//        org.joda.time.DateTime.Property property12 = dateTime7.yearOfCentury();
//        org.joda.time.LocalDate localDate13 = dateTime7.toLocalDate();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = buddhistChronology2.getZone();
//        boolean boolean5 = dateTimeZone3.isStandardOffset(10L);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone3);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.DateTime dateTime13 = localDate7.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.withTimeAtStartOfDay();
//        int int15 = dateTime14.getSecondOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime14.withWeekyear(2562);
//        int int18 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = skipUndoDateTimeField24.getAsShortText(0, locale60);
//        try {
//            long long64 = skipUndoDateTimeField24.set((-28799938L), (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [2,366]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "0" + "'", str61.equals("0"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.junit.Assert.assertNotNull(instant1);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime4.withMonthOfYear(1);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        int[] intArray11 = localDate10.getValues();
//        org.joda.time.Partial partial12 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial12.getFormatter();
//        java.lang.String str14 = dateTime4.toString(dateTimeFormatter13);
//        org.joda.time.DateTime dateTime16 = dateTime4.plus((long) '#');
//        org.joda.time.DateTime.Property property17 = dateTime4.yearOfCentury();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2513-01-01" + "'", str14.equals("2513-01-01"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = buddhistChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekOfWeekyear();
//        org.joda.time.DurationField durationField11 = buddhistChronology9.eras();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(chronology12);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = buddhistChronology17.eras();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        int int20 = dateTime19.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime19, 1);
//        int int23 = dateTime19.getYearOfCentury();
//        long long24 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTimeField dateTimeField25 = property14.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology9, dateTimeField25);
//        long long28 = skipDateTimeField26.roundCeiling((long) 62);
//        int int29 = skipDateTimeField26.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField30 = skipDateTimeField26.getWrappedField();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        int[] intArray32 = localDate31.getValues();
//        org.joda.time.LocalDate localDate34 = localDate31.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate36 = localDate31.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property37 = localDate36.era();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = skipDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate36, locale38);
//        long long41 = buddhistChronology6.set((org.joda.time.ReadablePartial) localDate36, 0L);
//        org.joda.time.DateTime dateTime42 = dateTime3.toDateTime((org.joda.time.Chronology) buddhistChronology6);
//        try {
//            org.joda.time.DateTime dateTime44 = dateTime3.withSecondOfMinute((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 86400000L + "'", long28 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-77094029222000L) + "'", long41 == (-77094029222000L));
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.getMinimumValue((long) 577);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate();
//        int[] intArray26 = localDate25.getValues();
//        org.joda.time.LocalDate localDate28 = localDate25.plusYears((int) (short) -1);
//        int int29 = skipDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 365 + "'", int29 == 365);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusWeeks((int) (byte) -1);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
        java.util.Date date2 = localDate0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate0.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate.Property property5 = localDate0.dayOfYear();
        org.joda.time.LocalDate localDate6 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology63.weekOfWeekyear();
//        org.joda.time.DurationField durationField65 = buddhistChronology63.eras();
//        org.joda.time.Chronology chronology66 = null;
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate(chronology66);
//        org.joda.time.LocalDate.Property property68 = localDate67.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone70);
//        org.joda.time.DurationField durationField72 = buddhistChronology71.eras();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology71);
//        int int74 = dateTime73.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone69, (org.joda.time.ReadableInstant) dateTime73, 1);
//        int int77 = dateTime73.getYearOfCentury();
//        long long78 = property68.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime73);
//        org.joda.time.DateTimeField dateTimeField79 = property68.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology63, dateTimeField79);
//        long long82 = skipDateTimeField80.roundCeiling((long) 62);
//        int int83 = skipDateTimeField80.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField84 = skipDateTimeField80.getWrappedField();
//        org.joda.time.LocalDate localDate85 = new org.joda.time.LocalDate();
//        int[] intArray86 = localDate85.getValues();
//        org.joda.time.LocalDate localDate88 = localDate85.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate90 = localDate85.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property91 = localDate90.era();
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = skipDateTimeField80.getAsShortText((org.joda.time.ReadablePartial) localDate90, locale92);
//        int int94 = remainderDateTimeField58.getMaximumValue((org.joda.time.ReadablePartial) localDate90);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField58, 1970, 3, 1969);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfYear must be in the range [3,1969]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertNotNull(buddhistChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(buddhistChronology71);
//        org.junit.Assert.assertNotNull(durationField72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(gJChronology76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 13 + "'", int77 == 13);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 86400000L + "'", long82 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 366 + "'", int83 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertNotNull(localDate90);
//        org.junit.Assert.assertNotNull(property91);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "1" + "'", str93.equals("1"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 99 + "'", int94 == 99);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(35, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology63.weekOfWeekyear();
//        org.joda.time.DurationField durationField65 = buddhistChronology63.eras();
//        org.joda.time.Chronology chronology66 = null;
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate(chronology66);
//        org.joda.time.LocalDate.Property property68 = localDate67.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone70);
//        org.joda.time.DurationField durationField72 = buddhistChronology71.eras();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology71);
//        int int74 = dateTime73.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone69, (org.joda.time.ReadableInstant) dateTime73, 1);
//        int int77 = dateTime73.getYearOfCentury();
//        long long78 = property68.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime73);
//        org.joda.time.DateTimeField dateTimeField79 = property68.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology63, dateTimeField79);
//        long long82 = skipDateTimeField80.roundCeiling((long) 62);
//        int int83 = skipDateTimeField80.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField84 = skipDateTimeField80.getWrappedField();
//        org.joda.time.LocalDate localDate85 = new org.joda.time.LocalDate();
//        int[] intArray86 = localDate85.getValues();
//        org.joda.time.LocalDate localDate88 = localDate85.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate90 = localDate85.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property91 = localDate90.era();
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = skipDateTimeField80.getAsShortText((org.joda.time.ReadablePartial) localDate90, locale92);
//        int int94 = remainderDateTimeField58.getMaximumValue((org.joda.time.ReadablePartial) localDate90);
//        int int95 = remainderDateTimeField58.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertNotNull(buddhistChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(buddhistChronology71);
//        org.junit.Assert.assertNotNull(durationField72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(gJChronology76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 13 + "'", int77 == 13);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 86400000L + "'", long82 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 366 + "'", int83 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertNotNull(localDate90);
//        org.junit.Assert.assertNotNull(property91);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "1" + "'", str93.equals("1"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 99 + "'", int94 == 99);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 99 + "'", int95 == 99);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) 'a', (int) 'a', 0, 1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        java.lang.String str8 = gJChronology7.toString();
//        org.joda.time.Chronology chronology9 = gJChronology7.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.monthOfYear();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str8.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 10 for hi! must be in the range [10.0,1]", "");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str12 = illegalFieldValueException10.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for org.joda.time.IllegalFieldValueException: Value 10 for hi! must be in the range [10.0,1] is not supported" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value \"\" for org.joda.time.IllegalFieldValueException: Value 10 for hi! must be in the range [10.0,1] is not supported"));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.DateTime dateTime13 = localDate7.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = buddhistChronology15.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime11.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime21 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.LocalDate.Property property22 = localDate1.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GJChronology[America/Los_Angeles,cutover=2019-06-15T22:23:38.463Z,mdfw=1]", "16:00:00.100");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles,cutover=2019-06-15T22:23:38.463Z,mdfw=1]" + "'", str3.equals("GJChronology[America/Los_Angeles,cutover=2019-06-15T22:23:38.463Z,mdfw=1]"));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.eras();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        java.util.Date date9 = localDate8.toDate();
//        org.joda.time.LocalDate localDate11 = localDate8.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekOfWeekyear();
//        org.joda.time.DurationField durationField19 = buddhistChronology17.eras();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(chronology20);
//        org.joda.time.LocalDate.Property property22 = localDate21.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone24);
//        org.joda.time.DurationField durationField26 = buddhistChronology25.eras();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology25);
//        int int28 = dateTime27.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime27, 1);
//        int int31 = dateTime27.getYearOfCentury();
//        long long32 = property22.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeField dateTimeField33 = property22.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField33);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology13, dateTimeField33, (int) 'a');
//        int int37 = skipUndoDateTimeField36.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatterBuilder38.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.weekOfWeekyear();
//        org.joda.time.DurationField durationField45 = buddhistChronology43.eras();
//        org.joda.time.Chronology chronology46 = null;
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(chronology46);
//        org.joda.time.LocalDate.Property property48 = localDate47.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
//        org.joda.time.DurationField durationField52 = buddhistChronology51.eras();
//        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology51);
//        int int54 = dateTime53.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime53, 1);
//        int int57 = dateTime53.getYearOfCentury();
//        long long58 = property48.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.DateTimeField dateTimeField59 = property48.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology43, dateTimeField59);
//        long long62 = skipDateTimeField60.roundCeiling((long) 62);
//        int int64 = skipDateTimeField60.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = skipDateTimeField60.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType65, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder38.appendText(dateTimeFieldType65);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, dateTimeFieldType65, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property71 = localDate8.property(dateTimeFieldType65);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType65, (int) (short) 100);
//        org.joda.time.LocalDate.Property property74 = localDate1.property(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 13 + "'", int57 == 13);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 86400000L + "'", long62 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(property74);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        long long6 = dateTimeZone2.convertLocalToUTC((long) '#', false, (long) 2019);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone2);
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800035L + "'", long6 == 28800035L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendYear(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 28800003L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
//        org.joda.time.LocalDate.Property property4 = localDate3.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = buddhistChronology7.eras();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology7);
//        int int10 = dateTime9.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime9, 1);
//        int int13 = dateTime9.getYearOfCentury();
//        long long14 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeField dateTimeField15 = property4.getField();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = buddhistChronology17.eras();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        int int20 = dateTime19.getHourOfDay();
//        int int21 = dateTime19.getWeekyear();
//        long long22 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime dateTime24 = dateTime19.withMinuteOfHour((int) (short) 0);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime24.toMutableDateTime();
//        int int28 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime25, "GJChronology[UTC]", 2512);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2513 + "'", int21 == 2513);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2513) + "'", int28 == (-2513));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate.Property property4 = localDate0.year();
        org.joda.time.LocalDate localDate5 = property4.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate6 = property4.roundCeilingCopy();
        org.joda.time.LocalDate localDate8 = localDate6.minusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekOfWeekyear();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology0);
        org.joda.time.LocalDate localDate5 = localDate3.minusDays(62);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        try {
//            long long29 = julianChronology1.getDateTimeMillis(100, 180254, 26, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 180254 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = buddhistChronology8.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime4.minus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear(366);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        long long64 = remainderDateTimeField58.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int66 = remainderDateTimeField58.getMinimumValue((long) (short) 10);
//        long long68 = remainderDateTimeField58.roundCeiling((long) 180254);
//        org.joda.time.ReadablePartial readablePartial69 = null;
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate();
//        int[] intArray72 = localDate71.getValues();
//        int[] intArray74 = remainderDateTimeField58.add(readablePartial69, 0, intArray72, 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertNotNull(intArray74);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.eras();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
//        int int7 = dateTime6.getHourOfDay();
//        org.joda.time.DateTime dateTime8 = localDate2.toDateTime((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = buddhistChronology10.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime6.toDateTime(dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = dateTime6.toLocalDate();
//        boolean boolean15 = copticChronology1.equals((java.lang.Object) localDate14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = buddhistChronology17.getZone();
//        boolean boolean20 = dateTimeZone18.isStandardOffset(10L);
//        java.lang.String str22 = dateTimeZone18.getName((long) (short) -1);
//        org.joda.time.Chronology chronology23 = copticChronology1.withZone(dateTimeZone18);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18, 366);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 366");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.years();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.era();
        boolean boolean9 = julianChronology1.equals((java.lang.Object) buddhistChronology6);
        org.joda.time.DurationField durationField10 = buddhistChronology6.weekyears();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.DateTime.Property property11 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime13 = property11.addToCopy(365);
//        org.joda.time.DateTime dateTime14 = property11.roundFloorCopy();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str6 = dateTimeFormatter0.print((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DurationField durationField9 = buddhistChronology8.eras();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = buddhistChronology14.eras();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        int int17 = dateTime16.getHourOfDay();
//        org.joda.time.DateTime dateTime18 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readableDuration19);
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str11, (java.lang.Object) dateTime18);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
//        org.joda.time.DurationField durationField25 = buddhistChronology24.eras();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology24);
//        int int27 = dateTime26.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) dateTime26, 1);
//        java.lang.String str30 = gJChronology29.toString();
//        org.joda.time.Chronology chronology31 = gJChronology29.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology29.getZone();
//        org.joda.time.DateTime dateTime33 = dateTime18.toDateTime(dateTimeZone32);
//        java.lang.String str34 = dateTimeZone32.getID();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "16:00:00.100" + "'", str6.equals("16:00:00.100"));
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "00:00:00.035" + "'", str11.equals("00:00:00.035"));
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str30.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "America/Los_Angeles" + "'", str34.equals("America/Los_Angeles"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = buddhistChronology8.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone9);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int22 = skipDateTimeField18.get((long) (short) 0);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        int[] intArray24 = localDate23.getValues();
//        int int25 = skipDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate23);
//        org.joda.time.LocalDate localDate27 = localDate23.withYear(100);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(localDate27);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.add(32L, 586);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = remainderDateTimeField58.getAsText(99, locale63);
//        boolean boolean65 = remainderDateTimeField58.isLenient();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 50630400032L + "'", long61 == 50630400032L);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "99" + "'", str64.equals("99"));
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-28799938L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2699181403200000L) + "'", long1 == (-2699181403200000L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(2562);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField18.getWrappedField();
//        java.util.Locale locale25 = null;
//        try {
//            long long26 = skipDateTimeField18.set((long) (-28800000), "0", locale25);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        org.joda.time.DateTimeField dateTimeField23 = skipDateTimeField18.getWrappedField();
//        java.util.Locale locale24 = null;
//        int int25 = skipDateTimeField18.getMaximumShortTextLength(locale24);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) julianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = buddhistChronology14.eras();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = buddhistChronology22.eras();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        int int25 = dateTime24.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24, 1);
//        int int28 = dateTime24.getYearOfCentury();
//        long long29 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField dateTimeField30 = property19.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField30);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField30, (int) 'a');
//        int int34 = skipUndoDateTimeField33.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatterBuilder35.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekOfWeekyear();
//        org.joda.time.DurationField durationField42 = buddhistChronology40.eras();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
//        org.joda.time.LocalDate.Property property45 = localDate44.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = buddhistChronology48.eras();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology48);
//        int int51 = dateTime50.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime50, 1);
//        int int54 = dateTime50.getYearOfCentury();
//        long long55 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeField dateTimeField56 = property45.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField56);
//        long long59 = skipDateTimeField57.roundCeiling((long) 62);
//        int int61 = skipDateTimeField57.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = skipDateTimeField57.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType62);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField67 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType62, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property68 = localDate5.property(dateTimeFieldType62);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType62, (int) (short) 100);
//        long long72 = offsetDateTimeField70.roundCeiling(28800035L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 13 + "'", int54 == 13);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 32400000L + "'", long72 == 32400000L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.Chronology chronology3 = null;
        try {
            org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(26, (int) '4', (int) (byte) -1, chronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.secondOfDay();
//        int int7 = dateTime3.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) '4');
        org.joda.time.Instant instant4 = instant2.withMillis((long) '#');
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013" + "'", str2.equals("1970W013"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.LocalDate.Property property3 = localDate2.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = buddhistChronology6.eras();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime8, 1);
//        int int12 = dateTime8.getYearOfCentury();
//        long long13 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTimeField dateTimeField14 = property3.getField();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology15);
//        int int17 = property3.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfSecond(577);
//        try {
//            java.lang.String str20 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(obj0, chronology3);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', 2512);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology9.hourOfHalfday();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        java.util.Date date14 = localDate13.toDate();
//        org.joda.time.LocalDate localDate16 = localDate13.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) julianChronology18);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.weekOfWeekyear();
//        org.joda.time.DurationField durationField24 = buddhistChronology22.eras();
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(chronology25);
//        org.joda.time.LocalDate.Property property27 = localDate26.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.eras();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology30);
//        int int33 = dateTime32.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) dateTime32, 1);
//        int int36 = dateTime32.getYearOfCentury();
//        long long37 = property27.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTimeField dateTimeField38 = property27.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology22, dateTimeField38);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology18, dateTimeField38, (int) 'a');
//        int int42 = skipUndoDateTimeField41.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatterBuilder43.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.weekOfWeekyear();
//        org.joda.time.DurationField durationField50 = buddhistChronology48.eras();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(chronology51);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone55);
//        org.joda.time.DurationField durationField57 = buddhistChronology56.eras();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology56);
//        int int59 = dateTime58.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone54, (org.joda.time.ReadableInstant) dateTime58, 1);
//        int int62 = dateTime58.getYearOfCentury();
//        long long63 = property53.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeField dateTimeField64 = property53.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField64);
//        long long67 = skipDateTimeField65.roundCeiling((long) 62);
//        int int69 = skipDateTimeField65.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = skipDateTimeField65.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder43.appendText(dateTimeFieldType70);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType70, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property76 = localDate13.property(dateTimeFieldType70);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType70, (int) (short) 100);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType70, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 13 + "'", int62 == 13);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 86400000L + "'", long67 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(property76);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = buddhistChronology6.eras();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
//        int int9 = dateTime8.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime8, 1);
//        java.lang.String str12 = gJChronology11.toString();
//        org.joda.time.Instant instant13 = gJChronology11.getGregorianCutover();
//        java.lang.String str14 = dateTimeFormatter3.print((org.joda.time.ReadableInstant) instant13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str12.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19691219T000000-0800" + "'", str14.equals("19691219T000000-0800"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfHour((int) '4', 577);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendCenturyOfEra((-2513), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(4, 70, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        int[] intArray1 = localDate0.getValues();
//        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
//        int int4 = localDate3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        long long64 = remainderDateTimeField58.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int66 = remainderDateTimeField58.getMinimumValue((long) (short) 10);
//        long long68 = remainderDateTimeField58.roundCeiling((long) 180254);
//        java.lang.String str69 = remainderDateTimeField58.getName();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "dayOfYear" + "'", str69.equals("dayOfYear"));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("��:��:��.000");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 0);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("��:��:��.000");
        java.lang.String str6 = jodaTimePermission5.getActions();
        java.lang.String str7 = jodaTimePermission5.getActions();
        boolean boolean9 = jodaTimePermission5.equals((java.lang.Object) 2019);
        java.lang.String str10 = jodaTimePermission5.getActions();
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
//        int int3 = partial0.size();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
//        org.joda.time.Partial partial8 = partial0.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        java.util.Date date10 = localDate9.toDate();
//        org.joda.time.LocalDate localDate12 = localDate9.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) julianChronology14);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.weekOfWeekyear();
//        org.joda.time.DurationField durationField20 = buddhistChronology18.eras();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(chronology21);
//        org.joda.time.LocalDate.Property property23 = localDate22.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.eras();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology26);
//        int int29 = dateTime28.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) dateTime28, 1);
//        int int32 = dateTime28.getYearOfCentury();
//        long long33 = property23.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeField dateTimeField34 = property23.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField34);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology14, dateTimeField34, (int) 'a');
//        int int38 = skipUndoDateTimeField37.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatterBuilder39.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeField dateTimeField45 = buddhistChronology44.weekOfWeekyear();
//        org.joda.time.DurationField durationField46 = buddhistChronology44.eras();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(chronology47);
//        org.joda.time.LocalDate.Property property49 = localDate48.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone51);
//        org.joda.time.DurationField durationField53 = buddhistChronology52.eras();
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology52);
//        int int55 = dateTime54.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime54, 1);
//        int int58 = dateTime54.getYearOfCentury();
//        long long59 = property49.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTimeField dateTimeField60 = property49.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField61 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField60);
//        long long63 = skipDateTimeField61.roundCeiling((long) 62);
//        int int65 = skipDateTimeField61.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = skipDateTimeField61.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder39.appendText(dateTimeFieldType66);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField37, dateTimeFieldType66, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property72 = localDate9.property(dateTimeFieldType66);
//        try {
//            org.joda.time.Partial.Property property73 = partial8.property(dateTimeFieldType66);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(partial2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(partial8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(buddhistChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(buddhistChronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 13 + "'", int58 == 13);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 86400000L + "'", long63 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(property72);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = buddhistChronology8.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime4.minus(readablePeriod12);
//        java.lang.String str14 = dateTime13.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.weekOfWeekyear();
//        org.joda.time.DurationField durationField22 = buddhistChronology20.eras();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(chronology23);
//        org.joda.time.LocalDate.Property property25 = localDate24.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone27);
//        org.joda.time.DurationField durationField29 = buddhistChronology28.eras();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology28);
//        int int31 = dateTime30.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) dateTime30, 1);
//        int int34 = dateTime30.getYearOfCentury();
//        long long35 = property25.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTimeField dateTimeField36 = property25.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology20, dateTimeField36);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField36, (int) 'a');
//        int int40 = skipUndoDateTimeField39.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatterBuilder41.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.weekOfWeekyear();
//        org.joda.time.DurationField durationField48 = buddhistChronology46.eras();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(chronology49);
//        org.joda.time.LocalDate.Property property51 = localDate50.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone53);
//        org.joda.time.DurationField durationField55 = buddhistChronology54.eras();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology54);
//        int int57 = dateTime56.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52, (org.joda.time.ReadableInstant) dateTime56, 1);
//        int int60 = dateTime56.getYearOfCentury();
//        long long61 = property51.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime56);
//        org.joda.time.DateTimeField dateTimeField62 = property51.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology46, dateTimeField62);
//        long long65 = skipDateTimeField63.roundCeiling((long) 62);
//        int int67 = skipDateTimeField63.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = skipDateTimeField63.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder41.appendText(dateTimeFieldType68);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField39, dateTimeFieldType68, (int) (byte) 100);
//        org.joda.time.DateTime.Property property74 = dateTime13.property(dateTimeFieldType68);
//        try {
//            org.joda.time.DateTime dateTime76 = property74.setCopy("923");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 923 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2513-01-01T00:00:00.035-08:00" + "'", str14.equals("2513-01-01T00:00:00.035-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 13 + "'", int34 == 13);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 13 + "'", int60 == 13);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 86400000L + "'", long65 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//        org.junit.Assert.assertNotNull(property74);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int22 = skipDateTimeField18.get((long) (short) 0);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(chronology23);
//        org.joda.time.LocalDate.Property property25 = localDate24.dayOfYear();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate24, locale26);
//        try {
//            long long30 = skipDateTimeField18.set((long) (byte) 1, "+00:00:00.100");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.100\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField18.getWrappedField();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        int[] intArray24 = localDate23.getValues();
//        org.joda.time.LocalDate localDate26 = localDate23.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate28 = localDate23.withCenturyOfEra(0);
//        org.joda.time.LocalDate.Property property29 = localDate28.era();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate28, locale30);
//        org.joda.time.LocalDate localDate33 = localDate28.withEra(0);
//        org.joda.time.DurationFieldType durationFieldType34 = null;
//        try {
//            org.joda.time.LocalDate localDate36 = localDate28.withFieldAdded(durationFieldType34, 432000045);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
//        org.junit.Assert.assertNotNull(localDate33);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        int[] intArray6 = localDate5.getValues();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate10 = localDate5.withCenturyOfEra(0);
//        org.joda.time.LocalDate localDate12 = localDate5.plusWeeks((int) (byte) 0);
//        org.joda.time.LocalDate localDate13 = localDate1.withFields((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekOfWeekyear();
//        org.joda.time.DurationField durationField17 = buddhistChronology15.eras();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(chronology18);
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
//        org.joda.time.DurationField durationField24 = buddhistChronology23.eras();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology23);
//        int int26 = dateTime25.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime25, 1);
//        int int29 = dateTime25.getYearOfCentury();
//        long long30 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTimeField dateTimeField31 = property20.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField31);
//        long long34 = skipDateTimeField32.roundCeiling((long) 62);
//        int int36 = skipDateTimeField32.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField32.getType();
//        org.joda.time.LocalDate localDate39 = localDate1.withField(dateTimeFieldType37, (int) ' ');
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType37, 81, 0, (int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 86400000L + "'", long34 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(localDate39);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 2562, (int) (byte) 100, (-35));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2562 for  must be in the range [100,-35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) 'a', false);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekOfWeekyear();
//        org.joda.time.DurationField durationField8 = buddhistChronology6.eras();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(chronology9);
//        org.joda.time.LocalDate.Property property11 = localDate10.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = buddhistChronology14.eras();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        int int17 = dateTime16.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime16, 1);
//        int int20 = dateTime16.getYearOfCentury();
//        long long21 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeField dateTimeField22 = property11.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, dateTimeField22);
//        long long25 = skipDateTimeField23.roundCeiling((long) 62);
//        int int27 = skipDateTimeField23.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipDateTimeField23.getType();
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType28, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Instant instant6 = instant3.withDurationAdded(readableDuration4, 0);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 28800035L + "'", long1 == 28800035L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant6);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 366, (-35), (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.getMinimumValue((long) 577);
//        int int26 = skipDateTimeField18.getLeapAmount((long) (short) 1);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipDateTimeField18.getAsShortText(28800035L, locale28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        int[] intArray32 = localDate31.getValues();
//        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate31);
//        java.lang.String str34 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.LocalDate localDate36 = localDate31.plus(readablePeriod35);
//        org.joda.time.LocalDate.Property property37 = localDate36.dayOfYear();
//        org.joda.time.LocalDate localDate39 = localDate36.withYear(586);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatterBuilder43.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.weekOfWeekyear();
//        org.joda.time.DurationField durationField50 = buddhistChronology48.eras();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(chronology51);
//        org.joda.time.LocalDate.Property property53 = localDate52.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone55);
//        org.joda.time.DurationField durationField57 = buddhistChronology56.eras();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology56);
//        int int59 = dateTime58.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone54, (org.joda.time.ReadableInstant) dateTime58, 1);
//        int int62 = dateTime58.getYearOfCentury();
//        long long63 = property53.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeField dateTimeField64 = property53.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField64);
//        long long67 = skipDateTimeField65.roundCeiling((long) 62);
//        int int69 = skipDateTimeField65.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = skipDateTimeField65.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder43.appendText(dateTimeFieldType70);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType70);
//        org.joda.time.LocalDate.Property property75 = localDate36.property(dateTimeFieldType70);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType70, 166, (int) 'a', 99);
//        java.util.Locale locale80 = null;
//        int int81 = offsetDateTimeField79.getMaximumTextLength(locale80);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "��:��:��.000" + "'", str34.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 13 + "'", int62 == 13);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 86400000L + "'", long67 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2 + "'", int81 == 2);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.convertLocalToUTC((long) (short) 100, false);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800100L + "'", long5 == 28800100L);
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        int int11 = dateTime7.getYearOfCentury();
//        long long12 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime14 = dateTime7.plusMonths(4);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour(2);
//        org.joda.time.DateTime dateTime18 = dateTime14.minusYears((int) '#');
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTime();
//        org.joda.time.Instant instant6 = instant0.minus((-77094029222000L));
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 28800035L + "'", long1 == 28800035L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(instant6);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("53");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        int int6 = mutableDateTime5.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusWeeks(1);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMillis(2512);
//        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        org.joda.time.DateTime dateTime12 = dateTime7.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfMonth();
//        org.joda.time.DateTime dateTime15 = dateTime12.withYear(365);
//        try {
//            java.lang.String str16 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(81);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(62, 577);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime7, 1);
//        int int11 = dateTime7.getYearOfCentury();
//        long long12 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeField dateTimeField13 = property2.getField();
//        java.lang.String str14 = property2.getAsString();
//        java.lang.String str15 = property2.getAsShortText();
//        org.joda.time.LocalDate localDate16 = property2.roundFloorCopy();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertNotNull(localDate16);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        int[] intArray5 = localDate4.getValues();
//        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate4);
//        java.lang.String str7 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) localDate4);
//        java.lang.String str9 = dateTimeFormatter3.print((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = buddhistChronology11.eras();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology11);
//        java.lang.String str14 = dateTimeFormatter3.print((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = buddhistChronology17.eras();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        int int20 = dateTime19.getHourOfDay();
//        org.joda.time.DateTime dateTime21 = localDate15.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.minus(readableDuration22);
//        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str14, (java.lang.Object) dateTime21);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
//        org.joda.time.DurationField durationField28 = buddhistChronology27.eras();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology27);
//        int int30 = dateTime29.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (org.joda.time.ReadableInstant) dateTime29, 1);
//        java.lang.String str33 = gJChronology32.toString();
//        org.joda.time.Chronology chronology34 = gJChronology32.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology32.getZone();
//        org.joda.time.DateTime dateTime36 = dateTime21.toDateTime(dateTimeZone35);
//        org.joda.time.Chronology chronology37 = copticChronology0.withZone(dateTimeZone35);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "��:��:��.000" + "'", str7.equals("��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "16:00:00.100" + "'", str9.equals("16:00:00.100"));
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "00:00:00.035" + "'", str14.equals("00:00:00.035"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str33.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(chronology37);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTime7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (short) -1);
        org.joda.time.DateTime.Property property3 = dateTime0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = buddhistChronology5.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfDay(100, 62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfSecond(923, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay(2, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = buddhistChronology2.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone3);
        long long8 = dateTimeZone3.convertUTCToLocal((long) 62);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.era();
        org.joda.time.DurationField durationField11 = copticChronology9.hours();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799938L) + "'", long8 == (-28799938L));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.months();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.years();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        org.joda.time.DateTime dateTime4 = dateTime1.withZoneRetainFields(dateTimeZone3);
//        int int5 = dateTime1.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print(2562L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 28800035L + "'", long0 == 28800035L);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getHourOfDay();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusDays(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(15);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfWeek(4);
//        org.joda.time.DateTime.Property property12 = dateTime7.yearOfCentury();
//        java.lang.String str13 = property12.getAsString();
//        org.joda.time.DateTimeField dateTimeField14 = property12.getField();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13" + "'", str13.equals("13"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekOfWeekyear();
//        org.joda.time.DurationField durationField4 = buddhistChronology2.eras();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(chronology5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = buddhistChronology10.eras();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology10);
//        int int13 = dateTime12.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime12, 1);
//        int int16 = dateTime12.getYearOfCentury();
//        long long17 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTimeField dateTimeField18 = property7.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField18);
//        long long21 = skipDateTimeField19.roundCeiling((long) 62);
//        long long23 = skipDateTimeField19.roundHalfFloor((long) 1);
//        org.joda.time.DateTimeField dateTimeField24 = skipDateTimeField19.getWrappedField();
//        long long26 = skipDateTimeField19.roundHalfCeiling((long) (byte) 10);
//        long long28 = skipDateTimeField19.roundFloor((long) ' ');
//        int int31 = skipDateTimeField19.getDifference(35L, (long) 1970);
//        boolean boolean32 = iSOChronology0.equals((java.lang.Object) skipDateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone34);
//        org.joda.time.DurationField durationField36 = buddhistChronology35.eras();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology35);
//        int int38 = dateTime37.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime37, 1);
//        java.lang.String str41 = gJChronology40.toString();
//        org.joda.time.Chronology chronology42 = gJChronology40.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone43 = gJChronology40.getZone();
//        org.joda.time.Chronology chronology44 = iSOChronology0.withZone(dateTimeZone43);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]" + "'", str41.equals("GJChronology[America/Los_Angeles,cutover=1970-01-01T08:00:00.035Z,mdfw=1]"));
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(chronology44);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = dateTime3.getMinuteOfHour();
//        int int5 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime7 = dateTime3.plusWeeks(1);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMillis(2512);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime9.minusYears(180254);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2513 + "'", int5 == 2513);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) (byte) 10);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(365, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfSecond((int) '4');
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        boolean boolean2 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter1.parseMutableDateTime("2");
//        java.lang.StringBuffer stringBuffer5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        int[] intArray8 = localDate7.getValues();
//        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
//        java.lang.String str10 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) localDate7);
//        java.lang.String str12 = dateTimeFormatter6.print((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = buddhistChronology14.eras();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        java.lang.String str17 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        org.joda.time.DurationField durationField21 = buddhistChronology20.eras();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology20);
//        int int23 = dateTime22.getHourOfDay();
//        org.joda.time.DateTime dateTime24 = localDate18.toDateTime((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readableDuration25);
//        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str17, (java.lang.Object) dateTime24);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime24.toMutableDateTime(dateTimeZone28);
//        try {
//            dateTimeFormatter1.printTo(stringBuffer5, (org.joda.time.ReadableInstant) mutableDateTime29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "��:��:��.000" + "'", str10.equals("��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "16:00:00.100" + "'", str12.equals("16:00:00.100"));
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "00:00:00.035" + "'", str17.equals("00:00:00.035"));
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime4.withMonthOfYear(1);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        int[] intArray11 = localDate10.getValues();
//        org.joda.time.Partial partial12 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = partial12.getFormatter();
//        java.lang.String str14 = dateTime4.toString(dateTimeFormatter13);
//        org.joda.time.DateTime dateTime16 = dateTime4.withMillisOfDay(69);
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
//        boolean boolean19 = dateTime16.isAfter(1969L);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2513-01-01" + "'", str14.equals("2513-01-01"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        int int3 = property2.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        int[] intArray1 = localDate0.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
//        org.joda.time.Interval interval4 = localDate0.toInterval();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate0.getFieldTypes();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.weekOfWeekyear();
//        org.joda.time.DurationField durationField9 = buddhistChronology7.eras();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(chronology10);
//        org.joda.time.LocalDate.Property property12 = localDate11.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = buddhistChronology15.eras();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology15);
//        int int18 = dateTime17.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime17, 1);
//        int int21 = dateTime17.getYearOfCentury();
//        long long22 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeField dateTimeField23 = property12.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField23);
//        long long26 = skipDateTimeField24.roundCeiling((long) 62);
//        int int28 = skipDateTimeField24.get((long) (short) 0);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate();
//        int[] intArray30 = localDate29.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str32 = localDate29.toString(dateTimeFormatter31);
//        int int33 = localDate29.getYearOfCentury();
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate();
//        int[] intArray35 = localDate34.getValues();
//        int int36 = skipDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) localDate29, intArray35);
//        org.joda.time.Partial partial37 = new org.joda.time.Partial(dateTimeFieldTypeArray5, intArray35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
//        boolean boolean39 = partial37.isSupported(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(interval4);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "��:��:��" + "'", str32.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 365 + "'", int36 == 365);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate.Property property4 = localDate0.year();
        org.joda.time.LocalDate localDate5 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("15:23:28.966");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = remainderDateTimeField58.getAsText((long) 19, locale63);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2" + "'", str64.equals("2"));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(365, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        long long6 = dateTimeZone2.convertLocalToUTC((long) '#', false, (long) 2019);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800035L + "'", long6 == 28800035L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        int[] intArray2 = localDate1.getValues();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
        int[] intArray9 = localDate8.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str11 = localDate8.toString(dateTimeFormatter10);
        int int12 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.LocalDate localDate14 = localDate8.plusDays((int) (short) 10);
        int int15 = localDate14.getEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "��:��:��" + "'", str11.equals("��:��:��"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekOfWeekyear();
//        org.joda.time.DurationField durationField4 = buddhistChronology2.eras();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(chronology5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = buddhistChronology10.eras();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology10);
//        int int13 = dateTime12.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime12, 1);
//        int int16 = dateTime12.getYearOfCentury();
//        long long17 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTimeField dateTimeField18 = property7.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField18);
//        long long21 = skipDateTimeField19.roundCeiling((long) 62);
//        long long23 = skipDateTimeField19.roundHalfFloor((long) 1);
//        org.joda.time.DateTimeField dateTimeField24 = skipDateTimeField19.getWrappedField();
//        long long26 = skipDateTimeField19.roundHalfCeiling((long) (byte) 10);
//        long long28 = skipDateTimeField19.roundFloor((long) ' ');
//        int int31 = skipDateTimeField19.getDifference(35L, (long) 1970);
//        boolean boolean32 = iSOChronology0.equals((java.lang.Object) skipDateTimeField19);
//        java.lang.String str33 = iSOChronology0.toString();
//        java.lang.String str34 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[UTC]" + "'", str33.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[UTC]" + "'", str34.equals("ISOChronology[UTC]"));
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withFieldAdded(durationFieldType1, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.lang.String str63 = remainderDateTimeField58.getAsShortText(14L);
//        int int64 = remainderDateTimeField58.getDivisor();
//        long long67 = remainderDateTimeField58.add((long) (short) 0, 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(365, 100);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField3 = julianChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = buddhistChronology5.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.Chronology chronology9 = julianChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.Chronology chronology4 = instant0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime5 = instant0.toMutableDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 28800035L + "'", long1 == 28800035L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = buddhistChronology1.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = buddhistChronology5.eras();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(100L);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(99);
//        int int13 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
//        long long4 = dateTimeZone1.adjustOffset((long) '4', true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        long long7 = instant6.getMillis();
//        int int8 = cachedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Chronology chronology9 = instant6.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800035L + "'", long7 == 28800035L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertNotNull(chronology9);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfYear();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        int[] intArray9 = localDate8.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str11 = localDate8.toString(dateTimeFormatter10);
//        int int12 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.LocalDate localDate14 = localDate8.plusDays((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = buddhistChronology16.getZone();
//        boolean boolean19 = dateTimeZone17.isStandardOffset(10L);
//        java.lang.String str21 = dateTimeZone17.getName((long) (short) -1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17, 1);
//        long long28 = dateTimeZone17.convertLocalToUTC((long) 3, true, 0L);
//        org.joda.time.DateMidnight dateMidnight29 = localDate8.toDateMidnight(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "��:��:��" + "'", str11.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800003L + "'", long28 == 28800003L);
//        org.junit.Assert.assertNotNull(dateMidnight29);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        long long11 = gJChronology7.add((long) (byte) -1, (long) 15, (int) (short) 1);
//        org.joda.time.Partial partial12 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        java.lang.String str14 = partial12.toString(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 14L + "'", long11 == 14L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "������" + "'", str14.equals("������"));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        long long6 = dateTimeZone2.convertLocalToUTC((long) '#', false, (long) 2019);
        org.joda.time.Chronology chronology7 = gJChronology0.withZone(dateTimeZone2);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800035L + "'", long6 == 28800035L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
//        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
//        int int3 = property2.getMaximumValue();
//        java.lang.String str4 = property2.getAsText();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 365 + "'", int3 == 365);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "166" + "'", str4.equals("166"));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long4 = dateTimeZone1.adjustOffset((long) '4', true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology7);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) julianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = buddhistChronology14.eras();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = buddhistChronology22.eras();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        int int25 = dateTime24.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24, 1);
//        int int28 = dateTime24.getYearOfCentury();
//        long long29 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField dateTimeField30 = property19.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField30);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField30, (int) 'a');
//        int int34 = skipUndoDateTimeField33.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatterBuilder35.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekOfWeekyear();
//        org.joda.time.DurationField durationField42 = buddhistChronology40.eras();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
//        org.joda.time.LocalDate.Property property45 = localDate44.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = buddhistChronology48.eras();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology48);
//        int int51 = dateTime50.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime50, 1);
//        int int54 = dateTime50.getYearOfCentury();
//        long long55 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeField dateTimeField56 = property45.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField56);
//        long long59 = skipDateTimeField57.roundCeiling((long) 62);
//        int int61 = skipDateTimeField57.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = skipDateTimeField57.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType62);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField67 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType62, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property68 = localDate5.property(dateTimeFieldType62);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType62, (int) (short) 100);
//        long long72 = offsetDateTimeField70.roundHalfCeiling((long) 1970);
//        org.joda.time.Chronology chronology73 = null;
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(chronology73);
//        java.util.Locale locale76 = null;
//        java.lang.String str77 = offsetDateTimeField70.getAsText((org.joda.time.ReadablePartial) localDate74, 12, locale76);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 62 + "'", int28 == 62);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 62 + "'", int54 == 62);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "12" + "'", str77.equals("12"));
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        int int21 = skipDateTimeField18.getMaximumValue();
//        int int23 = skipDateTimeField18.getMaximumValue(0L);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate();
//        int[] intArray25 = localDate24.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str27 = localDate24.toString(dateTimeFormatter26);
//        org.joda.time.Interval interval28 = localDate24.toInterval();
//        java.lang.Class<?> wildcardClass29 = localDate24.getClass();
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property31 = localDate30.yearOfCentury();
//        java.util.Date date32 = localDate30.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        boolean boolean34 = localDate30.isSupported(dateTimeFieldType33);
//        int int35 = localDate30.getWeekyear();
//        int int36 = localDate24.compareTo((org.joda.time.ReadablePartial) localDate30);
//        int[] intArray42 = new int[] { (-28800000), 577, '#', 2562, '#' };
//        int int43 = skipDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate30, intArray42);
//        org.joda.time.LocalDate.Property property44 = localDate30.yearOfEra();
//        int int45 = property44.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 366 + "'", int21 == 366);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "��:��:��" + "'", str27.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(interval28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 366 + "'", int43 == 366);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.LocalDate.Property property3 = localDate2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.lang.String str63 = remainderDateTimeField58.getAsShortText(14L);
//        int int64 = remainderDateTimeField58.getDivisor();
//        int int65 = remainderDateTimeField58.getDivisor();
//        long long68 = remainderDateTimeField58.addWrapField(316800052L, 365);
//        long long70 = remainderDateTimeField58.roundHalfEven(16761600000L);
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate();
//        int[] intArray72 = localDate71.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str74 = localDate71.toString(dateTimeFormatter73);
//        org.joda.time.Interval interval75 = localDate71.toInterval();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray76 = localDate71.getFieldTypes();
//        org.joda.time.LocalDate.Property property77 = localDate71.monthOfYear();
//        org.joda.time.DurationField durationField78 = property77.getRangeDurationField();
//        long long81 = durationField78.subtract((long) 4, (int) (byte) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField58, durationField78, dateTimeFieldType82);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 62 + "'", int45 == 62);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 5932800052L + "'", long68 == 5932800052L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 16761600000L + "'", long70 == 16761600000L);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "��:��:��" + "'", str74.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(interval75);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 31536000004L + "'", long81 == 31536000004L);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate localDate5 = localDate0.withCenturyOfEra(0);
        org.joda.time.LocalDate.Property property6 = localDate5.era();
        int int7 = property6.getMinimumValueOverall();
        java.lang.String str8 = property6.getAsText();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AD" + "'", str8.equals("AD"));
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        java.lang.String str63 = remainderDateTimeField58.getAsShortText(14L);
//        int int64 = remainderDateTimeField58.getDivisor();
//        int int65 = remainderDateTimeField58.getDivisor();
//        java.lang.String str67 = remainderDateTimeField58.getAsShortText(0L);
//        long long69 = remainderDateTimeField58.roundHalfFloor((long) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 62 + "'", int45 == 62);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2" + "'", str67.equals("2"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((-78688109222000L), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78688109222000L + "'", long2 == 78688109222000L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        int int3 = property2.getMaximumValue();
        org.joda.time.LocalDate localDate4 = property2.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property2.getFieldType();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 365 + "'", int3 == 365);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        org.joda.time.DateTime dateTime4 = dateTime1.withZoneRetainFields(dateTimeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone3.getShortName((long) (byte) 1, locale6);
//        java.util.TimeZone timeZone8 = dateTimeZone3.toTimeZone();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone8);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.Chronology chronology4 = instant0.getChronology();
//        org.joda.time.Instant instant6 = instant0.plus((long) 6);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.Instant instant8 = instant0.plus(readableDuration7);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560637499810L + "'", long1 == 1560637499810L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant8);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.util.Date date1 = localDate0.toDate();
//        org.joda.time.LocalDate localDate3 = localDate0.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) julianChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekOfWeekyear();
//        org.joda.time.DurationField durationField11 = buddhistChronology9.eras();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(chronology12);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = buddhistChronology17.eras();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        int int20 = dateTime19.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime19, 1);
//        int int23 = dateTime19.getYearOfCentury();
//        long long24 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTimeField dateTimeField25 = property14.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology9, dateTimeField25);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology5, dateTimeField25, (int) 'a');
//        int int29 = skipUndoDateTimeField28.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatterBuilder30.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology35.weekOfWeekyear();
//        org.joda.time.DurationField durationField37 = buddhistChronology35.eras();
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(chronology38);
//        org.joda.time.LocalDate.Property property40 = localDate39.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
//        org.joda.time.DurationField durationField44 = buddhistChronology43.eras();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology43);
//        int int46 = dateTime45.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) dateTime45, 1);
//        int int49 = dateTime45.getYearOfCentury();
//        long long50 = property40.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeField dateTimeField51 = property40.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology35, dateTimeField51);
//        long long54 = skipDateTimeField52.roundCeiling((long) 62);
//        int int56 = skipDateTimeField52.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = skipDateTimeField52.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType57);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType57, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property63 = localDate0.property(dateTimeFieldType57);
//        org.joda.time.DateTime dateTime64 = localDate0.toDateTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime66 = dateTime64.withMillis(28800100L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 62 + "'", int23 == 62);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 62 + "'", int49 == 62);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 86400000L + "'", long54 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withTimeAtStartOfDay();
//        boolean boolean9 = dateTime7.isAfter((long) 'a');
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendHourOfDay(62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekOfWeekyear();
//        org.joda.time.DurationField durationField17 = buddhistChronology15.eras();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(chronology18);
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
//        org.joda.time.DurationField durationField24 = buddhistChronology23.eras();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology23);
//        int int26 = dateTime25.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime25, 1);
//        int int29 = dateTime25.getYearOfCentury();
//        long long30 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTimeField dateTimeField31 = property20.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField31);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology11, dateTimeField31, (int) 'a');
//        int int35 = dateTime8.get((org.joda.time.DateTimeField) skipUndoDateTimeField34);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 62 + "'", int29 == 62);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 176 + "'", int35 == 176);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("15:23:28.966", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15:23:28.966\" is malformed at \":23:28.966\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        int int24 = skipDateTimeField18.get(14L);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipDateTimeField18.getAsShortText((long) 70, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipDateTimeField18.getAsText(readablePartial28, (-1), locale30);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str6 = dateTimeFormatter0.print((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DurationField durationField9 = buddhistChronology8.eras();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology8);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = buddhistChronology14.eras();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology14);
//        int int17 = dateTime16.getHourOfDay();
//        org.joda.time.DateTime dateTime18 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readableDuration19);
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str11, (java.lang.Object) dateTime18);
//        int int22 = dateTime18.getMinuteOfHour();
//        int int23 = dateTime18.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "16:00:00.100" + "'", str6.equals("16:00:00.100"));
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15:25:00.969" + "'", str11.equals("15:25:00.969"));
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 25 + "'", int22 == 25);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 167 + "'", int23 == 167);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property10.getDateTime();
//        int int12 = property10.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 999 + "'", int12 == 999);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(923L, 1560643200000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = localDate0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime13 = property10.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        org.joda.time.LocalDate.Property property1 = localDate0.yearOfCentury();
//        java.util.Date date2 = localDate0.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = localDate0.isSupported(dateTimeFieldType3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekOfWeekyear();
//        org.joda.time.DurationField durationField12 = buddhistChronology10.eras();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(chronology13);
//        org.joda.time.LocalDate.Property property15 = localDate14.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.DurationField durationField19 = buddhistChronology18.eras();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology18);
//        int int21 = dateTime20.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) dateTime20, 1);
//        int int24 = dateTime20.getYearOfCentury();
//        long long25 = property15.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeField dateTimeField26 = property15.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField26);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology6, dateTimeField26, (int) 'a');
//        int int30 = skipUndoDateTimeField29.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatterBuilder31.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekOfWeekyear();
//        org.joda.time.DurationField durationField38 = buddhistChronology36.eras();
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(chronology39);
//        org.joda.time.LocalDate.Property property41 = localDate40.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
//        org.joda.time.DurationField durationField45 = buddhistChronology44.eras();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology44);
//        int int47 = dateTime46.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (org.joda.time.ReadableInstant) dateTime46, 1);
//        int int50 = dateTime46.getYearOfCentury();
//        long long51 = property41.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.DateTimeField dateTimeField52 = property41.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology36, dateTimeField52);
//        long long55 = skipDateTimeField53.roundCeiling((long) 62);
//        int int57 = skipDateTimeField53.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = skipDateTimeField53.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder31.appendText(dateTimeFieldType58);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField29, dateTimeFieldType58, (int) (byte) 100);
//        long long66 = remainderDateTimeField63.addWrapField((-78689146022000L), 12);
//        long long69 = remainderDateTimeField63.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int71 = remainderDateTimeField63.getMinimumValue((long) (short) 10);
//        long long73 = remainderDateTimeField63.roundCeiling((long) 180254);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = remainderDateTimeField63.getAsText(10, locale75);
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = remainderDateTimeField63.getType();
//        boolean boolean78 = localDate0.equals((java.lang.Object) dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 62 + "'", int24 == 62);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(buddhistChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 62 + "'", int50 == 62);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 86400000L + "'", long55 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-78688109222000L) + "'", long66 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 86400000L + "'", long73 == 86400000L);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "10" + "'", str76.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        int[] intArray1 = localDate0.getValues();
//        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate0);
//        java.lang.String str3 = partial2.toStringList();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.Partial partial5 = partial2.plus(readablePeriod4);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType7 = partial2.getFieldType(25);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[year=2019, monthOfYear=6, dayOfMonth=15]" + "'", str3.equals("[year=2019, monthOfYear=6, dayOfMonth=15]"));
//        org.junit.Assert.assertNotNull(partial5);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 1, (int) 'a', (int) (byte) 1, 0, 432000045, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 432000045 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
//        org.joda.time.LocalDate localDate8 = localDate6.withYearOfCentury(4);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = buddhistChronology10.eras();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology10);
//        int int13 = dateTime12.getMinuteOfHour();
//        int int14 = dateTime12.getYear();
//        org.joda.time.DateTime dateTime16 = dateTime12.plusWeeks(1);
//        org.joda.time.DateTime dateTime18 = dateTime12.plusMillis(2512);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(10);
//        org.joda.time.DateTime dateTime21 = localDate8.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 25 + "'", int13 == 25);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2562 + "'", int14 == 2562);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = buddhistChronology5.eras();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(chronology8);
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.eras();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15, 1);
//        int int19 = dateTime15.getYearOfCentury();
//        long long20 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeField dateTimeField21 = property10.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField21, (int) 'a');
//        int int25 = skipUndoDateTimeField24.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekOfWeekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.eras();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(chronology34);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DurationField durationField40 = buddhistChronology39.eras();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology39);
//        int int42 = dateTime41.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) dateTime41, 1);
//        int int45 = dateTime41.getYearOfCentury();
//        long long46 = property36.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTimeField dateTimeField47 = property36.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField47);
//        long long50 = skipDateTimeField48.roundCeiling((long) 62);
//        int int52 = skipDateTimeField48.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField48.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType53);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType53, (int) (byte) 100);
//        long long61 = remainderDateTimeField58.addWrapField((-78689146022000L), 12);
//        long long64 = remainderDateTimeField58.getDifferenceAsLong((long) 2000, (long) 2562);
//        int int66 = remainderDateTimeField58.getMinimumValue((long) (short) 10);
//        long long68 = remainderDateTimeField58.roundCeiling((long) 180254);
//        long long71 = remainderDateTimeField58.getDifferenceAsLong((long) ' ', 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 62 + "'", int45 == 62);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400000L + "'", long50 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-78688109222000L) + "'", long61 == (-78688109222000L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime9.withYear(365);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = buddhistChronology16.getZone();
//        boolean boolean19 = dateTimeZone17.isStandardOffset(10L);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), dateTimeZone17);
//        int int22 = dateTimeZone17.getOffsetFromLocal((long) 0);
//        org.joda.time.DateTime dateTime23 = dateTime12.toDateTime(dateTimeZone17);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, 2514);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2514");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.Chronology chronology4 = instant0.getChronology();
//        org.joda.time.Instant instant6 = instant0.plus((long) 6);
//        org.joda.time.Instant instant9 = instant6.withDurationAdded(28800100L, 365);
//        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560637502345L + "'", long1 == 1560637502345L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
        int int4 = localDate0.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate0.plusYears(366);
        org.joda.time.LocalDate localDate8 = localDate0.plusYears(4);
        java.lang.Class<?> wildcardClass9 = localDate0.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        int[] intArray6 = localDate5.getValues();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears((int) (short) -1);
//        org.joda.time.LocalDate localDate10 = localDate5.withCenturyOfEra(0);
//        org.joda.time.LocalDate localDate12 = localDate5.plusWeeks((int) (byte) 0);
//        org.joda.time.LocalDate localDate13 = localDate1.withFields((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekOfWeekyear();
//        org.joda.time.DurationField durationField17 = buddhistChronology15.eras();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(chronology18);
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
//        org.joda.time.DurationField durationField24 = buddhistChronology23.eras();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology23);
//        int int26 = dateTime25.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime25, 1);
//        int int29 = dateTime25.getYearOfCentury();
//        long long30 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTimeField dateTimeField31 = property20.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField31);
//        long long34 = skipDateTimeField32.roundCeiling((long) 62);
//        int int36 = skipDateTimeField32.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField32.getType();
//        org.joda.time.LocalDate localDate39 = localDate1.withField(dateTimeFieldType37, (int) ' ');
//        int int40 = localDate39.getYearOfCentury();
//        int int41 = localDate39.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 62 + "'", int29 == 62);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 86400000L + "'", long34 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        int int3 = partial0.size();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.joda.time.Partial partial8 = partial0.withChronologyRetainFields((org.joda.time.Chronology) gJChronology4);
        try {
            int int10 = partial0.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DurationField durationField4 = gJChronology0.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField6);
        org.joda.time.DurationField durationField8 = skipDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfHour((int) '4', 577);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(167, 6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.minus((long) 16);
//        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime5 = instant0.toMutableDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560637502760L + "'", long1 == 1560637502760L);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
        try {
            long long5 = durationField2.subtract((long) 2513, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(13, 0, 999, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(chronology0);
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfYear();
        java.lang.String str3 = property2.getName();
        boolean boolean4 = property2.isLeap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfYear" + "'", str3.equals("dayOfYear"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        int int5 = dateTime4.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 0);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = property10.roundCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', 2512);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendCenturyOfEra(19, 586);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(176, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int int2 = localDate0.getValue(0);
        org.joda.time.LocalDate localDate4 = localDate0.minusWeeks((-35));
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        int int6 = localDate4.getEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.LocalDate localDate3 = localDate0.plusYears((int) (short) -1);
        org.joda.time.LocalDate.Property property4 = localDate0.weekyear();
        java.lang.String str5 = property4.getName();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property4.getAsShortText(locale6);
        org.joda.time.LocalDate localDate9 = property4.addWrapFieldToCopy((-292275054));
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "weekyear" + "'", str5.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = buddhistChronology2.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone3);
        long long8 = dateTimeZone3.convertUTCToLocal((long) 62);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        java.lang.String str10 = copticChronology9.toString();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799938L) + "'", long8 == (-28799938L));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str10.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', 2512);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendCenturyOfEra(10, 923);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra((int) '#', 2512);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder7.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekOfWeekyear();
//        org.joda.time.DurationField durationField14 = buddhistChronology12.eras();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(chronology15);
//        org.joda.time.LocalDate.Property property17 = localDate16.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
//        org.joda.time.DurationField durationField21 = buddhistChronology20.eras();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology20);
//        int int23 = dateTime22.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) dateTime22, 1);
//        int int26 = dateTime22.getYearOfCentury();
//        long long27 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTimeField dateTimeField28 = property17.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology12, dateTimeField28);
//        long long31 = skipDateTimeField29.roundCeiling((long) 62);
//        int int33 = skipDateTimeField29.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField29.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType34);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType34, 15);
//        try {
//            org.joda.time.Partial partial41 = new org.joda.time.Partial(dateTimeFieldType34, (-2513));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2513 for dayOfYear must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 62 + "'", int26 == 62);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 86400000L + "'", long31 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) julianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = buddhistChronology14.eras();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = buddhistChronology22.eras();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        int int25 = dateTime24.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24, 1);
//        int int28 = dateTime24.getYearOfCentury();
//        long long29 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField dateTimeField30 = property19.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField30);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField30, (int) 'a');
//        int int34 = skipUndoDateTimeField33.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatterBuilder35.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekOfWeekyear();
//        org.joda.time.DurationField durationField42 = buddhistChronology40.eras();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
//        org.joda.time.LocalDate.Property property45 = localDate44.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = buddhistChronology48.eras();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology48);
//        int int51 = dateTime50.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime50, 1);
//        int int54 = dateTime50.getYearOfCentury();
//        long long55 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeField dateTimeField56 = property45.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField56);
//        long long59 = skipDateTimeField57.roundCeiling((long) 62);
//        int int61 = skipDateTimeField57.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = skipDateTimeField57.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType62);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField67 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType62, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property68 = localDate5.property(dateTimeFieldType62);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType62, (int) (short) 100);
//        long long72 = offsetDateTimeField70.roundHalfCeiling((long) 1970);
//        long long74 = offsetDateTimeField70.remainder(1560637502760L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 62 + "'", int28 == 62);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 62 + "'", int54 == 62);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1502760L + "'", long74 == 1502760L);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.eras();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(chronology4);
//        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime11, 1);
//        int int15 = dateTime11.getYearOfCentury();
//        long long16 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeField dateTimeField17 = property6.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField17);
//        long long20 = skipDateTimeField18.roundCeiling((long) 62);
//        long long22 = skipDateTimeField18.roundHalfFloor((long) 1);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = skipDateTimeField18.getAsShortText((int) (short) 0, locale24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipDateTimeField18.getAsShortText((int) (byte) 0, locale27);
//        boolean boolean29 = skipDateTimeField18.isLenient();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400000L + "'", long20 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        int[] intArray2 = localDate1.getValues();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.eras();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        int int12 = dateTime11.getHourOfDay();
//        org.joda.time.DateTime dateTime13 = localDate7.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = buddhistChronology15.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime11.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime21 = localDate1.toDateTime((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property22 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime23 = property22.withMinimumValue();
//        org.joda.time.DateTime dateTime25 = dateTime23.withMinuteOfHour(16);
//        int int26 = dateTime23.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��:��:��.000" + "'", str4.equals("��:��:��.000"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 925 + "'", int26 == 925);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.hourOfHalfday();
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        java.util.Date date6 = localDate5.toDate();
//        org.joda.time.LocalDate localDate8 = localDate5.plusYears(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) julianChronology10);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekOfWeekyear();
//        org.joda.time.DurationField durationField16 = buddhistChronology14.eras();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = buddhistChronology22.eras();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        int int25 = dateTime24.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24, 1);
//        int int28 = dateTime24.getYearOfCentury();
//        long long29 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField dateTimeField30 = property19.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField30);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField30, (int) 'a');
//        int int34 = skipUndoDateTimeField33.getMinimumValue();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatterBuilder35.toFormatter();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekOfWeekyear();
//        org.joda.time.DurationField durationField42 = buddhistChronology40.eras();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
//        org.joda.time.LocalDate.Property property45 = localDate44.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = buddhistChronology48.eras();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology48);
//        int int51 = dateTime50.getHourOfDay();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime50, 1);
//        int int54 = dateTime50.getYearOfCentury();
//        long long55 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeField dateTimeField56 = property45.getField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField56);
//        long long59 = skipDateTimeField57.roundCeiling((long) 62);
//        int int61 = skipDateTimeField57.get((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = skipDateTimeField57.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, "15:23:28.966");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType62);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField67 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, dateTimeFieldType62, (int) (byte) 100);
//        org.joda.time.LocalDate.Property property68 = localDate5.property(dateTimeFieldType62);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType62, (int) (short) 100);
//        try {
//            long long73 = offsetDateTimeField70.set(0L, 13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for dayOfYear must be in the range [100,111]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 62 + "'", int28 == 62);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 62 + "'", int54 == 62);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 86400000L + "'", long59 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//        org.junit.Assert.assertNotNull(property68);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        int[] intArray3 = localDate2.getValues();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str5 = localDate2.toString(dateTimeFormatter4);
//        org.joda.time.Interval interval6 = localDate2.toInterval();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = localDate2.getFieldTypes();
//        org.joda.time.LocalDate.Property property8 = localDate2.monthOfYear();
//        org.joda.time.LocalDate localDate10 = localDate2.withDayOfMonth((int) (short) 10);
//        int int11 = localDate2.getDayOfMonth();
//        int int12 = localDate2.getCenturyOfEra();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "��:��:��" + "'", str5.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(interval6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfDay(100, 62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfSecond(923, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendClockhourOfDay(2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfHour(2562, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfDay(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int[] intArray1 = localDate0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str3 = localDate0.toString(dateTimeFormatter2);
        int int4 = localDate0.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate0.plusYears(366);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone8);
        org.joda.time.DateMidnight dateMidnight11 = localDate6.toDateMidnight(dateTimeZone8);
        long long14 = dateTimeZone8.convertLocalToUTC((long) 176, true);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "��:��:��" + "'", str3.equals("��:��:��"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 76L + "'", long14 == 76L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = copticChronology1.months();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
        boolean boolean4 = copticChronology1.equals((java.lang.Object) localDate3);
        try {
            long long12 = copticChronology1.getDateTimeMillis(167, 35, 25, 0, 180254, 81, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 180254 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}

