import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        long long29 = unsupportedDurationField28.getUnitMillis();
        long long30 = unsupportedDurationField28.getUnitMillis();
        java.lang.String str31 = unsupportedDurationField28.toString();
        try {
            long long34 = unsupportedDurationField28.getDifferenceAsLong((long) 56, (-522547199996400000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDurationField[years]" + "'", str31.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        long long36 = dividedDateTimeField33.set(50L, 0);
        try {
            long long39 = dividedDateTimeField33.set(187200134L, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for clockhourOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 50L + "'", long36 == 50L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long16 = offsetDateTimeField5.add((-2L), 99);
        boolean boolean17 = offsetDateTimeField5.isLenient();
        long long19 = offsetDateTimeField5.roundHalfFloor(22L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 356399998L + "'", long16 == 356399998L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Period period13 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period15 = period13.withDays((int) ' ');
        org.joda.time.Period period17 = period15.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationFrom(readableInstant18);
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        boolean boolean27 = period15.isSupported(durationFieldType26);
        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) boolean27);
        boolean boolean29 = fixedDateTimeZone4.isFixed();
        boolean boolean30 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology2.millis();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", number1, number2, number3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) number1, chronology7);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[-00:00:00.001]", "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.toString();
        java.lang.String str30 = unsupportedDurationField28.toString();
        java.lang.String str31 = unsupportedDurationField28.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDurationField[years]" + "'", str29.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 36000000L, "34");
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = illegalFieldValueException22.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray24 = illegalFieldValueException22.getSuppressed();
        java.lang.Throwable[] throwableArray25 = illegalFieldValueException22.getSuppressed();
        java.lang.Number number26 = illegalFieldValueException22.getLowerBound();
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        java.lang.Throwable[] throwableArray28 = illegalFieldValueException17.getSuppressed();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1 + "'", number26.equals(1));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long10 = preciseDurationField9.getUnitMillis();
        boolean boolean11 = preciseDurationField9.isPrecise();
        long long14 = preciseDurationField9.getDifferenceAsLong((-10L), 1560626482282L);
        long long16 = preciseDurationField9.getMillis(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-780313241146L) + "'", long14 == (-780313241146L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        jodaTimePermission1.checkGuard((java.lang.Object) periodType3);
        java.lang.String str5 = jodaTimePermission1.getName();
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean10 = dateTimeZone8.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((long) (short) 10);
        int int15 = cachedDateTimeZone11.getStandardOffset((long) (byte) 100);
        int int17 = cachedDateTimeZone11.getOffsetFromLocal(2440588L);
        org.joda.time.Chronology chronology18 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        long long20 = cachedDateTimeZone11.previousTransition((long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType8 = periodType5.withHoursRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(10L, (long) '4', periodType8);
        int int10 = period9.size();
        int int11 = period9.getWeeks();
        org.joda.time.Period period12 = period9.negated();
        try {
            int int14 = period9.getValue(89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology11);
        int[] intArray16 = period15.getValues();
        int int17 = offsetDateTimeField5.getMaximumValue(readablePartial9, intArray16);
        long long19 = offsetDateTimeField5.roundCeiling((-522547199999999948L));
        long long21 = offsetDateTimeField5.roundHalfCeiling((long) (short) 0);
        long long23 = offsetDateTimeField5.remainder(82800100L);
        boolean boolean25 = offsetDateTimeField5.isLeap((long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-522547199996400000L) + "'", long19 == (-522547199996400000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        java.lang.String str79 = unsupportedDateTimeField76.getName();
//        try {
//            int int81 = unsupportedDateTimeField76.getLeapAmount((long) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "clockhourOfDay" + "'", str79.equals("clockhourOfDay"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
        int int6 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology4.getZone();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType6 = periodType3.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        long long5 = iSOChronology0.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField6 = iSOChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        long long11 = dateTimeZone8.adjustOffset(2440588L, false);
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        int int19 = cachedDateTimeZone17.getOffset((long) (short) 10);
        int int21 = cachedDateTimeZone17.getStandardOffset((long) (byte) 100);
        int int23 = cachedDateTimeZone17.getOffset(4L);
        long long26 = cachedDateTimeZone17.convertLocalToUTC((long) 8, true);
        long long28 = cachedDateTimeZone17.previousTransition((-59107967999900L));
        long long30 = cachedDateTimeZone17.previousTransition((long) (short) 100);
        org.joda.time.Chronology chronology31 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2440588L + "'", long11 == 2440588L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 8L + "'", long26 == 8L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-59107967999900L) + "'", long28 == (-59107967999900L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DurationField durationField3 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((long) '4', 0, (int) 'a', (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        org.joda.time.DurationField durationField35 = dividedDateTimeField33.getDurationField();
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 10);
        long long46 = offsetDateTimeField43.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.secondOfDay();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology49.hourOfDay();
        org.joda.time.Period period53 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology49);
        int[] intArray54 = period53.getValues();
        int int55 = offsetDateTimeField43.getMaximumValue(readablePartial47, intArray54);
        java.util.Locale locale57 = null;
        try {
            int[] intArray58 = dividedDateTimeField33.set(readablePartial36, 10, intArray54, "GregorianChronology[-00:00:00.001]", locale57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[-00:00:00.001]\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1704L + "'", long46 == 1704L);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 34 + "'", int55 == 34);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray10 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField5 = iSOChronology3.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology7 = lenientChronology6.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DurationField durationField12 = iSOChronology10.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.era();
        org.joda.time.DurationField durationField15 = iSOChronology10.days();
        boolean boolean16 = lenientChronology6.equals((java.lang.Object) durationField15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        int int23 = cachedDateTimeZone21.getOffset((long) (short) 10);
        int int25 = cachedDateTimeZone21.getStandardOffset((long) (byte) 100);
        int int27 = cachedDateTimeZone21.getOffset(4L);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.Chronology chronology29 = lenientChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        int int31 = cachedDateTimeZone21.getStandardOffset((long) 99);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        long long12 = fixedDateTimeZone4.previousTransition((long) 'a');
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone4.getName(200L, locale16);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        long long17 = offsetDateTimeField5.add(0L, 10L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType24 = periodType23.withHoursRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant21, readableDuration22, periodType24);
        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType24);
        org.joda.time.PeriodType periodType27 = periodType24.withHoursRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(10L, (long) '4', periodType27);
        int[] intArray29 = period28.getValues();
        int int30 = offsetDateTimeField5.getMinimumValue(readablePartial18, intArray29);
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        boolean boolean40 = offsetDateTimeField38.isLeap(8L);
        boolean boolean41 = offsetDateTimeField38.isSupported();
        java.lang.String str42 = offsetDateTimeField38.getName();
        int int44 = offsetDateTimeField38.getLeapAmount((long) 8);
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology47.hourOfDay();
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology47);
        int[] intArray52 = period51.getValues();
        int int53 = offsetDateTimeField38.getMaximumValue(readablePartial45, intArray52);
        try {
            int[] intArray55 = offsetDateTimeField5.set(readablePartial31, 152, intArray52, 197);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 197 for clockhourOfDay must be in the range [11,34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 36000000L + "'", long17 == 36000000L);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "clockhourOfDay" + "'", str42.equals("clockhourOfDay"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 34 + "'", int53 == 34);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.addWrapField(52L, (int) (byte) 1);
        int int10 = offsetDateTimeField5.getLeapAmount((long) (short) 10);
        long long12 = offsetDateTimeField5.roundHalfFloor(134L);
        long long14 = offsetDateTimeField5.roundCeiling(107L);
        long long17 = offsetDateTimeField5.add(0L, 1704L);
        java.lang.String str18 = offsetDateTimeField5.toString();
        long long20 = offsetDateTimeField5.roundFloor(21772800000000010L);
        long long23 = offsetDateTimeField5.set((-10965067027200000L), 11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600052L + "'", long8 == 3600052L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 6134400000L + "'", long17 == 6134400000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str18.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 21772800000000000L + "'", long20 == 21772800000000000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-10965067023600000L) + "'", long23 == (-10965067023600000L));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsText(1, locale16);
        int int19 = offsetDateTimeField5.get(52L);
        boolean boolean21 = offsetDateTimeField5.isLeap(40L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 34 + "'", int19 == 34);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period3 = period1.withDays((int) ' ');
        org.joda.time.Period period5 = period3.minusMinutes((-1));
        org.joda.time.Period period7 = period3.plusMillis((int) (short) 0);
        org.joda.time.Period period9 = period7.withMinutes(7);
        org.joda.time.Period period11 = period7.withMonths(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.Period period4 = new org.joda.time.Period(101, (int) (byte) 100, 27, (int) '#');
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        java.lang.String str13 = illegalFieldValueException12.getIllegalStringValue();
        java.lang.String str14 = illegalFieldValueException12.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Number number16 = illegalFieldValueException12.getUpperBound();
        java.lang.Number number17 = illegalFieldValueException12.getLowerBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) 100 + "'", number16.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        long long15 = dateTimeZone4.convertUTCToLocal(2440588L);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone4, (-1L));
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone1.getShortName((long) (-1), locale19);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        int int22 = dateTimeZone1.getOffset(readableInstant21);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2440588L + "'", long15 == 2440588L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2L) + "'", long17 == (-2L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DurationFieldType durationFieldType18 = null;
//        int int19 = period15.indexOf(durationFieldType18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType23 = periodType22.withHoursRemoved();
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant20, readableInstant21, periodType23);
//        org.joda.time.Period period25 = period15.normalizedStandard(periodType23);
//        int int26 = period15.getWeeks();
//        org.joda.time.Period period28 = period15.minusMinutes(7);
//        int[] intArray31 = iSOChronology0.get((org.joda.time.ReadablePeriod) period15, (-99L), (-210866673600000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(intArray31);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Period period4 = new org.joda.time.Period(52, (int) (short) 100, 152, (int) ' ');
        org.joda.time.Period period6 = period4.plusWeeks(0);
        org.junit.Assert.assertNotNull(period6);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.Chronology chronology23 = gregorianChronology20.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsText(1, locale16);
        long long19 = offsetDateTimeField5.roundHalfCeiling(63244800000L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField5.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 63244800000L + "'", long19 == 63244800000L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period3 = period1.minusYears((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableDuration5, periodType6);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.joda.time.Period period10 = period8.withWeeks(10);
        org.joda.time.Period period12 = period10.plusMonths((int) (short) 0);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        org.joda.time.Period period15 = period13.minusWeeks((-1));
        org.joda.time.Period period17 = period15.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType19 = period17.getFieldType(0);
        int int20 = period12.get(durationFieldType19);
        boolean boolean21 = period3.isSupported(durationFieldType19);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType19);
        try {
            long long25 = unsupportedDurationField22.getValueAsLong((long) (short) 1, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        int int5 = period3.getValue(0);
        org.joda.time.Period period7 = period3.plusSeconds((int) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period3.toDurationFrom(readableInstant8);
        org.joda.time.Period period11 = org.joda.time.Period.weeks((int) (byte) 0);
        org.joda.time.Period period12 = period3.plus((org.joda.time.ReadablePeriod) period11);
        int int13 = period11.getSeconds();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("52");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '52' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfHalfday();
        long long7 = iSOChronology2.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ', periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        int int15 = fixedDateTimeZone13.getOffsetFromLocal((long) 34);
        org.joda.time.Chronology chronology16 = iSOChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone10 = fixedDateTimeZone9.toTimeZone();
        int int12 = fixedDateTimeZone9.getOffsetFromLocal((-60507817129998L));
        int int14 = fixedDateTimeZone9.getOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant17, readableDuration18, periodType20);
        org.joda.time.PeriodType periodType22 = periodType20.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        long long27 = dateTimeZone24.adjustOffset(2440588L, false);
        boolean boolean28 = periodType20.equals((java.lang.Object) long27);
        org.joda.time.ReadableInterval readableInterval29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
        boolean boolean31 = periodType20.equals((java.lang.Object) readableInterval29);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.dayOfWeek();
        org.joda.time.Period period34 = new org.joda.time.Period((long) 0, periodType20, (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.Period period36 = period34.minusMonths((int) (byte) 0);
        int[] intArray38 = zonedChronology15.get((org.joda.time.ReadablePeriod) period36, 80L);
        java.lang.String str39 = zonedChronology15.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2440588L + "'", long27 == 2440588L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ZonedChronology[ISOChronology[UTC], -00:00:00.001]" + "'", str39.equals("ZonedChronology[ISOChronology[UTC], -00:00:00.001]"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Period period4 = new org.joda.time.Period(4, 10, (int) (short) 1, 1);
        int int5 = period4.getWeeks();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.time();
        java.lang.Object obj9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period(obj9, periodType10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) -1, 10L, periodType8, (org.joda.time.Chronology) gregorianChronology13);
        int int16 = periodType8.size();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', chronology20);
        org.joda.time.Period period23 = period21.plusMinutes(0);
        int int24 = period21.getMillis();
        org.joda.time.Period period25 = org.joda.time.Period.ZERO;
        org.joda.time.Period period27 = period25.minusWeeks((-1));
        org.joda.time.Period period29 = period27.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType31 = period29.getFieldType(0);
        int int32 = period21.get(durationFieldType31);
        int int33 = periodType8.indexOf(durationFieldType31);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType31);
        int int35 = period4.indexOf(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.lang.String str77 = unsupportedDateTimeField76.getName();
//        org.joda.time.ReadablePartial readablePartial78 = null;
//        try {
//            int int79 = unsupportedDateTimeField76.getMaximumValue(readablePartial78);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "clockhourOfDay" + "'", str77.equals("clockhourOfDay"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long10 = preciseDurationField9.getUnitMillis();
        long long12 = preciseDurationField9.getMillis(100);
        long long15 = preciseDurationField9.getMillis((int) (short) 1, 50L);
        long long18 = preciseDurationField9.getMillis((-316800000L), 97052L);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.hourOfHalfday();
        long long24 = iSOChronology19.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField25 = iSOChronology19.weekyears();
        int int26 = preciseDurationField9.compareTo(durationField25);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 200L + "'", long12 == 200L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-633600000L) + "'", long18 == (-633600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.joda.time.ReadablePartial readablePartial0 = null;
//        org.joda.time.ReadablePartial readablePartial1 = null;
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str9 = dateTimeZone7.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str13 = dateTimeZone11.getShortName((long) '4');
//        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone11, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology16.getZone();
//        org.joda.time.Period period18 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period20 = period18.normalizedStandard(periodType19);
//        boolean boolean21 = jodaTimePermission3.equals((java.lang.Object) periodType19);
//        org.joda.time.PeriodType periodType22 = periodType19.withDaysRemoved();
//        org.joda.time.PeriodType periodType23 = periodType19.withDaysRemoved();
//        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
//        try {
//            org.joda.time.Period period25 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertNotNull(period20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertNotNull(periodType24);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
        long long12 = offsetDateTimeField9.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText((long) (byte) 100, locale14);
        java.lang.String str17 = offsetDateTimeField9.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "");
        java.lang.Number number21 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, number21, (java.lang.Number) (-216733233600000L), (java.lang.Number) (-210866673600000L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType18, 98);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1704L + "'", long12 == 1704L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "34" + "'", str15.equals("34"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "33" + "'", str17.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.lang.String str77 = unsupportedDateTimeField76.getName();
//        org.joda.time.ReadablePartial readablePartial78 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField82 = iSOChronology81.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField83 = iSOChronology81.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField84 = iSOChronology81.hourOfDay();
//        org.joda.time.Period period85 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology81);
//        int[] intArray86 = period85.getValues();
//        try {
//            int[] intArray88 = unsupportedDateTimeField76.addWrapPartial(readablePartial78, 33, intArray86, 152);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "clockhourOfDay" + "'", str77.equals("clockhourOfDay"));
//        org.junit.Assert.assertNotNull(iSOChronology81);
//        org.junit.Assert.assertNotNull(dateTimeField82);
//        org.junit.Assert.assertNotNull(dateTimeField83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(intArray86);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        long long44 = offsetDateTimeField41.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField41.getAsText((long) (byte) 100, locale46);
        java.lang.String str49 = offsetDateTimeField41.getAsText((-1L));
        long long52 = offsetDateTimeField41.add((-2L), 99);
        long long55 = offsetDateTimeField41.add(134L, (int) '4');
        int int57 = offsetDateTimeField41.get(2L);
        long long59 = offsetDateTimeField41.roundCeiling((long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology62.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology62.hourOfDay();
        org.joda.time.Period period66 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology62);
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.PeriodType periodType71 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType72 = periodType71.withHoursRemoved();
        org.joda.time.Period period73 = new org.joda.time.Period(readableInstant69, readableDuration70, periodType72);
        org.joda.time.PeriodType periodType74 = org.joda.time.DateTimeUtils.getPeriodType(periodType72);
        org.joda.time.PeriodType periodType75 = periodType72.withMillisRemoved();
        org.joda.time.Period period76 = org.joda.time.Period.ZERO;
        org.joda.time.Period period78 = period76.minusWeeks((-1));
        org.joda.time.Period period80 = period78.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType82 = period80.getFieldType(0);
        boolean boolean83 = periodType72.isSupported(durationFieldType82);
        org.joda.time.PeriodType periodType84 = org.joda.time.DateTimeUtils.getPeriodType(periodType72);
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType72, chronology85);
        int[] intArray88 = iSOChronology62.get((org.joda.time.ReadablePeriod) period86, 0L);
        int int89 = offsetDateTimeField41.getMinimumValue(readablePartial60, intArray88);
        int int90 = dividedDateTimeField33.getMinimumValue(readablePartial35, intArray88);
        long long93 = dividedDateTimeField33.set((-31622399L), (int) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1704L + "'", long44 == 1704L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "34" + "'", str47.equals("34"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "33" + "'", str49.equals("33"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 356399998L + "'", long52 == 356399998L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 187200134L + "'", long55 == 187200134L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 34 + "'", int57 == 34);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(period78);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(durationFieldType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(periodType84);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 31417977601L + "'", long93 == 31417977601L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.time();
        java.lang.Object obj4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Period period9 = new org.joda.time.Period(obj4, periodType5, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) -1, 10L, periodType3, (org.joda.time.Chronology) gregorianChronology8);
        int int11 = periodType3.size();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        int int19 = period16.getMillis();
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        int int27 = period16.get(durationFieldType26);
        int int28 = periodType3.indexOf(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        java.lang.String str30 = unsupportedDurationField29.getName();
        org.joda.time.DurationFieldType durationFieldType31 = unsupportedDurationField29.getType();
        boolean boolean32 = periodType0.isSupported(durationFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType31, "-00:00:00.001");
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(durationFieldType31, (java.lang.Number) 4, (java.lang.Number) 100000L, (java.lang.Number) 56);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        long long37 = dividedDateTimeField33.addWrapField((-6134400000L), 34);
        long long40 = dividedDateTimeField33.addWrapField((long) (short) -1, 58);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-6134400000L) + "'", long37 == (-6134400000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology4.getZone();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str3 = dateTimeZone1.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str7 = dateTimeZone5.getShortName((long) '4');
//        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        long long14 = dateTimeZone5.convertLocalToUTC((long) (short) 0, true, 0L);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone5.isLocalDateTimeGap(localDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 0, 187200134L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-187200134L) + "'", long2 == (-187200134L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone10 = fixedDateTimeZone9.toTimeZone();
        int int12 = fixedDateTimeZone9.getOffsetFromLocal((-60507817129998L));
        int int14 = fixedDateTimeZone9.getOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        long long36 = dividedDateTimeField33.set(50L, 0);
        long long38 = dividedDateTimeField33.remainder(637200000L);
        long long40 = dividedDateTimeField33.remainder((long) 89);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 50L + "'", long36 == 50L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 637200000L + "'", long38 == 637200000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 89L + "'", long40 == 89L);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        try {
//            long long80 = unsupportedDateTimeField76.roundFloor((long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.dayOfWeek();
        long long11 = lenientChronology5.getDateTimeMillis((int) 'a', 0, (int) (short) 10, (int) (short) 100);
        org.joda.time.DurationField durationField12 = lenientChronology5.millis();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType16);
        boolean boolean18 = lenientChronology5.equals((java.lang.Object) readableInstant13);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59107967999900L) + "'", long11 == (-59107967999900L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 10, (-6048000000L), periodType2, (org.joda.time.Chronology) gregorianChronology5);
        int int7 = period6.getMonths();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period6.toDurationFrom(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", "-00:00:00.001");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale8 = null;
        java.lang.String str11 = defaultNameProvider0.getShortName(locale8, "34", "-1");
        java.util.Locale locale12 = null;
        java.lang.String str15 = defaultNameProvider0.getName(locale12, "33", "GregorianChronology[-00:00:00.001]");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfHalfday();
        long long7 = iSOChronology2.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField8 = iSOChronology2.weekyears();
        org.joda.time.DurationField durationField9 = iSOChronology2.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.millisOfSecond();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (byte) 100, (long) (byte) 100, (org.joda.time.Chronology) iSOChronology2);
        java.lang.String str12 = iSOChronology2.toString();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 100);
        int int2 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Seconds seconds6 = period5.toStandardSeconds();
        org.joda.time.Period period8 = period5.plusWeeks((int) 'a');
        org.joda.time.MutablePeriod mutablePeriod9 = period8.toMutablePeriod();
        org.joda.time.Period period10 = period8.toPeriod();
        int[] intArray11 = period8.getValues();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 101, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.lang.String str77 = unsupportedDateTimeField76.getName();
//        org.joda.time.ReadablePartial readablePartial78 = null;
//        java.util.Locale locale80 = null;
//        try {
//            java.lang.String str81 = unsupportedDateTimeField76.getAsText(readablePartial78, 99, locale80);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "clockhourOfDay" + "'", str77.equals("clockhourOfDay"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = periodType5.indexOf(durationFieldType6);
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period11 = period9.minusYears((int) (short) 1);
        org.joda.time.Period period13 = period9.withSeconds((int) (byte) -1);
        org.joda.time.Period period15 = period9.multipliedBy(56);
        boolean boolean16 = periodType5.equals((java.lang.Object) 56);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.hourOfHalfday();
        long long22 = iSOChronology17.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField23 = iSOChronology17.weekyears();
        boolean boolean24 = periodType5.equals((java.lang.Object) durationField23);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
        long long32 = offsetDateTimeField29.roundHalfCeiling((long) 33);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 946684800000L + "'", long32 == 946684800000L);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test069");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone24);
//        java.lang.String str27 = gregorianChronology20.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str27.equals("GregorianChronology[-00:00:00.001]"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Seconds seconds6 = period5.toStandardSeconds();
        org.joda.time.Period period8 = period5.plusWeeks((int) 'a');
        org.joda.time.MutablePeriod mutablePeriod9 = period8.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        org.joda.time.Period period12 = period10.minusWeeks((-1));
        org.joda.time.Period period14 = period12.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType16 = period14.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType16, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField19 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        int int20 = period8.indexOf(durationFieldType16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(unsupportedDurationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("22", "");
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period8 = period4.plusHours((int) '4');
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant9, readableDuration10, periodType12);
        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.joda.time.PeriodType periodType15 = periodType12.withMillisRemoved();
        org.joda.time.Period period16 = org.joda.time.Period.ZERO;
        org.joda.time.Period period18 = period16.minusWeeks((-1));
        org.joda.time.Period period20 = period18.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType22 = period20.getFieldType(0);
        boolean boolean23 = periodType12.isSupported(durationFieldType22);
        org.joda.time.field.PreciseDurationField preciseDurationField25 = new org.joda.time.field.PreciseDurationField(durationFieldType22, 48L);
        boolean boolean26 = period8.isSupported(durationFieldType22);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        try {
//            long long81 = unsupportedDateTimeField76.set(21772800000000000L, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.addWrapField(52L, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial9, intArray10);
        java.util.Locale locale14 = null;
        try {
            long long15 = offsetDateTimeField5.set((-10965067027200000L), "P-99D", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"P-99D\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600052L + "'", long8 == 3600052L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        long long39 = offsetDateTimeField36.addWrapField(52L, (int) (byte) 1);
        int int41 = offsetDateTimeField36.getLeapAmount((long) (short) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor(134L);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField36.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField30, dateTimeFieldType44, (int) (byte) 10);
        long long49 = dividedDateTimeField46.add((-99L), (int) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600052L + "'", long39 == 3600052L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1104493363199901L + "'", long49 == 1104493363199901L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.toString();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.hourOfHalfday();
        long long35 = iSOChronology30.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField36 = iSOChronology30.halfdays();
        long long39 = durationField36.subtract((-1L), 0L);
        int int40 = unsupportedDurationField28.compareTo(durationField36);
        long long41 = unsupportedDurationField28.getUnitMillis();
        try {
            int int44 = unsupportedDurationField28.getValue((-6134400000L), 52L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDurationField[years]" + "'", str29.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long16 = offsetDateTimeField5.add((-2L), 99);
        long long19 = offsetDateTimeField5.add(134L, (int) '4');
        long long21 = offsetDateTimeField5.roundCeiling(3600052L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 356399998L + "'", long16 == 356399998L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 187200134L + "'", long19 == 187200134L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200000L + "'", long21 == 7200000L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology11);
        int[] intArray16 = period15.getValues();
        int int17 = offsetDateTimeField5.getMaximumValue(readablePartial9, intArray16);
        long long19 = offsetDateTimeField5.roundCeiling(107L);
        boolean boolean20 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.era();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        java.lang.String str79 = unsupportedDateTimeField76.getName();
//        org.joda.time.ReadablePartial readablePartial80 = null;
//        int[] intArray82 = null;
//        try {
//            int[] intArray84 = unsupportedDateTimeField76.addWrapPartial(readablePartial80, (int) (byte) 0, intArray82, (-97));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "clockhourOfDay" + "'", str79.equals("clockhourOfDay"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) (byte) 100);
        int int4 = period3.getWeeks();
        org.joda.time.Weeks weeks5 = period3.toStandardWeeks();
        org.joda.time.Period period6 = period1.plus((org.joda.time.ReadablePeriod) weeks5);
        org.joda.time.Period period8 = period6.plusHours((int) '#');
        org.joda.time.PeriodType periodType9 = period6.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(weeks5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long10 = preciseDurationField9.getUnitMillis();
        long long11 = preciseDurationField9.getUnitMillis();
        long long14 = preciseDurationField9.getDifferenceAsLong(0L, 19L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9L) + "'", long14 == (-9L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 10, '#', (int) '4', (int) (byte) 1, (int) (short) -1, false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("Coordinated Universal Time", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder8.setStandardOffset((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField7 = iSOChronology5.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = lenientChronology8.dayOfWeek();
        long long14 = lenientChronology8.getDateTimeMillis((int) 'a', 0, (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField15 = lenientChronology8.yearOfCentury();
        org.joda.time.DurationField durationField16 = lenientChronology8.weekyears();
        org.joda.time.Period period17 = new org.joda.time.Period(100000L, periodType2, (org.joda.time.Chronology) lenientChronology8);
        org.joda.time.Period period19 = period17.plusHours((int) (byte) 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-59107967999900L) + "'", long14 == (-59107967999900L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        long long9 = fixedDateTimeZone4.previousTransition(2440588L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 34);
        boolean boolean12 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2440588L + "'", long9 == 2440588L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        try {
//            long long79 = unsupportedDateTimeField76.roundFloor(134L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler7 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file8 = null;
        java.io.File[] fileArray9 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = zoneInfoCompiler7.compile(file8, fileArray9);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = zoneInfoCompiler5.compile(file6, fileArray9);
        java.io.File file12 = null;
        java.io.File[] fileArray13 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = zoneInfoCompiler5.compile(file12, fileArray13);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = zoneInfoCompiler0.compile(file4, fileArray13);
        java.io.File file16 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler17 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file18 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler19 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file20 = null;
        java.io.File[] fileArray21 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = zoneInfoCompiler19.compile(file20, fileArray21);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap23 = zoneInfoCompiler17.compile(file18, fileArray21);
        java.io.File file24 = null;
        java.io.File[] fileArray25 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap26 = zoneInfoCompiler17.compile(file24, fileArray25);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap27 = zoneInfoCompiler0.compile(file16, fileArray25);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(fileArray13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertNotNull(strMap15);
        org.junit.Assert.assertNotNull(fileArray21);
        org.junit.Assert.assertNotNull(strMap22);
        org.junit.Assert.assertNotNull(strMap23);
        org.junit.Assert.assertNotNull(fileArray25);
        org.junit.Assert.assertNotNull(strMap26);
        org.junit.Assert.assertNotNull(strMap27);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long11 = preciseDurationField9.getValueAsLong(31622400000L);
        long long13 = preciseDurationField9.getMillis(82800100L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 15811200000L + "'", long11 == 15811200000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 165600200L + "'", long13 == 165600200L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("UTC", false);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 101");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsText(1, locale16);
        long long19 = offsetDateTimeField5.roundHalfCeiling(63244800000L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField5.getAsShortText((int) '#', locale21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 63244800000L + "'", long19 == 63244800000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "35" + "'", str22.equals("35"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.Period period1 = org.joda.time.Period.years(4);
        org.joda.time.Period period3 = period1.plusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        org.joda.time.DurationFieldType durationFieldType34 = decoratedDurationField30.getType();
        long long37 = decoratedDurationField30.add(6048000000L, 2440588L);
        long long40 = decoratedDurationField30.getMillis(0, (long) '#');
        long long42 = decoratedDurationField30.getValueAsLong(0L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 8488588000L + "'", long37 == 8488588000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        long long10 = offsetDateTimeField5.roundCeiling(1L);
        java.lang.String str11 = offsetDateTimeField5.getName();
        boolean boolean13 = offsetDateTimeField5.isLeap(0L);
        long long15 = offsetDateTimeField5.roundHalfFloor((-1L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "clockhourOfDay" + "'", str11.equals("clockhourOfDay"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.dayOfWeek();
        long long11 = lenientChronology5.getDateTimeMillis((int) 'a', 0, (int) (short) 10, (int) (short) 100);
        org.joda.time.DurationField durationField12 = lenientChronology5.centuries();
        java.lang.String str13 = lenientChronology5.toString();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59107967999900L) + "'", long11 == (-59107967999900L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str13.equals("LenientChronology[ISOChronology[UTC]]"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long16 = offsetDateTimeField5.add((-2L), 99);
        boolean boolean17 = offsetDateTimeField5.isLenient();
        long long19 = offsetDateTimeField5.roundCeiling((long) (byte) 10);
        long long22 = offsetDateTimeField5.add((long) 0, 0);
        int int24 = offsetDateTimeField5.getMaximumValue((-21086667360000000L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField5.getAsText((long) '4', locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField5.getLeapDurationField();
        long long30 = offsetDateTimeField5.roundHalfEven(0L);
        long long32 = offsetDateTimeField5.roundCeiling(100000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 356399998L + "'", long16 == 356399998L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 34 + "'", int24 == 34);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "34" + "'", str27.equals("34"));
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600000L + "'", long32 == 3600000L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        long long12 = dateTimeZone9.adjustOffset(2440588L, false);
        boolean boolean13 = periodType5.equals((java.lang.Object) long12);
        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withMillisRemoved();
        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType16);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2440588L + "'", long12 == 2440588L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        long long12 = fixedDateTimeZone4.previousTransition((long) 'a');
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        int int16 = fixedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long12 = preciseDurationField9.add(18532799896L, (-21086667360000000L));
        boolean boolean13 = preciseDurationField9.isPrecise();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-42173316187200104L) + "'", long12 == (-42173316187200104L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int12 = cachedDateTimeZone10.getOffset((long) (short) 10);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType17);
        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType17);
        org.joda.time.PeriodType periodType20 = periodType17.withHoursRemoved();
        org.joda.time.PeriodType periodType21 = periodType17.withMinutesRemoved();
        int int22 = periodType21.size();
        boolean boolean23 = cachedDateTimeZone10.equals((java.lang.Object) periodType21);
        int int25 = cachedDateTimeZone10.getOffsetFromLocal(6048000000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 4, (long) 101);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long16 = offsetDateTimeField5.add((-2L), 99);
        boolean boolean17 = offsetDateTimeField5.isLenient();
        long long20 = offsetDateTimeField5.addWrapField((long) 52, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 356399998L + "'", long16 == 356399998L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        org.joda.time.DurationField durationField35 = dividedDateTimeField33.getDurationField();
        long long38 = dividedDateTimeField33.add((-216733233500000L), 58);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-214909156700000L) + "'", long38 == (-214909156700000L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        java.lang.String str34 = decoratedDurationField30.getName();
        long long37 = decoratedDurationField30.getMillis(40, 6048000000L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 40000L + "'", long37 == 40000L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 1, (java.lang.Number) 100000L, (java.lang.Number) (-31449600000L));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 100, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for clockhourOfDay must be in the range [32,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        long long5 = iSOChronology0.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField6 = iSOChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        long long11 = dateTimeZone8.adjustOffset(2440588L, false);
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        int int20 = cachedDateTimeZone18.getOffset((long) (short) 10);
        int int22 = cachedDateTimeZone18.getStandardOffset((long) (byte) 100);
        int int24 = cachedDateTimeZone18.getOffset(4L);
        org.joda.time.JodaTimePermission jodaTimePermission26 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection27 = jodaTimePermission26.newPermissionCollection();
        org.joda.time.Period period29 = org.joda.time.Period.weeks((int) (byte) 100);
        int int30 = period29.getWeeks();
        org.joda.time.Weeks weeks31 = period29.toStandardWeeks();
        boolean boolean32 = jodaTimePermission26.equals((java.lang.Object) weeks31);
        org.joda.time.JodaTimePermission jodaTimePermission34 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType36 = periodType35.withHoursRemoved();
        jodaTimePermission34.checkGuard((java.lang.Object) periodType36);
        boolean boolean38 = jodaTimePermission26.implies((java.security.Permission) jodaTimePermission34);
        boolean boolean39 = cachedDateTimeZone18.equals((java.lang.Object) jodaTimePermission34);
        int int41 = cachedDateTimeZone18.getStandardOffset(97L);
        int int43 = cachedDateTimeZone18.getOffset((-10965067027200000L));
        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2440588L + "'", long11 == 2440588L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(permissionCollection27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(weeks31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(zonedChronology44);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period3 = period1.withDays((int) ' ');
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period1.toString(periodFormatter4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "P100W" + "'", str5.equals("P100W"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-59002819199995L), 27);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1593076118399865L) + "'", long2 == (-1593076118399865L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-7) + "'", int1 == (-7));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Period period13 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period15 = period13.withDays((int) ' ');
        org.joda.time.Period period17 = period15.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationFrom(readableInstant18);
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        boolean boolean27 = period15.isSupported(durationFieldType26);
        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) boolean27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone4.getShortName(60480000000L, locale30);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.010" + "'", str31.equals("+00:00:00.010"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (java.lang.Number) (byte) 10, (java.lang.Number) 0L, (java.lang.Number) (-1.0d));
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        try {
//            int int80 = unsupportedDateTimeField76.getLeapAmount(2440588L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField5.getWrappedField();
        long long11 = offsetDateTimeField5.roundHalfEven((-6134400000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-6134400000L) + "'", long11 == (-6134400000L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
        long long9 = gregorianChronology4.add((long) (short) -1, 0L, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology4.getZone();
        try {
            long long18 = gregorianChronology4.getDateTimeMillis(400, 11, 7, 27, 2, (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 27 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology6 = lenientChronology5.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField11 = iSOChronology9.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.era();
        org.joda.time.DurationField durationField14 = iSOChronology9.days();
        boolean boolean15 = lenientChronology5.equals((java.lang.Object) durationField14);
        org.joda.time.DurationField durationField16 = lenientChronology5.minutes();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField6 = iSOChronology4.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        java.lang.String str8 = lenientChronology7.toString();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 100, (long) 'a', (org.joda.time.Chronology) lenientChronology7);
        org.joda.time.Period period10 = period9.normalizedStandard();
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str8.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.Period period1 = org.joda.time.Period.days(40);
        org.joda.time.Hours hours2 = period1.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.minusWeeks((-1));
        org.joda.time.Period period4 = period2.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType6 = period4.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException(durationFieldType6, "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException13.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException13.getSuppressed();
        java.lang.Throwable[] throwableArray16 = illegalFieldValueException13.getSuppressed();
        java.lang.Number number17 = illegalFieldValueException13.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        java.lang.String str23 = illegalFieldValueException22.getIllegalStringValue();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalFieldValueException22);
        org.joda.time.Period period27 = org.joda.time.Period.weeks(4);
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) illegalFieldValueException8, (java.lang.Object) period27);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology11);
        int[] intArray16 = period15.getValues();
        int int17 = offsetDateTimeField5.getMaximumValue(readablePartial9, intArray16);
        long long19 = offsetDateTimeField5.roundCeiling((-522547199999999948L));
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField5.getAsText(96L, locale21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-522547199996400000L) + "'", long19 == (-522547199996400000L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "34" + "'", str22.equals("34"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        long long39 = offsetDateTimeField36.addWrapField(52L, (int) (byte) 1);
        int int41 = offsetDateTimeField36.getLeapAmount((long) (short) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor(134L);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField36.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField30, dateTimeFieldType44, (int) (byte) 10);
        int int48 = dividedDateTimeField46.get((long) (byte) 1);
        int int49 = dividedDateTimeField46.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600052L + "'", long39 == 3600052L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Period period1 = org.joda.time.Period.days(97);
        org.joda.time.Period period3 = period1.plusHours((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        try {
//            long long80 = unsupportedDateTimeField76.roundHalfFloor(356399998L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
        int int7 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        jodaTimePermission1.checkGuard((java.lang.Object) periodType3);
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period8 = period6.minusYears((int) (short) 1);
        org.joda.time.Period period10 = period6.withDays((int) '4');
        org.joda.time.Period period11 = org.joda.time.Period.ZERO;
        org.joda.time.Period period13 = period11.minusWeeks((-1));
        org.joda.time.Period period15 = period13.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType17 = period15.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        org.joda.time.Period period21 = period10.withField(durationFieldType17, (int) (short) 0);
        int int22 = periodType3.indexOf(durationFieldType17);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long15 = offsetDateTimeField5.roundHalfCeiling((long) (byte) 1);
        org.joda.time.DurationField durationField16 = offsetDateTimeField5.getRangeDurationField();
        java.lang.String str18 = offsetDateTimeField5.getAsText(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.util.Locale locale77 = null;
//        try {
//            int int78 = unsupportedDateTimeField76.getMaximumTextLength(locale77);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test131");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str7 = dateTimeZone5.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str11 = dateTimeZone9.getShortName((long) '4');
//        long long13 = dateTimeZone5.getMillisKeepLocal(dateTimeZone9, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone15 = iSOChronology14.getZone();
//        org.joda.time.Period period16 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period18 = period16.normalizedStandard(periodType17);
//        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) periodType17);
//        org.joda.time.PeriodType periodType20 = periodType17.withDaysRemoved();
//        org.joda.time.PeriodType periodType21 = periodType17.withDaysRemoved();
//        org.joda.time.PeriodType periodType22 = periodType21.withMillisRemoved();
//        org.joda.time.PeriodType periodType23 = periodType21.withWeeksRemoved();
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertNotNull(periodType22);
//        org.junit.Assert.assertNotNull(periodType23);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        long long29 = unsupportedDurationField28.getUnitMillis();
        java.lang.String str30 = unsupportedDurationField28.toString();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period34 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DurationField durationField35 = iSOChronology33.weeks();
        long long38 = durationField35.subtract(0L, (int) (byte) 10);
        long long41 = durationField35.subtract(48L, (int) 'a');
        int int42 = unsupportedDurationField28.compareTo(durationField35);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-6048000000L) + "'", long38 == (-6048000000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-58665599952L) + "'", long41 == (-58665599952L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        java.lang.String str79 = unsupportedDateTimeField76.getName();
//        java.util.Locale locale80 = null;
//        try {
//            int int81 = unsupportedDateTimeField76.getMaximumTextLength(locale80);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "clockhourOfDay" + "'", str79.equals("clockhourOfDay"));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-21086667360000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        org.joda.time.DurationFieldType durationFieldType34 = decoratedDurationField30.getType();
        long long37 = decoratedDurationField30.add(6048000000L, 2440588L);
        long long39 = decoratedDurationField30.getValueAsLong((-315100800000L));
        int int41 = decoratedDurationField30.getValue(31622400000L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 8488588000L + "'", long37 == 8488588000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-315100800L) + "'", long39 == (-315100800L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31622400 + "'", int41 == 31622400);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission6.newPermissionCollection();
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (byte) 100);
        int int10 = period9.getWeeks();
        org.joda.time.Weeks weeks11 = period9.toStandardWeeks();
        boolean boolean12 = jodaTimePermission6.equals((java.lang.Object) weeks11);
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        jodaTimePermission14.checkGuard((java.lang.Object) periodType16);
        boolean boolean18 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission14);
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler19 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file20 = null;
        java.io.File[] fileArray21 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = zoneInfoCompiler19.compile(file20, fileArray21);
        boolean boolean23 = jodaTimePermission6.equals((java.lang.Object) fileArray21);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap24 = zoneInfoCompiler0.compile(file4, fileArray21);
        java.io.BufferedReader bufferedReader25 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(weeks11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(fileArray21);
        org.junit.Assert.assertNotNull(strMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strMap24);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 10, '#', (int) '4', (int) (byte) 1, (int) (short) -1, false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("Coordinated Universal Time", (int) (short) 1);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder8.writeTo("UnsupportedDurationField[years]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period3 = period1.withDays((int) ' ');
        org.joda.time.Period period5 = period3.minusMinutes((-1));
        org.joda.time.Period period7 = period3.plusMillis((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.ZERO;
        org.joda.time.Period period10 = period8.minusWeeks((-1));
        org.joda.time.Period period12 = period10.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period12.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "");
        boolean boolean17 = period3.isSupported(durationFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "GregorianChronology[-00:00:00.001]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "GregorianChronology[-00:00:00.001]");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType14);
        try {
            int int25 = unsupportedDurationField22.getDifference(7200000L, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        long long36 = decoratedDurationField30.getDifferenceAsLong((long) (short) 0, 6048000000L);
        long long39 = decoratedDurationField30.getDifferenceAsLong((-99000L), 0L);
        org.joda.time.DurationField durationField40 = decoratedDurationField30.getWrappedField();
        long long43 = decoratedDurationField30.getValueAsLong(356399998L, 637200000L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-6048000L) + "'", long36 == (-6048000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-99L) + "'", long39 == (-99L));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 356399L + "'", long43 == 356399L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        long long36 = dividedDateTimeField33.remainder(0L);
        int int38 = dividedDateTimeField33.get(50L);
        java.util.Locale locale39 = null;
        int int40 = dividedDateTimeField33.getMaximumTextLength(locale39);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsText((long) (byte) 100, locale23);
        java.lang.String str26 = offsetDateTimeField18.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType27, (int) 'a', (-1), 8);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType27, 52);
        org.joda.time.DurationField durationField34 = dividedDateTimeField33.getDurationField();
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        long long44 = offsetDateTimeField41.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField41.getAsText((long) (byte) 100, locale46);
        java.lang.String str49 = offsetDateTimeField41.getAsText((-1L));
        long long52 = offsetDateTimeField41.add((-2L), 99);
        long long55 = offsetDateTimeField41.add(134L, (int) '4');
        int int57 = offsetDateTimeField41.get(2L);
        long long59 = offsetDateTimeField41.roundCeiling((long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology62.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology62.hourOfDay();
        org.joda.time.Period period66 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology62);
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.PeriodType periodType71 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType72 = periodType71.withHoursRemoved();
        org.joda.time.Period period73 = new org.joda.time.Period(readableInstant69, readableDuration70, periodType72);
        org.joda.time.PeriodType periodType74 = org.joda.time.DateTimeUtils.getPeriodType(periodType72);
        org.joda.time.PeriodType periodType75 = periodType72.withMillisRemoved();
        org.joda.time.Period period76 = org.joda.time.Period.ZERO;
        org.joda.time.Period period78 = period76.minusWeeks((-1));
        org.joda.time.Period period80 = period78.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType82 = period80.getFieldType(0);
        boolean boolean83 = periodType72.isSupported(durationFieldType82);
        org.joda.time.PeriodType periodType84 = org.joda.time.DateTimeUtils.getPeriodType(periodType72);
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((long) (short) 100, (long) 0, periodType72, chronology85);
        int[] intArray88 = iSOChronology62.get((org.joda.time.ReadablePeriod) period86, 0L);
        int int89 = offsetDateTimeField41.getMinimumValue(readablePartial60, intArray88);
        int int90 = dividedDateTimeField33.getMinimumValue(readablePartial35, intArray88);
        int int92 = dividedDateTimeField33.get(1L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1704L + "'", long21 == 1704L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "34" + "'", str24.equals("34"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1704L + "'", long44 == 1704L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "34" + "'", str47.equals("34"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "33" + "'", str49.equals("33"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 356399998L + "'", long52 == 356399998L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 187200134L + "'", long55 == 187200134L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 34 + "'", int57 == 34);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(period78);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(durationFieldType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(periodType84);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField5.getMinimumValue(readablePartial7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.lang.String str77 = unsupportedDateTimeField76.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = unsupportedDateTimeField76.getType();
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "clockhourOfDay" + "'", str77.equals("clockhourOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone24);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
//        org.joda.time.Period period31 = new org.joda.time.Period((long) '4', chronology30);
//        org.joda.time.Period period33 = period31.plusMinutes(0);
//        int[] intArray36 = zonedChronology26.get((org.joda.time.ReadablePeriod) period31, 0L, (long) 99);
//        try {
//            long long44 = zonedChronology26.getDateTimeMillis(27, 1, 89, 0, (int) '#', (int) (short) 1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Period period3 = period1.withMinutes(27);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 10, 356399998L, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getOffset(0L);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        java.lang.String str12 = fixedDateTimeZone4.getNameKey((-216733233600000L));
        java.lang.String str14 = fixedDateTimeZone4.getNameKey((-210866414400000L));
        int int16 = fixedDateTimeZone4.getOffsetFromLocal((long) 58);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
//        java.lang.String str28 = zonedChronology26.toString();
//        org.joda.time.Chronology chronology29 = zonedChronology26.withUTC();
//        org.joda.time.Period period30 = org.joda.time.Period.ZERO;
//        org.joda.time.MutablePeriod mutablePeriod31 = period30.toMutablePeriod();
//        int[] intArray34 = zonedChronology26.get((org.joda.time.ReadablePeriod) mutablePeriod31, 2440588L, (long) 10);
//        org.joda.time.DateTimeField dateTimeField35 = zonedChronology26.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone36 = zonedChronology26.getZone();
//        long long40 = zonedChronology26.add(0L, 58022L, 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
//        java.util.TimeZone timeZone46 = fixedDateTimeZone45.toTimeZone();
//        int int48 = fixedDateTimeZone45.getOffsetFromLocal((-2L));
//        int int50 = fixedDateTimeZone45.getStandardOffset((-210866414400000L));
//        boolean boolean51 = fixedDateTimeZone45.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone45);
//        org.joda.time.Period period54 = org.joda.time.Period.weeks((int) (byte) 100);
//        org.joda.time.Period period56 = period54.withDays((int) ' ');
//        org.joda.time.Period period58 = period56.minusMinutes((-1));
//        org.joda.time.ReadableInstant readableInstant59 = null;
//        org.joda.time.Duration duration60 = period56.toDurationFrom(readableInstant59);
//        org.joda.time.Period period61 = org.joda.time.Period.ZERO;
//        org.joda.time.Period period63 = period61.minusWeeks((-1));
//        org.joda.time.Period period65 = period63.withMinutes((int) (byte) 10);
//        org.joda.time.DurationFieldType durationFieldType67 = period65.getFieldType(0);
//        boolean boolean68 = period56.isSupported(durationFieldType67);
//        boolean boolean69 = fixedDateTimeZone45.equals((java.lang.Object) boolean68);
//        boolean boolean70 = fixedDateTimeZone45.isFixed();
//        java.lang.String str72 = fixedDateTimeZone45.getName(40L);
//        org.joda.time.Chronology chronology73 = zonedChronology26.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str28.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(period30);
//        org.junit.Assert.assertNotNull(mutablePeriod31);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertNotNull(period56);
//        org.junit.Assert.assertNotNull(period58);
//        org.junit.Assert.assertNotNull(duration60);
//        org.junit.Assert.assertNotNull(period61);
//        org.junit.Assert.assertNotNull(period63);
//        org.junit.Assert.assertNotNull(period65);
//        org.junit.Assert.assertNotNull(durationFieldType67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "+00:00:00.010" + "'", str72.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(chronology73);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int12 = cachedDateTimeZone10.getOffset((long) (short) 10);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType17);
        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType17);
        org.joda.time.PeriodType periodType20 = periodType17.withHoursRemoved();
        org.joda.time.PeriodType periodType21 = periodType17.withMinutesRemoved();
        int int22 = periodType21.size();
        boolean boolean23 = cachedDateTimeZone10.equals((java.lang.Object) periodType21);
        java.lang.String str25 = cachedDateTimeZone10.getNameKey((-210866673600000L));
        long long29 = cachedDateTimeZone10.convertLocalToUTC(0L, false, (-522547199996400000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.time();
        java.lang.Object obj4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Period period9 = new org.joda.time.Period(obj4, periodType5, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) -1, 10L, periodType3, (org.joda.time.Chronology) gregorianChronology8);
        int int11 = periodType3.size();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        int int19 = period16.getMillis();
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        int int27 = period16.get(durationFieldType26);
        int int28 = periodType3.indexOf(durationFieldType26);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType26);
        java.lang.String str30 = unsupportedDurationField29.getName();
        org.joda.time.DurationFieldType durationFieldType31 = unsupportedDurationField29.getType();
        boolean boolean32 = periodType0.isSupported(durationFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType31, "-00:00:00.001");
        java.lang.String str35 = illegalFieldValueException34.getFieldName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "years" + "'", str35.equals("years"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.toString();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.hourOfHalfday();
        long long35 = iSOChronology30.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DurationField durationField36 = iSOChronology30.halfdays();
        long long39 = durationField36.subtract((-1L), 0L);
        int int40 = unsupportedDurationField28.compareTo(durationField36);
        long long41 = unsupportedDurationField28.getUnitMillis();
        try {
            long long44 = unsupportedDurationField28.getMillis(197, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDurationField[years]" + "'", str29.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period5 = period3.withDays((int) ' ');
        org.joda.time.Period period7 = period5.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period5.toDurationFrom(readableInstant8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12);
        int int14 = period13.getWeeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.Period period16 = period13.withPeriodType(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        long long11 = offsetDateTimeField5.add(10L, 6048000000L);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumTextLength(locale12);
        java.lang.String str15 = offsetDateTimeField5.getAsText((-10L));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 52, 11, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for clockhourOfDay must be in the range [11,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 21772800000000010L + "'", long11 == 21772800000000010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "33" + "'", str15.equals("33"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsText(1, locale16);
        long long19 = offsetDateTimeField5.remainder((long) '4');
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField5.getAsShortText(readablePartial20, (int) '#', locale22);
        int int25 = offsetDateTimeField5.getMaximumValue(1560625200000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "35" + "'", str23.equals("35"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 34 + "'", int25 == 34);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        boolean boolean15 = offsetDateTimeField5.isLeap((long) 'a');
        long long17 = offsetDateTimeField5.remainder((long) (short) 10);
        java.lang.String str19 = offsetDateTimeField5.getAsText(187200134L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField5.getAsText((int) 'a', locale21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = offsetDateTimeField5.getAsShortText(readablePartial23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "14" + "'", str19.equals("14"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withMillisRemoved();
        org.joda.time.Period period7 = org.joda.time.Period.ZERO;
        org.joda.time.Period period9 = period7.minusWeeks((-1));
        org.joda.time.Period period11 = period9.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType13 = period11.getFieldType(0);
        boolean boolean14 = periodType3.isSupported(durationFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "52");
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.toString();
        java.lang.String str30 = unsupportedDurationField28.toString();
        java.lang.String str31 = unsupportedDurationField28.toString();
        java.lang.String str32 = unsupportedDurationField28.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDurationField[years]" + "'", str29.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDurationField[years]" + "'", str31.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "years" + "'", str32.equals("years"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        org.joda.time.DurationFieldType durationFieldType34 = decoratedDurationField30.getType();
        long long37 = decoratedDurationField30.add(6048000000L, 2440588L);
        long long40 = decoratedDurationField30.getMillis(0, (long) '#');
        int int43 = decoratedDurationField30.getValue(0L, (long) 11);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 8488588000L + "'", long37 == 8488588000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-7));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        long long5 = iSOChronology0.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        java.lang.String str8 = iSOChronology0.toString();
        org.joda.time.DurationField durationField9 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str6 = lenientChronology5.toString();
        org.joda.time.chrono.LenientChronology lenientChronology7 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology5);
        org.joda.time.DateTimeField dateTimeField8 = lenientChronology5.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str6.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(lenientChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
//        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
//        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
//        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
//        long long39 = offsetDateTimeField36.addWrapField(52L, (int) (byte) 1);
//        int int41 = offsetDateTimeField36.getLeapAmount((long) (short) 10);
//        long long43 = offsetDateTimeField36.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField36.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField30, dateTimeFieldType44, (int) (byte) 10);
//        int int48 = dividedDateTimeField46.get((-62095507199911L));
//        int int51 = dividedDateTimeField46.getDifference(946684800000L, 97052L);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str60 = dateTimeZone58.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str64 = dateTimeZone62.getShortName((long) '4');
//        long long66 = dateTimeZone58.getMillisKeepLocal(dateTimeZone62, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone68 = iSOChronology67.getZone();
//        org.joda.time.Period period69 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology67);
//        org.joda.time.PeriodType periodType70 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period71 = period69.normalizedStandard(periodType70);
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone73);
//        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology74.clockhourOfHalfday();
//        org.joda.time.Period period76 = new org.joda.time.Period(2440588L, periodType70, (org.joda.time.Chronology) gregorianChronology74);
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone78);
//        org.joda.time.chrono.ZonedChronology zonedChronology80 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology74, dateTimeZone78);
//        org.joda.time.DateTimeZone dateTimeZone81 = zonedChronology80.getZone();
//        org.joda.time.Period period83 = new org.joda.time.Period(0L);
//        int int84 = period83.getMillis();
//        org.joda.time.ReadableInstant readableInstant85 = null;
//        org.joda.time.Duration duration86 = period83.toDurationTo(readableInstant85);
//        org.joda.time.Weeks weeks87 = period83.toStandardWeeks();
//        int[] intArray90 = zonedChronology80.get((org.joda.time.ReadablePeriod) period83, (-315100800000L), (long) 0);
//        try {
//            int[] intArray92 = dividedDateTimeField46.addWrapPartial(readablePartial52, 97, intArray90, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600052L + "'", long39 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "UTC" + "'", str60.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UTC" + "'", str64.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1L + "'", long66 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(periodType70);
//        org.junit.Assert.assertNotNull(period71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(gregorianChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(gregorianChronology79);
//        org.junit.Assert.assertNotNull(zonedChronology80);
//        org.junit.Assert.assertNotNull(dateTimeZone81);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertNotNull(duration86);
//        org.junit.Assert.assertNotNull(weeks87);
//        org.junit.Assert.assertNotNull(intArray90);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone10 = fixedDateTimeZone9.toTimeZone();
        int int12 = fixedDateTimeZone9.getOffsetFromLocal((-60507817129998L));
        int int14 = fixedDateTimeZone9.getOffset((long) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str16 = zonedChronology15.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[ISOChronology[UTC], -00:00:00.001]" + "'", str16.equals("ZonedChronology[ISOChronology[UTC], -00:00:00.001]"));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test165");
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfHalfday();
//        long long7 = iSOChronology2.add((long) '4', (long) (byte) 10, 0);
//        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ', periodType1, (org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.Chronology chronology9 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        boolean boolean13 = dateTimeZone11.isStandardOffset((long) (byte) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        int int16 = cachedDateTimeZone14.getOffset((long) (short) 10);
//        java.lang.String str18 = cachedDateTimeZone14.getName((long) 4);
//        java.lang.String str20 = cachedDateTimeZone14.getNameKey((-15811199L));
//        org.joda.time.Chronology chronology21 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology21);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.Period period9 = period7.multipliedBy((-97));
        org.joda.time.Period period11 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.MutablePeriod mutablePeriod12 = period11.toMutablePeriod();
        org.joda.time.Period period14 = period11.minusWeeks((int) (byte) 1);
        org.joda.time.Period period16 = period14.plusDays((int) (short) 10);
        org.joda.time.Period period18 = period14.multipliedBy((int) '#');
        boolean boolean19 = period9.equals((java.lang.Object) '#');
        org.joda.time.Days days20 = period9.toStandardDays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(mutablePeriod12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(days20);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField6 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long11 = preciseDurationField9.getValueAsLong(31622400000L);
        long long14 = preciseDurationField9.getMillis((-522547199999999948L), (-10965067023600000L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 15811200000L + "'", long11 == 15811200000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1045094399999999896L) + "'", long14 == (-1045094399999999896L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-7));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        long long17 = offsetDateTimeField5.getDifferenceAsLong((long) 8, 10L);
        int int18 = offsetDateTimeField5.getMinimumValue();
        int int20 = offsetDateTimeField5.getLeapAmount((-210866414400000L));
        long long23 = offsetDateTimeField5.add(18532799896L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 18532799896L + "'", long23 == 18532799896L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period6 = new org.joda.time.Period(obj1, periodType2, (org.joda.time.Chronology) gregorianChronology5);
        int int7 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.Period period10 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology5.getZone();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) '4', chronology15);
        org.joda.time.Period period18 = period16.plusMinutes(0);
        org.joda.time.Period period19 = period18.toPeriod();
        boolean boolean20 = gregorianChronology5.equals((java.lang.Object) period19);
        int int21 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) iSOChronology11);
        int[] intArray16 = period15.getValues();
        int int17 = offsetDateTimeField5.getMaximumValue(readablePartial9, intArray16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField5.getType();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 10);
        java.lang.String str25 = offsetDateTimeField24.getName();
        org.joda.time.DurationField durationField26 = offsetDateTimeField24.getRangeDurationField();
        org.joda.time.DurationField durationField27 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField28 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType18, durationField26, durationField27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "clockhourOfDay" + "'", str25.equals("clockhourOfDay"));
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period4 = org.joda.time.Period.weeks((int) (byte) 100);
        int int5 = period4.getWeeks();
        org.joda.time.Weeks weeks6 = period4.toStandardWeeks();
        org.joda.time.Period period7 = period2.plus((org.joda.time.ReadablePeriod) weeks6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.years();
        org.joda.time.Period period9 = period7.normalizedStandard(periodType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11, periodType13);
        java.lang.String str15 = periodType13.getName();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType19 = periodType18.withHoursRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant16, readableDuration17, periodType19);
        org.joda.time.PeriodType periodType21 = org.joda.time.DateTimeUtils.getPeriodType(periodType19);
        org.joda.time.DurationFieldType durationFieldType23 = periodType21.getFieldType(0);
        int int24 = periodType13.indexOf(durationFieldType23);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(weeks6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Minutes" + "'", str15.equals("Minutes"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Period period13 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period15 = period13.withDays((int) ' ');
        org.joda.time.Period period17 = period15.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationFrom(readableInstant18);
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        boolean boolean27 = period15.isSupported(durationFieldType26);
        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) boolean27);
        boolean boolean29 = fixedDateTimeZone4.isFixed();
        java.lang.String str31 = fixedDateTimeZone4.getName(40L);
        java.lang.String str32 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.010" + "'", str31.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.001" + "'", str32.equals("-00:00:00.001"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffset((long) (short) 10);
        int int8 = cachedDateTimeZone4.getStandardOffset((long) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        int int16 = fixedDateTimeZone13.getOffsetFromLocal((-2L));
        java.lang.String str18 = fixedDateTimeZone13.getNameKey((-2L));
        boolean boolean19 = cachedDateTimeZone4.equals((java.lang.Object) fixedDateTimeZone13);
        long long21 = fixedDateTimeZone13.nextTransition(3600000L);
        int int23 = fixedDateTimeZone13.getOffset((-31622451L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3600000L + "'", long21 == 3600000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        long long16 = offsetDateTimeField5.add((-2L), 99);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField5.getAsText((-210866414400000L), locale18);
        long long22 = offsetDateTimeField5.set(5708011L, 27);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 356399998L + "'", long16 == 356399998L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "22" + "'", str19.equals("22"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 63308011L + "'", long22 == 63308011L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.addWrapField(52L, (int) (byte) 1);
        int int10 = offsetDateTimeField5.getLeapAmount((long) (short) 10);
        long long12 = offsetDateTimeField5.roundHalfFloor(134L);
        long long14 = offsetDateTimeField5.roundCeiling(107L);
        long long16 = offsetDateTimeField5.roundCeiling((long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600052L + "'", long8 == 3600052L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600000L + "'", long16 == 3600000L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        java.lang.String str15 = illegalFieldValueException14.getIllegalStringValue();
        java.lang.String str16 = illegalFieldValueException14.toString();
        java.lang.String str17 = illegalFieldValueException14.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        java.lang.Throwable[] throwableArray19 = illegalFieldValueException14.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = illegalFieldValueException14.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType21 = illegalFieldValueException14.getDurationFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 100 + "'", number9.equals((byte) 100));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNull(dateTimeFieldType20);
        org.junit.Assert.assertNull(durationFieldType21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.addWrapField(52L, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial9, intArray10);
        int int12 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3600052L + "'", long8 == 3600052L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str6 = lenientChronology5.toString();
        java.lang.String str7 = lenientChronology5.toString();
        boolean boolean9 = lenientChronology5.equals((java.lang.Object) 99);
        org.joda.time.Chronology chronology10 = lenientChronology5.withUTC();
        org.joda.time.DurationField durationField11 = lenientChronology5.minutes();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str6.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str7.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        long long14 = offsetDateTimeField5.add(52L, 52L);
        long long17 = offsetDateTimeField5.getDifferenceAsLong((long) 8, 10L);
        java.lang.String str18 = offsetDateTimeField5.toString();
        long long21 = offsetDateTimeField5.getDifferenceAsLong(0L, (long) 52);
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField5.getAsShortText(readablePartial22, 0, locale24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200052L + "'", long14 == 187200052L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str18.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test182");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.monthOfYear();
//        org.joda.time.Chronology chronology7 = gregorianChronology4.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str13 = dateTimeZone11.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str17 = dateTimeZone15.getShortName((long) '4');
//        long long19 = dateTimeZone11.getMillisKeepLocal(dateTimeZone15, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology20.getZone();
//        org.joda.time.Period period22 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology20);
//        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology4, (java.lang.Object) period22);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test183");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
//        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
//        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
//        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str16 = dateTimeZone14.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str20 = dateTimeZone18.getShortName((long) '4');
//        long long22 = dateTimeZone14.getMillisKeepLocal(dateTimeZone18, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.Period period25 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology23);
//        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period27 = period25.normalizedStandard(periodType26);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.clockhourOfHalfday();
//        org.joda.time.Period period32 = new org.joda.time.Period(2440588L, periodType26, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology30, dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone37 = zonedChronology36.getZone();
//        java.lang.String str38 = zonedChronology36.toString();
//        org.joda.time.Chronology chronology39 = zonedChronology36.withUTC();
//        java.lang.String str40 = zonedChronology36.toString();
//        boolean boolean41 = preciseDurationField9.equals((java.lang.Object) zonedChronology36);
//        org.junit.Assert.assertNotNull(periodType2);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(periodType5);
//        org.junit.Assert.assertNotNull(durationFieldType7);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(periodType26);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str38.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str40.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.getName();
        org.joda.time.DurationFieldType durationFieldType30 = unsupportedDurationField28.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        boolean boolean36 = unsupportedDurationField28.equals((java.lang.Object) illegalFieldValueException35);
        try {
            long long38 = unsupportedDurationField28.getMillis((long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "years" + "'", str29.equals("years"));
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test185");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
//        java.lang.String str28 = zonedChronology26.toString();
//        org.joda.time.Chronology chronology29 = zonedChronology26.withUTC();
//        java.lang.Object obj30 = null;
//        boolean boolean31 = zonedChronology26.equals(obj30);
//        org.joda.time.DurationField durationField32 = zonedChronology26.minutes();
//        java.lang.String str33 = zonedChronology26.toString();
//        long long37 = zonedChronology26.add(48L, (long) 40, (int) (byte) -1);
//        long long41 = zonedChronology26.add(8488588000L, 100L, (int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str28.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str33.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 8L + "'", long37 == 8L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8488598000L + "'", long41 == 8488598000L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        boolean boolean31 = decoratedDurationField30.isSupported();
        long long34 = decoratedDurationField30.getDifferenceAsLong((long) 'a', 31622400000L);
        org.joda.time.DurationField durationField35 = decoratedDurationField30.getWrappedField();
        long long38 = decoratedDurationField30.add(22L, 58);
        java.lang.String str39 = decoratedDurationField30.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31622399L) + "'", long34 == (-31622399L));
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 58022L + "'", long38 == 58022L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[years]" + "'", str39.equals("DurationField[years]"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test188");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        java.lang.String str79 = unsupportedDateTimeField76.getName();
//        org.joda.time.DurationField durationField80 = unsupportedDateTimeField76.getDurationField();
//        org.joda.time.ReadablePartial readablePartial81 = null;
//        java.util.Locale locale82 = null;
//        try {
//            java.lang.String str83 = unsupportedDateTimeField76.getAsShortText(readablePartial81, locale82);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "clockhourOfDay" + "'", str79.equals("clockhourOfDay"));
//        org.junit.Assert.assertNotNull(durationField80);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int6 = cachedDateTimeZone4.getOffset((long) (short) 10);
        int int8 = cachedDateTimeZone4.getStandardOffset((long) (byte) 100);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal(2440588L);
        int int12 = cachedDateTimeZone4.getStandardOffset((-60507817129998L));
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection15 = jodaTimePermission14.newPermissionCollection();
        org.joda.time.Period period17 = org.joda.time.Period.weeks((int) (byte) 100);
        int int18 = period17.getWeeks();
        org.joda.time.Weeks weeks19 = period17.toStandardWeeks();
        boolean boolean20 = jodaTimePermission14.equals((java.lang.Object) weeks19);
        boolean boolean21 = cachedDateTimeZone4.equals((java.lang.Object) jodaTimePermission14);
        java.security.PermissionCollection permissionCollection22 = jodaTimePermission14.newPermissionCollection();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(permissionCollection15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(weeks19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(permissionCollection22);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str29 = unsupportedDurationField28.toString();
        java.lang.String str30 = unsupportedDurationField28.toString();
        long long31 = unsupportedDurationField28.getUnitMillis();
        try {
            int int34 = unsupportedDurationField28.getValue((long) 'a', 15811200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDurationField[years]" + "'", str29.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.era();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology2.getZone();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        java.lang.String str6 = offsetDateTimeField5.getName();
        org.joda.time.DurationField durationField7 = offsetDateTimeField5.getRangeDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "clockhourOfDay" + "'", str6.equals("clockhourOfDay"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test193");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        java.lang.String str78 = unsupportedDateTimeField76.toString();
//        long long81 = unsupportedDateTimeField76.getDifferenceAsLong((long) 100, (-315100800000L));
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "UnsupportedDateTimeField" + "'", str78.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 157550400050L + "'", long81 == 157550400050L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission6.newPermissionCollection();
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (byte) 100);
        int int10 = period9.getWeeks();
        org.joda.time.Weeks weeks11 = period9.toStandardWeeks();
        boolean boolean12 = jodaTimePermission6.equals((java.lang.Object) weeks11);
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType16 = periodType15.withHoursRemoved();
        jodaTimePermission14.checkGuard((java.lang.Object) periodType16);
        boolean boolean18 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission14);
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler19 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file20 = null;
        java.io.File[] fileArray21 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = zoneInfoCompiler19.compile(file20, fileArray21);
        boolean boolean23 = jodaTimePermission6.equals((java.lang.Object) fileArray21);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap24 = zoneInfoCompiler0.compile(file4, fileArray21);
        java.io.File file25 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler26 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file27 = null;
        java.io.File[] fileArray28 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = zoneInfoCompiler26.compile(file27, fileArray28);
        java.io.File file30 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler31 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file32 = null;
        java.io.File[] fileArray33 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap34 = zoneInfoCompiler31.compile(file32, fileArray33);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap35 = zoneInfoCompiler26.compile(file30, fileArray33);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap36 = zoneInfoCompiler0.compile(file25, fileArray33);
        java.io.File file37 = null;
        java.io.File[] fileArray38 = null;
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = zoneInfoCompiler0.compile(file37, fileArray38);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(weeks11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(fileArray21);
        org.junit.Assert.assertNotNull(strMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strMap24);
        org.junit.Assert.assertNotNull(fileArray28);
        org.junit.Assert.assertNotNull(strMap29);
        org.junit.Assert.assertNotNull(fileArray33);
        org.junit.Assert.assertNotNull(strMap34);
        org.junit.Assert.assertNotNull(strMap35);
        org.junit.Assert.assertNotNull(strMap36);
        org.junit.Assert.assertNotNull(strMap39);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.Period period4 = new org.joda.time.Period(11, (-1), 10, 7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.Period period9 = period7.multipliedBy((-97));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', chronology13);
        org.joda.time.Period period16 = period14.plusMinutes(0);
        org.joda.time.Period period18 = period14.multipliedBy(0);
        org.joda.time.Period period20 = period18.minusYears(0);
        org.joda.time.Period period21 = period9.plus((org.joda.time.ReadablePeriod) period18);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-59002819199995L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        long long6 = gregorianChronology0.getDateTimeMillis(2, 4, (int) (short) 10, 89);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField8 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62095507199911L) + "'", long6 == (-62095507199911L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test200");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str3 = dateTimeZone1.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str7 = dateTimeZone5.getShortName((long) '4');
//        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DurationField durationField12 = iSOChronology10.centuries();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField5 = iSOChronology3.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology7 = lenientChronology6.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DurationField durationField12 = iSOChronology10.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology13 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.era();
        org.joda.time.DurationField durationField15 = iSOChronology10.days();
        boolean boolean16 = lenientChronology6.equals((java.lang.Object) durationField15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        int int23 = cachedDateTimeZone21.getOffset((long) (short) 10);
        int int25 = cachedDateTimeZone21.getStandardOffset((long) (byte) 100);
        int int27 = cachedDateTimeZone21.getOffset(4L);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.Chronology chronology29 = lenientChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
        org.joda.time.DurationField durationField36 = offsetDateTimeField35.getLeapDurationField();
        org.joda.time.DurationField durationField37 = offsetDateTimeField35.getRangeDurationField();
        long long40 = durationField37.subtract((long) 52, 6048000000L);
        boolean boolean41 = cachedDateTimeZone21.equals((java.lang.Object) durationField37);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(lenientChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-522547199999999948L) + "'", long40 == (-522547199999999948L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-633600000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440580L + "'", long1 == 2440580L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int12 = cachedDateTimeZone10.getOffset((long) (short) 10);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType17);
        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType17);
        org.joda.time.PeriodType periodType20 = periodType17.withHoursRemoved();
        org.joda.time.PeriodType periodType21 = periodType17.withMinutesRemoved();
        int int22 = periodType21.size();
        boolean boolean23 = cachedDateTimeZone10.equals((java.lang.Object) periodType21);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.hourOfDay();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) iSOChronology25);
        boolean boolean30 = cachedDateTimeZone10.equals((java.lang.Object) 10);
        boolean boolean31 = cachedDateTimeZone10.isFixed();
        boolean boolean32 = cachedDateTimeZone10.isFixed();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        int int8 = period4.getValue(1);
        org.joda.time.Period period10 = period4.multipliedBy((int) (byte) 100);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period10.getFieldTypes();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        boolean boolean7 = offsetDateTimeField5.isLeap(8L);
        boolean boolean8 = offsetDateTimeField5.isSupported();
        java.lang.String str9 = offsetDateTimeField5.getName();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField5.getAsText(readablePartial12, 34, locale14);
        long long17 = offsetDateTimeField5.roundHalfEven(200L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "clockhourOfDay" + "'", str9.equals("clockhourOfDay"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "34" + "'", str15.equals("34"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(4L, periodType6);
        boolean boolean8 = gregorianChronology2.equals((java.lang.Object) periodType6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        int int16 = fixedDateTimeZone13.getOffsetFromLocal((-2L));
        int int18 = fixedDateTimeZone13.getStandardOffset((-210866414400000L));
        boolean boolean19 = fixedDateTimeZone13.isFixed();
        long long22 = fixedDateTimeZone13.adjustOffset(0L, false);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant24, readableInstant25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) '4', chronology26);
        org.joda.time.Period period29 = period27.plusMinutes(0);
        org.joda.time.Period period31 = period27.multipliedBy(0);
        org.joda.time.Period period33 = period27.plusMillis((int) (byte) 100);
        boolean boolean34 = fixedDateTimeZone13.equals((java.lang.Object) period27);
        org.joda.time.Chronology chronology35 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.ReadablePartial readablePartial36 = null;
        try {
            long long38 = gregorianChronology2.set(readablePartial36, 63565200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (java.lang.Number) (byte) 10, (java.lang.Number) 0L, (java.lang.Number) (-1.0d));
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long10 = preciseDurationField9.getUnitMillis();
        long long12 = preciseDurationField9.getMillis(100);
        long long15 = preciseDurationField9.getMillis((int) (short) 1, 50L);
        long long18 = preciseDurationField9.add((long) 56, 89);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 200L + "'", long12 == 200L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 234L + "'", long18 == 234L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period8 = period4.multipliedBy(0);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Days days11 = period10.toStandardDays();
        org.joda.time.Period period13 = period10.plusYears((int) (byte) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(days11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        boolean boolean9 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test212");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int6 = cachedDateTimeZone4.getOffset((long) (short) 10);
//        java.lang.String str8 = cachedDateTimeZone4.getName((long) 4);
//        try {
//            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) str8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period8 = period4.plusHours((int) '4');
        org.joda.time.Period period10 = period4.withDays((-97));
        org.joda.time.Weeks weeks11 = period4.toStandardWeeks();
        org.joda.time.Period period13 = period4.minusMillis(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(weeks11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 8, (java.lang.Number) 19L, (java.lang.Number) 15811200000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test215");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        long long79 = preciseDurationField35.getMillis((int) (byte) 0, (long) (short) -1);
//        long long81 = preciseDurationField35.getMillis((-10965067023600000L));
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-21930134047200000L) + "'", long81 == (-21930134047200000L));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField10 = gregorianChronology7.seconds();
        long long13 = durationField10.subtract((long) 0, (long) 99);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) '4', chronology17);
        org.joda.time.Period period20 = period18.plusMinutes(0);
        int int21 = period18.getMillis();
        org.joda.time.Period period22 = org.joda.time.Period.ZERO;
        org.joda.time.Period period24 = period22.minusWeeks((-1));
        org.joda.time.Period period26 = period24.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period26.getFieldType(0);
        int int29 = period18.get(durationFieldType28);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType28);
        long long33 = decoratedDurationField30.getMillis(100L, (long) (-1));
        java.lang.String str34 = decoratedDurationField30.getName();
        boolean boolean35 = decoratedDurationField30.isSupported();
        org.joda.time.DurationField durationField36 = decoratedDurationField30.getWrappedField();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-99000L) + "'", long13 == (-99000L));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100000L + "'", long33 == 100000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.minusWeeks((-1));
        org.joda.time.Period period4 = period2.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType6 = period4.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField8 = new org.joda.time.field.PreciseDurationField(durationFieldType6, (long) (short) -1);
        java.lang.String str9 = preciseDurationField8.getName();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "years" + "'", str9.equals("years"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long8 = offsetDateTimeField5.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((long) (byte) 100, locale10);
        java.lang.String str13 = offsetDateTimeField5.getAsText((-1L));
        boolean boolean15 = offsetDateTimeField5.isLeap((long) 'a');
        long long17 = offsetDateTimeField5.roundFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField5.getAsText(readablePartial18, (int) (byte) 1, locale20);
        long long23 = offsetDateTimeField5.roundHalfFloor((-315100800L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField5.getAsShortText((-1), locale25);
        int int28 = offsetDateTimeField5.getMaximumValue(165600200L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1704L + "'", long8 == 1704L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "34" + "'", str11.equals("34"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-316800000L) + "'", long23 == (-316800000L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-1" + "'", str26.equals("-1"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 34 + "'", int28 == 34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType7 = periodType5.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField9 = new org.joda.time.field.PreciseDurationField(durationFieldType7, (long) 2);
        long long12 = preciseDurationField9.add(18532799896L, (-21086667360000000L));
        int int15 = preciseDurationField9.getDifference(2L, (long) 197);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfWeek();
        org.joda.time.Period period19 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period21 = period19.minusYears((int) (short) 1);
        boolean boolean22 = iSOChronology16.equals((java.lang.Object) period19);
        int int23 = period19.getMonths();
        org.joda.time.Period period25 = period19.minusYears((int) (short) 0);
        int int26 = period19.getMillis();
        boolean boolean27 = preciseDurationField9.equals((java.lang.Object) int26);
        java.lang.String str28 = preciseDurationField9.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-42173316187200104L) + "'", long12 == (-42173316187200104L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-97) + "'", int15 == (-97));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DurationField[minutes]" + "'", str28.equals("DurationField[minutes]"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        int int2 = period1.getWeeks();
        int int3 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getOffset(0L);
        long long11 = fixedDateTimeZone4.previousTransition((long) 8);
        int int13 = fixedDateTimeZone4.getOffset(63565200000L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8L + "'", long11 == 8L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test222");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        try {
//            java.lang.String str79 = unsupportedDateTimeField76.getAsShortText((long) 27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test223");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone24);
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
//        org.joda.time.Period period31 = new org.joda.time.Period((long) '4', chronology30);
//        org.joda.time.Period period33 = period31.plusMinutes(0);
//        int[] intArray36 = zonedChronology26.get((org.joda.time.ReadablePeriod) period31, 0L, (long) 99);
//        org.joda.time.Chronology chronology37 = zonedChronology26.withUTC();
//        org.joda.time.DateTimeField dateTimeField38 = zonedChronology26.minuteOfHour();
//        java.lang.String str39 = zonedChronology26.toString();
//        try {
//            long long47 = zonedChronology26.getDateTimeMillis(152, (int) (short) 0, 0, (int) (short) 1, 0, 58, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ZonedChronology[GregorianChronology[UTC], -00:00:00.001]" + "'", str39.equals("ZonedChronology[GregorianChronology[UTC], -00:00:00.001]"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 100);
        int int2 = period1.getWeeks();
        org.joda.time.Period period4 = period1.plusYears((int) (short) 0);
        int int5 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfHalfday();
        long long7 = iSOChronology2.add((long) '4', (long) (byte) 10, 0);
        org.joda.time.Period period8 = new org.joda.time.Period((long) ' ', periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test226");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        long long15 = dateTimeZone4.convertUTCToLocal(2440588L);
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone4, (-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology19 = iSOChronology18.withUTC();
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        try {
//            int[] intArray22 = iSOChronology18.get(readablePartial20, 1704L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2440588L + "'", long15 == 2440588L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2L) + "'", long17 == (-2L));
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(187200134L);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime8);
        int int11 = fixedDateTimeZone4.getOffset((long) 56);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        long long7 = offsetDateTimeField5.roundHalfFloor((-10L));
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = offsetDateTimeField5.getMaximumValue(readablePartial8);
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 34 + "'", int9 == 34);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 34 + "'", int10 == 34);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        int int10 = periodType2.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', chronology14);
        org.joda.time.Period period17 = period15.plusMinutes(0);
        int int18 = period15.getMillis();
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        org.joda.time.Period period21 = period19.minusWeeks((-1));
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period23.getFieldType(0);
        int int26 = period15.get(durationFieldType25);
        int int27 = periodType2.indexOf(durationFieldType25);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        long long29 = unsupportedDurationField28.getUnitMillis();
        java.lang.String str30 = unsupportedDurationField28.toString();
        try {
            long long32 = unsupportedDurationField28.getValueAsLong((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test230");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.lang.String str77 = unsupportedDateTimeField76.getName();
//        try {
//            long long79 = unsupportedDateTimeField76.roundHalfFloor((long) 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "clockhourOfDay" + "'", str77.equals("clockhourOfDay"));
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test231");
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str5 = dateTimeZone3.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str9 = dateTimeZone7.getShortName((long) '4');
//        long long11 = dateTimeZone3.getMillisKeepLocal(dateTimeZone7, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone13 = iSOChronology12.getZone();
//        org.joda.time.Period period14 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period16 = period14.normalizedStandard(periodType15);
//        org.joda.time.Period period18 = org.joda.time.Period.hours((-97));
//        try {
//            org.joda.time.Period period19 = period16.withFields((org.joda.time.ReadablePeriod) period18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = iSOChronology0.eras();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.millisOfSecond();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test233");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str7 = dateTimeZone5.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str11 = dateTimeZone9.getShortName((long) '4');
//        long long13 = dateTimeZone5.getMillisKeepLocal(dateTimeZone9, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone15 = iSOChronology14.getZone();
//        org.joda.time.Period period16 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period18 = period16.normalizedStandard(periodType17);
//        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) periodType17);
//        org.joda.time.JodaTimePermission jodaTimePermission21 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str27 = dateTimeZone25.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str31 = dateTimeZone29.getShortName((long) '4');
//        long long33 = dateTimeZone25.getMillisKeepLocal(dateTimeZone29, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone35 = iSOChronology34.getZone();
//        org.joda.time.Period period36 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology34);
//        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period38 = period36.normalizedStandard(periodType37);
//        boolean boolean39 = jodaTimePermission21.equals((java.lang.Object) periodType37);
//        boolean boolean40 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission21);
//        org.joda.time.JodaTimePermission jodaTimePermission42 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType44 = periodType43.withHoursRemoved();
//        jodaTimePermission42.checkGuard((java.lang.Object) periodType44);
//        boolean boolean46 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission42);
//        org.joda.time.JodaTimePermission jodaTimePermission48 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType50 = periodType49.withHoursRemoved();
//        jodaTimePermission48.checkGuard((java.lang.Object) periodType50);
//        org.joda.time.JodaTimePermission jodaTimePermission53 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean54 = jodaTimePermission48.implies((java.security.Permission) jodaTimePermission53);
//        org.joda.time.JodaTimePermission jodaTimePermission56 = new org.joda.time.JodaTimePermission("hi!");
//        java.security.PermissionCollection permissionCollection57 = jodaTimePermission56.newPermissionCollection();
//        org.joda.time.Period period59 = org.joda.time.Period.weeks((int) (byte) 100);
//        int int60 = period59.getWeeks();
//        org.joda.time.Weeks weeks61 = period59.toStandardWeeks();
//        boolean boolean62 = jodaTimePermission56.equals((java.lang.Object) weeks61);
//        boolean boolean64 = jodaTimePermission56.equals((java.lang.Object) 4);
//        boolean boolean65 = jodaTimePermission48.implies((java.security.Permission) jodaTimePermission56);
//        boolean boolean66 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission56);
//        java.lang.String str67 = jodaTimePermission1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(periodType43);
//        org.junit.Assert.assertNotNull(periodType44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNotNull(periodType49);
//        org.junit.Assert.assertNotNull(periodType50);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(permissionCollection57);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
//        org.junit.Assert.assertNotNull(weeks61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str67.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test234");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        java.util.Locale locale78 = null;
//        try {
//            java.lang.String str79 = unsupportedDateTimeField76.getAsShortText(1, locale78);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period7 = period5.withDays((int) ' ');
        org.joda.time.Period period9 = period7.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration11);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 63244800000L + "'", long14 == 63244800000L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(234L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 234 + "'", int1 == 234);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test237");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str3 = dateTimeZone1.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str7 = dateTimeZone5.getShortName((long) '4');
//        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, (long) 1);
//        int int11 = dateTimeZone1.getOffsetFromLocal(0L);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone1.getName(0L, locale13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology6 = lenientChronology5.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField11 = iSOChronology9.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.era();
        org.joda.time.DurationField durationField14 = iSOChronology9.days();
        boolean boolean15 = lenientChronology5.equals((java.lang.Object) durationField14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        boolean boolean19 = dateTimeZone17.isStandardOffset((long) (byte) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        int int22 = cachedDateTimeZone20.getOffset((long) (short) 10);
        int int24 = cachedDateTimeZone20.getStandardOffset((long) (byte) 100);
        int int26 = cachedDateTimeZone20.getOffset(4L);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.joda.time.Chronology chronology28 = lenientChronology5.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.joda.time.Period period30 = org.joda.time.Period.seconds(99);
        int[] intArray32 = lenientChronology5.get((org.joda.time.ReadablePeriod) period30, (-216733233600000L));
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period(obj3, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) -1, 10L, periodType2, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyearOfCentury();
        org.joda.time.DurationField durationField11 = gregorianChronology7.halfdays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        int int6 = fixedDateTimeZone4.getStandardOffset(0L);
        long long8 = fixedDateTimeZone4.previousTransition((-210866414400000L));
        org.joda.time.ReadableInstant readableInstant9 = null;
        int int10 = fixedDateTimeZone4.getOffset(readableInstant9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-210866414400000L) + "'", long8 == (-210866414400000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test241");
//        java.lang.Object obj0 = null;
//        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.Period period5 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.weekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.addWrapField(52L, (int) (byte) 1);
//        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) 10);
//        long long20 = offsetDateTimeField13.roundHalfFloor(134L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType21, 34, (int) (byte) 0, (int) (byte) 100);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
//        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
//        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
//        org.joda.time.PeriodType periodType31 = org.joda.time.DateTimeUtils.getPeriodType(periodType29);
//        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType33, (long) 2);
//        long long36 = preciseDurationField35.getUnitMillis();
//        long long39 = preciseDurationField35.getValueAsLong((long) (short) 100, 6134400000L);
//        long long42 = preciseDurationField35.getMillis((-10965067027200000L), (long) 52);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str49 = dateTimeZone47.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str53 = dateTimeZone51.getShortName((long) '4');
//        long long55 = dateTimeZone47.getMillisKeepLocal(dateTimeZone51, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone57 = iSOChronology56.getZone();
//        org.joda.time.Period period58 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.PeriodType periodType59 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period60 = period58.normalizedStandard(periodType59);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.clockhourOfHalfday();
//        org.joda.time.Period period65 = new org.joda.time.Period(2440588L, periodType59, (org.joda.time.Chronology) gregorianChronology63);
//        long long69 = gregorianChronology63.add((long) 1, (-1L), (int) (short) -1);
//        java.lang.String str70 = gregorianChronology63.toString();
//        org.joda.time.DurationField durationField71 = gregorianChronology63.days();
//        int int72 = preciseDurationField35.compareTo(durationField71);
//        long long75 = preciseDurationField35.getValueAsLong((-31622399L), 15811200000L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) preciseDurationField35);
//        boolean boolean77 = unsupportedDateTimeField76.isLenient();
//        org.joda.time.DurationField durationField78 = unsupportedDateTimeField76.getDurationField();
//        java.lang.String str79 = unsupportedDateTimeField76.getName();
//        int int82 = unsupportedDateTimeField76.getDifference(99L, 7200000L);
//        org.junit.Assert.assertNotNull(periodType1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3600052L + "'", long16 == 3600052L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(durationFieldType33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2L + "'", long36 == 2L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 50L + "'", long39 == 50L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-21930134054400000L) + "'", long42 == (-21930134054400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(periodType59);
//        org.junit.Assert.assertNotNull(period60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2L + "'", long69 == 2L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str70.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-15811199L) + "'", long75 == (-15811199L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "clockhourOfDay" + "'", str79.equals("clockhourOfDay"));
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-3599950) + "'", int82 == (-3599950));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        long long15 = offsetDateTimeField12.getDifferenceAsLong(2L, (-6134400000L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField12.getAsText((long) (byte) 100, locale17);
        java.lang.String str20 = offsetDateTimeField12.getAsText((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 2L, (java.lang.Number) (byte) 100, (java.lang.Number) 100000L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType21, (int) (short) 10, 2, (-97));
        org.joda.time.DateTimeField dateTimeField30 = offsetDateTimeField29.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        long long39 = offsetDateTimeField36.addWrapField(52L, (int) (byte) 1);
        int int41 = offsetDateTimeField36.getLeapAmount((long) (short) 10);
        long long43 = offsetDateTimeField36.roundHalfFloor(134L);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField36.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField30, dateTimeFieldType44, (int) (byte) 10);
        int int48 = dividedDateTimeField46.get((-62095507199911L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
        long long51 = remainderDateTimeField49.roundHalfCeiling(10L);
        long long54 = remainderDateTimeField49.addWrapField(40000L, 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1704L + "'", long15 == 1704L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "34" + "'", str18.equals("34"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3600052L + "'", long39 == 3600052L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 946684800000L + "'", long51 == 946684800000L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 40000L + "'", long54 == 40000L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]", (int) (byte) 10, (int) (byte) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-2L));
        int int9 = fixedDateTimeZone4.getStandardOffset((-210866414400000L));
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Period period13 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period15 = period13.withDays((int) ' ');
        org.joda.time.Period period17 = period15.minusMinutes((-1));
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationFrom(readableInstant18);
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        org.joda.time.Period period22 = period20.minusWeeks((-1));
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(0);
        boolean boolean27 = period15.isSupported(durationFieldType26);
        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) boolean27);
        boolean boolean29 = fixedDateTimeZone4.isFixed();
        java.lang.String str31 = fixedDateTimeZone4.getName(40L);
        java.util.TimeZone timeZone32 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.010" + "'", str31.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
        int int2 = period1.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) 100);
        org.joda.time.Period period8 = period6.minusYears((int) (short) 1);
        boolean boolean9 = iSOChronology3.equals((java.lang.Object) period6);
        org.joda.time.Period period10 = period1.minus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period12 = period1.plusDays((int) (short) 0);
        org.joda.time.Period period14 = period12.minusMillis(400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.lang.String str6 = lenientChronology5.toString();
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("97");
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("UTC", "");
        java.lang.String str12 = illegalFieldValueException11.getIllegalValueAsString();
        illegalInstantException8.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        boolean boolean14 = lenientChronology5.equals((java.lang.Object) illegalFieldValueException11);
        org.joda.time.Chronology chronology15 = lenientChronology5.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str6.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test247");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int6 = cachedDateTimeZone4.getOffset((long) (short) 10);
//        int int8 = cachedDateTimeZone4.getStandardOffset((long) (byte) 100);
//        int int10 = cachedDateTimeZone4.getOffsetFromLocal(2440588L);
//        int int12 = cachedDateTimeZone4.getStandardOffset((-60507817129998L));
//        long long15 = cachedDateTimeZone4.convertLocalToUTC(1560626482282L, true);
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = cachedDateTimeZone4.getOffset(readableInstant16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = cachedDateTimeZone4.getName((-210866673600000L), locale19);
//        int int22 = cachedDateTimeZone4.getStandardOffset((long) (byte) 0);
//        java.lang.String str24 = cachedDateTimeZone4.getNameKey(48L);
//        int int26 = cachedDateTimeZone4.getStandardOffset(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560626482282L + "'", long15 == 1560626482282L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("UTC", "");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.Number number13 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str14 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for  must be in the range [1,100]"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', chronology3);
        org.joda.time.Period period6 = period4.plusMinutes(0);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.Period period9 = period7.multipliedBy((-97));
        org.joda.time.Period period11 = period7.minusYears(0);
        int int12 = period7.getDays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test250");
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str6 = dateTimeZone4.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone8, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology13.getZone();
//        org.joda.time.Period period15 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period17 = period15.normalizedStandard(periodType16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.clockhourOfHalfday();
//        org.joda.time.Period period22 = new org.joda.time.Period(2440588L, periodType16, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField23 = gregorianChronology20.hours();
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period4 = period3.normalizedStandard();
        org.joda.time.Period period6 = period4.withSeconds(97);
        int int7 = period4.size();
        org.joda.time.Period period9 = period4.withDays((int) (short) 0);
        org.joda.time.Period period11 = period9.plusHours(56);
        org.joda.time.Period period13 = period11.withMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test252");
//        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str10 = dateTimeZone8.getShortName((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
//        java.lang.String str14 = dateTimeZone12.getShortName((long) '4');
//        long long16 = dateTimeZone8.getMillisKeepLocal(dateTimeZone12, (long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology17.getZone();
//        org.joda.time.Period period19 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.minutes();
//        org.joda.time.Period period21 = period19.normalizedStandard(periodType20);
//        boolean boolean22 = jodaTimePermission4.equals((java.lang.Object) periodType20);
//        org.joda.time.PeriodType periodType23 = periodType20.withDaysRemoved();
//        org.joda.time.PeriodType periodType24 = periodType20.withMillisRemoved();
//        org.joda.time.Period period25 = new org.joda.time.Period(2440588L, (long) 40, periodType24);
//        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.hourOfHalfday();
//        long long33 = iSOChronology28.add((long) '4', (long) (byte) 10, 0);
//        org.joda.time.Period period34 = new org.joda.time.Period((long) ' ', periodType27, (org.joda.time.Chronology) iSOChronology28);
//        boolean boolean35 = periodType24.equals((java.lang.Object) iSOChronology28);
//        org.joda.time.Period period36 = new org.joda.time.Period(0L, (org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.Chronology chronology37 = iSOChronology28.withUTC();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology28.era();
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(periodType23);
//        org.junit.Assert.assertNotNull(periodType24);
//        org.junit.Assert.assertNotNull(periodType27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//    }
//}

