import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTwoDigitYear(73376);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder23.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder12.append(dateTimePrinter24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder30.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder30.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatterBuilder37.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser40 = dateTimeFormatter39.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder26.append(dateTimePrinter38, dateTimeParser40);
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatterBuilder41.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder9.append(dateTimePrinter24, dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimePrinter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeParser40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 19);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getShortName((long) (byte) 10, locale9);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19L + "'", long6 == 19L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:01:13.331" + "'", str10.equals("+00:01:13.331"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "---15");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("--06-15", (java.lang.Number) (byte) 0, (java.lang.Number) (short) 100, (java.lang.Number) 28800100L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 28800100L + "'", number5.equals(28800100L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 28800100L + "'", number6.equals(28800100L));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMinutes(1222);
//        org.joda.time.DateTime dateTime28 = dateTime26.plusMillis(73333);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now(dateTimeZone31);
//        int int33 = monthDay30.compareTo((org.joda.time.ReadablePartial) monthDay32);
//        org.joda.time.Instant instant34 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant35 = instant34.toInstant();
//        org.joda.time.DateTime dateTime36 = monthDay30.toDateTime((org.joda.time.ReadableInstant) instant34);
//        org.joda.time.DateTime.Property property37 = dateTime36.dayOfYear();
//        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime40 = dateTime38.minusWeeks(0);
//        int int41 = dateTime40.getHourOfDay();
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime40);
//        boolean boolean43 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime.Property property44 = dateTime40.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73418 + "'", int18 == 73418);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(instant34);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(property44);
//    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long5 = offsetDateTimeField3.roundHalfEven((long) 1969);
//        long long8 = offsetDateTimeField3.addWrapField(19L, 0);
//        long long10 = offsetDateTimeField3.roundFloor((long) 5);
//        int int12 = offsetDateTimeField3.getMinimumValue((long) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-73331L) + "'", long5 == (-73331L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19L + "'", long8 == 19L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-73331L) + "'", long10 == (-73331L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 73330 + "'", int12 == 73330);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        boolean boolean9 = dateTime7.isBefore((long) 15);
//        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
//        boolean boolean11 = dateTime10.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant1 = instant0.toInstant();
//        java.lang.String str2 = instant1.toString();
//        org.joda.time.Instant instant4 = instant1.withMillis((long) 2809);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T20:23:39.133Z" + "'", str2.equals("2019-06-15T20:23:39.133Z"));
//        org.junit.Assert.assertNotNull(instant4);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay.Property property1 = monthDay0.dayOfMonth();
        int int2 = property1.getMinimumValue();
        org.joda.time.DurationField durationField3 = property1.getDurationField();
        long long6 = durationField3.subtract(0L, 73391);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-6340982400000L) + "'", long6 == (-6340982400000L));
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        long long6 = dateTimeZone2.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay monthDay9 = monthDay7.plusMonths((int) (short) 10);
//        long long11 = iSOChronology0.set((org.joda.time.ReadablePartial) monthDay9, 28800100L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 73330);
//        long long18 = offsetDateTimeField15.add((long) (short) 10, 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) offsetDateTimeField15, (int) (byte) 10);
//        org.joda.time.DurationField durationField21 = iSOChronology0.weeks();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-73231L) + "'", long6 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9014400100L + "'", long11 == 9014400100L);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 360000010L + "'", long18 == 360000010L);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test14");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long5 = offsetDateTimeField3.roundHalfEven((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay7.getFieldType(1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText(0, locale15);
//        long long18 = delegatedDateTimeField13.roundCeiling((long) 2);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-73331L) + "'", long5 == (-73331L));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3526669L + "'", long18 == 3526669L);
//    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test15");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant12 = instant11.toInstant();
//        org.joda.time.DateTime dateTime13 = monthDay7.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfFloorCopy();
//        int int16 = dateTime15.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology5, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime17);
//        org.joda.time.Instant instant19 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField20 = gJChronology5.minutes();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay.Property property1 = monthDay0.dayOfMonth();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = property1.getAsText(locale2);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "15" + "'", str3.equals("15"));
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long6 = offsetDateTimeField3.add((long) (short) 10, 100);
//        int int8 = offsetDateTimeField3.getMinimumValue((long) (short) 100);
//        int int9 = offsetDateTimeField3.getMaximumValue();
//        long long11 = offsetDateTimeField3.roundFloor(4647600000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 360000010L + "'", long6 == 360000010L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 73330 + "'", int8 == 73330);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 73341 + "'", int9 == 73341);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4647526669L + "'", long11 == 4647526669L);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = dateTime0.withDurationAdded(10L, 73330);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
//        int int5 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
        long long6 = offsetDateTimeField3.add(1560630129480L, (int) (short) 10);
        boolean boolean8 = offsetDateTimeField3.isLeap((long) (-1));
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField3.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType10, 73341, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 73341 for hourOfHalfday must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560666129480L + "'", long6 == 1560666129480L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsShortText(locale9);
//        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
//        int int12 = property8.getMinimumValue();
//        org.joda.time.DateTime dateTime14 = property8.addToCopy(62);
//        org.joda.time.DurationField durationField15 = property8.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "166" + "'", str10.equals("166"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        boolean boolean9 = property8.isLeap();
//        org.joda.time.DateTime dateTime10 = property8.roundCeilingCopy();
//        org.joda.time.Interval interval11 = property8.toInterval();
//        java.lang.String str12 = property8.getAsText();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "166" + "'", str12.equals("166"));
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 73330);
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField4, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipDateTimeField8.getAsShortText(16, locale10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "16" + "'", str11.equals("16"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long8 = fixedDateTimeZone6.nextTransition((long) 19);
        java.lang.String str10 = fixedDateTimeZone6.getShortName((long) (byte) 1);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19L + "'", long8 == 19L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:01:13.331" + "'", str10.equals("+00:01:13.331"));
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 73330);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField4, (int) ' ');
//        long long11 = skipDateTimeField8.getDifferenceAsLong((long) 100, (long) 1969);
//        int int13 = skipDateTimeField8.getMaximumValue((long) 73330);
//        long long15 = skipDateTimeField8.roundHalfEven(1560630129480L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560628726669L + "'", long15 == 1560628726669L);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long7 = fixedDateTimeZone4.adjustOffset((long) (short) 10, true);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = julianChronology8.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]" + "'", str9.equals("JulianChronology[org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]"));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
        long long6 = offsetDateTimeField3.add((long) (short) 10, 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
        org.joda.time.MonthDay monthDay10 = monthDay8.plusDays(0);
        int int11 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay8.minus(readablePeriod12);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay8.getFields();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 360000010L + "'", long6 == 360000010L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 73341 + "'", int11 == 73341);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-15T20:22:50.291Z", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.joda.time.Instant instant2 = instant0.toInstant();
        org.joda.time.Instant instant4 = instant2.plus(1055951926670L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test31");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant12 = instant11.toInstant();
//        org.joda.time.DateTime dateTime13 = monthDay7.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfFloorCopy();
//        int int16 = dateTime15.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology5, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime17);
//        boolean boolean20 = dateTime15.isBefore((long) 73415);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime0.withDurationAdded(10L, 73330);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        boolean boolean9 = property8.isLeap();
        org.joda.time.DateTime dateTime10 = property8.roundCeilingCopy();
        int int11 = property8.getMaximumValue();
        org.joda.time.DateTime dateTime12 = property8.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long7 = fixedDateTimeZone4.adjustOffset((long) (short) 10, true);
        int int9 = fixedDateTimeZone4.getOffset((long) 1178);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 73331 + "'", int9 == 73331);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        java.lang.String str25 = dateTime24.toString();
//        org.joda.time.DateTime.Property property26 = dateTime24.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73420 + "'", int18 == 73420);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-06-15T20:23:40.432Z" + "'", str25.equals("2019-06-15T20:23:40.432Z"));
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime7.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long6 = offsetDateTimeField3.add((long) (short) 10, 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        int int11 = monthDay8.compareTo((org.joda.time.ReadablePartial) monthDay10);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant13 = instant12.toInstant();
//        org.joda.time.DateTime dateTime14 = monthDay8.toDateTime((org.joda.time.ReadableInstant) instant12);
//        boolean boolean16 = monthDay8.equals((java.lang.Object) 0);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay8, 31, locale18);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay21, (int) (short) 10, locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        int int28 = monthDay21.indexOf(dateTimeFieldType27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone29);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology34);
//        boolean boolean36 = monthDay21.isAfter((org.joda.time.ReadablePartial) monthDay35);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 360000010L + "'", long6 == 360000010L);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-73231L) + "'", long33 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test40");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(dateTimeZone3);
//        int int5 = monthDay2.compareTo((org.joda.time.ReadablePartial) monthDay4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay2.getFieldType(1);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = monthDay2.getFieldTypes();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay10.getFields();
//        boolean boolean12 = monthDay2.equals((java.lang.Object) dateTimeFieldArray11);
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone16);
//        int int18 = monthDay15.compareTo((org.joda.time.ReadablePartial) monthDay17);
//        org.joda.time.Instant instant19 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant20 = instant19.toInstant();
//        org.joda.time.DateTime dateTime21 = monthDay15.toDateTime((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        int int23 = dateTime21.getMinuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 73330);
//        long long30 = offsetDateTimeField27.add((long) (short) 10, 100);
//        int int32 = offsetDateTimeField27.getMinimumValue((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now(dateTimeZone35);
//        int int37 = monthDay34.compareTo((org.joda.time.ReadablePartial) monthDay36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay34.getFieldType(1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField27, dateTimeFieldType39, 1178);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now(dateTimeZone44);
//        int int46 = monthDay43.compareTo((org.joda.time.ReadablePartial) monthDay45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = monthDay43.getFieldType(1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField50 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField41, dateTimeFieldType48, (int) (byte) 10);
//        int int51 = dateTime21.get(dateTimeFieldType48);
//        org.joda.time.MonthDay monthDay53 = monthDay2.withField(dateTimeFieldType48, 3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Jun 15, ����" + "'", str13.equals("Jun 15, ����"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1223 + "'", int23 == 1223);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 360000010L + "'", long30 == 360000010L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 73330 + "'", int32 == 73330);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertNotNull(monthDay53);
//    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone15);
        int int17 = monthDay14.compareTo((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay14.getFieldType(1);
        java.lang.Number number20 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, number20, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder11.appendFixedDecimal(dateTimeFieldType19, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType19, 2019, 57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendClockhourOfDay(73416);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test43");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsShortText(locale9);
//        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra(73370);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "166" + "'", str10.equals("166"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test44");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes(73338);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendWeekyear((int) (byte) 0, 19);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        int int21 = monthDay18.compareTo((org.joda.time.ReadablePartial) monthDay20);
//        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant23 = instant22.toInstant();
//        org.joda.time.DateTime dateTime24 = monthDay18.toDateTime((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfYear();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        int int28 = dateTime26.getMinuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now(dateTimeZone31);
//        int int33 = monthDay30.compareTo((org.joda.time.ReadablePartial) monthDay32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = monthDay30.getFieldType(1);
//        java.lang.Number number36 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, number36, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 100);
//        int int40 = dateTime26.get(dateTimeFieldType35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType35);
//        int int42 = dateTime9.get(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(instant23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 16 + "'", int40 == 16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
//    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long8 = fixedDateTimeZone6.nextTransition((long) 19);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean11 = fixedDateTimeZone6.isStandardOffset((long) 53);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        java.lang.String str14 = zonedChronology12.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19L + "'", long8 == 19L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]"));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYear((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder7.append(dateTimePrinter19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder1.append(dateTimePrinter19, dateTimeParserArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder25.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatterBuilder32.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder34.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder34.append(dateTimeParser42);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray46 = new org.joda.time.format.DateTimeParser[] { dateTimeParser42, dateTimeParser45 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder1.append(dateTimePrinter33, dateTimeParserArray46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder47.appendClockhourOfHalfday(73332);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeParserArray46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsShortText(locale9);
//        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
//        int int12 = property8.getMinimumValue();
//        org.joda.time.DateTime dateTime14 = property8.addToCopy(62);
//        long long15 = property8.remainder();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "166" + "'", str10.equals("166"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 73422541L + "'", long15 == 73422541L);
//    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test48");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long8 = fixedDateTimeZone6.nextTransition((long) 19);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        boolean boolean11 = fixedDateTimeZone6.isStandardOffset((long) 53);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone13);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone21);
//        int int23 = monthDay20.compareTo((org.joda.time.ReadablePartial) monthDay22);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant25 = instant24.toInstant();
//        org.joda.time.DateTime dateTime26 = monthDay20.toDateTime((org.joda.time.ReadableInstant) instant24);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        org.joda.time.DateTime dateTime28 = property27.roundHalfFloorCopy();
//        int int29 = dateTime28.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime30 = null;
//        org.joda.time.chrono.LimitChronology limitChronology31 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology18, (org.joda.time.ReadableDateTime) dateTime28, readableDateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now(dateTimeZone32);
//        long long36 = dateTimeZone32.convertLocalToUTC((long) 100, true);
//        org.joda.time.Chronology chronology37 = gJChronology18.withZone(dateTimeZone32);
//        org.joda.time.Chronology chronology38 = zonedChronology12.withZone(dateTimeZone32);
//        java.lang.String str39 = zonedChronology12.toString();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now(dateTimeZone41);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now(dateTimeZone43);
//        int int45 = monthDay42.compareTo((org.joda.time.ReadablePartial) monthDay44);
//        org.joda.time.Instant instant46 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant47 = instant46.toInstant();
//        org.joda.time.DateTime dateTime48 = monthDay42.toDateTime((org.joda.time.ReadableInstant) instant46);
//        org.joda.time.DateTime.Property property49 = dateTime48.dayOfYear();
//        int int50 = dateTime48.getSecondOfDay();
//        org.joda.time.chrono.LimitChronology limitChronology51 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) zonedChronology12, (org.joda.time.ReadableDateTime) dateTime40, (org.joda.time.ReadableDateTime) dateTime48);
//        org.joda.time.DateTime dateTime53 = dateTime40.plusMonths(73364);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19L + "'", long8 == 19L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-73231L) + "'", long17 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(limitChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-73231L) + "'", long36 == (-73231L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]" + "'", str39.equals("ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]"));
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(monthDay44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(instant46);
//        org.junit.Assert.assertNotNull(instant47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 73422 + "'", int50 == 73422);
//        org.junit.Assert.assertNotNull(limitChronology51);
//        org.junit.Assert.assertNotNull(dateTime53);
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear((int) (short) 0, 57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendMinuteOfDay(53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.appendTimeZoneOffset("GregorianChronology[UTC]", "", true, 73330, 73468220);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 19);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 73330);
        long long14 = offsetDateTimeField11.add((long) (short) 10, 100);
        int int16 = offsetDateTimeField11.getMinimumValue((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
        int int21 = monthDay18.compareTo((org.joda.time.ReadablePartial) monthDay20);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay18.getFieldType(1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType23, 1178);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now(dateTimeZone28);
        int int30 = monthDay27.compareTo((org.joda.time.ReadablePartial) monthDay29);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = monthDay27.getFieldType(1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField25, dateTimeFieldType32, (int) (byte) 10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeField) remainderDateTimeField25, (int) 'a');
        org.joda.time.ReadablePartial readablePartial37 = null;
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = remainderDateTimeField25.getAsText(readablePartial37, locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19L + "'", long6 == 19L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 360000010L + "'", long14 == 360000010L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 73330 + "'", int16 == 73330);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant12 = instant11.toInstant();
//        org.joda.time.DateTime dateTime13 = monthDay7.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfFloorCopy();
//        int int16 = dateTime15.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology5, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        long long23 = dateTimeZone19.convertLocalToUTC((long) 100, true);
//        org.joda.time.Chronology chronology24 = gJChronology5.withZone(dateTimeZone19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long31 = fixedDateTimeZone29.nextTransition((long) 19);
//        org.joda.time.Chronology chronology32 = gJChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        long long34 = fixedDateTimeZone29.previousTransition((long) 1222);
//        org.joda.time.ReadableInstant readableInstant35 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone29, readableInstant35);
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-73231L) + "'", long23 == (-73231L));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19L + "'", long31 == 19L);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1222L + "'", long34 == 1222L);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay1.getFieldType(1);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 73330);
//        long long12 = offsetDateTimeField10.roundHalfEven((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone15);
//        int int17 = monthDay14.compareTo((org.joda.time.ReadablePartial) monthDay16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay14.getFieldType(1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType19);
//        int int21 = monthDay1.indexOf(dateTimeFieldType19);
//        org.joda.time.MonthDay monthDay23 = monthDay1.minusDays(73421);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-73331L) + "'", long12 == (-73331L));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(monthDay23);
//    }

//    @Test
//    public void test53() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test53");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant1 = instant0.toInstant();
//        java.lang.String str2 = instant0.toString();
//        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T20:23:43.615Z" + "'", str2.equals("2019-06-15T20:23:43.615Z"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long8 = fixedDateTimeZone6.nextTransition((long) 19);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        boolean boolean11 = fixedDateTimeZone6.isStandardOffset((long) 53);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone13);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone21);
//        int int23 = monthDay20.compareTo((org.joda.time.ReadablePartial) monthDay22);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant25 = instant24.toInstant();
//        org.joda.time.DateTime dateTime26 = monthDay20.toDateTime((org.joda.time.ReadableInstant) instant24);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        org.joda.time.DateTime dateTime28 = property27.roundHalfFloorCopy();
//        int int29 = dateTime28.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime30 = null;
//        org.joda.time.chrono.LimitChronology limitChronology31 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology18, (org.joda.time.ReadableDateTime) dateTime28, readableDateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now(dateTimeZone32);
//        long long36 = dateTimeZone32.convertLocalToUTC((long) 100, true);
//        org.joda.time.Chronology chronology37 = gJChronology18.withZone(dateTimeZone32);
//        org.joda.time.Chronology chronology38 = zonedChronology12.withZone(dateTimeZone32);
//        java.lang.String str39 = zonedChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone40 = zonedChronology12.getZone();
//        java.lang.String str41 = zonedChronology12.toString();
//        org.joda.time.Chronology chronology42 = zonedChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField43 = zonedChronology12.hourOfHalfday();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19L + "'", long8 == 19L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-73231L) + "'", long17 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(limitChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-73231L) + "'", long36 == (-73231L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]" + "'", str39.equals("ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]"));
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]" + "'", str41.equals("ZonedChronology[ISOChronology[UTC], org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]]"));
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test55");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone12);
//        int int14 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.Instant instant15 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant16 = instant15.toInstant();
//        org.joda.time.DateTime dateTime17 = monthDay11.toDateTime((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone21);
//        int int23 = monthDay20.compareTo((org.joda.time.ReadablePartial) monthDay22);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant25 = instant24.toInstant();
//        org.joda.time.DateTime dateTime26 = monthDay20.toDateTime((org.joda.time.ReadableInstant) instant24);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        int int28 = dateTime26.getSecondOfDay();
//        int int29 = property18.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone30);
//        org.joda.time.MonthDay monthDay33 = monthDay31.plusDays(0);
//        org.joda.time.DateTime dateTime34 = dateTime26.withFields((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTime dateTime36 = dateTime34.plusMinutes(1222);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime38 = dateTime34.toDateTime((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTime dateTime39 = dateTime9.toDateTime((org.joda.time.Chronology) iSOChronology37);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now(dateTimeZone40);
//        org.joda.time.MonthDay monthDay43 = monthDay41.plusDays(0);
//        java.lang.String str44 = monthDay41.toString();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone47);
//        int int49 = monthDay46.compareTo((org.joda.time.ReadablePartial) monthDay48);
//        int int50 = monthDay41.compareTo((org.joda.time.ReadablePartial) monthDay46);
//        long long52 = iSOChronology37.set((org.joda.time.ReadablePartial) monthDay41, (-1L));
//        java.lang.Object obj53 = null;
//        boolean boolean54 = iSOChronology37.equals(obj53);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 73424 + "'", int28 == 73424);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "--06-15" + "'", str44.equals("--06-15"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-17193600001L) + "'", long52 == (-17193600001L));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test56");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
//        long long4 = instant1.getMillis();
//        org.joda.time.Instant instant7 = instant1.withDurationAdded((long) 10, (int) (short) 10);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.MonthDay monthDay12 = monthDay10.plusDays(0);
//        java.lang.String str13 = monthDay10.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone16);
//        int int18 = monthDay15.compareTo((org.joda.time.ReadablePartial) monthDay17);
//        int int19 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay15);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone22);
//        int int24 = monthDay21.compareTo((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.Instant instant25 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant26 = instant25.toInstant();
//        org.joda.time.DateTime dateTime27 = monthDay21.toDateTime((org.joda.time.ReadableInstant) instant25);
//        org.joda.time.DateTime.Property property28 = dateTime27.dayOfYear();
//        org.joda.time.DateTime dateTime29 = property28.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime30 = monthDay10.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        boolean boolean31 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560630224330L + "'", long4 == 1560630224330L);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15T20" + "'", str8.equals("2019-06-15T20"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "--06-15" + "'", str13.equals("--06-15"));
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(instant26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test57() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test57");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long6 = fixedDateTimeZone4.nextTransition((long) 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(dateTimeZone10);
//        int int12 = monthDay9.compareTo((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = monthDay9.getFieldType(1);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray15 = monthDay9.getFieldTypes();
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.minutes();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone18);
//        long long22 = dateTimeZone18.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone18);
//        org.joda.time.MonthDay monthDay25 = monthDay23.plusMonths((int) (short) 10);
//        long long27 = iSOChronology16.set((org.joda.time.ReadablePartial) monthDay25, 28800100L);
//        int[] intArray28 = monthDay25.getValues();
//        gregorianChronology7.validate((org.joda.time.ReadablePartial) monthDay9, intArray28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology7.weekyearOfCentury();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19L + "'", long6 == 19L);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-73231L) + "'", long22 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9014400100L + "'", long27 == 9014400100L);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        long long6 = dateTimeZone2.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay monthDay9 = monthDay7.plusMonths((int) (short) 10);
//        long long11 = iSOChronology0.set((org.joda.time.ReadablePartial) monthDay9, 28800100L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 73330);
//        long long18 = offsetDateTimeField15.add((long) (short) 10, 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) offsetDateTimeField15, (int) (byte) 10);
//        long long23 = skipUndoDateTimeField20.addWrapField((long) (byte) -1, 100);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = skipUndoDateTimeField20.getAsShortText((long) '#', locale25);
//        int int28 = skipUndoDateTimeField20.getMinimumValue((long) (-1));
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 73330);
//        long long35 = offsetDateTimeField32.add((long) (short) 10, 100);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now(dateTimeZone36);
//        org.joda.time.MonthDay monthDay39 = monthDay37.plusDays(0);
//        int int40 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay37);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.MonthDay monthDay42 = monthDay37.minus(readablePeriod41);
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField45 = iSOChronology44.minutes();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now(dateTimeZone46);
//        long long50 = dateTimeZone46.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now(dateTimeZone46);
//        org.joda.time.MonthDay monthDay53 = monthDay51.plusMonths((int) (short) 10);
//        long long55 = iSOChronology44.set((org.joda.time.ReadablePartial) monthDay53, 28800100L);
//        int[] intArray56 = monthDay53.getValues();
//        try {
//            int[] intArray58 = skipUndoDateTimeField20.set((org.joda.time.ReadablePartial) monthDay42, 73416, intArray56, 73413);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 73413 for hourOfHalfday must be in the range [73330,73341]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-73231L) + "'", long6 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9014400100L + "'", long11 == 9014400100L);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 360000010L + "'", long18 == 360000010L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 14399999L + "'", long23 == 14399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "73330" + "'", str26.equals("73330"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 73330 + "'", int28 == 73330);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 360000010L + "'", long35 == 360000010L);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 73341 + "'", int40 == 73341);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(monthDay47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-73231L) + "'", long50 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9014400100L + "'", long55 == 9014400100L);
//        org.junit.Assert.assertNotNull(intArray56);
//    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test59");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.minutes();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(dateTimeZone3);
//        long long7 = dateTimeZone3.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone3);
//        org.joda.time.MonthDay monthDay10 = monthDay8.plusMonths((int) (short) 10);
//        long long12 = iSOChronology1.set((org.joda.time.ReadablePartial) monthDay10, 28800100L);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 73373, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.Instant instant14 = dateTime13.toInstant();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-73231L) + "'", long7 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9014400100L + "'", long12 == 9014400100L);
//        org.junit.Assert.assertNotNull(instant14);
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
        long long6 = offsetDateTimeField3.add((long) (short) 10, 100);
        int int8 = offsetDateTimeField3.getMinimumValue((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = monthDay10.getFieldType(1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType15, 1178);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
        int int22 = monthDay19.compareTo((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = monthDay19.getFieldType(1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType24, (int) (byte) 10);
        java.util.Locale locale27 = null;
        int int28 = remainderDateTimeField26.getMaximumShortTextLength(locale27);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 360000010L + "'", long6 == 360000010L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 73330 + "'", int8 == 73330);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

//    @Test
//    public void test61() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test61");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long5 = offsetDateTimeField3.roundHalfEven((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = monthDay7.getFieldType(1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType12);
//        java.lang.String str15 = delegatedDateTimeField13.getAsText((long) (byte) 10);
//        java.lang.String str16 = delegatedDateTimeField13.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-73331L) + "'", long5 == (-73331L));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "73330" + "'", str15.equals("73330"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
//    }

//    @Test
//    public void test62() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test62");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime28 = property25.addToCopy((long) 73364);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73424 + "'", int18 == 73424);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969-12-31T16", (java.lang.Number) 4, (java.lang.Number) 4647526669L, (java.lang.Number) 1560630181898L);
    }

//    @Test
//    public void test64() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test64");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long7 = fixedDateTimeZone4.adjustOffset((long) (short) 10, true);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 73330);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField14, (int) ' ');
//        long long21 = skipDateTimeField18.getDifferenceAsLong((long) 100, (long) 1969);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, (org.joda.time.DateTimeField) skipDateTimeField18);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now(dateTimeZone25);
//        int int27 = monthDay24.compareTo((org.joda.time.ReadablePartial) monthDay26);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay24.getFieldType(1);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 73330);
//        long long35 = offsetDateTimeField33.roundHalfEven((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now(dateTimeZone38);
//        int int40 = monthDay37.compareTo((org.joda.time.ReadablePartial) monthDay39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = monthDay37.getFieldType(1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33, dateTimeFieldType42);
//        int int44 = monthDay24.indexOf(dateTimeFieldType42);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType42, 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType47, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-73331L) + "'", long35 == (-73331L));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour(0, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test66() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test66");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant12 = instant11.toInstant();
//        org.joda.time.DateTime dateTime13 = monthDay7.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfFloorCopy();
//        int int16 = dateTime15.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology5, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone21);
//        int int23 = monthDay20.compareTo((org.joda.time.ReadablePartial) monthDay22);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant25 = instant24.toInstant();
//        org.joda.time.DateTime dateTime26 = monthDay20.toDateTime((org.joda.time.ReadableInstant) instant24);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone30);
//        int int32 = monthDay29.compareTo((org.joda.time.ReadablePartial) monthDay31);
//        org.joda.time.Instant instant33 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant34 = instant33.toInstant();
//        org.joda.time.DateTime dateTime35 = monthDay29.toDateTime((org.joda.time.ReadableInstant) instant33);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfYear();
//        int int37 = dateTime35.getSecondOfDay();
//        int int38 = property27.compareTo((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now(dateTimeZone39);
//        org.joda.time.MonthDay monthDay42 = monthDay40.plusDays(0);
//        org.joda.time.DateTime dateTime43 = dateTime35.withFields((org.joda.time.ReadablePartial) monthDay42);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusMinutes(1222);
//        int int46 = dateTime45.getCenturyOfEra();
//        boolean boolean47 = limitChronology18.equals((java.lang.Object) int46);
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.hourOfHalfday();
//        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 73330);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology48, dateTimeField52, (int) ' ');
//        long long59 = skipDateTimeField56.getDifferenceAsLong((long) 100, (long) 1969);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology18, (org.joda.time.DateTimeField) skipDateTimeField56, (-1));
//        long long64 = skipUndoDateTimeField61.add(1L, (int) '4');
//        int int65 = skipUndoDateTimeField61.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(instant33);
//        org.junit.Assert.assertNotNull(instant34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 73425 + "'", int37 == 73425);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 20 + "'", int46 == 20);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 187200001L + "'", long64 == 187200001L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        boolean boolean9 = property8.isLeap();
        org.joda.time.DateTime dateTime10 = property8.roundCeilingCopy();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.withPeriodAdded(readablePeriod12, 16);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYear((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear((int) (short) 0, 57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = monthDay10.getFieldType(1);
        java.lang.Number number16 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, number16, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType15, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType15, 73389, 73420);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("����0615T������.000", 13, 73416, 365, '4', 73397, 0, 73380, false, 11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("2019-06-15T20:22:45.048Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T20:22:45.048Z\" is malformed at \":45.048Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withEra((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test73() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test73");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay monthDay3 = monthDay1.plusDays(0);
//        java.lang.String str4 = monthDay1.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
//        int int9 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        int int10 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone13);
//        int int15 = monthDay12.compareTo((org.joda.time.ReadablePartial) monthDay14);
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant17 = instant16.toInstant();
//        org.joda.time.DateTime dateTime18 = monthDay12.toDateTime((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.DateTime.Property property19 = dateTime18.dayOfYear();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property19.getAsShortText(locale20);
//        org.joda.time.DateTime dateTime22 = property19.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime23 = property19.roundCeilingCopy();
//        boolean boolean24 = monthDay6.equals((java.lang.Object) dateTime23);
//        try {
//            int int26 = monthDay6.getValue(73425);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 73425");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "--06-15" + "'", str4.equals("--06-15"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "166" + "'", str21.equals("166"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getStandardOffset((long) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology8);
    }

//    @Test
//    public void test76() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test76");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
//        int int10 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant12 = instant11.toInstant();
//        org.joda.time.DateTime dateTime13 = monthDay7.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfFloorCopy();
//        int int16 = dateTime15.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology5, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 73330);
//        int int25 = offsetDateTimeField22.getDifference((long) 73331, (long) '#');
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) limitChronology18, (org.joda.time.DateTimeField) offsetDateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test77() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test77");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        int int6 = copticChronology5.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        int int11 = monthDay8.compareTo((org.joda.time.ReadablePartial) monthDay10);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant13 = instant12.toInstant();
//        org.joda.time.DateTime dateTime14 = monthDay8.toDateTime((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime14.withLaterOffsetAtOverlap();
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant18 = instant17.toInstant();
//        java.lang.String str19 = instant17.toString();
//        boolean boolean20 = dateTime16.isAfter((org.joda.time.ReadableInstant) instant17);
//        org.joda.time.DateTime dateTime22 = dateTime16.minus((long) 10);
//        org.joda.time.DateTime dateTime24 = dateTime16.minusDays((int) (byte) -1);
//        org.joda.time.DateTime.Property property25 = dateTime24.secondOfMinute();
//        org.joda.time.DateTime dateTime28 = dateTime24.withDurationAdded((long) (-1), 995);
//        org.joda.time.DateTime dateTime30 = dateTime24.plusWeeks(73386);
//        boolean boolean31 = copticChronology5.equals((java.lang.Object) dateTime24);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone34);
//        int int36 = monthDay33.compareTo((org.joda.time.ReadablePartial) monthDay35);
//        org.joda.time.Instant instant37 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant38 = instant37.toInstant();
//        org.joda.time.DateTime dateTime39 = monthDay33.toDateTime((org.joda.time.ReadableInstant) instant37);
//        org.joda.time.DateTime.Property property40 = dateTime39.dayOfYear();
//        java.lang.String str41 = property40.toString();
//        boolean boolean42 = copticChronology5.equals((java.lang.Object) str41);
//        try {
//            long long50 = copticChronology5.getDateTimeMillis((int) (short) 100, 73381, 2, 13, 1, (int) 'a', (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15T20:23:46.171Z" + "'", str19.equals("2019-06-15T20:23:46.171Z"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(instant38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Property[dayOfYear]" + "'", str41.equals("Property[dayOfYear]"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test78() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test78");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime28 = property25.setCopy("1223");
//        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73426 + "'", int18 == 73426);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks(0);
        int int12 = dateTime11.getHourOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime11.toMutableDateTime();
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(53);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test80() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test80");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = offsetDateTimeField3.getAsShortText(0L, locale6);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "73330" + "'", str7.equals("73330"));
//    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test82() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test82");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((long) 1);
//        java.lang.String str3 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 73332L + "'", long2 == 73332L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]"));
//    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test83");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
//        int int9 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant11 = instant10.toInstant();
//        org.joda.time.DateTime dateTime12 = monthDay6.toDateTime((org.joda.time.ReadableInstant) instant10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfYear();
//        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
//        org.joda.time.Instant instant15 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant16 = instant15.toInstant();
//        java.lang.String str17 = instant15.toString();
//        boolean boolean18 = dateTime14.isAfter((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) instant15);
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.Chronology chronology21 = julianChronology20.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-06-15T20:23:46.660Z" + "'", str17.equals("2019-06-15T20:23:46.660Z"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//    }

//    @Test
//    public void test84() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test84");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone7);
//        int int9 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant11 = instant10.toInstant();
//        org.joda.time.DateTime dateTime12 = monthDay6.toDateTime((org.joda.time.ReadableInstant) instant10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfYear();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
//        int int16 = dateTime14.getMinuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone19);
//        int int21 = monthDay18.compareTo((org.joda.time.ReadablePartial) monthDay20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay18.getFieldType(1);
//        java.lang.Number number24 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, number24, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 100);
//        int int28 = dateTime14.get(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendFractionOfMinute(8, 73392);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//    }

//    @Test
//    public void test85() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test85");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusMonths((int) (short) 10);
//        org.joda.time.MonthDay.Property property8 = monthDay5.dayOfMonth();
//        int int9 = property8.get();
//        int int10 = property8.getMinimumValueOverall();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 73330);
//        long long17 = offsetDateTimeField14.add(1560630129480L, (int) (short) 10);
//        boolean boolean19 = offsetDateTimeField14.isLeap((long) (-1));
//        org.joda.time.DurationField durationField20 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay.Property property22 = monthDay21.dayOfMonth();
//        int[] intArray24 = new int[] {};
//        int[] intArray26 = offsetDateTimeField14.add((org.joda.time.ReadablePartial) monthDay21, 19, intArray24, (int) (short) 0);
//        int int27 = property8.compareTo((org.joda.time.ReadablePartial) monthDay21);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560666129480L + "'", long17 == 1560666129480L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

//    @Test
//    public void test86() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test86");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 73330);
//        long long6 = offsetDateTimeField3.add((long) (short) 10, 100);
//        int int8 = offsetDateTimeField3.getMinimumValue((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = monthDay10.getFieldType(1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType15, 1178);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        int int22 = monthDay19.compareTo((org.joda.time.ReadablePartial) monthDay21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = monthDay19.getFieldType(1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType24, (int) (byte) 10);
//        long long28 = remainderDateTimeField26.roundCeiling((long) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = remainderDateTimeField26.getType();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 360000010L + "'", long6 == 360000010L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 73330 + "'", int8 == 73330);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3526669L + "'", long28 == 3526669L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

//    @Test
//    public void test87() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test87");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 100, true);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-73231L) + "'", long4 == (-73231L));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//    }

//    @Test
//    public void test88() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test88");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMinutes(1222);
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime28 = dateTime24.toDateTime((org.joda.time.Chronology) iSOChronology27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology27.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73427 + "'", int18 == 73427);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

//    @Test
//    public void test89() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test89");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        int int4 = monthDay1.compareTo((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant6 = instant5.toInstant();
//        org.joda.time.DateTime dateTime7 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone11);
//        int int13 = monthDay10.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant15 = instant14.toInstant();
//        org.joda.time.DateTime dateTime16 = monthDay10.toDateTime((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        int int18 = dateTime16.getSecondOfDay();
//        int int19 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        org.joda.time.DateTime dateTime24 = dateTime16.withFields((org.joda.time.ReadablePartial) monthDay23);
//        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
//        java.lang.String str26 = property25.getAsShortText();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone29);
//        int int31 = monthDay28.compareTo((org.joda.time.ReadablePartial) monthDay30);
//        org.joda.time.Instant instant32 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant33 = instant32.toInstant();
//        org.joda.time.DateTime dateTime34 = monthDay28.toDateTime((org.joda.time.ReadableInstant) instant32);
//        org.joda.time.DateTime.Property property35 = dateTime34.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now(dateTimeZone38);
//        int int40 = monthDay37.compareTo((org.joda.time.ReadablePartial) monthDay39);
//        org.joda.time.Instant instant41 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant42 = instant41.toInstant();
//        org.joda.time.DateTime dateTime43 = monthDay37.toDateTime((org.joda.time.ReadableInstant) instant41);
//        org.joda.time.DateTime.Property property44 = dateTime43.dayOfYear();
//        int int45 = dateTime43.getSecondOfDay();
//        int int46 = property35.compareTo((org.joda.time.ReadableInstant) dateTime43);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone47);
//        org.joda.time.MonthDay monthDay50 = monthDay48.plusDays(0);
//        org.joda.time.DateTime dateTime51 = dateTime43.withFields((org.joda.time.ReadablePartial) monthDay50);
//        java.lang.String str52 = dateTime51.toString();
//        org.joda.time.DateTime dateTime54 = dateTime51.withMillisOfSecond(10);
//        int int55 = property25.compareTo((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime54.isEqualNow();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", "org.joda.time.IllegalFieldValueException: Value 0 for --06-15 must be in the range [100,28800100]", 73331, 0);
//        long long63 = fixedDateTimeZone61.nextTransition((long) 19);
//        org.joda.time.DateTime dateTime64 = dateTime54.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 73427 + "'", int18 == 73427);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "73427385" + "'", str26.equals("73427385"));
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(instant32);
//        org.junit.Assert.assertNotNull(instant33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(instant41);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 73427 + "'", int45 == 73427);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019-06-15T20:23:47.390Z" + "'", str52.equals("2019-06-15T20:23:47.390Z"));
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 19L + "'", long63 == 19L);
//        org.junit.Assert.assertNotNull(dateTime64);
//    }
//}

